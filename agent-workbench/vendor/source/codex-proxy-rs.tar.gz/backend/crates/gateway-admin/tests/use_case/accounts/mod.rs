//! 账号管理用例测试及共享 Provider、存储替身

mod reset_credit_automation;

use gateway_core::engine::probe::AccountProbeTarget;
use std::{
    collections::BTreeMap,
    sync::{Arc, Mutex},
};

use async_trait::async_trait;
use chrono::{TimeDelta, Utc};
use futures::{StreamExt as _, future::BoxFuture};
use gateway_core::{
    account::{
        AccountStatusFacts, CredentialState, OpaqueProviderData, ProviderAccountId, QuotaEvidence,
        QuotaState, resolve_account_status,
    },
    engine::probe::{
        AccountProbe, AccountProbeError, AccountProbeErrorSource, AccountProbeRequest,
        AccountProbeResult,
    },
    error::{ClientVisibleUpstreamError, GatewayError, GatewayErrorKind},
    operation::{GenerateRequest, Operation, ProtocolPayload},
    routing::ProviderKind,
    upstream::UpstreamSendState,
};

use gateway_admin::{
    AdminServices,
    model::{
        AdminError, MutationContext, Revision,
        accounts::{
            AccountConnectionTestEvent, AccountListQuery, AccountPage, AccountPageItem,
            AccountRecord, AccountRuntimeSnapshot, AccountSummary, AccountUpdateResult,
            AccountUsage, AccountUsageWindowQuery, AccountUsageWindowResult, AccountsUpdateResult,
            BatchUpdateAccounts, DeleteAccounts, UpdateAccount,
        },
        observability::TimeRange,
        provider_credentials::{
            AuthorizationCommit, AuthorizationCommitGuard, AuthorizationCredentialCommit,
            AuthorizationMutationTarget, AuthorizationStarted, CompleteAuthorization,
            ConsumeProviderResetCredit, CredentialCommitGuard, CredentialDetails,
            CredentialImportCommit, CredentialImportResult, CredentialMutationResult,
            CredentialRotationCommit, PendingAuthorizationMutation, PrepareCredentialImport,
            PrepareCredentialRefresh, PrepareCredentialRotation, PreparedAuthorizationCommit,
            PreparedAuthorizationCredential, PreparedCredentialCreate, PreparedCredentialImport,
            PreparedCredentialRotation, PreparedCredentialRotationFacts, PreparedPluginAccountSave,
            ProviderDocument, ProviderExport, ProviderExportCredentialInput, ProviderModels,
            ProviderProfileActivityInsights, ProviderProfileStatistics,
            ProviderProfileStatisticsSummary, ProviderQuota, ProviderQuotaRequest,
            ProviderQuotaWindow, ProviderResetCreditResult, ProviderSubscription,
            QuotaLocalUsageAttribution,
        },
        quota_forecast_sampling::{QuotaForecastHistory, QuotaForecastUsage},
        settings::{
            AdminApiKey, AdminApiKeyMutation, ReplaceRuntimeSettings, RotationStrategy,
            RuntimeSettings,
        },
    },
    ports::{
        provider::{
            ProviderAdmin, ProviderAdminError, ProviderAdminErrorKind, ProviderAdminRegistry,
        },
        store::{
            AccountRuntimeStore, AccountStore, AdminStoreError, AdminStoreErrorKind,
            AdminStoreResult, SettingsStore,
        },
    },
};
use serde_json::{Map, json};

pub(super) type EventLog = Arc<Mutex<Vec<&'static str>>>;

pub(super) struct FakeProviderAdmin {
    kind: ProviderKind,
    capabilities: Mutex<gateway_admin::model::accounts::ProviderAccountCapabilities>,
    events: EventLog,
    failure: Mutex<Option<ProviderAdminError>>,
    import_gate: Mutex<Option<Arc<tokio::sync::Semaphore>>>,
    quota_failure: Mutex<Option<ProviderAdminErrorKind>>,
    pending: Arc<Mutex<Option<PendingAuthorizationMutation>>>,
    retry_authorization_after_abort: Mutex<bool>,
    export_inputs: Mutex<Vec<ProviderExportCredentialInput>>,
    import_account_ids: Mutex<Vec<String>>,
    quota_requests: Mutex<Vec<ProviderQuotaRequest>>,
    quota_started: tokio::sync::Notify,
    quota_gate: Mutex<Option<tokio::sync::oneshot::Receiver<()>>>,
    quota: Mutex<ProviderQuota>,
    quota_refresh_account: Mutex<Option<(Arc<FakeAccountStore>, AccountRecord)>>,
    current_credential_revision: Mutex<Revision>,
    reset_credit_commands: Mutex<Vec<ConsumeProviderResetCredit>>,
    reset_credits: Mutex<Vec<gateway_admin::model::provider_credentials::ProviderResetCredit>>,
    reset_credit_failure: Mutex<Option<ProviderAdminErrorKind>>,
    reset_credit_result: Mutex<String>,
    reset_credit_query_started: tokio::sync::Notify,
    reset_credit_query_gate: Mutex<Option<tokio::sync::oneshot::Receiver<()>>>,
    profile_result: Mutex<Result<ProviderProfileStatistics, ProviderAdminErrorKind>>,
    subscription_result: Mutex<Result<Option<ProviderSubscription>, ProviderAdminErrorKind>>,
    personal_info_barrier: Mutex<Option<Arc<tokio::sync::Barrier>>>,
}

impl FakeProviderAdmin {
    pub(super) fn new(kind: &str, events: EventLog) -> Arc<Self> {
        Arc::new(Self {
            kind: ProviderKind::new(kind).expect("provider kind"),
            capabilities: Mutex::default(),
            events,
            failure: Mutex::new(None),
            import_gate: Mutex::new(None),
            quota_failure: Mutex::new(None),
            pending: Arc::new(Mutex::new(None)),
            retry_authorization_after_abort: Mutex::new(false),
            export_inputs: Mutex::new(Vec::new()),
            import_account_ids: Mutex::new(vec!["acct_prepared".to_owned()]),
            quota_requests: Mutex::new(Vec::new()),
            quota_started: tokio::sync::Notify::new(),
            quota_gate: Mutex::new(None),
            quota: Mutex::new(empty_quota()),
            quota_refresh_account: Mutex::new(None),
            current_credential_revision: Mutex::new(revision(1)),
            reset_credit_commands: Mutex::new(Vec::new()),
            reset_credits: Mutex::default(),
            reset_credit_failure: Mutex::default(),
            reset_credit_result: Mutex::new("reset".into()),
            reset_credit_query_started: tokio::sync::Notify::new(),
            reset_credit_query_gate: Mutex::new(None),
            profile_result: Mutex::new(Ok(empty_profile_statistics())),
            subscription_result: Mutex::new(Ok(None)),
            personal_info_barrier: Mutex::new(None),
        })
    }

    pub(super) fn block_imports(&self) -> Arc<tokio::sync::Semaphore> {
        let gate = Arc::new(tokio::sync::Semaphore::new(0));
        *self.import_gate.lock().expect("import gate") = Some(gate.clone());
        gate
    }

    pub(super) fn fail_next(&self, kind: ProviderAdminErrorKind) {
        *self.failure.lock().expect("provider failure") = Some(ProviderAdminError::new(kind));
    }

    async fn wait_personal_info_queries(&self) {
        let barrier = self.personal_info_barrier.lock().unwrap().clone();
        if let Some(barrier) = barrier {
            barrier.wait().await;
            barrier.wait().await;
        }
    }

    fn fail_next_with_message(&self, kind: ProviderAdminErrorKind, message: &str) {
        *self.failure.lock().expect("provider failure") =
            Some(ProviderAdminError::new(kind).with_message(message));
    }

    pub(super) fn fail_next_with_public_message(
        &self,
        kind: ProviderAdminErrorKind,
        message: &'static str,
    ) {
        *self.failure.lock().expect("provider failure") = Some(
            ProviderAdminError::new(kind)
                .with_message("upstream body containing a secret token")
                .with_public_message(message),
        );
    }

    pub(super) fn fail_next_quota(&self, kind: ProviderAdminErrorKind) {
        *self.quota_failure.lock().expect("provider quota failure") = Some(kind);
    }

    pub(super) fn set_import_account_ids(&self, account_ids: &[&str]) {
        *self
            .import_account_ids
            .lock()
            .expect("provider import account IDs") = account_ids
            .iter()
            .map(|account_id| (*account_id).to_owned())
            .collect();
    }

    pub(super) fn quota_requests(&self) -> Vec<ProviderQuotaRequest> {
        self.quota_requests
            .lock()
            .expect("provider quota requests")
            .clone()
    }

    pub(super) fn pause_next_quota(&self) -> tokio::sync::oneshot::Sender<()> {
        let (sender, receiver) = tokio::sync::oneshot::channel();
        *self.quota_gate.lock().expect("quota gate") = Some(receiver);
        sender
    }

    pub(super) async fn wait_for_quota_requests(&self, expected: usize) {
        tokio::time::timeout(std::time::Duration::from_secs(5), async {
            loop {
                let notified = self.quota_started.notified();
                if self.quota_requests().len() >= expected {
                    return;
                }
                notified.await;
            }
        })
        .await
        .expect("quota observation started");
    }

    fn reset_credit_commands(&self) -> Vec<ConsumeProviderResetCredit> {
        self.reset_credit_commands
            .lock()
            .expect("provider reset-credit commands")
            .clone()
    }

    pub(super) fn set_quota(&self, quota: ProviderQuota) {
        *self.quota.lock().expect("provider quota") = quota;
    }

    pub(super) fn pending(&self) -> Option<PendingAuthorizationMutation> {
        self.pending.lock().expect("pending authorization").clone()
    }

    pub(super) fn retry_authorization_after_abort(&self) {
        *self
            .retry_authorization_after_abort
            .lock()
            .expect("authorization retry") = true;
    }

    pub(super) fn set_current_credential_revision(&self, revision: Revision) {
        *self
            .current_credential_revision
            .lock()
            .expect("current credential revision") = revision;
    }

    fn export_inputs(&self) -> Vec<ProviderExportCredentialInput> {
        self.export_inputs.lock().expect("export inputs").clone()
    }

    fn record(&self, event: &'static str) {
        self.events.lock().expect("provider events").push(event);
    }

    fn require_available(&self) -> Result<(), ProviderAdminError> {
        match self.failure.lock().expect("provider failure").take() {
            Some(error) => Err(error),
            None => Ok(()),
        }
    }

    fn prepared_rotation(&self, account: &AccountRecord) -> PreparedCredentialRotation {
        PreparedCredentialRotation::new(
            PreparedCredentialRotationFacts {
                account_id: ProviderAccountId::new(account.id.clone()).expect("account ID"),
                provider_kind: account.provider_kind.clone(),
                expected_credential_revision: *self
                    .current_credential_revision
                    .lock()
                    .expect("current credential revision"),
                replacement_identity: None,
                name: account.name.clone(),
                email: account.email.clone(),
                plan_type: account.plan_type.clone(),
                preserve_profile: false,
                preserve_credential_state: false,
                provider_material: document(),
                has_refresh_token: account.has_refresh_token,
                access_token_expires_at: account
                    .access_token_expires_at
                    .map(|expires_at| expires_at + TimeDelta::hours(1)),
                next_refresh_at: account.next_refresh_at,
            },
            Box::new(RecordingGuard::new(self.events.clone())),
        )
    }
}

#[async_trait]
impl ProviderAdmin for FakeProviderAdmin {
    fn peer_authentication_kinds(&self) -> &[&str] {
        &["api_key"]
    }

    fn account_capabilities(
        &self,
        _account_id: &ProviderAccountId,
        _authentication_kind: &str,
    ) -> gateway_admin::model::accounts::ProviderAccountCapabilities {
        *self.capabilities.lock().unwrap()
    }
    fn provider_kind(&self) -> &ProviderKind {
        &self.kind
    }

    async fn profile_statistics(
        &self,
        _: &ProviderAccountId,
    ) -> Result<ProviderProfileStatistics, ProviderAdminError> {
        self.record("provider.profile_statistics");
        self.wait_personal_info_queries().await;
        self.profile_result
            .lock()
            .unwrap()
            .clone()
            .map_err(ProviderAdminError::new)
    }

    async fn subscription(
        &self,
        _: &ProviderAccountId,
    ) -> Result<Option<ProviderSubscription>, ProviderAdminError> {
        self.record("provider.subscription");
        self.wait_personal_info_queries().await;
        self.subscription_result
            .lock()
            .unwrap()
            .clone()
            .map_err(ProviderAdminError::new)
    }

    fn plan_type_display(&self, plan_type: &str) -> String {
        match plan_type {
            "prolite" => "ProLite".to_owned(),
            "pro" => "Pro".to_owned(),
            "promax" => "ProMax".to_owned(),
            _ => format!("{} display: {plan_type}", self.kind),
        }
    }

    async fn account_unavailable(&self, _: &ProviderAccountId) {
        self.record("provider.account_unavailable");
    }

    async fn account_facts_changed(&self, _: &[ProviderAccountId]) {
        self.record("provider.account_facts_changed");
    }

    async fn connection_test_operation(
        &self,
        model: &gateway_core::routing::UpstreamModelId,
        input: &str,
    ) -> Result<gateway_core::operation::Operation, ProviderAdminError> {
        let payload = ProtocolPayload::json_object(
            "openai",
            Map::from_iter([
                ("model".to_owned(), json!(model.as_str())),
                ("input".to_owned(), json!(input)),
                ("stream".to_owned(), json!(true)),
                ("store".to_owned(), json!(false)),
            ]),
        )
        .map_err(|_| ProviderAdminError::new(ProviderAdminErrorKind::Invalid))?;
        Ok(Operation::Generate(GenerateRequest::from_protocol_payload(
            payload,
        )))
    }

    fn dashboard_wire_profile(
        &self,
    ) -> Option<gateway_admin::model::observability::DashboardWireProfile> {
        None
    }

    fn calculated_billing(
        &self,
        _: &gateway_admin::model::observability::ProviderBillingInput,
    ) -> Result<
        Option<gateway_admin::model::observability::CalculatedBillingBreakdown>,
        ProviderAdminError,
    > {
        Ok(None)
    }

    async fn prepare_import(
        &self,
        _command: PrepareCredentialImport,
    ) -> Result<PreparedCredentialImport, ProviderAdminError> {
        self.record("provider.prepare_import");
        let gate = self.import_gate.lock().expect("import gate").clone();
        if let Some(gate) = gate {
            gate.acquire().await.expect("import permit").forget();
        }
        self.require_available()?;
        let account_ids = self
            .import_account_ids
            .lock()
            .expect("provider import account IDs")
            .clone();
        Ok(PreparedCredentialImport {
            provider_kind: self.kind.clone(),
            credentials: account_ids
                .into_iter()
                .map(|account_id| {
                    prepared_create_with_id(self.kind.clone(), &account_id, "prepared-import")
                })
                .collect(),
        })
    }

    async fn start_authorization(
        &self,
        pending: gateway_admin::model::provider_credentials::PendingAuthorizationMutation,
    ) -> Result<AuthorizationStarted, ProviderAdminError> {
        self.record("provider.start_authorization");
        self.require_available()?;
        *self.pending.lock().expect("pending authorization") = Some(pending);
        Ok(AuthorizationStarted {
            flow_id: "flow-test".to_owned(),
            authorization_url: "https://example.invalid/oauth".to_owned(),
            expires_at: Utc::now() + TimeDelta::minutes(10),
        })
    }

    async fn complete_authorization(
        &self,
        command: CompleteAuthorization,
    ) -> Result<PreparedAuthorizationCommit, ProviderAdminError> {
        self.record("provider.complete_authorization");
        self.require_available()?;
        let pending = self
            .pending
            .lock()
            .expect("pending authorization")
            .take()
            .ok_or_else(unsupported)?;
        if !pending.owner_binding().matches_context(&command.context) {
            return Err(ProviderAdminError::new(ProviderAdminErrorKind::NotFound));
        }
        let retry_pending = (*self
            .retry_authorization_after_abort
            .lock()
            .expect("authorization retry"))
        .then(|| pending.clone());
        let credential = match pending.target() {
            AuthorizationMutationTarget::Create { name } => {
                PreparedAuthorizationCredential::Create(Box::new(prepared_create(
                    self.kind.clone(),
                    name,
                )))
            }
            AuthorizationMutationTarget::Reauthorize { account_id } => {
                let mut account = account_record(self.kind.as_str());
                account.id = account_id.as_str().to_owned();
                PreparedAuthorizationCredential::Reauthorize(Box::new(
                    self.prepared_rotation(&account),
                ))
            }
        };
        let prepared = PreparedAuthorizationCommit::new(pending, credential);
        Ok(match retry_pending {
            Some(pending) => {
                prepared.with_authorization_guard(Box::new(RetryableAuthorizationGuard::new(
                    self.events.clone(),
                    Arc::clone(&self.pending),
                    pending,
                )))
            }
            None => prepared,
        })
    }

    async fn prepare_rotation(
        &self,
        command: PrepareCredentialRotation,
    ) -> Result<PreparedCredentialRotation, ProviderAdminError> {
        self.record("provider.prepare_rotation");
        self.require_available()?;
        Ok(self.prepared_rotation(&command.account))
    }

    async fn prepare_refresh(
        &self,
        command: PrepareCredentialRefresh,
    ) -> Result<PreparedCredentialRotation, ProviderAdminError> {
        self.record("provider.prepare_refresh");
        self.require_available()?;
        Ok(self.prepared_rotation(&command.account))
    }

    async fn quota(
        &self,
        request: ProviderQuotaRequest,
    ) -> Result<ProviderQuota, ProviderAdminError> {
        if request.refresh {
            self.record("provider.quota");
            if let Some((store, account)) = self
                .quota_refresh_account
                .lock()
                .expect("quota refresh account")
                .take()
            {
                store.set_accounts(vec![account]);
            }
        }
        self.quota_requests
            .lock()
            .expect("provider quota requests")
            .push(request);
        self.quota_started.notify_one();
        let gate = self.quota_gate.lock().expect("quota gate").take();
        if let Some(gate) = gate {
            gate.await.expect("release paused quota");
        }
        if let Some(kind) = self
            .quota_failure
            .lock()
            .expect("provider quota failure")
            .take()
        {
            return Err(ProviderAdminError::new(kind));
        }
        Ok(self.quota.lock().expect("provider quota").clone())
    }

    async fn reset_credits(
        &self,
        _: &ProviderAccountId,
    ) -> Result<gateway_admin::model::provider_credentials::ProviderResetCredits, ProviderAdminError>
    {
        self.record("provider.reset_credits");
        self.require_available()?;
        self.reset_credit_query_started.notify_one();
        let gate = self.reset_credit_query_gate.lock().unwrap().take();
        if let Some(gate) = gate {
            let _ = gate.await;
        }

        let credits = self.reset_credits.lock().unwrap().clone();
        Ok(
            gateway_admin::model::provider_credentials::ProviderResetCredits {
                available_count: credits.len() as u64,
                credits,
            },
        )
    }

    async fn consume_reset_credit(
        &self,
        command: ConsumeProviderResetCredit,
    ) -> Result<ProviderResetCreditResult, ProviderAdminError> {
        self.record("provider.consume_reset_credit");
        self.reset_credit_commands
            .lock()
            .expect("provider reset-credit commands")
            .push(command);
        self.require_available()?;
        if let Some(kind) = self.reset_credit_failure.lock().unwrap().take() {
            return Err(ProviderAdminError::new(kind));
        }
        Ok(ProviderResetCreditResult {
            code: self.reset_credit_result.lock().unwrap().clone(),
            credit: None,
        })
    }

    fn quota_forecast_observation(
        &self,
        document: &ProviderDocument,
        _: &ProviderQuotaWindow,
    ) -> Option<gateway_admin::model::quota_forecast_sampling::QuotaForecastObservation> {
        let fields = document.expose_to_provider().expose_to_provider();
        Some(
            gateway_admin::model::quota_forecast_sampling::QuotaForecastObservation {
                used_percent: fields.get("percent")?.as_f64()?,
                reset_at: fields.get("reset")?.as_str()?.parse().ok()?,
                plan_type: fields.get("plan")?.as_str().map(str::to_owned),
            },
        )
    }

    async fn models(
        &self,
        _: &ProviderAccountId,
        _: bool,
    ) -> Result<ProviderModels, ProviderAdminError> {
        Ok(ProviderModels {
            models: Vec::new(),
            observed_at: None,
        })
    }

    async fn export_credentials(
        &self,
        credentials: Vec<ProviderExportCredentialInput>,
    ) -> Result<ProviderExport, ProviderAdminError> {
        self.record("provider.export");
        self.require_available()?;
        *self.export_inputs.lock().expect("export inputs") = credentials.clone();
        Ok(ProviderExport {
            provider_kind: self.kind.clone(),
            account_ids: credentials
                .into_iter()
                .map(|credential| {
                    ProviderAccountId::new(credential.account.id).expect("stored account ID")
                })
                .collect(),
            document: document(),
        })
    }
}

pub(super) struct FakeAccountStore {
    events: EventLog,
    accounts: Mutex<Vec<AccountRecord>>,
    account_after_probe: Mutex<Option<AccountRecord>>,
    fail_commit: Mutex<bool>,
    receipts: Mutex<
        std::collections::BTreeMap<
            gateway_admin::model::provider_credentials::AuthorizationReceiptKey,
            gateway_admin::model::provider_credentials::CredentialMutationResult,
        >,
    >,
    audit_requests: Mutex<Vec<String>>,
    import_settings: Mutex<Vec<Option<gateway_admin::model::accounts::AccountImportSettings>>>,
    quota_window_usage: Mutex<Vec<AccountUsageWindowResult>>,
    quota_window_queries: Mutex<Vec<AccountUsageWindowQuery>>,
    quota_forecast_history: Mutex<QuotaForecastHistory>,
    update_commands: Mutex<Vec<UpdateAccount>>,
    automations: Mutex<
        BTreeMap<String, gateway_admin::model::reset_credit_automation::ResetCreditAutomation>,
    >,
}

impl FakeAccountStore {
    pub(super) fn new(kind: &str, events: EventLog) -> Arc<Self> {
        Self::with_account(account_record(kind), events)
    }

    pub(super) fn with_account(account: AccountRecord, events: EventLog) -> Arc<Self> {
        Arc::new(Self {
            events,
            accounts: Mutex::new(vec![account]),
            account_after_probe: Mutex::new(None),
            fail_commit: Mutex::new(false),
            receipts: Mutex::new(Default::default()),
            audit_requests: Mutex::new(Vec::new()),
            import_settings: Mutex::new(Vec::new()),
            quota_window_usage: Mutex::new(Vec::new()),
            quota_window_queries: Mutex::new(Vec::new()),
            quota_forecast_history: Mutex::new(QuotaForecastHistory::default()),
            update_commands: Mutex::new(Vec::new()),
            automations: Mutex::default(),
        })
    }

    pub(super) fn update_commands(&self) -> Vec<UpdateAccount> {
        self.update_commands
            .lock()
            .expect("update commands")
            .clone()
    }

    pub(super) fn fail_next_commit(&self) {
        *self.fail_commit.lock().expect("store failure") = true;
    }

    pub(super) fn import_settings(
        &self,
    ) -> Vec<Option<gateway_admin::model::accounts::AccountImportSettings>> {
        self.import_settings
            .lock()
            .expect("import settings")
            .clone()
    }

    pub(super) fn audit_requests(&self) -> Vec<String> {
        self.audit_requests.lock().expect("audit requests").clone()
    }

    pub(super) fn set_quota_window_usage(&self, usage: Vec<AccountUsageWindowResult>) {
        *self.quota_window_usage.lock().expect("quota window usage") = usage;
    }

    fn quota_window_queries(&self) -> Vec<AccountUsageWindowQuery> {
        self.quota_window_queries
            .lock()
            .expect("quota window queries")
            .clone()
    }

    pub(super) fn set_accounts(&self, accounts: Vec<AccountRecord>) {
        *self.accounts.lock().expect("accounts") = accounts;
    }

    fn set_account_after_probe(&self, account: AccountRecord) {
        *self
            .account_after_probe
            .lock()
            .expect("account after probe") = Some(account);
    }

    fn record(&self, event: &'static str) {
        self.events.lock().expect("store events").push(event);
    }

    fn require_commit(&self) -> AdminStoreResult<()> {
        let mut failure = self.fail_commit.lock().expect("store failure");
        if std::mem::take(&mut *failure) {
            Err(store_unavailable())
        } else {
            Ok(())
        }
    }

    fn record_context(&self, context: &MutationContext) {
        self.audit_requests
            .lock()
            .expect("audit requests")
            .push(context.request_id.clone());
    }

    fn page_item(account: AccountRecord) -> AccountPageItem {
        let facts = AccountStatusFacts {
            quota_paused: false,
            enabled: account.enabled,
            credential_state: account.credential_state,
            access_token_expires_at: account.access_token_expires_at.map(Into::into),
            quota: account.quota,
            cooldown: None,
            last_error_reason: account.last_error_reason,
            last_error_message: account.last_error_message.clone(),
        };
        AccountPageItem {
            protection_rules: Vec::new(),
            capacity: gateway_admin::model::accounts::AccountCapacity {
                used_slots: None,
                total_slots: account
                    .concurrency_limit
                    .map(|limit| u64::from(limit.get())),
            },
            account,
            projection: resolve_account_status(&facts, std::time::SystemTime::now()),
        }
    }
}

#[async_trait]
impl AccountStore for FakeAccountStore {
    async fn load_account_record(
        &self,
        account_id: &ProviderAccountId,
    ) -> AdminStoreResult<Option<AccountRecord>> {
        self.record("store.load_account_record");
        Ok(self
            .accounts
            .lock()
            .expect("accounts")
            .iter()
            .find(|account| account.id == account_id.as_str())
            .cloned())
    }

    async fn account_exists(&self, account_id: &str) -> AdminStoreResult<bool> {
        self.record("store.account_exists");
        Ok(self
            .accounts
            .lock()
            .expect("accounts")
            .iter()
            .any(|account| account.id == account_id))
    }

    async fn list_plugin_accounts(
        &self,
        _: gateway_admin::model::provider_credentials::PluginAccountListQuery,
    ) -> AdminStoreResult<gateway_admin::model::provider_credentials::PluginAccountPage> {
        Err(AdminStoreError::new(
            AdminStoreErrorKind::Unavailable,
            "plugin accounts",
            "unavailable",
        ))
    }

    async fn list_accounts(
        &self,
        _: AccountListQuery,
        _: AccountRuntimeSnapshot,
    ) -> AdminStoreResult<AccountPage> {
        self.record("store.list_accounts");
        let accounts = self.accounts.lock().expect("accounts").clone();
        let total = accounts.len() as u64;
        Ok(AccountPage {
            config_revision: revision(1),
            items: accounts.into_iter().map(Self::page_item).collect(),
            total,
            summary: AccountSummary {
                total,
                normal: 1,
                quota_paused: 0,
                quota_exhausted: 0,
                rate_limited: 0,
                disabled: 0,
                error: 0,
            },
        })
    }

    async fn load_account(
        &self,
        account_id: &str,
        _: AccountRuntimeSnapshot,
    ) -> AdminStoreResult<Option<AccountPageItem>> {
        self.record("store.load_account");
        // probe 后的账号状态覆盖只对同一 id 生效；其余按账号列表查询
        let account = self
            .account_after_probe
            .lock()
            .expect("account after probe")
            .clone()
            .filter(|account| account.id == account_id)
            .or_else(|| {
                self.accounts
                    .lock()
                    .expect("accounts")
                    .iter()
                    .find(|account| account.id == account_id)
                    .cloned()
            });
        Ok(account.map(Self::page_item))
    }

    async fn load_account_usage(
        &self,
        _: TimeRange,
        _: &[String],
    ) -> AdminStoreResult<Vec<AccountUsage>> {
        Ok(Vec::new())
    }

    async fn load_account_usage_by_windows(
        &self,
        windows: &[AccountUsageWindowQuery],
    ) -> AdminStoreResult<Vec<AccountUsageWindowResult>> {
        *self
            .quota_window_queries
            .lock()
            .expect("quota window queries") = windows.to_vec();
        Ok(self
            .quota_window_usage
            .lock()
            .expect("quota window usage")
            .clone())
    }

    async fn load_quota_forecast_history(
        &self,
        window: &AccountUsageWindowQuery,
    ) -> AdminStoreResult<QuotaForecastHistory> {
        self.quota_window_queries
            .lock()
            .unwrap()
            .push(window.clone());
        Ok(self.quota_forecast_history.lock().unwrap().clone())
    }

    async fn credential_details(
        &self,
        provider_kind: &ProviderKind,
        account_id: &ProviderAccountId,
    ) -> AdminStoreResult<Option<CredentialDetails>> {
        self.record("store.credential_details");
        let account = self
            .accounts
            .lock()
            .expect("accounts")
            .iter()
            .find(|account| {
                &account.provider_kind == provider_kind && account.id == account_id.as_str()
            })
            .cloned();
        Ok(account.map(|credential| CredentialDetails {
            config_revision: revision(1),
            credential,
        }))
    }

    async fn credential_details_by_id(
        &self,
        account_id: &ProviderAccountId,
    ) -> AdminStoreResult<Option<CredentialDetails>> {
        self.record("store.credential_details_by_id");
        let account = self
            .accounts
            .lock()
            .expect("accounts")
            .iter()
            .find(|account| account.id == account_id.as_str())
            .cloned();
        Ok(account.map(|credential| CredentialDetails {
            config_revision: revision(1),
            credential,
        }))
    }

    async fn load_credentials_for_export(
        &self,
        provider_kind: &ProviderKind,
        account_ids: &[ProviderAccountId],
    ) -> AdminStoreResult<Vec<ProviderExportCredentialInput>> {
        self.record("store.load_credentials_for_export");
        let accounts = self.accounts.lock().expect("accounts").clone();
        if accounts.iter().any(|account| {
            &account.provider_kind != provider_kind
                || !account_ids
                    .iter()
                    .any(|account_id| account_id.as_str() == account.id)
        }) {
            return Err(AdminStoreError::new(
                AdminStoreErrorKind::NotFound,
                "test account",
                "credential not found",
            ));
        }
        Ok(accounts
            .into_iter()
            .map(|account| ProviderExportCredentialInput {
                account,
                provider_material: document(),
            })
            .collect())
    }

    async fn load_credential_for_plugin(
        &self,
        account_id: &ProviderAccountId,
    ) -> AdminStoreResult<Option<ProviderExportCredentialInput>> {
        self.record("store.load_credential_for_plugin");
        Ok(self
            .accounts
            .lock()
            .expect("accounts")
            .iter()
            .find(|account| account.id == account_id.as_str())
            .cloned()
            .map(|account| ProviderExportCredentialInput {
                account,
                provider_material: document(),
            }))
    }

    async fn commit_credential_import(
        &self,
        command: CredentialImportCommit,
        context: &MutationContext,
    ) -> AdminStoreResult<CredentialImportResult> {
        self.import_settings
            .lock()
            .expect("import settings")
            .push(command.settings);
        self.record("store.commit_import");
        self.record_context(context);
        self.require_commit()?;
        Ok(CredentialImportResult {
            config_revision: revision(2),
            credential_ids: command
                .prepared
                .credentials
                .into_iter()
                .map(|credential| credential.account_id)
                .collect(),
        })
    }

    async fn commit_authorization(
        &self,
        command: AuthorizationCommit,
        context: &MutationContext,
    ) -> AdminStoreResult<gateway_admin::model::provider_credentials::AuthorizationCommitResult>
    {
        self.import_settings
            .lock()
            .expect("import settings")
            .push(command.settings);
        if let Some(result) = self.receipts.lock().unwrap().get(&command.key).cloned() {
            return Ok(
                gateway_admin::model::provider_credentials::AuthorizationCommitResult {
                    result,
                    newly_committed: false,
                },
            );
        }
        self.record("store.commit_authorization");
        self.record_context(context);
        self.require_commit()?;
        let (account_id, credential_revision) = match command.credential {
            AuthorizationCredentialCommit::Create(credential) => (credential.account_id, None),
            AuthorizationCredentialCommit::Reauthorize(credential) => (
                credential.account_id,
                Some(revision(credential.expected_credential_revision.get() + 1)),
            ),
        };
        let result = CredentialMutationResult {
            config_revision: revision(2),
            account_id,
            credential_revision,
        };
        self.receipts
            .lock()
            .unwrap()
            .insert(command.key, result.clone());
        Ok(
            gateway_admin::model::provider_credentials::AuthorizationCommitResult {
                result,
                newly_committed: true,
            },
        )
    }

    async fn authorization_receipt(
        &self,
        key: &gateway_admin::model::provider_credentials::AuthorizationReceiptKey,
    ) -> AdminStoreResult<Option<CredentialMutationResult>> {
        Ok(self.receipts.lock().unwrap().get(key).cloned())
    }

    async fn commit_credential_rotation(
        &self,
        command: CredentialRotationCommit,
        context: &MutationContext,
    ) -> AdminStoreResult<CredentialMutationResult> {
        self.record("store.commit_rotation");
        self.record_context(context);
        self.require_commit()?;
        Ok(rotation_result(command))
    }

    async fn commit_credential_refresh(
        &self,
        command: CredentialRotationCommit,
        context: &MutationContext,
    ) -> AdminStoreResult<CredentialMutationResult> {
        self.record("store.commit_refresh");
        self.record_context(context);
        self.require_commit()?;
        Ok(rotation_result(command))
    }

    async fn update_account(
        &self,
        command: UpdateAccount,
        context: &MutationContext,
    ) -> AdminStoreResult<AccountUpdateResult> {
        self.record("store.update_account");
        self.record_context(context);
        self.require_commit()?;
        self.update_commands
            .lock()
            .expect("update commands")
            .push(command.clone());
        Ok(AccountUpdateResult {
            config_revision: revision(2),
            account_id: ProviderAccountId::new(command.account_id).expect("account ID"),
        })
    }

    async fn recover_account(
        &self,
        account_id: &ProviderAccountId,
        context: &MutationContext,
    ) -> AdminStoreResult<AccountUpdateResult> {
        self.record("store.recover_account");
        self.record_context(context);
        self.require_commit()?;
        let mut accounts = self.accounts.lock().expect("accounts");
        if let Some(account) = accounts
            .iter_mut()
            .find(|account| account.id == account_id.as_str())
        {
            account.enabled = true;
            account.credential_state = CredentialState::Ready;
            account.quota = QuotaState::allowed(std::time::SystemTime::now());
            account.last_error_reason = None;
            account.last_error_message = None;
        }
        Ok(AccountUpdateResult {
            config_revision: revision(2),
            account_id: account_id.clone(),
        })
    }

    async fn batch_update_accounts(
        &self,
        command: BatchUpdateAccounts,
        _: gateway_admin::model::accounts::PreparedQuotaPauses,
        context: &MutationContext,
    ) -> AdminStoreResult<AccountsUpdateResult> {
        self.record("store.batch_update_accounts");
        self.record_context(context);
        self.require_commit()?;
        if let Some(enabled) = command.enabled {
            for account in self.accounts.lock().expect("accounts").iter_mut() {
                if command.account_ids.contains(&account.id) {
                    account.enabled = enabled;
                }
            }
        }
        Ok(AccountsUpdateResult {
            config_revision: revision(2),
            account_ids: command
                .account_ids
                .into_iter()
                .map(|id| ProviderAccountId::new(id).expect("account ID"))
                .collect(),
        })
    }

    async fn delete_accounts(
        &self,
        _: DeleteAccounts,
        context: &MutationContext,
    ) -> AdminStoreResult<Revision> {
        self.record("store.delete");
        self.record_context(context);
        self.require_commit()?;
        Ok(revision(2))
    }

    async fn record_credential_export(
        &self,
        _: &[ProviderAccountId],
        context: &MutationContext,
    ) -> AdminStoreResult<()> {
        self.record("store.audit_export");
        self.record_context(context);
        Ok(())
    }
}

#[derive(Default)]
struct StaticSettingsStore {
    reset_credit_on_low_weekly_quota: bool,
    reset_credit_max_weekly_remaining_percent: Option<u32>,
}

#[async_trait]
impl SettingsStore for StaticSettingsStore {
    async fn load_pricing(&self) -> AdminStoreResult<gateway_admin::model::pricing::StoredPricing> {
        Ok(Default::default())
    }
    async fn sync_pricing(
        &self,
        _: gateway_admin::model::pricing::PricingSyncChanges,
        _: &MutationContext,
    ) -> AdminStoreResult<gateway_admin::model::Revision> {
        panic!("unexpected pricing sync")
    }
    async fn update_pricing(
        &self,
        _: gateway_admin::model::pricing::UpdatePricing,
        _: &MutationContext,
    ) -> AdminStoreResult<gateway_admin::model::Revision> {
        panic!("unexpected pricing update")
    }
    async fn load_runtime_settings(&self) -> AdminStoreResult<RuntimeSettings> {
        Ok(RuntimeSettings {
            request_profiles: Default::default(),
            config_revision: revision(1),
            model_mappings: Default::default(),
            rotation_strategy: RotationStrategy::Smart,
            updated_at: Utc::now(),
            values: gateway_admin::model::settings::RuntimeSettingsValues {
                codex_privacy_policy: Default::default(),
                request_location_enabled: false,
                request_location: Default::default(),
                refresh_margin_seconds: 300,
                refresh_concurrency: 2,
                max_concurrent_per_account: 1,
                max_waiting_per_key: 0,
                max_waiting_per_account: 0,
                key_queue_timeout_seconds: 30,
                account_queue_timeout_seconds: 30,
                switch_account_on_queue_failure: false,
                max_retry_after_seconds: 240,
                openai_guardian_reserved_concurrency: 0,
                openai_account_affinity: gateway_core::account::AccountAffinity::Relaxed,
                max_account_rotations: 3,
                openai_session_affinity_ttl_hours: 24,
                responses_max_decompressed_body_bytes: 64 * 1024 * 1024,
                smart_scheduling: gateway_core::account::SmartSchedulingConfig::default(),
                quota_reset_window_weights: gateway_core::account::ResetWindowWeights::default(),
                min_codex_desktop_version: None,
                min_codex_cli_version: None,
                usage_retention_days: 30,
                ops_event_retention_days: 30,
                audit_retention_days: 30,
                account_error_protection: gateway_core::account::AccountErrorProtection::default(),
                account_warmup_enabled: false,
                account_warmup_cron: "0 8 * * *".to_owned(),
                account_warmup_model: None,
                reset_credit_lead_minutes: 10,
                reset_credit_on_low_weekly_quota: self.reset_credit_on_low_weekly_quota,
                reset_credit_max_weekly_remaining_percent: self
                    .reset_credit_max_weekly_remaining_percent,
            },
        })
    }

    async fn admin_api_key_exists(&self) -> AdminStoreResult<bool> {
        Err(store_unavailable())
    }

    async fn replace_runtime_settings(
        &self,
        _: ReplaceRuntimeSettings,
        _: &MutationContext,
    ) -> AdminStoreResult<RuntimeSettings> {
        Err(store_unavailable())
    }

    async fn replace_admin_api_key(
        &self,
        _: AdminApiKey,
        _: &MutationContext,
    ) -> AdminStoreResult<AdminApiKeyMutation> {
        Err(store_unavailable())
    }

    async fn delete_admin_api_key(
        &self,
        _: &MutationContext,
    ) -> AdminStoreResult<AdminApiKeyMutation> {
        Err(store_unavailable())
    }
}

struct RecordingGuard {
    events: EventLog,
    finished: bool,
}

impl RecordingGuard {
    fn new(events: EventLog) -> Self {
        Self {
            events,
            finished: false,
        }
    }
}

impl CredentialCommitGuard for RecordingGuard {
    fn finish(mut self: Box<Self>) {
        self.events
            .lock()
            .expect("guard events")
            .push("guard.finish");
        self.finished = true;
    }
}

impl Drop for RecordingGuard {
    fn drop(&mut self) {
        if !self.finished {
            self.events.lock().expect("guard events").push("guard.drop");
        }
    }
}

struct RetryableAuthorizationGuard {
    events: EventLog,
    pending: Arc<Mutex<Option<PendingAuthorizationMutation>>>,
    authorization: PendingAuthorizationMutation,
}

impl RetryableAuthorizationGuard {
    fn new(
        events: EventLog,
        pending: Arc<Mutex<Option<PendingAuthorizationMutation>>>,
        authorization: PendingAuthorizationMutation,
    ) -> Self {
        Self {
            events,
            pending,
            authorization,
        }
    }
}

#[async_trait]
impl AuthorizationCommitGuard for RetryableAuthorizationGuard {
    async fn commit(self: Box<Self>) -> Result<(), AdminError> {
        self.events
            .lock()
            .expect("authorization guard events")
            .push("authorization_guard.commit");
        Ok(())
    }

    async fn abort(self: Box<Self>) -> Result<(), AdminError> {
        let Self {
            events,
            pending,
            authorization,
        } = *self;
        *pending.lock().expect("pending authorization") = Some(authorization);
        events
            .lock()
            .expect("authorization guard events")
            .push("authorization_guard.abort");
        Ok(())
    }
}

#[test]
fn provider_registry_should_resolve_custom_kind_without_central_match() {
    let provider = FakeProviderAdmin::new("custom-provider", events());
    let registry = ProviderAdminRegistry::new([provider as Arc<dyn ProviderAdmin>])
        .expect("provider registry");
    let resolved = registry
        .require(&ProviderKind::new("custom-provider").expect("provider kind"))
        .expect("registered provider");
    assert_eq!(resolved.provider_kind().as_str(), "custom-provider");
}

#[test]
fn provider_registry_should_reject_duplicate_kind() {
    let first = FakeProviderAdmin::new("duplicate", events());
    let second = FakeProviderAdmin::new("duplicate", events());
    let result = ProviderAdminRegistry::new([
        first as Arc<dyn ProviderAdmin>,
        second as Arc<dyn ProviderAdmin>,
    ]);
    assert!(matches!(
        result,
        Err(error) if error.kind() == ProviderAdminErrorKind::Conflict
    ));
}

#[tokio::test]
async fn connection_test_should_probe_unavailable_account() {
    let provider = FakeProviderAdmin::new("xai", events());
    let mut account = account_record("xai");
    account.quota = QuotaState::exhausted(
        QuotaEvidence::UsageLimitReached,
        std::time::SystemTime::now(),
        None,
    );
    let store = FakeAccountStore::with_account(account, events());
    let services =
        accounts_service_with_probe(provider, store, Arc::new(FailingAccountProbe)).await;

    let events = services
        .accounts()
        .test_connection(
            AccountProbeTarget::ConnectionTest(
                ProviderAccountId::new("acct_test").expect("account ID"),
            ),
            gateway_core::routing::UpstreamModelId::new("grok-4.5").expect("model"),
        )
        .await
        .expect("connection test stream")
        .collect::<Vec<_>>()
        .await;

    assert!(matches!(
        events.last(),
        Some(AccountConnectionTestEvent::Failed {
            source: AccountProbeErrorSource::Upstream,
            gateway_error_code: GatewayErrorKind::RateLimited,
            send_state: Some(UpstreamSendState::NotSent),
            message,
            provider_error_code: Some(code),
            provider_error_type: Some(error_type),
            ..
        }) if message == "included usage exhausted"
            && code == "usage_exhausted"
            && error_type == "invalid_request_error"
    ));
}

#[tokio::test]
async fn connection_test_rate_limited_probe_returns_provider_failure() {
    let events = events();
    let provider = FakeProviderAdmin::new("xai", events.clone());
    let store = FakeAccountStore::new("xai", events);
    let probe = Arc::new(FreeModelQuotaProbe {
        store: Arc::clone(&store),
    });
    let services = accounts_service_with_probe(provider, store, probe).await;

    let events = services
        .accounts()
        .test_connection(
            AccountProbeTarget::ConnectionTest(
                ProviderAccountId::new("acct_test").expect("account ID"),
            ),
            gateway_core::routing::UpstreamModelId::new("grok-4.5").expect("model"),
        )
        .await
        .expect("connection test stream")
        .collect::<Vec<_>>()
        .await;

    assert!(matches!(
        events.last(),
        Some(AccountConnectionTestEvent::Failed {
            source: AccountProbeErrorSource::Provider,
            gateway_error_code: GatewayErrorKind::RateLimited,
            send_state: Some(UpstreamSendState::NotSent),
            message,
            ..
        })
        if message == "xAI free model quota is exhausted"
    ));
}

#[tokio::test]
async fn connection_test_should_preserve_disabled_account_status() {
    let provider = FakeProviderAdmin::new("xai", events());
    let mut account = account_record("xai");
    account.enabled = false;
    let store = FakeAccountStore::with_account(account, events());
    let services =
        accounts_service_with_probe(provider, store, Arc::new(FailingAccountProbe)).await;

    let events = services
        .accounts()
        .test_connection(
            AccountProbeTarget::ConnectionTest(
                ProviderAccountId::new("acct_test").expect("account ID"),
            ),
            gateway_core::routing::UpstreamModelId::new("grok-4.5").expect("model"),
        )
        .await
        .expect("connection test stream")
        .collect::<Vec<_>>()
        .await;

    assert!(matches!(
        events.last(),
        Some(AccountConnectionTestEvent::Failed { .. })
    ));
}

#[tokio::test]
async fn accounts_export_should_pass_store_loaded_timestamps_and_material_to_provider() {
    let provider = FakeProviderAdmin::new("openai", events());
    let store = FakeAccountStore::new("openai", events());
    let expected = store.accounts.lock().expect("accounts")[0].clone();
    accounts_service(provider.clone(), store)
        .await
        .accounts()
        .export(
            &context("export-complete-input"),
            vec![ProviderAccountId::new(expected.id.clone()).expect("account ID")],
        )
        .await
        .expect("export credentials");

    let inputs = provider.export_inputs();
    let input = inputs.first().expect("provider export input");
    assert_eq!(
        (
            input.account.created_at,
            input.account.updated_at,
            &input.provider_material,
        ),
        (expected.created_at, expected.updated_at, &document()),
    );
}

#[tokio::test]
async fn accounts_refresh_should_keep_guard_through_store_commit() {
    let events = events();
    let provider = FakeProviderAdmin::new("openai", events.clone());
    let store = FakeAccountStore::new("openai", events.clone());
    let services = accounts_service(provider, store.clone()).await;

    let result = services
        .accounts()
        .refresh(
            &context("refresh-request"),
            ProviderAccountId::new("acct_test").expect("account ID"),
        )
        .await
        .expect("refresh credential");
    assert_eq!(result.config_revision, revision(2));
    assert_eq!(result.account.account.provider_kind.as_str(), "openai");
    assert_eq!(
        result.account.projection.status,
        gateway_admin::model::accounts::AccountStatus::Normal
    );

    assert_eq!(
        recorded(&events),
        [
            "store.load_account",
            "provider.prepare_refresh",
            "store.commit_refresh",
            "guard.finish",
            "provider.account_facts_changed",
            "store.load_account",
        ]
    );
    assert_eq!(store.audit_requests(), ["refresh-request"]);
}

#[tokio::test]
async fn plugin_account_save_publishes_native_credential_change() {
    let events = events();
    let provider = FakeProviderAdmin::new("openai", events.clone());
    let store = FakeAccountStore::new("openai", events.clone());
    let snapshot = Arc::new(RecordingPluginAccountPublication(events.clone()));
    let access = gateway_admin::initialize_plugin_accounts(
        ProviderAdminRegistry::new([provider.clone() as Arc<dyn ProviderAdmin>]).unwrap(),
        store.clone(),
        snapshot,
        None,
    );
    let result = access
        .save(
            PreparedPluginAccountSave::Replace {
                facts: plugin_rotation_facts(&account_record("openai")),
                authentication_kind: "oauth".to_owned(),
            },
            &context("plugin-explicit-save"),
        )
        .await
        .expect("save prepared plugin account facts");
    tokio::time::timeout(
        std::time::Duration::from_secs(1),
        provider.quota_started.notified(),
    )
    .await
    .expect("start post-commit quota observation");
    assert_eq!(result.account_id.as_str(), "acct_test");
    assert_eq!(result.credential_revision, revision(2));
    assert_eq!(store.audit_requests(), ["plugin-explicit-save"]);
    assert_eq!(
        recorded(&events),
        [
            "store.credential_details",
            "store.commit_rotation",
            "provider.account_facts_changed",
            "snapshot.publish_committed",
            "provider.quota"
        ]
    );
}

#[tokio::test]
async fn plugin_account_reads_resolve_the_authoritative_provider_from_the_account_id() {
    let events = events();
    let store = FakeAccountStore::new("xai", events.clone());
    // 读取端口不能让调用方提供或伪造 Provider；注册表中即使只有另一 Provider，
    // 也必须按 Store 中该 account ID 的权威事实返回
    let registered_provider = FakeProviderAdmin::new("openai", events.clone());
    let access = gateway_admin::initialize_plugin_accounts(
        ProviderAdminRegistry::new([registered_provider as Arc<dyn ProviderAdmin>]).unwrap(),
        store,
        Arc::new(RecordingPluginAccountPublication(events.clone())),
        None,
    );
    let account_id = ProviderAccountId::new("acct_test").expect("account ID");

    let runtime = access
        .get_runtime(&account_id)
        .await
        .expect("load plugin account runtime");
    let credential = access
        .get_credential(&account_id)
        .await
        .expect("load plugin account credential");

    assert_eq!(runtime.provider_kind.as_str(), "xai");
    assert_eq!(credential.account.provider_kind.as_str(), "xai");
    assert_eq!(credential.account.id, account_id.as_str());
    assert_eq!(
        recorded(&events),
        [
            "store.credential_details_by_id",
            "store.load_credential_for_plugin",
        ]
    );
}

struct RecordingPluginAccountPublication(EventLog);

impl gateway_core::runtime::SnapshotControl for RecordingPluginAccountPublication {
    fn publish_committed(
        &self,
        revision: gateway_core::routing::ConfigRevision,
    ) -> BoxFuture<'_, ()> {
        Box::pin(async move {
            assert_eq!(revision.get(), 2);
            self.0.lock().unwrap().push("snapshot.publish_committed");
        })
    }
}

#[tokio::test]
async fn plugin_account_save_rejects_stale_authentication_kind_before_commit() {
    let events = events();
    let provider = FakeProviderAdmin::new("openai", events.clone());
    let store = FakeAccountStore::new("openai", events.clone());
    let access = gateway_admin::initialize_plugin_accounts(
        ProviderAdminRegistry::new([provider as Arc<dyn ProviderAdmin>]).unwrap(),
        store.clone(),
        Arc::new(RecordingPluginAccountPublication(events.clone())),
        None,
    );

    let error = access
        .save(
            PreparedPluginAccountSave::Replace {
                facts: plugin_rotation_facts(&account_record("openai")),
                authentication_kind: "api_key".to_owned(),
            },
            &context("plugin-stale-auth-kind"),
        )
        .await
        .expect_err("authentication kind change must be rejected");

    assert_eq!(error.kind(), gateway_admin::model::AdminErrorKind::Conflict);
    assert_eq!(recorded(&events), ["store.credential_details"]);
    assert!(store.audit_requests().is_empty());
}

#[tokio::test]
async fn accounts_quota_refresh_should_return_the_updated_account_status() {
    let events = events();
    let provider = FakeProviderAdmin::new("openai", events.clone());
    let mut account = account_record("openai");
    account.quota = QuotaState::exhausted(
        QuotaEvidence::UsageLimitReached,
        std::time::SystemTime::now(),
        None,
    );
    let store = FakeAccountStore::with_account(account.clone(), events.clone());
    account.quota = QuotaState::allowed(std::time::SystemTime::now());
    *provider
        .quota_refresh_account
        .lock()
        .expect("quota refresh account") = Some((store.clone(), account));

    let result = accounts_service(provider, store)
        .await
        .accounts()
        .quota(
            &ProviderAccountId::new("acct_test").expect("account ID"),
            true,
        )
        .await
        .expect("refresh quota");

    assert_eq!(
        result.account.quota.access(),
        gateway_core::account::QuotaAccessState::Allowed
    );
    assert_eq!(
        result.projection.status,
        gateway_admin::model::accounts::AccountStatus::Normal
    );
    assert_eq!(
        recorded(&events),
        ["store.load_account", "provider.quota", "store.load_account"]
    );
}

#[tokio::test]
async fn accounts_recover_should_commit_facts_then_return_normal_account() {
    let events = events();
    let provider = FakeProviderAdmin::new("openai", events.clone());
    let mut account = account_record("openai");
    account.credential_state = CredentialState::Invalid;
    account.quota = QuotaState::exhausted(
        QuotaEvidence::UsageLimitReached,
        std::time::SystemTime::now(),
        None,
    );
    account.last_error_reason = Some(gateway_core::account::AccountErrorReason::CredentialInvalid);
    account.last_error_message = Some("invalid credential".to_owned());
    let store = FakeAccountStore::with_account(account, events.clone());
    let services = accounts_service(provider, store.clone()).await;

    let result = services
        .accounts()
        .recover(
            &context("recover-request"),
            ProviderAccountId::new("acct_test").expect("account ID"),
        )
        .await
        .expect("recover account");

    assert_eq!(result.config_revision, revision(2));
    assert!(result.account.account.enabled);
    assert_eq!(
        result.account.account.credential_state,
        CredentialState::Ready
    );
    assert_eq!(
        result.account.account.quota.access(),
        gateway_core::account::QuotaAccessState::Allowed
    );
    assert_eq!(
        result.account.projection.status,
        gateway_admin::model::accounts::AccountStatus::Normal
    );
    assert_eq!(
        recorded(&events),
        [
            "store.load_account",
            "store.recover_account",
            "provider.account_facts_changed",
            "store.load_account",
        ]
    );
    assert_eq!(store.audit_requests(), ["recover-request"]);
}

#[tokio::test]
async fn accounts_recover_disabled_should_only_enable_scheduling_and_preserve_quota() {
    for has_error in [false, true] {
        let events = events();
        let provider = FakeProviderAdmin::new("openai", events.clone());
        let mut account = account_record("openai");
        account.enabled = false;
        if has_error {
            account.credential_state = CredentialState::Invalid;
            account.last_error_reason =
                Some(gateway_core::account::AccountErrorReason::CredentialInvalid);
            account.last_error_message = Some("invalid credential".to_owned());
            account.quota = QuotaState::exhausted(
                QuotaEvidence::UsageLimitReached,
                std::time::SystemTime::now(),
                None,
            );
        }
        let quota = ProviderQuota {
            upstream: None,
            credits: None,
            observed_at: Some(Utc::now()),
            windows: vec![ProviderQuotaWindow {
                upstream: None,
                key: "primary".to_owned(),
                group: "shortTerm".to_owned(),
                label: "5小时限额".to_owned(),
                limit_id: None,
                limit_name: None,
                role: None,
                local_usage_attribution: QuotaLocalUsageAttribution::AccountWide,
                window_seconds: Some(5 * 60 * 60),
                used_percent: Some(92.0),
                reset_at: Some(Utc::now() + TimeDelta::hours(1)),
                limit_reached: false,
                local_usage: None,
                provider_data: None,
            }],
            ..empty_quota()
        };
        provider.set_quota(quota.clone());
        let store = FakeAccountStore::with_account(account.clone(), events.clone());
        let services = accounts_service(provider.clone(), store.clone()).await;

        let result = services
            .accounts()
            .recover(
                &context("enable-request"),
                ProviderAccountId::new("acct_test").expect("account ID"),
            )
            .await
            .expect("enable disabled account");

        account.enabled = true;
        assert_eq!(result.config_revision, revision(2));
        assert_eq!(result.account.account, account);
        assert_eq!(result.account.quota, quota);
        assert_eq!(
            result.account.projection.status,
            if has_error {
                gateway_admin::model::accounts::AccountStatus::Error
            } else {
                gateway_admin::model::accounts::AccountStatus::Normal
            }
        );
        assert_eq!(
            recorded(&events),
            [
                "store.load_account",
                "store.batch_update_accounts",
                "provider.account_facts_changed",
                "store.load_account",
            ]
        );
        assert_eq!(store.audit_requests(), ["enable-request"]);
        let requests = provider.quota_requests();
        assert_eq!(requests.len(), 1);
        assert!(!requests[0].refresh);
    }
}

#[tokio::test]
async fn accounts_recover_disabled_should_not_publish_when_enabling_fails() {
    let events = events();
    let provider = FakeProviderAdmin::new("openai", events.clone());
    let mut account = account_record("openai");
    account.enabled = false;
    let store = FakeAccountStore::with_account(account.clone(), events.clone());
    store.fail_next_commit();
    let services = accounts_service(provider, store.clone()).await;

    let result = services
        .accounts()
        .recover(
            &context("enable-failed"),
            ProviderAccountId::new("acct_test").expect("account ID"),
        )
        .await;

    assert!(result.is_err());
    assert_eq!(*store.accounts.lock().expect("accounts"), [account]);
    assert_eq!(
        recorded(&events),
        ["store.load_account", "store.batch_update_accounts"]
    );
}

#[tokio::test]
async fn accounts_update_should_commit_then_release_disabled_account_and_publish_facts() {
    let events = events();
    let provider = FakeProviderAdmin::new("openai", events.clone());
    let store = FakeAccountStore::new("openai", events.clone());
    let services = accounts_service(provider, store.clone()).await;

    let result = services
        .accounts()
        .update(
            &context("update-request"),
            UpdateAccount {
                name: None,
                notes: None,
                model_access: Default::default(),
                outbound_proxy: None,
                account_id: "acct_test".to_owned(),
                enabled: false,
                concurrency_limit: None,
                weight: gateway_core::account::AccountWeight::DEFAULT,
                group_ids: Vec::new(),
            },
        )
        .await
        .expect("update account");

    assert_eq!(result.config_revision, revision(2));
    assert_eq!(
        recorded(&events),
        [
            "store.load_account",
            "store.update_account",
            "provider.account_unavailable",
            "provider.account_facts_changed",
        ]
    );
    assert_eq!(store.audit_requests(), ["update-request"]);
}

#[tokio::test]
async fn accounts_update_should_not_notify_provider_when_store_commit_fails() {
    let events = events();
    let provider = FakeProviderAdmin::new("openai", events.clone());
    let store = FakeAccountStore::new("openai", events.clone());
    store.fail_next_commit();
    let services = accounts_service(provider, store).await;

    services
        .accounts()
        .update(
            &context("update-failure"),
            UpdateAccount {
                name: None,
                notes: None,
                model_access: Default::default(),
                outbound_proxy: None,
                account_id: "acct_test".to_owned(),
                enabled: false,
                concurrency_limit: None,
                weight: gateway_core::account::AccountWeight::DEFAULT,
                group_ids: Vec::new(),
            },
        )
        .await
        .expect_err("failed account update");

    assert_eq!(
        recorded(&events),
        ["store.load_account", "store.update_account"]
    );
}

#[tokio::test]
async fn accounts_batch_update_should_commit_once_and_notify_each_provider() {
    let events = events();
    let openai = FakeProviderAdmin::new("openai", events.clone());
    let xai = FakeProviderAdmin::new("xai", events.clone());
    let store = FakeAccountStore::new("openai", events.clone());
    let mut openai_account = account_record("openai");
    openai_account.id = "acct_openai".to_owned();
    let mut xai_account = account_record("xai");
    xai_account.id = "acct_xai".to_owned();
    store.set_accounts(vec![openai_account, xai_account]);
    let services = super::AdminHarness::new()
        .accounts(store.clone())
        .settings(Arc::new(StaticSettingsStore::default()))
        .provider(openai)
        .provider(xai)
        .probe(Arc::new(SuccessfulAccountProbe))
        .build()
        .await;

    let result = services
        .accounts()
        .batch_update(
            &context("batch-update-request"),
            BatchUpdateAccounts {
                quota_limits: None,
                auto_use_quota_credits: None,
                model_access: Default::default(),
                outbound_proxy: None,
                account_ids: vec!["acct_openai".to_owned(), "acct_xai".to_owned()],
                enabled: Some(false),
                concurrency_limit: Some(None),
                weight: Some(gateway_core::account::AccountWeight::DEFAULT),
                group_ids: Some(Vec::new()),
            },
        )
        .await
        .expect("batch update accounts");

    assert_eq!(result.config_revision, revision(2));
    assert_eq!(result.account_ids.len(), 2);
    assert_eq!(store.audit_requests(), ["batch-update-request"]);
    assert_eq!(
        recorded(&events),
        [
            "store.load_account",
            "store.load_account",
            "store.batch_update_accounts",
            "provider.account_unavailable",
            "provider.account_facts_changed",
            "provider.account_unavailable",
            "provider.account_facts_changed",
        ]
    );
}

#[tokio::test]
async fn accounts_list_should_return_complete_directory_semantics() {
    let provider = FakeProviderAdmin::new("openai", events());
    let capabilities = gateway_admin::model::accounts::ProviderAccountCapabilities {
        quota: true,
        profile: true,
        ..Default::default()
    };
    *provider.capabilities.lock().unwrap() = capabilities;
    let mut stored = account_record("openai");
    stored.plan_type = Some("  self_serve_business_prolite  ".to_owned());
    let store = FakeAccountStore::with_account(stored, events());
    let services = accounts_service(provider, store).await;
    let page = services
        .accounts()
        .list(AccountListQuery {
            page: 1,
            page_size: gateway_admin::model::PageSize::new(20).expect("page size"),
            provider_kind: None,
            group_filter: None,
            search: None,
            status: None,
            sort: None,
        })
        .await
        .expect("complete account directory");

    assert_eq!(page.summary.total, 1);
    assert_eq!(page.summary.normal, 1);
    let account = page.items.first().expect("account item");
    assert_eq!(account.capabilities, capabilities);
    assert_eq!(account.account.provider_kind.as_str(), "openai");
    assert_eq!(
        account.projection.status,
        gateway_admin::model::accounts::AccountStatus::Normal
    );
    assert_eq!(
        (
            account.account.plan_type.as_deref(),
            account.plan_type_display.as_deref(),
        ),
        (
            Some("  self_serve_business_prolite  "),
            Some("openai display: self_serve_business_prolite"),
        )
    );

    let detail = services
        .accounts()
        .quota(
            &ProviderAccountId::new("acct_test").expect("account ID"),
            false,
        )
        .await
        .expect("account detail");
    assert_eq!(detail.plan_type_display, account.plan_type_display);
    assert_eq!(detail.capabilities, account.capabilities);
    assert_eq!(detail.account.plan_type, account.account.plan_type);
}

#[tokio::test]
async fn accounts_should_fill_missing_plan_from_quota_without_overriding_known_subtypes() {
    for (stored_plan, quota_plan, expected, expected_display) in [
        (
            None,
            Some("free"),
            Some("free"),
            Some("openai display: free"),
        ),
        (
            Some("  "),
            Some("free"),
            Some("free"),
            Some("openai display: free"),
        ),
        (
            Some("unknown"),
            Some("free"),
            Some("free"),
            Some("openai display: free"),
        ),
        (
            Some("self_serve_business_prolite"),
            Some("team"),
            Some("self_serve_business_prolite"),
            Some("openai display: self_serve_business_prolite"),
        ),
        (Some("prolite"), None, Some("prolite"), Some("ProLite")),
        (Some("pro"), None, Some("pro"), Some("Pro")),
        (Some("promax"), None, Some("promax"), Some("ProMax")),
        (None, None, None, None),
    ] {
        let provider = FakeProviderAdmin::new("openai", events());
        provider.set_quota(ProviderQuota {
            upstream: None,
            plan_type: quota_plan.map(str::to_owned),
            ..empty_quota()
        });
        let mut stored = account_record("openai");
        stored.plan_type = stored_plan.map(str::to_owned);
        let store = FakeAccountStore::with_account(stored, events());
        let services = accounts_service(provider, store).await;
        let page = services
            .accounts()
            .list(AccountListQuery {
                page: 1,
                page_size: gateway_admin::model::PageSize::new(20).expect("page size"),
                provider_kind: None,
                group_filter: None,
                search: None,
                status: None,
                sort: None,
            })
            .await
            .expect("account list");
        let account = page.items.first().expect("account item");
        assert_eq!(account.account.plan_type.as_deref(), expected);
        assert_eq!(account.plan_type_display.as_deref(), expected_display);
        for refresh in [false, true] {
            let detail = services
                .accounts()
                .quota(
                    &ProviderAccountId::new("acct_test").expect("account ID"),
                    refresh,
                )
                .await
                .expect("account quota detail");
            assert_eq!(detail.account.plan_type.as_deref(), expected);
            assert_eq!(detail.plan_type_display, account.plan_type_display);
        }
    }
}

#[tokio::test]
async fn accounts_list_should_degrade_quota_failure_to_empty_window_without_dropping_page() {
    let events = events();
    let openai = FakeProviderAdmin::new("openai", events.clone());
    openai.set_quota(ProviderQuota {
        paused_windows: Vec::new(),
        upstream: None,
        credits: None,
        plan_type: None,
        observed_at: Some(Utc::now()),
        refresh_token_expires_at: None,
        windows: vec![ProviderQuotaWindow {
            upstream: None,
            key: "primary".to_owned(),
            group: "shortTerm".to_owned(),
            label: "5小时限额".to_owned(),
            limit_id: None,
            limit_name: None,
            role: None,
            local_usage_attribution: QuotaLocalUsageAttribution::AccountWide,
            window_seconds: Some(5 * 60 * 60),
            used_percent: Some(97.0),
            reset_at: Some(Utc::now() + TimeDelta::hours(1)),
            limit_reached: false,
            local_usage: None,
            provider_data: None,
        }],
        limit_reached: false,
        provider_data: None,
    });
    let failing = FakeProviderAdmin::new("xai", events.clone());
    let mut xai_quota = failing.quota.lock().expect("provider quota").clone();
    xai_quota.observed_at = Some(Utc::now());
    failing.set_quota(xai_quota);
    failing.fail_next_quota(ProviderAdminErrorKind::Invalid);
    let store = FakeAccountStore::new("openai", events.clone());
    let mut xai_account = account_record("xai");
    xai_account.id = "acct_bad_xai".to_owned();
    let mut healthy_xai = xai_account.clone();
    healthy_xai.id = "acct_healthy_xai".to_owned();
    let mut second_openai = account_record("openai");
    second_openai.id = "acct_second_openai".to_owned();
    store.set_accounts(vec![
        account_record("openai"),
        xai_account,
        second_openai,
        healthy_xai,
    ]);
    let services = super::AdminHarness::new()
        .accounts(store.clone())
        .settings(Arc::new(StaticSettingsStore::default()))
        .provider(openai)
        .provider(failing)
        .probe(Arc::new(SuccessfulAccountProbe))
        .build()
        .await;

    let page = services
        .accounts()
        .list(AccountListQuery {
            page: 1,
            page_size: gateway_admin::model::PageSize::new(20).expect("page size"),
            provider_kind: None,
            group_filter: None,
            search: None,
            status: None,
            sort: None,
        })
        .await
        .expect("one failing quota must not fail the directory page");

    assert_eq!(
        page.items
            .iter()
            .map(|item| item.account.id.as_str())
            .collect::<Vec<_>>(),
        [
            "acct_test",
            "acct_bad_xai",
            "acct_second_openai",
            "acct_healthy_xai"
        ]
    );
    let by_id = page
        .items
        .iter()
        .map(|item| (item.account.id.as_str(), item))
        .collect::<std::collections::HashMap<_, _>>();
    let healthy = by_id.get("acct_test").expect("healthy account item");
    assert_eq!(healthy.quota.windows.len(), 1);
    assert_eq!(healthy.quota.windows[0].key, "primary");
    let degraded = by_id.get("acct_bad_xai").expect("degraded account item");
    assert!(degraded.quota.windows.is_empty());
    assert!(degraded.quota.observed_at.is_none());
    assert!(degraded.quota.provider_data.is_none());
    assert!(by_id["acct_healthy_xai"].quota.observed_at.is_some());
    assert_eq!(by_id["acct_second_openai"].quota.windows.len(), 1);
    assert_eq!(page.summary.total, 4);
}

#[tokio::test]
async fn accounts_list_should_prefer_credential_error_over_quota_exhaustion() {
    let provider = FakeProviderAdmin::new("openai", events());
    let mut account = account_record("openai");
    account.quota = QuotaState::exhausted(
        QuotaEvidence::ProviderDenied,
        std::time::SystemTime::now(),
        None,
    );
    account.access_token_expires_at = Some(Utc::now() - TimeDelta::minutes(5));
    let store = FakeAccountStore::with_account(account, events());

    let page = accounts_service(provider, store)
        .await
        .accounts()
        .list(AccountListQuery {
            page: 1,
            page_size: gateway_admin::model::PageSize::new(20).expect("page size"),
            provider_kind: None,
            group_filter: None,
            search: None,
            status: None,
            sort: None,
        })
        .await
        .expect("usage-limited account directory");

    assert_eq!(
        page.items.first().expect("account item").projection.status,
        gateway_admin::model::accounts::AccountStatus::Error,
    );
}

#[tokio::test]
async fn accounts_list_should_map_unknown_credential_to_error_not_normal() {
    // Unknown 不可调度，Admin 不得显示为 normal
    let provider = FakeProviderAdmin::new("openai", events());
    let mut account = account_record("openai");
    account.credential_state = CredentialState::Unknown;
    let store = FakeAccountStore::with_account(account, events());

    let page = accounts_service(provider, store)
        .await
        .accounts()
        .list(AccountListQuery {
            page: 1,
            page_size: gateway_admin::model::PageSize::new(20).expect("page size"),
            provider_kind: None,
            group_filter: None,
            search: None,
            status: None,
            sort: None,
        })
        .await
        .expect("unknown account directory");

    assert_eq!(
        page.items.first().expect("account item").projection.status,
        gateway_admin::model::accounts::AccountStatus::Error,
    );
}

#[tokio::test]
async fn accounts_list_should_not_derive_rate_limited_from_provider_quota_view() {
    let provider = FakeProviderAdmin::new("openai", events());
    provider.set_quota(ProviderQuota {
        paused_windows: Vec::new(),
        upstream: None,
        credits: None,
        plan_type: None,
        observed_at: Some(Utc::now()),
        refresh_token_expires_at: None,
        windows: vec![ProviderQuotaWindow {
            upstream: None,
            key: "primary".to_owned(),
            group: "shortTerm".to_owned(),
            label: "5小时限额".to_owned(),
            limit_id: None,
            limit_name: None,
            role: None,
            local_usage_attribution: QuotaLocalUsageAttribution::AccountWide,
            window_seconds: Some(5 * 60 * 60),
            used_percent: Some(100.0),
            reset_at: Some(Utc::now() + TimeDelta::hours(1)),
            limit_reached: true,
            local_usage: None,
            provider_data: None,
        }],
        limit_reached: true,
        provider_data: None,
    });
    let store = FakeAccountStore::new("openai", events());

    let page = accounts_service(provider, store)
        .await
        .accounts()
        .list(AccountListQuery {
            page: 1,
            page_size: gateway_admin::model::PageSize::new(20).expect("page size"),
            provider_kind: None,
            group_filter: None,
            search: None,
            status: None,
            sort: None,
        })
        .await
        .expect("account directory with display quota cooldown");

    assert_eq!(
        page.items.first().expect("account item").projection.status,
        gateway_admin::model::accounts::AccountStatus::Normal,
    );
}

#[tokio::test]
async fn accounts_list_should_not_derive_exhaustion_from_provider_quota_view() {
    let provider = FakeProviderAdmin::new("openai", events());
    provider.set_quota(ProviderQuota {
        paused_windows: Vec::new(),
        upstream: None,
        credits: None,
        plan_type: None,
        observed_at: Some(Utc::now()),
        refresh_token_expires_at: None,
        windows: vec![ProviderQuotaWindow {
            upstream: None,
            key: "primary".to_owned(),
            group: "shortTerm".to_owned(),
            label: "5小时限额".to_owned(),
            limit_id: None,
            limit_name: None,
            role: None,
            local_usage_attribution: QuotaLocalUsageAttribution::AccountWide,
            window_seconds: Some(5 * 60 * 60),
            used_percent: Some(100.0),
            reset_at: Some(Utc::now() + TimeDelta::hours(1)),
            limit_reached: true,
            local_usage: None,
            provider_data: None,
        }],
        limit_reached: true,
        provider_data: None,
    });
    let store = FakeAccountStore::new("openai", events());

    let page = accounts_service(provider, store)
        .await
        .accounts()
        .list(AccountListQuery {
            page: 1,
            page_size: gateway_admin::model::PageSize::new(20).expect("page size"),
            provider_kind: None,
            group_filter: None,
            search: None,
            status: None,
            sort: None,
        })
        .await
        .expect("account directory with display quota limit");

    assert_eq!(
        page.items.first().expect("account item").projection.status,
        gateway_admin::model::accounts::AccountStatus::Normal,
    );
}

#[tokio::test]
async fn quota_forecast_reads_raw_snapshot_and_limits_usage_to_observation_time() {
    let provider = FakeProviderAdmin::new("openai", events());
    let now = Utc::now();
    let observed = now - TimeDelta::hours(1);
    let reset = now + TimeDelta::days(1);
    provider.set_quota(ProviderQuota {
        upstream: None,
        credits: None,
        observed_at: Some(observed),
        limit_reached: true,
        windows: vec![ProviderQuotaWindow {
            upstream: None,
            key: "week".to_owned(),
            group: "shortTerm".to_owned(),
            label: "周额度".to_owned(),
            limit_id: None,
            limit_name: None,
            role: None,
            local_usage_attribution: QuotaLocalUsageAttribution::AccountWide,
            window_seconds: Some(7 * 86_400),
            used_percent: Some(20.0),
            reset_at: Some(reset),
            limit_reached: true,
            // Provider 自带的统计不保证与快照同一时间，预测必须重新采样
            local_usage: Some(quota_local_usage("acct_test", 999_999)),
            provider_data: None,
        }],
        ..empty_quota()
    });
    let mut account = account_record("openai");
    account.created_at = now - TimeDelta::days(60);
    let store = FakeAccountStore::with_account(account, events());
    store.set_quota_window_usage(vec![AccountUsageWindowResult {
        account_id: "acct_test".to_owned(),
        key: "week".to_owned(),
        usage: quota_local_usage("acct_test", 1_000),
    }]);
    store.quota_forecast_history.lock().unwrap().usage = QuotaForecastUsage {
        request_count: 10,
        tokens: 1_000,
        known_cost_count: 10,
        ..Default::default()
    };
    let report = accounts_service(provider.clone(), store.clone())
        .await
        .accounts()
        .quota_forecast(&ProviderAccountId::new("acct_test").unwrap())
        .await
        .expect("quota forecast");
    assert_eq!(report.account_id, "acct_test");
    assert_eq!(report.forecasts[0].estimated_tokens, Some(5_000));
    assert_eq!(
        report.forecasts[0].source.as_ref().unwrap().observed_at,
        Some(observed)
    );
    assert_eq!(
        report.forecasts[1].source.as_ref().unwrap().label,
        report.forecasts[0].source.as_ref().unwrap().label,
        "缺少月窗口时两个展示周期复用同一周窗口"
    );
    let queries = store.quota_window_queries();
    assert_eq!(queries.len(), 1);
    assert_eq!(queries[0].range.start, reset - TimeDelta::days(7));
    assert_eq!(queries[0].range.end, observed);
    let requests = provider.quota_requests.lock().unwrap();
    assert_eq!(requests.len(), 1);
    assert!(!requests[0].refresh);
    assert!(requests[0].rolling_usage.is_none());
}

#[tokio::test]
async fn quota_forecast_does_not_query_usage_without_a_current_snapshot() {
    let provider = FakeProviderAdmin::new("openai", events());
    let store = FakeAccountStore::new("openai", events());
    let report = accounts_service(provider.clone(), store.clone())
        .await
        .accounts()
        .quota_forecast(&ProviderAccountId::new("acct_test").unwrap())
        .await
        .expect("empty forecast");
    assert!(
        report
            .forecasts
            .iter()
            .all(|item| item.estimated_tokens.is_none())
    );
    assert!(store.quota_window_queries().is_empty());
    assert!(!provider.quota_requests.lock().unwrap()[0].refresh);
}

#[tokio::test]
async fn quota_forecast_only_queries_the_two_selected_source_windows() {
    let provider = FakeProviderAdmin::new("openai", events());
    let now = Utc::now();
    let observed = now - TimeDelta::minutes(1);
    let reset = now + TimeDelta::days(1);
    let windows = (0..64)
        .map(|index| {
            let monthly = index % 2 == 1;
            ProviderQuotaWindow {
                upstream: None,
                key: if monthly {
                    format!("month-{index}")
                } else {
                    format!("week-{index}")
                },
                group: if monthly { "monthly" } else { "shortTerm" }.to_owned(),
                label: format!("window-{index}"),
                limit_id: None,
                limit_name: None,
                role: None,
                local_usage_attribution: QuotaLocalUsageAttribution::AccountWide,
                window_seconds: Some(if monthly { 30 } else { 7 } * 86_400),
                used_percent: Some(20.0),
                reset_at: Some(reset),
                limit_reached: false,
                local_usage: None,
                provider_data: None,
            }
        })
        .collect();
    provider.set_quota(ProviderQuota {
        upstream: None,
        plan_type: Some("pro".to_owned()),
        observed_at: Some(observed),
        windows,
        ..empty_quota()
    });
    let mut account = account_record("openai");
    account.created_at = now - TimeDelta::days(60);
    let store = FakeAccountStore::with_account(account, events());
    let report = accounts_service(provider, store.clone())
        .await
        .accounts()
        .quota_forecast(&ProviderAccountId::new("acct_test").unwrap())
        .await
        .expect("quota forecast");

    let queries = store.quota_window_queries();
    assert_eq!(
        queries
            .iter()
            .map(|query| query.key.as_str())
            .collect::<Vec<_>>(),
        ["week-0", "month-1"]
    );
    assert_eq!(
        report.forecasts[0].source.as_ref().unwrap().label,
        "window-0"
    );
    assert_eq!(
        report.forecasts[1].source.as_ref().unwrap().label,
        "window-1"
    );
}

#[tokio::test]
async fn quota_forecast_same_window_reversal_keeps_recorded_usage_in_the_report() {
    use gateway_admin::model::quota_forecast_sampling::QuotaForecastHistoryPoint;

    for (percents, tokens, expected_tokens, expected_usd) in [
        ([32.0, 30.0, 35.0], [100, 120, 140], 400, 0.4),
        (
            [100.0, 99.0, 99.5],
            [10_000, 10_010, 10_020],
            10_070,
            10.02 / 0.995,
        ),
    ] {
        let now = Utc::now();
        let observed = now - TimeDelta::minutes(1);
        let reset = now + TimeDelta::days(1);
        let provider = FakeProviderAdmin::new("openai", events());
        provider.set_quota(ProviderQuota {
            upstream: None,
            plan_type: Some("pro".to_owned()),
            observed_at: Some(observed),
            windows: vec![ProviderQuotaWindow {
                upstream: None,
                key: "week".to_owned(),
                group: "shortTerm".to_owned(),
                label: "周额度".to_owned(),
                limit_id: None,
                limit_name: None,
                role: None,
                local_usage_attribution: QuotaLocalUsageAttribution::AccountWide,
                window_seconds: Some(604_800),
                used_percent: Some(percents[2]),
                reset_at: Some(reset),
                limit_reached: false,
                local_usage: None,
                provider_data: None,
            }],
            ..empty_quota()
        });
        let mut account = account_record("openai");
        account.created_at = now - TimeDelta::days(7);
        let store = FakeAccountStore::with_account(account, events());
        let usage = |requests, tokens| QuotaForecastUsage {
            request_count: requests,
            tokens,
            input_tokens: tokens,
            known_cost_count: requests,
            usd: tokens as f64 / 1_000.0,
            ..Default::default()
        };
        *store.quota_forecast_history.lock().unwrap() = QuotaForecastHistory {
            points: [(3, percents[0], tokens[0]), (2, percents[1], tokens[1])]
                .into_iter()
                .enumerate()
                .map(
                    |(index, (minutes, percent, tokens))| QuotaForecastHistoryPoint {
                        started_at: now - TimeDelta::minutes(5),
                        completed_at: now - TimeDelta::minutes(minutes),
                        usage: usage(index as u64 + 1, tokens),
                        provider_observation: ProviderDocument::new(OpaqueProviderData::new(
                            serde_json::json!({
                                "percent": percent, "reset": reset.to_rfc3339(), "plan": "pro",
                            })
                            .as_object()
                            .unwrap()
                            .clone(),
                        )),
                    },
                )
                .collect(),
            usage: usage(3, tokens[2]),
            pending_request_count: 0,
        };
        let services = accounts_service(provider, store).await;
        let result = services
            .accounts()
            .quota_forecast(&ProviderAccountId::new("acct_test").unwrap())
            .await
            .unwrap();
        let forecast = &result.forecasts[0];
        let source = forecast.source.as_ref().unwrap();
        assert_eq!(source.tokens, Some(tokens[2]));
        assert!((source.usd.unwrap() - tokens[2] as f64 / 1_000.0).abs() < 1e-10);
        assert_eq!(forecast.estimated_tokens, Some(expected_tokens));
        assert!((forecast.estimated_usd.unwrap() - expected_usd).abs() < 1e-10);
        assert!(forecast.unavailable_reason.is_none());
    }
}

#[tokio::test]
async fn quota_forecast_mid_cycle_sampling_accepts_small_reset_jitter_but_not_a_changed_bucket() {
    use gateway_admin::model::quota_forecast_sampling::QuotaForecastHistoryPoint;
    let now = Utc::now();
    let observed = now - TimeDelta::minutes(1);
    let reset = now + TimeDelta::days(1);
    let added = now - TimeDelta::hours(5);
    let provider = FakeProviderAdmin::new("openai", events());
    provider.set_quota(ProviderQuota {
        upstream: None,
        credits: None,
        plan_type: Some("pro".to_owned()),
        observed_at: Some(observed),
        windows: vec![ProviderQuotaWindow {
            upstream: None,
            key: "week".to_owned(),
            group: "shortTerm".to_owned(),
            label: "周额度".to_owned(),
            limit_id: None,
            limit_name: None,
            role: None,
            local_usage_attribution: QuotaLocalUsageAttribution::AccountWide,
            window_seconds: Some(604_800),
            used_percent: Some(40.0),
            reset_at: Some(reset),
            limit_reached: false,
            local_usage: None,
            provider_data: None,
        }],
        ..empty_quota()
    });
    let mut account = account_record("openai");
    account.created_at = added;
    let store = FakeAccountStore::with_account(account, events());
    let make_point = |hours, percent, tokens, delta| {
        QuotaForecastHistoryPoint {
        started_at: now - TimeDelta::hours(hours) - TimeDelta::seconds(10),
        completed_at: now - TimeDelta::hours(hours),
        usage: QuotaForecastUsage { request_count: tokens / 100, tokens, ..Default::default() },
        provider_observation: ProviderDocument::new(OpaqueProviderData::new(serde_json::json!({
            "percent": percent, "reset": (reset + TimeDelta::seconds(delta)).to_rfc3339(), "plan": "pro",
        }).as_object().unwrap().clone())),
    }
    };
    *store.quota_forecast_history.lock().unwrap() = QuotaForecastHistory {
        points: vec![
            make_point(3, 20.0, 1_000, 1),
            make_point(2, 30.0, 1_500, -1),
        ],
        usage: QuotaForecastUsage {
            request_count: 20,
            tokens: 2_000,
            ..Default::default()
        },
        pending_request_count: 1,
    };
    let services = accounts_service(provider, store.clone()).await;
    let result = services
        .accounts()
        .quota_forecast(&ProviderAccountId::new("acct_test").unwrap())
        .await
        .unwrap();
    assert!(result.forecasts[0].unavailable_reason.is_none());
    assert_eq!(result.forecasts[0].estimated_tokens, Some(5_000));
    assert_eq!(store.quota_window_queries()[0].range.start, added);
    store
        .quota_forecast_history
        .lock()
        .unwrap()
        .points
        .push(make_point(1, 35.0, 1_700, 3_600));
    let result = services
        .accounts()
        .quota_forecast(&ProviderAccountId::new("acct_test").unwrap())
        .await
        .unwrap();
    assert!(result.forecasts[0].estimated_tokens.is_none());
    assert!(
        result.forecasts[0]
            .unavailable_reason
            .unwrap()
            .contains("不连续")
    );
    // 新额度段已有足够观测后恢复预测，但总量不能带回重置前的累计用量
    let mut first = make_point(1, 5.0, 1_750, 0);
    first.completed_at = now - TimeDelta::minutes(45);
    first.started_at = first.completed_at - TimeDelta::seconds(10);
    let mut next = make_point(1, 20.0, 1_900, 0);
    next.completed_at = now - TimeDelta::minutes(20);
    next.started_at = next.completed_at - TimeDelta::seconds(10);
    store
        .quota_forecast_history
        .lock()
        .unwrap()
        .points
        .extend([first, next]);
    let result = services
        .accounts()
        .quota_forecast(&ProviderAccountId::new("acct_test").unwrap())
        .await
        .unwrap();
    let cycle = &result.forecasts[0];
    assert!(cycle.unavailable_reason.is_none());
    assert_eq!(cycle.source.as_ref().unwrap().tokens, Some(250));
    assert_eq!(cycle.estimated_tokens, Some(679));
}

#[tokio::test]
async fn peer_account_usage_should_follow_budget_windows_without_borrowing_pool_windows() {
    use gateway_admin::model::upstream_info::{
        ProviderUpstreamInfo, UpstreamQuotaAmount, UpstreamQuotaWindow,
    };

    for longest in [86_400, 604_800] {
        let provider = FakeProviderAdmin::new("openai", events());
        let mut account = account_record("openai");
        account.concurrency_limit = None;
        account.authentication_kind = "api_key".to_owned();
        account.created_at = Utc::now() - TimeDelta::days(60);
        let store = FakeAccountStore::with_account(account, events());
        let reset_at = Utc::now() + TimeDelta::hours(1);
        let mut quota = empty_quota();
        quota.upstream = Some(ProviderUpstreamInfo {
            max_concurrency: Some(7),
            requests_per_minute: Some(60),
            discovered: true,
            observed_at: Some(Utc::now()),
            stale: false,
            connection_revision: "1".to_owned(),
            last_error: None,
            pool: None,
        });
        quota.windows = [86_400, 604_800, 30 * 86_400]
            .into_iter()
            .filter(|seconds| *seconds <= longest || *seconds == 30 * 86_400)
            .map(|seconds| ProviderQuotaWindow {
                upstream: Some(UpstreamQuotaWindow {
                    account_id: None,
                    observed_at: Some(Utc::now()),
                    stale: false,
                    amount: (seconds <= longest).then(|| UpstreamQuotaAmount {
                        unit: "USD".to_owned(),
                        used: "1".to_owned(),
                        remaining: Some("9".to_owned()),
                        total: Some("10".to_owned()),
                    }),
                }),
                key: seconds.to_string(),
                group: "general".to_owned(),
                label: "额度".to_owned(),
                limit_id: None,
                limit_name: None,
                role: None,
                local_usage_attribution: if seconds <= longest {
                    QuotaLocalUsageAttribution::AccountWide
                } else {
                    QuotaLocalUsageAttribution::Unavailable
                },
                window_seconds: Some(seconds),
                used_percent: Some(10.0),
                reset_at: Some(reset_at),
                limit_reached: false,
                local_usage: None,
                provider_data: None,
            })
            .collect();
        provider.set_quota(quota.clone());
        let window_usage = [86_400, 604_800]
            .into_iter()
            .filter(|seconds| *seconds <= longest)
            .map(|seconds| AccountUsageWindowResult {
                account_id: "acct_test".to_owned(),
                key: seconds.to_string(),
                usage: quota_local_usage("acct_test", if seconds == longest { 1_234 } else { 123 }),
            })
            .collect::<Vec<_>>();
        store.set_quota_window_usage(window_usage.clone());
        let services = accounts_service(provider.clone(), store.clone()).await;
        let page = services
            .accounts()
            .list(AccountListQuery {
                page: 1,
                page_size: gateway_admin::model::PageSize::new(20).unwrap(),
                provider_kind: None,
                group_filter: None,
                search: None,
                status: None,
                sort: None,
            })
            .await
            .unwrap();
        assert_eq!(
            page.items[0].usage.as_ref().unwrap().total_tokens,
            Some(1_234)
        );
        assert_eq!(page.items[0].capacity.total_slots, Some(7));
        assert_eq!(page.items[0].account.concurrency_limit, None);
        let queries = store.quota_window_queries();
        assert_eq!(queries.len(), window_usage.len());
        for (query, expected) in queries.iter().zip(&window_usage) {
            assert_eq!(query.key, expected.key);
            assert_eq!(
                query.range.start,
                reset_at - TimeDelta::seconds(query.key.parse().unwrap())
            );
            assert_eq!(query.range.end, reset_at);
            let window = page.items[0]
                .quota
                .windows
                .iter()
                .find(|window| window.key == query.key)
                .unwrap();
            assert_eq!(window.local_usage.as_ref(), Some(&expected.usage));
            assert_eq!(window.used_percent, Some(10.0));
            assert_eq!(
                window
                    .upstream
                    .as_ref()
                    .unwrap()
                    .amount
                    .as_ref()
                    .unwrap()
                    .used,
                "1"
            );
        }
        assert!(
            page.items[0]
                .quota
                .windows
                .last()
                .unwrap()
                .local_usage
                .is_none()
        );
        let id = ProviderAccountId::new("acct_test").unwrap();
        let detail = services.accounts().quota(&id, false).await.unwrap();
        assert_eq!(detail.usage, page.items[0].usage);
        assert_eq!(detail.quota.windows, page.items[0].quota.windows);
        assert_eq!(store.quota_window_queries()[0].range, queries[0].range);

        quota
            .windows
            .iter_mut()
            .find(|window| window.window_seconds == Some(longest))
            .unwrap()
            .reset_at = None;
        provider.set_quota(quota);
        store.set_quota_window_usage(
            window_usage
                .into_iter()
                .filter(|usage| usage.key != longest.to_string())
                .collect(),
        );
        let unopened = services.accounts().quota(&id, false).await.unwrap();
        assert!(
            unopened.usage.is_none(),
            "未开启的最长窗口不能借用日窗口或历史累计"
        );
    }
}

#[tokio::test]
async fn api_key_list_and_detail_should_accumulate_local_usage_without_subscription_windows() {
    let provider = FakeProviderAdmin::new("openai", events());
    let mut account = account_record("openai");
    account.authentication_kind = "api_key".to_owned();
    account.created_at = Utc::now() - TimeDelta::days(60);
    let added_at = account.created_at;
    let store = FakeAccountStore::with_account(account, events());
    store.set_quota_window_usage(vec![AccountUsageWindowResult {
        account_id: "acct_test".to_owned(),
        key: "account-lifetime".to_owned(),
        usage: quota_local_usage("acct_test", 4_330_000),
    }]);
    let services = accounts_service(provider, store.clone()).await;
    let page = services
        .accounts()
        .list(AccountListQuery {
            page: 1,
            page_size: gateway_admin::model::PageSize::new(20).unwrap(),
            provider_kind: None,
            group_filter: None,
            search: None,
            status: None,
            sort: None,
        })
        .await
        .unwrap();
    assert!(page.items[0].quota.windows.is_empty());
    assert_eq!(
        page.items[0].usage.as_ref().unwrap().total_tokens,
        Some(4_330_000)
    );
    let queries = store.quota_window_queries();
    assert_eq!(queries.len(), 1);
    assert_eq!(queries[0].range.start, added_at);
    assert!(queries[0].range.end > added_at + TimeDelta::days(59));
    let detail = services
        .accounts()
        .quota(&ProviderAccountId::new("acct_test").unwrap(), false)
        .await
        .unwrap();
    assert_eq!(detail.usage, page.items[0].usage);
    assert!(detail.quota.windows.is_empty());
    assert_eq!(store.quota_window_queries()[0].range.start, added_at);
}

#[tokio::test]
async fn accounts_list_should_attach_local_usage_to_quota_windows() {
    let provider = FakeProviderAdmin::new("openai", events());
    let reset_at = Utc::now() + TimeDelta::hours(1);
    provider.set_quota(ProviderQuota {
        paused_windows: Vec::new(),
        upstream: None,
        credits: None,
        plan_type: None,
        observed_at: Some(Utc::now()),
        refresh_token_expires_at: None,
        windows: vec![ProviderQuotaWindow {
            upstream: None,
            key: "primary".to_owned(),
            group: "shortTerm".to_owned(),
            label: "5小时限额".to_owned(),
            limit_id: None,
            limit_name: None,
            role: None,
            local_usage_attribution: QuotaLocalUsageAttribution::AccountWide,
            window_seconds: Some(5 * 60 * 60),
            used_percent: Some(97.0),
            reset_at: Some(reset_at),
            limit_reached: false,
            local_usage: None,
            provider_data: None,
        }],
        limit_reached: false,
        provider_data: None,
    });
    let store = FakeAccountStore::new("openai", events());
    store.set_quota_window_usage(vec![AccountUsageWindowResult {
        account_id: "acct_test".to_owned(),
        key: "primary".to_owned(),
        usage: quota_local_usage("acct_test", 4_330_000),
    }]);

    let page = accounts_service(provider, store.clone())
        .await
        .accounts()
        .list(AccountListQuery {
            page: 1,
            page_size: gateway_admin::model::PageSize::new(20).expect("page size"),
            provider_kind: None,
            group_filter: None,
            search: None,
            status: None,
            sort: None,
        })
        .await
        .expect("quota window usage");

    let item = &page.items[0];
    let usage = item.quota.windows[0]
        .local_usage
        .as_ref()
        .expect("quota window local usage");
    assert_eq!(usage.total_tokens, Some(4_330_000));
    // 短期额度条保留自己的本地用量，但不作为周/月统计面板的回退
    assert!(item.usage.is_none());

    let queries = store.quota_window_queries();
    assert_eq!(queries.len(), 1);
    assert_eq!(queries[0].account_id, "acct_test");
    assert_eq!(queries[0].key, "primary");
    assert_eq!(queries[0].range.start, reset_at - TimeDelta::hours(5));
    assert_eq!(queries[0].range.end, reset_at);
}

#[tokio::test]
async fn accounts_list_and_quota_refresh_should_select_the_same_weekly_or_monthly_usage() {
    let provider = FakeProviderAdmin::new("openai", events());
    let store = FakeAccountStore::new("openai", events());
    let services = accounts_service(provider.clone(), store.clone()).await;
    let account_id = ProviderAccountId::new("acct_test").expect("account id");
    let reset_at = Utc::now() + TimeDelta::days(1);
    let short = ProviderQuotaWindow {
        upstream: None,
        key: "short".to_owned(),
        group: "shortTerm".to_owned(),
        label: "5小时限额".to_owned(),
        limit_id: None,
        limit_name: None,
        role: None,
        local_usage_attribution: QuotaLocalUsageAttribution::AccountWide,
        window_seconds: Some(18_000),
        used_percent: Some(50.0),
        reset_at: Some(reset_at),
        limit_reached: false,
        local_usage: None,
        provider_data: None,
    };
    let week = ProviderQuotaWindow {
        upstream: None,
        key: "week".to_owned(),
        label: "周额度".to_owned(),
        window_seconds: Some(7 * 86_400),
        ..short.clone()
    };
    let month = ProviderQuotaWindow {
        upstream: None,
        key: "month".to_owned(),
        group: "monthly".to_owned(),
        label: "月额度".to_owned(),
        window_seconds: Some(30 * 86_400),
        ..short.clone()
    };
    for (windows, selected_key, tokens, duration) in [
        (vec![short.clone(), month.clone(), week], "week", 700, 7),
        (vec![short, month], "month", 3000, 30),
    ] {
        provider.set_quota(ProviderQuota {
            upstream: None,
            windows,
            ..empty_quota()
        });
        store.set_quota_window_usage(
            [("short", 50), ("week", 700), ("month", 3000)]
                .into_iter()
                .map(|(key, total)| AccountUsageWindowResult {
                    account_id: account_id.to_string(),
                    key: key.to_owned(),
                    usage: quota_local_usage(account_id.as_str(), total),
                })
                .collect(),
        );
        let page = services
            .accounts()
            .list(AccountListQuery {
                page: 1,
                page_size: gateway_admin::model::PageSize::new(20).expect("page size"),
                provider_kind: None,
                group_filter: None,
                search: None,
                status: None,
                sort: None,
            })
            .await
            .expect("list accounts");
        let refreshed = services
            .accounts()
            .quota(&account_id, true)
            .await
            .expect("refresh quota");
        let expected = quota_local_usage(account_id.as_str(), tokens);
        for item in [&page.items[0], &refreshed] {
            let usage = item.usage.as_ref().expect("selected window usage");
            assert_eq!(usage.total_tokens, expected.total_tokens);
            assert_eq!(
                item.quota
                    .usage_window()
                    .map(|(window, _)| window.key.as_str()),
                Some(selected_key)
            );
        }
        let queries = store.quota_window_queries();
        let selected = queries
            .iter()
            .find(|query| query.key == selected_key)
            .expect("selected query");
        assert_eq!(selected.range.start, reset_at - TimeDelta::days(duration));
        assert_eq!(selected.range.end, reset_at);
    }
}

#[tokio::test]
async fn accounts_list_should_not_attach_account_usage_to_model_specific_quota_windows() {
    let provider = FakeProviderAdmin::new("openai", events());
    let reset_at = Utc::now() + TimeDelta::days(7);
    provider.set_quota(ProviderQuota {
        paused_windows: Vec::new(),
        upstream: None,
        credits: None,
        plan_type: None,
        observed_at: Some(Utc::now()),
        refresh_token_expires_at: None,
        windows: vec![
            ProviderQuotaWindow {
                upstream: None,
                key: "core-primary".to_owned(),
                group: "weekly".to_owned(),
                label: "周额度".to_owned(),
                limit_id: Some("codex".to_owned()),
                limit_name: None,
                role: None,
                local_usage_attribution: QuotaLocalUsageAttribution::AccountWide,
                window_seconds: Some(7 * 24 * 60 * 60),
                used_percent: Some(1.0),
                reset_at: Some(reset_at),
                limit_reached: false,
                local_usage: None,
                provider_data: None,
            },
            ProviderQuotaWindow {
                upstream: None,
                key: "codex-bengalfox-primary".to_owned(),
                group: "weekly".to_owned(),
                label: "周额度".to_owned(),
                limit_id: Some("codex_bengalfox".to_owned()),
                limit_name: Some("GPT-5.3-Codex-Spark".to_owned()),
                role: None,
                local_usage_attribution: QuotaLocalUsageAttribution::Unavailable,
                window_seconds: Some(7 * 24 * 60 * 60),
                used_percent: Some(0.0),
                reset_at: Some(reset_at),
                limit_reached: false,
                local_usage: None,
                provider_data: None,
            },
        ],
        limit_reached: false,
        provider_data: None,
    });
    let store = FakeAccountStore::new("openai", events());
    store.set_quota_window_usage(vec![
        AccountUsageWindowResult {
            account_id: "acct_test".to_owned(),
            key: "core-primary".to_owned(),
            usage: quota_local_usage("acct_test", 12_818_806),
        },
        AccountUsageWindowResult {
            account_id: "acct_test".to_owned(),
            key: "codex-bengalfox-primary".to_owned(),
            usage: quota_local_usage("acct_test", 127_926),
        },
    ]);

    let page = accounts_service(provider, store)
        .await
        .accounts()
        .list(AccountListQuery {
            page: 1,
            page_size: gateway_admin::model::PageSize::new(20).expect("page size"),
            provider_kind: None,
            group_filter: None,
            search: None,
            status: None,
            sort: None,
        })
        .await
        .expect("quota window usage");

    let local_tokens = page.items[0]
        .quota
        .windows
        .iter()
        .map(|window| {
            (
                window.key.as_str(),
                window
                    .local_usage
                    .as_ref()
                    .and_then(|usage| usage.total_tokens),
            )
        })
        .collect::<Vec<_>>();
    assert_eq!(
        local_tokens,
        [
            ("core-primary", Some(12_818_806)),
            ("codex-bengalfox-primary", None),
        ],
    );
    assert_eq!(
        page.items[0]
            .usage
            .as_ref()
            .and_then(|usage| usage.total_tokens),
        Some(12_818_806),
    );
}

#[tokio::test]
async fn accounts_refresh_provider_failure_should_not_call_store_commit() {
    let events = events();
    let provider = FakeProviderAdmin::new("openai", events.clone());
    provider.fail_next(ProviderAdminErrorKind::Unavailable);
    let store = FakeAccountStore::new("openai", events.clone());
    let services = accounts_service(provider, store).await;

    services
        .accounts()
        .refresh(
            &context("refresh-provider-error"),
            ProviderAccountId::new("acct_test").expect("account ID"),
        )
        .await
        .expect_err("Provider preparation must fail");

    assert_eq!(
        recorded(&events),
        ["store.load_account", "provider.prepare_refresh"]
    );
}

#[tokio::test]
async fn reset_credit_oauth_refresh_should_reuse_the_exact_consume_command() {
    let events = events();
    let provider = FakeProviderAdmin::new("openai", events.clone());
    provider.fail_next(ProviderAdminErrorKind::CredentialRefreshRequired);
    let store = FakeAccountStore::new("openai", events.clone());
    let services = accounts_service(provider.clone(), store).await;
    let redeem_request_id =
        uuid::Uuid::parse_str("8fbf302d-11df-4bd5-82e4-08e4b3df7874").expect("UUID v4");
    let command = ConsumeProviderResetCredit {
        account_id: ProviderAccountId::new("acct_test").expect("account ID"),
        credit_id: Some("credit_1".to_owned()),
        redeem_request_id,
    };

    let result = services
        .accounts()
        .consume_reset_credit(&context("reset-credit-refresh"), command.clone())
        .await
        .expect("consume after OAuth refresh");

    assert_eq!(result.code, "reset");
    assert_eq!(provider.reset_credit_commands(), [command.clone(), command]);
    assert!(recorded(&events).contains(&"provider.prepare_refresh"));
    assert!(recorded(&events).contains(&"store.commit_refresh"));
}

#[tokio::test]
async fn reset_credit_refresh_without_quota_should_complete_with_the_same_command() {
    let events = events();
    let provider = FakeProviderAdmin::new("example", events.clone());
    provider.fail_next(ProviderAdminErrorKind::CredentialRefreshRequired);
    *provider.quota_failure.lock().unwrap() = Some(ProviderAdminErrorKind::Unsupported);
    let store = FakeAccountStore::new("example", events.clone());
    let services = accounts_service(provider.clone(), store).await;
    let command = ConsumeProviderResetCredit {
        account_id: ProviderAccountId::new("acct_test").unwrap(),
        credit_id: Some("credit_1".into()),
        redeem_request_id: uuid::Uuid::parse_str("dbabeb20-040e-4e9f-8615-0b7c81e79987").unwrap(),
    };

    let result = services
        .accounts()
        .consume_reset_credit(&context("reset-without-quota"), command.clone())
        .await
        .expect("缺少可选额度能力不能中断凭据刷新后的消费重试");

    assert_eq!(result.code, "reset");
    assert_eq!(provider.reset_credit_commands(), [command.clone(), command]);
    assert_eq!(
        recorded(&events)
            .iter()
            .filter(|event| **event == "store.commit_refresh")
            .count(),
        1
    );
}

#[tokio::test]
async fn accounts_quota_refresh_should_still_reject_an_unsupported_operation() {
    let provider = FakeProviderAdmin::new("example", events());
    *provider.quota_failure.lock().unwrap() = Some(ProviderAdminErrorKind::Unsupported);
    let services = accounts_service(provider, FakeAccountStore::new("example", events())).await;

    let error = services
        .accounts()
        .quota(&ProviderAccountId::new("acct_test").unwrap(), true)
        .await
        .expect_err("显式刷新不能被解释为空额度投影");

    assert_eq!(error.kind(), gateway_admin::model::AdminErrorKind::Invalid);
}

#[tokio::test]
async fn reset_credit_unknown_result_should_keep_a_stable_admin_kind() {
    let events = events();
    let provider = FakeProviderAdmin::new("openai", events.clone());
    provider.fail_next(ProviderAdminErrorKind::Ambiguous);
    let store = FakeAccountStore::new("openai", events);
    let services = accounts_service(provider, store).await;
    let command = ConsumeProviderResetCredit {
        account_id: ProviderAccountId::new("acct_test").expect("account ID"),
        credit_id: Some("credit_1".to_owned()),
        redeem_request_id: uuid::Uuid::parse_str("244e790c-42a3-4ec9-a45d-a32b218bc8ac")
            .expect("UUID v4"),
    };

    let error = services
        .accounts()
        .consume_reset_credit(&context("reset-credit-ambiguous"), command)
        .await
        .expect_err("ambiguous consume result must remain classified");

    assert_eq!(
        error.kind(),
        gateway_admin::model::AdminErrorKind::UpstreamResultUnknown
    );
    assert_eq!(
        error.to_string(),
        "上游执行结果未知，请刷新状态后再决定是否重试"
    );
}

#[tokio::test]
async fn accounts_refresh_should_not_expose_the_provider_failure_message() {
    let events = events();
    let provider = FakeProviderAdmin::new("openai", events.clone());
    let upstream_message = "Your refresh token has already been used.";
    provider.fail_next_with_message(ProviderAdminErrorKind::Conflict, upstream_message);
    let store = FakeAccountStore::new("openai", events.clone());
    let services = accounts_service(provider, store).await;

    let error = services
        .accounts()
        .refresh(
            &context("refresh-provider-message"),
            ProviderAccountId::new("acct_test").expect("account ID"),
        )
        .await
        .expect_err("Provider preparation must fail");

    assert_eq!(error.kind(), gateway_admin::model::AdminErrorKind::Conflict);
    assert_eq!(error.to_string(), "服务商资源状态冲突，请刷新后重试");
    assert!(!error.to_string().contains(upstream_message));
    assert_eq!(
        recorded(&events),
        ["store.load_account", "provider.prepare_refresh"]
    );
}

#[tokio::test]
async fn accounts_refresh_store_failure_should_drop_guard_after_commit_attempt() {
    let events = events();
    let provider = FakeProviderAdmin::new("openai", events.clone());
    let store = FakeAccountStore::new("openai", events.clone());
    store.fail_next_commit();
    let services = accounts_service(provider, store).await;

    services
        .accounts()
        .refresh(
            &context("refresh-store-error"),
            ProviderAccountId::new("acct_test").expect("account ID"),
        )
        .await
        .expect_err("Store commit must fail");

    assert_eq!(
        recorded(&events),
        [
            "store.load_account",
            "provider.prepare_refresh",
            "store.commit_refresh",
            "guard.drop",
        ]
    );
}

pub(super) fn events() -> EventLog {
    Arc::new(Mutex::new(Vec::new()))
}

pub(super) fn recorded(events: &EventLog) -> Vec<&'static str> {
    events.lock().expect("recorded events").clone()
}

pub(super) fn context(request_id: &str) -> MutationContext {
    MutationContext {
        actor: gateway_admin::model::MutationActor::AdminSession {
            admin_user_id: "admin-test".to_owned(),
        },
        request_id: request_id.to_owned(),
    }
}

pub(super) fn document() -> ProviderDocument {
    ProviderDocument::new(OpaqueProviderData::new(Default::default()))
}

fn empty_quota() -> ProviderQuota {
    ProviderQuota {
        paused_windows: Vec::new(),
        upstream: None,
        credits: None,
        plan_type: None,
        observed_at: None,
        refresh_token_expires_at: None,
        windows: Vec::new(),
        limit_reached: false,
        provider_data: None,
    }
}

fn quota_local_usage(account_id: &str, total_tokens: u64) -> AccountUsage {
    AccountUsage {
        account_id: account_id.to_owned(),
        request_count: 1,
        success_count: 1,
        input_tokens: Some(total_tokens),
        output_tokens: Some(0),
        cached_input_tokens: Some(0),
        cache_write_input_tokens: Some(0),
        reasoning_output_tokens: Some(0),
        image_input_tokens: Some(0),
        image_output_tokens: Some(0),
        image_request_count: 0,
        image_request_failed_count: 0,
        total_tokens: Some(total_tokens),
        cost_coverage: Default::default(),
        costs: Vec::new(),
        last_used_at: Some(Utc::now()),
        request_buckets: Vec::new(),
        models: Vec::new(),
    }
}

pub(super) fn account_record(kind: &str) -> AccountRecord {
    let now = Utc::now();
    AccountRecord {
        quota_paused: false,
        quota_limits: Default::default(),
        auto_use_quota_credits: false,
        outbound_proxy_id: None,
        outbound_proxy_enabled: true,
        notes: None,
        model_access: Default::default(),
        outbound_proxy: None,
        id: "acct_test".to_owned(),
        provider_kind: ProviderKind::new(kind).expect("provider kind"),
        groups: Vec::new(),
        name: "test account".to_owned(),
        email: Some("test@example.invalid".to_owned()),
        upstream_user_id: Some("upstream-user".to_owned()),
        upstream_account_id: None,
        plan_type: Some("test".to_owned()),
        authentication_kind: "oauth".to_owned(),
        credential_revision: revision(1),
        has_refresh_token: true,
        access_token_expires_at: Some(now + TimeDelta::hours(1)),
        next_refresh_at: Some(now + TimeDelta::minutes(30)),
        enabled: true,
        concurrency_limit: None,
        weight: gateway_core::account::AccountWeight::DEFAULT,
        credential_state: CredentialState::Ready,
        credential_observed_at: now,
        quota: QuotaState::allowed(now.into()),
        last_error_reason: None,
        last_error_message: None,
        created_at: now,
        updated_at: now,
    }
}

pub(super) fn revision(value: u64) -> Revision {
    Revision::new(value).expect("positive revision")
}

fn prepared_create(provider_kind: ProviderKind, name: &str) -> PreparedCredentialCreate {
    prepared_create_with_id(provider_kind, "acct_prepared", name)
}

pub(super) fn prepared_create_with_id(
    provider_kind: ProviderKind,
    account_id: &str,
    name: &str,
) -> PreparedCredentialCreate {
    let now = Utc::now();
    PreparedCredentialCreate {
        model_access: Default::default(),
        outbound_proxy: None,
        account_id: ProviderAccountId::new(account_id).expect("prepared account ID"),
        provider_kind,
        name: name.to_owned(),
        email: Some("prepared@example.invalid".to_owned()),
        upstream_user_id: Some("prepared-user".to_owned()),
        upstream_account_id: None,
        plan_type: Some("test".to_owned()),
        authentication_kind: "oauth".to_owned(),
        provider_material: document(),
        has_refresh_token: true,
        access_token_expires_at: Some(now + TimeDelta::hours(1)),
        next_refresh_at: Some(now + TimeDelta::minutes(30)),
        enabled: true,
        credential_state: CredentialState::Ready,
        credential_observed_at: now,
    }
}

fn rotation_result(command: CredentialRotationCommit) -> CredentialMutationResult {
    CredentialMutationResult {
        config_revision: revision(2),
        account_id: command.prepared.account_id,
        credential_revision: Some(revision(
            command.prepared.expected_credential_revision.get() + 1,
        )),
    }
}

fn plugin_rotation_facts(account: &AccountRecord) -> PreparedCredentialRotationFacts {
    PreparedCredentialRotationFacts {
        account_id: ProviderAccountId::new(account.id.clone()).expect("account ID"),
        provider_kind: account.provider_kind.clone(),
        expected_credential_revision: account.credential_revision,
        replacement_identity: None,
        name: "plugin refreshed account".to_owned(),
        email: account.email.clone(),
        plan_type: account.plan_type.clone(),
        preserve_profile: true,
        preserve_credential_state: false,
        provider_material: document(),
        has_refresh_token: account.has_refresh_token,
        access_token_expires_at: account.access_token_expires_at,
        next_refresh_at: account.next_refresh_at,
    }
}

fn empty_profile_statistics() -> ProviderProfileStatistics {
    ProviderProfileStatistics {
        display_name: Some("Preview user".to_owned()),
        username: None,
        image_url: None,
        has_stats_error: false,
        summary: ProviderProfileStatisticsSummary {
            total_text_tokens: Some(123),
            peak_tokens: None,
            longest_task_duration_ms: None,
            current_streak_days: None,
            longest_streak_days: None,
        },
        daily_usage: None,
        activity_insights: ProviderProfileActivityInsights {
            fast_mode_percent: None,
            reasoning_effort: None,
            reasoning_effort_percent: None,
            skills_explored: None,
            total_skills_used: None,
            total_threads: None,
            invocations: None,
        },
    }
}

fn personal_info_subscription() -> ProviderSubscription {
    ProviderSubscription {
        starts_at: None,
        expires_at: Utc::now(),
        will_renew: Some(true),
        billing_period: Some("monthly".to_owned()),
        billing_currency: Some("USD".to_owned()),
        observed_at: Utc::now(),
    }
}

#[tokio::test]
async fn personal_info_should_query_both_parts_concurrently_once_on_every_request() {
    let events = events();
    let provider = FakeProviderAdmin::new("openai", events.clone());
    let subscription = personal_info_subscription();
    *provider.subscription_result.lock().unwrap() = Ok(Some(subscription.clone()));
    *provider.personal_info_barrier.lock().unwrap() = Some(Arc::new(tokio::sync::Barrier::new(2)));
    let store = FakeAccountStore::new("openai", events.clone());
    let services = accounts_service(provider, store).await;
    let account_id = ProviderAccountId::new("acct_test").unwrap();

    for _ in 0..2 {
        let info = tokio::time::timeout(
            std::time::Duration::from_secs(1),
            services.accounts().personal_info(&account_id),
        )
        .await
        .expect("两项查询应并发执行")
        .unwrap();
        assert_eq!(info.profile.unwrap(), empty_profile_statistics());
        assert_eq!(info.subscription, Some(subscription.clone()));
    }
    assert_eq!(
        recorded(&events),
        [
            "store.load_account",
            "provider.profile_statistics",
            "provider.subscription",
            "store.load_account",
            "store.load_account",
            "provider.profile_statistics",
            "provider.subscription",
            "store.load_account",
        ]
    );
}

#[tokio::test]
async fn personal_info_should_keep_profile_when_subscription_is_missing_or_fails() {
    for subscription in [Ok(None), Err(ProviderAdminErrorKind::Unavailable)] {
        let provider = FakeProviderAdmin::new("openai", events());
        *provider.subscription_result.lock().unwrap() = subscription;
        let services = accounts_service(provider, FakeAccountStore::new("openai", events())).await;
        let info = services
            .accounts()
            .personal_info(&ProviderAccountId::new("acct_test").unwrap())
            .await
            .unwrap();
        assert_eq!(info.profile.unwrap(), empty_profile_statistics());
        assert_eq!(info.subscription, None);
    }
}

#[tokio::test]
async fn personal_info_should_keep_subscription_when_profile_fails() {
    let provider = FakeProviderAdmin::new("openai", events());
    *provider.profile_result.lock().unwrap() = Err(ProviderAdminErrorKind::BadGateway);
    let subscription = personal_info_subscription();
    *provider.subscription_result.lock().unwrap() = Ok(Some(subscription.clone()));
    let services = accounts_service(provider, FakeAccountStore::new("openai", events())).await;
    let info = services
        .accounts()
        .personal_info(&ProviderAccountId::new("acct_test").unwrap())
        .await
        .unwrap();
    assert_eq!(
        info.profile.unwrap_err().kind(),
        gateway_admin::model::AdminErrorKind::BadGateway
    );
    assert_eq!(info.subscription, Some(subscription));
}

#[tokio::test]
async fn personal_info_should_reject_missing_account_before_querying_provider() {
    let events = events();
    let provider = FakeProviderAdmin::new("openai", events.clone());
    let store = FakeAccountStore::new("openai", events.clone());
    store.set_accounts(Vec::new());
    let services = accounts_service(provider, store).await;
    let error = services
        .accounts()
        .personal_info(&ProviderAccountId::new("acct_test").unwrap())
        .await
        .unwrap_err();
    assert_eq!(error.kind(), gateway_admin::model::AdminErrorKind::NotFound);
    assert_eq!(recorded(&events), ["store.load_account"]);
}

#[tokio::test]
async fn personal_info_should_discard_results_when_account_changes_during_query() {
    for change in 0..5 {
        let provider = FakeProviderAdmin::new("openai", events());
        let barrier = Arc::new(tokio::sync::Barrier::new(3));
        *provider.personal_info_barrier.lock().unwrap() = Some(barrier.clone());
        let store = FakeAccountStore::new("openai", events());
        let services = accounts_service(provider, store.clone()).await;
        let account_id = ProviderAccountId::new("acct_test").unwrap();
        let mutate = async {
            barrier.wait().await;
            let mut accounts = store.accounts.lock().unwrap().clone();
            match change {
                0 => accounts[0].credential_revision = revision(99),
                1 => accounts[0].upstream_account_id = Some("changed-account".to_owned()),
                2 => accounts[0].upstream_user_id = Some("changed-user".to_owned()),
                3 => accounts[0].provider_kind = ProviderKind::new("xai").unwrap(),
                _ => accounts.clear(),
            }
            store.set_accounts(accounts);
            barrier.wait().await;
        };
        let (result, ()) = tokio::time::timeout(std::time::Duration::from_secs(1), async {
            tokio::join!(services.accounts().personal_info(&account_id), mutate)
        })
        .await
        .unwrap();
        let expected = if change == 4 {
            gateway_admin::model::AdminErrorKind::NotFound
        } else {
            gateway_admin::model::AdminErrorKind::Conflict
        };
        assert_eq!(result.unwrap_err().kind(), expected);
    }
}

async fn accounts_service(
    provider: Arc<FakeProviderAdmin>,
    store: Arc<FakeAccountStore>,
) -> AdminServices {
    accounts_service_with_probe(provider, store, Arc::new(SuccessfulAccountProbe)).await
}

async fn accounts_service_with_probe(
    provider: Arc<FakeProviderAdmin>,
    store: Arc<FakeAccountStore>,
    probe: Arc<dyn AccountProbe>,
) -> AdminServices {
    super::AdminHarness::new()
        .accounts(store)
        .settings(Arc::new(StaticSettingsStore::default()))
        .provider(provider)
        .probe(probe)
        .build()
        .await
}

struct SuccessfulAccountProbe;

impl AccountProbe for SuccessfulAccountProbe {
    fn probe(
        &self,
        _: AccountProbeRequest,
        _: Option<Arc<gateway_core::routing::RuntimeSnapshot>>,
    ) -> BoxFuture<'_, Result<AccountProbeResult, AccountProbeError>> {
        Box::pin(async {
            Ok(AccountProbeResult {
                text: vec!["OK".to_owned()],
            })
        })
    }
}

struct FailingAccountProbe;

impl AccountProbe for FailingAccountProbe {
    fn probe(
        &self,
        _: AccountProbeRequest,
        _: Option<Arc<gateway_core::routing::RuntimeSnapshot>>,
    ) -> BoxFuture<'_, Result<AccountProbeResult, AccountProbeError>> {
        Box::pin(async {
            let detail = ClientVisibleUpstreamError::new(
                "included usage exhausted",
                Some("usage_exhausted".to_owned()),
                Some("invalid_request_error".to_owned()),
            );
            Err(AccountProbeError::new(
                GatewayError::new(
                    GatewayErrorKind::RateLimited,
                    "upstream capacity is temporarily unavailable",
                )
                .with_client_visible_upstream_error(detail),
                AccountProbeErrorSource::Upstream,
                Some(UpstreamSendState::NotSent),
                None,
            ))
        })
    }
}

struct FreeModelQuotaProbe {
    store: Arc<FakeAccountStore>,
}

impl AccountProbe for FreeModelQuotaProbe {
    fn probe(
        &self,
        _: AccountProbeRequest,
        _: Option<Arc<gateway_core::routing::RuntimeSnapshot>>,
    ) -> BoxFuture<'_, Result<AccountProbeResult, AccountProbeError>> {
        Box::pin(async move {
            self.store.set_account_after_probe(account_record("xai"));
            Err(AccountProbeError::new(
                GatewayError::new(
                    GatewayErrorKind::RateLimited,
                    "xAI free model quota is exhausted",
                ),
                AccountProbeErrorSource::Provider,
                Some(UpstreamSendState::NotSent),
                None,
            ))
        })
    }
}

fn store_unavailable() -> AdminStoreError {
    AdminStoreError::new(
        AdminStoreErrorKind::Unavailable,
        "test account",
        "unavailable",
    )
}

fn unsupported() -> ProviderAdminError {
    ProviderAdminError::new(ProviderAdminErrorKind::Unsupported)
}

pub(super) fn import_settings() -> gateway_admin::model::accounts::AccountImportSettings {
    gateway_admin::model::accounts::AccountImportSettings {
        name: None,
        notes: Some("团队备用".to_owned()),
        model_access: Default::default(),
        enabled: false,
        concurrency_limit: Some(
            gateway_core::account::AccountConcurrencyLimit::new(3).expect("concurrency"),
        ),
        weight: gateway_core::account::AccountWeight::new(7).expect("weight"),
        group_ids: vec![
            gateway_core::routing::AccountGroupId::new("grp_00000000000000000000000000000091")
                .expect("group ID"),
        ],
    }
}

#[tokio::test]
async fn unregistered_provider_accounts_have_no_live_management_capabilities() {
    let provider = FakeProviderAdmin::new("openai", events());
    let store = FakeAccountStore::with_account(account_record("retired-provider"), events());
    let services = accounts_service(provider, store).await;
    let page = services
        .accounts()
        .list(AccountListQuery {
            page: 1,
            page_size: gateway_admin::model::PageSize::new(20).unwrap(),
            provider_kind: None,
            group_filter: None,
            search: None,
            status: None,
            sort: None,
        })
        .await
        .unwrap();
    assert_eq!(page.items.len(), 1);
    assert_eq!(
        page.items[0].account.provider_kind.as_str(),
        "retired-provider"
    );
    assert_eq!(page.items[0].capabilities, Default::default());
}

#[tokio::test]
async fn plugin_quota_refresh_uses_native_provider_without_changing_configuration() {
    let events = events();
    let provider = FakeProviderAdmin::new("openai", events.clone());
    let store = FakeAccountStore::new("openai", events.clone());
    let access = gateway_admin::initialize_plugin_accounts(
        ProviderAdminRegistry::new([provider.clone() as Arc<dyn ProviderAdmin>]).unwrap(),
        store,
        Arc::new(RecordingPluginAccountPublication(events.clone())),
        None,
    );
    let id = ProviderAccountId::new("acct_test").unwrap();
    access.get_quota(&id).await.unwrap();
    access.refresh_quota(&id).await.unwrap();
    assert_eq!(
        provider.quota_requests(),
        vec![
            ProviderQuotaRequest {
                account_id: id.clone(),
                refresh: false,
                rolling_usage: None
            },
            ProviderQuotaRequest {
                account_id: id,
                refresh: true,
                rolling_usage: None
            },
        ]
    );
    assert!(!recorded(&events).contains(&"snapshot.publish_committed"));
}

struct CapacityRuntime {
    counts: Option<BTreeMap<String, u64>>,
    fail: bool,
    reads: Mutex<Vec<Vec<String>>>,
}

#[async_trait]
impl AccountRuntimeStore for CapacityRuntime {
    async fn account_concurrency(
        &self,
        _: &str,
        _: u64,
        _: u32,
    ) -> AdminStoreResult<gateway_admin::model::accounts::AccountConcurrencyPage> {
        Err(gateway_admin::ports::store::AdminStoreError::new(
            gateway_admin::ports::store::AdminStoreErrorKind::Unavailable,
            "account concurrency",
            "not configured in this fixture",
        ))
    }

    async fn active_rate_limits(&self) -> AdminStoreResult<AccountRuntimeSnapshot> {
        Ok(AccountRuntimeSnapshot::default())
    }

    async fn account_runtime(&self, ids: &[String]) -> AdminStoreResult<AccountRuntimeSnapshot> {
        self.reads.lock().unwrap().push(ids.to_vec());
        if self.fail {
            return Err(store_unavailable());
        }
        Ok(AccountRuntimeSnapshot {
            protection_rules: std::collections::BTreeMap::new(),
            in_flight: self.counts.clone(),
            ..Default::default()
        })
    }

    async fn active_freezes(
        &self,
    ) -> AdminStoreResult<BTreeMap<String, gateway_admin::model::accounts::AccountFreeze>> {
        Ok(BTreeMap::new())
    }

    async fn finish_freeze(
        &self,
        _: &str,
        _: &gateway_admin::model::accounts::AccountFreeze,
        _: Option<chrono::DateTime<Utc>>,
    ) -> AdminStoreResult<bool> {
        Ok(false)
    }
}

#[tokio::test]
async fn account_capacity_should_batch_page_ids_and_distinguish_idle_from_unavailable() {
    for (counts, fail, expected) in [
        (
            Some(BTreeMap::from([("acct_test".to_owned(), 3)])),
            false,
            Some(3),
        ),
        (Some(BTreeMap::new()), false, Some(0)),
        (None, false, None),
        (None, true, None),
    ] {
        for empty in [false, true] {
            let runtime = Arc::new(CapacityRuntime {
                counts: counts.clone(),
                fail,
                reads: Mutex::default(),
            });
            let mut account = account_record("openai");
            account.concurrency_limit = gateway_core::account::AccountConcurrencyLimit::new(5);
            let store = FakeAccountStore::with_account(account, events());
            if empty {
                store.set_accounts(Vec::new());
            }
            let services = super::AdminHarness::new()
                .accounts(store)
                .account_runtime(runtime.clone())
                .settings(Arc::new(StaticSettingsStore::default()))
                .provider(FakeProviderAdmin::new("openai", events()))
                .build()
                .await;
            let page = services
                .accounts()
                .list(AccountListQuery {
                    page: 1,
                    page_size: gateway_admin::model::PageSize::new(20).unwrap(),
                    provider_kind: None,
                    group_filter: None,
                    search: None,
                    status: None,
                    sort: None,
                })
                .await
                .unwrap();
            if empty {
                assert!(page.items.is_empty());
                assert!(runtime.reads.lock().unwrap().is_empty());
            } else {
                assert_eq!(
                    *runtime.reads.lock().unwrap(),
                    [vec!["acct_test".to_owned()]]
                );
                assert_eq!(page.items[0].capacity.used_slots, expected);
                assert_eq!(page.items[0].capacity.total_slots, Some(5));
            }
        }
    }
}

#[async_trait]
impl gateway_admin::ports::reset_credit_automation::ResetCreditAutomationStore
    for FakeAccountStore
{
    async fn reset_credit_automation(
        &self,
        account_id: &str,
    ) -> AdminStoreResult<
        Option<gateway_admin::model::reset_credit_automation::ResetCreditAutomation>,
    > {
        Ok(self.automations.lock().unwrap().get(account_id).cloned())
    }
    async fn due_reset_credit_automations(
        &self,
        now: chrono::DateTime<Utc>,
        limit: u32,
    ) -> AdminStoreResult<Vec<String>> {
        let records = self.automations.lock().unwrap();
        let mut due = records
            .values()
            .filter(|r| r.enabled && r.next_run_at <= now)
            .collect::<Vec<_>>();
        due.sort_by_key(|r| r.next_run_at);
        Ok(due
            .into_iter()
            .take(limit as usize)
            .map(|r| r.account_id.clone())
            .collect())
    }
    async fn save_reset_credit_automation(
        &self,
        record: &gateway_admin::model::reset_credit_automation::ResetCreditAutomation,
        context: Option<&MutationContext>,
    ) -> AdminStoreResult<u64> {
        let mut records = self.automations.lock().unwrap();
        if records.get(&record.account_id).map_or(0, |r| r.revision) != record.revision {
            return Err(AdminStoreError::new(
                AdminStoreErrorKind::Conflict,
                "automation",
                "stale revision",
            ));
        }
        let mut next = record.clone();
        next.revision += 1;
        let revision = next.revision;
        records.insert(next.account_id.clone(), next);
        if let Some(context) = context {
            self.record_context(context);
        }
        Ok(revision)
    }
}
