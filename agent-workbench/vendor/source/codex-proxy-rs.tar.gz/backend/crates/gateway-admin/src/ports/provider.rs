//! 原生 Provider 管理能力与启动时注册表

use std::{collections::BTreeMap, sync::Arc};

use async_trait::async_trait;
use gateway_core::{
    account::ProviderAccountId,
    operation::Operation,
    routing::{ProviderKind, UpstreamModelId},
};
use heck::ToUpperCamelCase;

use crate::model::observability::{
    CalculatedBillingBreakdown, DashboardWireProfile, ProviderBillingInput,
};
use crate::model::provider_credentials::{
    AuthorizationStarted, CompleteAuthorization, ConsumeProviderResetCredit,
    PrepareCredentialImport, PrepareCredentialRefresh, PrepareCredentialRotation,
    PreparedAuthorizationCommit, PreparedCredentialImport, PreparedCredentialRotation,
    ProviderExport, ProviderExportCredentialInput, ProviderModelCatalogDocument, ProviderModels,
    ProviderProfileAvatar, ProviderProfileStatistics, ProviderQuota, ProviderQuotaReadRequest,
    ProviderQuotaRequest, ProviderResetCreditResult, ProviderResetCredits, ProviderSubscription,
    explicit_plan_type,
};
use crate::model::{
    provider_credentials::{ProviderDocument, ProviderQuotaWindow},
    quota_forecast_sampling::QuotaForecastObservation,
};

/// 按原生 Token 口径计算的报价输入，额外费用由调用方处理
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ProviderUsagePricingInput {
    pub upstream_model_id: String,
    pub service_tier: Option<String>,
    pub usage: gateway_core::metering::Usage,
}

/// Provider 管理失败的稳定分类
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ProviderAdminErrorKind {
    Invalid,
    Unsupported,
    NotFound,
    Conflict,
    /// Provider 已发起不可逆操作，但无法确认最终执行结果
    Ambiguous,
    Unavailable,
    CredentialRefreshRequired,
    BadGateway,
    Internal,
}

/// 不携带 OAuth 请求材料的管理错误
///
/// `message` 是 Provider 局部诊断，可能包含原始上游正文；通用管理用例不得自动把它作为公开文案
/// 只有明确拥有原始诊断合同的调用方才能读取，`Debug` 始终只记录是否存在
/// `public_message` 则是明确标记为可公开的静态提示，不允许携带动态上游材料
#[derive(Clone, thiserror::Error)]
#[error("provider admin operation failed: {kind:?}")]
pub struct ProviderAdminError {
    kind: ProviderAdminErrorKind,
    #[source]
    diagnostic: Option<Arc<ProviderAdminDiagnostic>>,
    public_message: Option<&'static str>,
}

impl std::fmt::Debug for ProviderAdminError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter
            .debug_struct("ProviderAdminError")
            .field("kind", &self.kind)
            .field("message", &self.message().map(|_| "<redacted>"))
            .field("public_message", &self.public_message)
            .finish()
    }
}

impl ProviderAdminError {
    #[must_use]
    pub const fn new(kind: ProviderAdminErrorKind) -> Self {
        Self {
            kind,
            diagnostic: None,
            public_message: None,
        }
    }

    #[must_use]
    pub fn with_source(mut self, source: impl Into<gateway_core::error::ErrorSource>) -> Self {
        Arc::make_mut(self.diagnostic.get_or_insert_with(Default::default)).source =
            Some(source.into());
        self
    }

    #[must_use]
    pub fn with_message(mut self, message: impl Into<String>) -> Self {
        Arc::make_mut(self.diagnostic.get_or_insert_with(Default::default)).message =
            Some(message.into());
        self
    }

    /// Provider 明确允许公开的静态提示；不得承载上游响应或凭据材料
    #[must_use]
    pub const fn with_public_message(mut self, message: &'static str) -> Self {
        self.public_message = Some(message);
        self
    }

    #[must_use]
    pub const fn public_message(&self) -> Option<&'static str> {
        self.public_message
    }

    #[must_use]
    pub const fn kind(&self) -> ProviderAdminErrorKind {
        self.kind
    }

    #[must_use]
    pub fn message(&self) -> Option<&str> {
        self.diagnostic
            .as_ref()
            .and_then(|diagnostic| diagnostic.message.as_deref())
    }
}

// Provider 局部消息与 typed 来源共用一个不公开的上下文，避免跨用例转换后丢失
#[derive(Debug, Clone, Default, thiserror::Error)]
#[error("{}", message.as_deref().unwrap_or("provider admin dependency failed"))]
struct ProviderAdminDiagnostic {
    message: Option<String>,
    source: Option<gateway_core::error::ErrorSource>,
}

/// 一个具体 Provider 对管理控制面提供的解析、验证、上游交互与运行时资源回收能力
///
/// 数据变更由 Provider 返回 prepared facts；config revision、审计与 PostgreSQL 事务
/// 全部由 [`crate::ports::store::AccountStore`] 提交
/// 运行时资源通知只在事务成功后发生
#[async_trait]
pub trait ProviderAdmin: Send + Sync {
    fn compile_privacy_policy(
        &self,
        _policy: &gateway_core::settings::privacy::CodexPrivacyPolicy,
    ) -> Result<
        Arc<dyn gateway_core::settings::privacy::CompiledPrivacyPolicy>,
        gateway_core::settings::privacy::PrivacyError,
    > {
        Err(gateway_core::settings::privacy::PrivacyError {
            rule_index: 0,
            reason: "该服务商不支持隐私策略",
        })
    }

    fn preview_privacy_policy(
        &self,
        _request: gateway_core::settings::privacy::PrivacyPreviewRequest,
    ) -> Result<
        gateway_core::settings::privacy::PrivacyPreviewResult,
        gateway_core::settings::privacy::PrivacyError,
    > {
        Err(gateway_core::settings::privacy::PrivacyError {
            rule_index: 0,
            reason: "该服务商不支持隐私策略",
        })
    }

    /// 只读内置价目；没有本地计价能力的 Provider 返回空目录
    fn pricing_catalog(&self) -> crate::model::pricing::ProviderPricingCatalog {
        Default::default()
    }

    fn evaluate_usage_pricing(
        &self,
        _input: &ProviderUsagePricingInput,
        _pricing: Option<&gateway_core::metering::ModelPriceOverride>,
    ) -> Result<Option<gateway_core::metering::CalculatedCostBreakdown>, ProviderAdminError> {
        Err(ProviderAdminError::new(ProviderAdminErrorKind::Unsupported))
    }

    fn provider_kind(&self) -> &ProviderKind;
    /// 与执行 Provider 共用的直连资格，未知实现默认不公开账号
    fn is_direct_account(&self, _authentication_kind: &str) -> bool {
        false
    }

    /// 仅依据本地账号事实判断通用模型资格；未知实现不能宣称完整覆盖
    fn peer_model_eligible(
        &self,
        _account: &crate::model::accounts::AccountRecord,
        _model: &str,
    ) -> Option<bool> {
        None
    }

    /// 只读取原生 Provider 能力及账号类型，不执行网络或数据库查询
    fn account_capabilities(
        &self,
        _account_id: &ProviderAccountId,
        _authentication_kind: &str,
    ) -> crate::model::accounts::ProviderAccountCapabilities {
        Default::default()
    }

    /// 提供该 Provider 的可选客户端身份；通用管理层不解释内部字段
    fn client_profile_options(
        &self,
    ) -> Result<gateway_core::account::OpaqueProviderData, ProviderAdminError> {
        Err(ProviderAdminError::new(ProviderAdminErrorKind::Unsupported))
    }

    /// 没有持久选择时使用的 Provider 默认画像；只返回已准备的本地事实
    fn default_client_profile(&self) -> Option<gateway_core::account::OpaqueProviderData> {
        None
    }

    /// 校验并投影客户端身份，结果不含认证或账号材料
    fn preview_client_profile(
        &self,
        _configuration: &gateway_core::account::OpaqueProviderData,
    ) -> Result<gateway_core::account::OpaqueProviderData, ProviderAdminError> {
        Err(ProviderAdminError::new(ProviderAdminErrorKind::Unsupported))
    }

    /// Key 可以继承当前全局画像；额外字段的合法性由对应 Provider 判定
    fn preview_key_client_profile(
        &self,
        key: &gateway_core::account::OpaqueProviderData,
        _global: Option<&gateway_core::account::OpaqueProviderData>,
    ) -> Result<gateway_core::account::OpaqueProviderData, ProviderAdminError> {
        self.preview_client_profile(key)
    }

    /// 提供最终套餐展示名称；未覆盖时采用通用的大驼峰格式
    fn plan_type_display(&self, plan_type: &str) -> String {
        default_plan_type_display(plan_type)
    }

    /// 账号已经由控制面提交为不可调度状态，释放 Provider 持有的账号级运行时资源
    ///
    /// 无账号级运行时资源的 Provider 不需要执行额外操作
    /// 该通知发生在 Store 事务
    /// 成功之后，不参与事务成败，也不得恢复或改写已经提交的账号状态
    async fn account_unavailable(&self, account_id: &ProviderAccountId);

    /// 账号资格事实已经由控制面提交，失效 Provider 持有的可重建派生状态
    ///
    /// 该通知发生在 Store 事务成功之后、下一份 RuntimeSnapshot 编译之前；通知
    /// 不参与已提交事务成败
    /// 没有账号派生状态的 Provider 可使用默认空实现
    async fn account_facts_changed(&self, _account_ids: &[ProviderAccountId]) {}

    /// 生成一次连接测试所需的 Provider-owned operation；Core 负责实际执行与落账
    async fn connection_test_operation(
        &self,
        upstream_model: &UpstreamModelId,
        input_text: &str,
    ) -> Result<Operation, ProviderAdminError>;

    /// 返回该 Provider 实际持有的 Dashboard 上游身份画像
    fn dashboard_wire_profile(&self) -> Option<DashboardWireProfile>;

    fn configured_wire_profile(
        &self,
        _configuration: &gateway_core::account::OpaqueProviderData,
    ) -> Option<DashboardWireProfile> {
        self.dashboard_wire_profile()
    }

    /// 使用 Provider-owned 价格规则恢复持久请求的逐项费用
    /// 未保存的长上下文计费标记不得从当前价格反推
    fn calculated_billing(
        &self,
        input: &ProviderBillingInput,
    ) -> Result<Option<CalculatedBillingBreakdown>, ProviderAdminError>;

    async fn prepare_import(
        &self,
        command: PrepareCredentialImport,
    ) -> Result<PreparedCredentialImport, ProviderAdminError>;

    async fn start_authorization(
        &self,
        pending: crate::model::provider_credentials::PendingAuthorizationMutation,
    ) -> Result<AuthorizationStarted, ProviderAdminError>;

    async fn complete_authorization(
        &self,
        command: CompleteAuthorization,
    ) -> Result<PreparedAuthorizationCommit, ProviderAdminError>;

    async fn prepare_rotation(
        &self,
        command: PrepareCredentialRotation,
    ) -> Result<PreparedCredentialRotation, ProviderAdminError>;

    async fn prepare_refresh(
        &self,
        command: PrepareCredentialRefresh,
    ) -> Result<PreparedCredentialRotation, ProviderAdminError>;

    /// 可公开的账号连接设置；实现只能显式投影非敏感字段，不能返回凭据原文
    async fn account_configuration(
        &self,
        _account_id: &ProviderAccountId,
    ) -> Result<Option<ProviderDocument>, ProviderAdminError> {
        Ok(None)
    }

    async fn quota(
        &self,
        request: ProviderQuotaRequest,
    ) -> Result<ProviderQuota, ProviderAdminError>;

    /// 只读投影当前页额度，返回值与输入逐项对应，单个失败不影响其他账号
    /// 没有批量存储能力的 Provider 继续使用原有单账号语义
    async fn read_quotas(
        &self,
        requests: &[ProviderQuotaReadRequest<'_>],
    ) -> Vec<Result<ProviderQuota, ProviderAdminError>> {
        futures::future::join_all(requests.iter().map(|request| async {
            let account_id = ProviderAccountId::new(request.account.id.clone())
                .map_err(|_| ProviderAdminError::new(ProviderAdminErrorKind::Invalid))?;
            self.quota(ProviderQuotaRequest {
                account_id,
                refresh: false,
                rolling_usage: request.rolling_usage.cloned(),
            })
            .await
        }))
        .await
    }

    /// 仅依据账号类型声明 CPR 连接能力，通用用例不解析 Provider 凭据
    fn peer_authentication_kinds(&self) -> &[&str] {
        &[]
    }

    fn supports_peer_connection(&self, authentication_kind: &str) -> bool {
        self.peer_authentication_kinds()
            .contains(&authentication_kind)
    }

    /// 从本轮加载的凭据提取连接材料，避免在校验连接版本后另读一份凭据
    fn peer_connection(
        &self,
        _loaded: &gateway_core::account::LoadedCredential,
    ) -> Result<Option<super::peer::PeerConnection>, ProviderAdminError> {
        Ok(None)
    }

    /// 历史观测的协议字段仅由具体 Provider 解释；不支持时保留累计估算
    fn quota_forecast_observation(
        &self,
        _document: &ProviderDocument,
        _window: &ProviderQuotaWindow,
    ) -> Option<QuotaForecastObservation> {
        None
    }

    /// 查询 Provider 官方个人资料统计；不支持该能力的 Provider 使用默认拒绝
    /// 只由个人信息显式查询，不在额度刷新或后台任务中预取
    async fn subscription(
        &self,
        _account_id: &ProviderAccountId,
    ) -> Result<Option<ProviderSubscription>, ProviderAdminError> {
        Err(ProviderAdminError::new(ProviderAdminErrorKind::Unsupported))
    }

    async fn profile_statistics(
        &self,
        _account_id: &ProviderAccountId,
    ) -> Result<ProviderProfileStatistics, ProviderAdminError> {
        Err(ProviderAdminError::new(ProviderAdminErrorKind::Unsupported))
    }

    /// 打开 Provider 官方头像字节流；不支持该能力的 Provider 使用默认拒绝
    async fn profile_avatar(
        &self,
        _account_id: &ProviderAccountId,
    ) -> Result<ProviderProfileAvatar, ProviderAdminError> {
        Err(ProviderAdminError::new(ProviderAdminErrorKind::Unsupported))
    }

    /// 查询 Provider 主动额度重置卡；不支持该能力的 Provider 使用默认拒绝
    async fn reset_credits(
        &self,
        _account_id: &ProviderAccountId,
    ) -> Result<ProviderResetCredits, ProviderAdminError> {
        Err(ProviderAdminError::new(ProviderAdminErrorKind::Unsupported))
    }

    /// 消费 Provider 主动额度重置卡；不支持该能力的 Provider 使用默认拒绝
    async fn consume_reset_credit(
        &self,
        _command: ConsumeProviderResetCredit,
    ) -> Result<ProviderResetCreditResult, ProviderAdminError> {
        Err(ProviderAdminError::new(ProviderAdminErrorKind::Unsupported))
    }

    async fn models(
        &self,
        account_id: &ProviderAccountId,
        refresh: bool,
    ) -> Result<ProviderModels, ProviderAdminError>;

    /// 导出该账号的 Provider 原生模型目录正文；不提供原生目录的 Provider 使用默认拒绝
    async fn model_catalog_document(
        &self,
        _account_id: &ProviderAccountId,
    ) -> Result<ProviderModelCatalogDocument, ProviderAdminError> {
        Err(ProviderAdminError::new(ProviderAdminErrorKind::Unsupported))
    }

    async fn export_credentials(
        &self,
        credentials: Vec<ProviderExportCredentialInput>,
    ) -> Result<ProviderExport, ProviderAdminError>;
}

/// 启动时注册原生 Provider，按 ProviderKind 查找管理能力
#[derive(Clone)]
pub struct ProviderAdminRegistry {
    providers: Arc<BTreeMap<ProviderKind, Arc<dyn ProviderAdmin>>>,
}

impl ProviderAdminRegistry {
    pub(crate) fn registered(&self) -> BTreeMap<ProviderKind, Arc<dyn ProviderAdmin>> {
        self.providers.as_ref().clone()
    }

    pub fn pricing_catalog(&self) -> gateway_core::metering::PricingOverrides {
        self.providers
            .iter()
            .map(|(kind, provider)| (kind.as_str().to_owned(), provider.pricing_catalog()))
            .collect()
    }

    /// 创建无重复 ProviderKind 的注册表
    ///
    /// # Errors
    ///
    /// 重复注册同一 ProviderKind 时返回 Conflict
    pub fn new(
        providers: impl IntoIterator<Item = Arc<dyn ProviderAdmin>>,
    ) -> Result<Self, ProviderAdminError> {
        let mut registered = BTreeMap::new();
        for provider in providers {
            let kind = provider.provider_kind().clone();
            if registered.insert(kind, provider).is_some() {
                return Err(ProviderAdminError::new(ProviderAdminErrorKind::Conflict));
            }
        }
        Ok(Self {
            providers: Arc::new(registered),
        })
    }

    pub fn require(
        &self,
        provider_kind: &ProviderKind,
    ) -> Result<Arc<dyn ProviderAdmin>, ProviderAdminError> {
        self.providers
            .get(provider_kind)
            .cloned()
            .ok_or_else(|| ProviderAdminError::new(ProviderAdminErrorKind::Unsupported))
    }

    /// 账号目录与关联列表共用套餐补全和展示规则，已知账号套餐优先于额度快照
    pub(crate) fn resolve_account_plan(
        &self,
        provider_kind: &str,
        plan_type: &mut Option<String>,
        quota: Option<&ProviderQuota>,
    ) -> Option<String> {
        if let Some(quota) = quota {
            quota.fill_missing_plan_type(plan_type);
        }
        self.plan_type_display(provider_kind, plan_type.as_deref())
    }

    /// 账号页和 Dashboard 共用 Provider 的最终展示名称，不改写官方拼写或原始套餐值
    pub(crate) fn plan_type_display(
        &self,
        provider_kind: &str,
        plan_type: Option<&str>,
    ) -> Option<String> {
        let plan_type = explicit_plan_type(plan_type)?.trim();
        let provider = ProviderKind::new(provider_kind.to_owned())
            .ok()
            .and_then(|kind| self.require(&kind).ok());
        Some(provider.map_or_else(
            || default_plan_type_display(plan_type),
            |provider| provider.plan_type_display(plan_type),
        ))
    }

    /// 返回所有已注册 Provider 的 Dashboard 上游身份画像
    pub fn dashboard_wire_profiles(
        &self,
        configurations: &std::collections::BTreeMap<
            ProviderKind,
            gateway_core::account::OpaqueProviderData,
        >,
    ) -> Vec<DashboardWireProfile> {
        self.providers
            .iter()
            .filter_map(|(kind, provider)| match configurations.get(kind) {
                Some(configuration) => provider.configured_wire_profile(configuration),
                None => provider.dashboard_wire_profile(),
            })
            .collect()
    }

    /// 按平台计算请求费用
    pub fn calculated_billing(
        &self,
        provider_kind: &ProviderKind,
        input: &ProviderBillingInput,
    ) -> Result<Option<CalculatedBillingBreakdown>, ProviderAdminError> {
        self.require(provider_kind)?.calculated_billing(input)
    }
}

fn default_plan_type_display(plan_type: &str) -> String {
    plan_type.replace('+', " Plus ").to_upper_camel_case()
}
