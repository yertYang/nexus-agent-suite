//! 统一账号目录与原生 Provider 分派

mod reset_credit_automation;

use std::{
    collections::{BTreeMap, BTreeSet},
    sync::Arc,
};

use async_trait::async_trait;
use chrono::{Duration, Utc};
use futures::StreamExt as _;
use gateway_core::{
    account::ProviderAccountId,
    engine::probe::{AccountProbe, AccountProbeRequest, AccountProbeTarget},
    routing::{ProviderKind, UpstreamModelId},
    runtime::SnapshotControl,
};

use crate::{
    model::{
        AdminError, MutationContext,
        accounts::{
            AccountConnectionTestEvent, AccountConnectionTestEventStream, AccountListQuery,
            AccountPageItem, AccountUpdateResult, AccountUsage, AccountUsageWindowQuery,
            AccountsUpdateResult, BatchUpdateAccounts, UpdateAccount,
        },
        observability::TimeRange,
        provider_credentials::{
            AccountDirectoryItem, AccountDirectoryPage, AccountExportBundle, AccountPersonalInfo,
            AccountRefreshResult, AccountUsagePeriod, ConsumeProviderResetCredit,
            PrepareCredentialRefresh, ProviderModelCatalogDocument, ProviderModels,
            ProviderProfileAvatar, ProviderQuota, ProviderQuotaReadRequest, ProviderQuotaRequest,
            ProviderQuotaWindow, ProviderResetCreditResult, ProviderResetCredits,
            QuotaLocalUsageAttribution,
        },
        quota_forecast::{
            AccountQuotaForecastReport, account_quota_forecasts, quota_forecast_source_window,
        },
        quota_forecast_sampling::{QuotaForecastPoint, select_forecast_sample},
    },
    ports::{
        provider::ProviderAdminRegistry,
        store::{AccountRuntimeStore, AccountStore},
    },
};

use super::{
    commit_credential_refresh, map_provider_error, map_store_error, publish_committed,
    validate_prepared_rotation,
};

const CONNECTION_TEST_INPUT: &str = "Reply with exactly OK.";

/// 统一账号页消费的服务
#[async_trait]
pub trait AccountsService: Send + Sync {
    async fn concurrency(
        &self,
        account_id: ProviderAccountId,
        page: u32,
        page_size: u32,
    ) -> Result<crate::model::accounts::AccountConcurrencyPage, AdminError>;

    async fn list(&self, query: AccountListQuery) -> Result<AccountDirectoryPage, AdminError>;

    async fn export(
        &self,
        context: &MutationContext,
        account_ids: Vec<ProviderAccountId>,
    ) -> Result<AccountExportBundle, AdminError>;

    async fn refresh(
        &self,
        context: &MutationContext,
        account_id: ProviderAccountId,
    ) -> Result<AccountRefreshResult, AdminError>;

    async fn recover(
        &self,
        context: &MutationContext,
        account_id: ProviderAccountId,
    ) -> Result<AccountRefreshResult, AdminError>;

    async fn update(
        &self,
        context: &MutationContext,
        command: UpdateAccount,
    ) -> Result<AccountUpdateResult, AdminError>;

    async fn batch_update(
        &self,
        context: &MutationContext,
        command: BatchUpdateAccounts,
    ) -> Result<AccountsUpdateResult, AdminError>;

    async fn account_configuration(
        &self,
        _account_id: &ProviderAccountId,
    ) -> Result<Option<crate::model::provider_credentials::ProviderDocument>, AdminError> {
        Ok(None)
    }

    async fn quota(
        &self,
        account_id: &ProviderAccountId,
        refresh: bool,
    ) -> Result<AccountDirectoryItem, AdminError>;

    async fn quota_forecast(
        &self,
        account_id: &ProviderAccountId,
    ) -> Result<AccountQuotaForecastReport, AdminError>;

    async fn personal_info(
        &self,
        _account_id: &ProviderAccountId,
    ) -> Result<AccountPersonalInfo, AdminError> {
        Err(AdminError::invalid("该服务商不支持个人信息查询"))
    }

    async fn profile_avatar(
        &self,
        _account_id: &ProviderAccountId,
    ) -> Result<ProviderProfileAvatar, AdminError> {
        Err(AdminError::invalid("该服务商不支持账号头像"))
    }

    async fn reset_credit_automation_status(
        &self,
        _account_id: ProviderAccountId,
    ) -> Result<crate::model::reset_credit_automation::ResetCreditAutomationStatus, AdminError>
    {
        Err(AdminError::invalid("账号不支持自动重置卡"))
    }
    async fn set_reset_credit_automation(
        &self,
        _context: &MutationContext,
        _account_id: ProviderAccountId,
        _enabled: bool,
    ) -> Result<crate::model::reset_credit_automation::ResetCreditAutomationStatus, AdminError>
    {
        Err(AdminError::invalid("账号不支持自动重置卡"))
    }
    async fn reconcile_reset_credit_automation(
        &self,
        _account_id: ProviderAccountId,
    ) -> Result<(), AdminError> {
        Err(AdminError::invalid("账号不支持自动重置卡"))
    }

    async fn reset_credits(
        &self,
        _context: &MutationContext,
        _account_id: ProviderAccountId,
    ) -> Result<ProviderResetCredits, AdminError> {
        Err(AdminError::invalid("该服务商不支持额度重置"))
    }

    async fn consume_reset_credit(
        &self,
        _context: &MutationContext,
        _command: ConsumeProviderResetCredit,
    ) -> Result<ProviderResetCreditResult, AdminError> {
        Err(AdminError::invalid("该服务商不支持额度重置"))
    }

    async fn models(
        &self,
        account_id: &ProviderAccountId,
        refresh: bool,
    ) -> Result<ProviderModels, AdminError>;

    async fn model_catalog_document(
        &self,
        account_id: &ProviderAccountId,
    ) -> Result<ProviderModelCatalogDocument, AdminError>;

    async fn test_connection(
        &self,
        target: AccountProbeTarget,
        upstream_model: UpstreamModelId,
    ) -> Result<AccountConnectionTestEventStream, AdminError>;
}

pub(crate) struct DefaultAccountsService {
    accounts: Arc<dyn AccountStore>,
    account_runtime: Arc<dyn AccountRuntimeStore>,
    settings: Arc<dyn crate::ports::store::SettingsStore>,
    timezone: gateway_core::time::DeploymentTimeZone,
    providers: ProviderAdminRegistry,
    snapshot: Arc<dyn SnapshotControl>,
    probe: Arc<dyn AccountProbe>,
    upstream_info: Option<Arc<dyn crate::ports::peer::PeerUpstreamService>>,
    reset_credit_locks:
        Arc<futures::lock::Mutex<BTreeMap<ProviderAccountId, Arc<futures::lock::Mutex<()>>>>>,
}

impl DefaultAccountsService {
    #[must_use]
    #[expect(
        clippy::too_many_arguments,
        reason = "账号存储、发布、探测与互联分别通过独立端口注入"
    )]
    pub(crate) fn new(
        accounts: Arc<dyn AccountStore>,
        account_runtime: Arc<dyn AccountRuntimeStore>,
        settings: Arc<dyn crate::ports::store::SettingsStore>,
        timezone: gateway_core::time::DeploymentTimeZone,
        providers: ProviderAdminRegistry,
        snapshot: Arc<dyn SnapshotControl>,
        probe: Arc<dyn AccountProbe>,
        upstream_info: Option<Arc<dyn crate::ports::peer::PeerUpstreamService>>,
    ) -> Self {
        Self {
            accounts,
            account_runtime,
            settings,
            timezone,
            providers,
            snapshot,
            probe,
            upstream_info,
            reset_credit_locks: Arc::new(futures::lock::Mutex::new(BTreeMap::new())),
        }
    }

    async fn reset_credit_lock(
        &self,
        account_id: &ProviderAccountId,
    ) -> Arc<futures::lock::Mutex<()>> {
        let mut locks = self.reset_credit_locks.lock().await;
        Arc::clone(
            locks
                .entry(account_id.clone())
                .or_insert_with(|| Arc::new(futures::lock::Mutex::new(()))),
        )
    }

    async fn read_quotas(
        &self,
        items: &[AccountPageItem],
        rolling_usage: &BTreeMap<String, AccountUsage>,
    ) -> Vec<ProviderQuota> {
        let providers = &self.providers;
        let mut groups = BTreeMap::<_, Vec<usize>>::new();
        for (index, item) in items.iter().enumerate() {
            groups
                .entry(&item.account.provider_kind)
                .or_default()
                .push(index);
        }
        let batches = groups.into_iter().map(|(kind, indices)| async move {
            let provider = match providers.require(kind) {
                Ok(provider) => provider,
                Err(error) => {
                    tracing::warn!(
                        provider = %kind,
                        error = %error,
                        "account directory provider is not registered; showing empty quota"
                    );
                    return Vec::new();
                }
            };
            let requests = indices
                .iter()
                .map(|&index| {
                    let account = &items[index].account;
                    ProviderQuotaReadRequest {
                        account,
                        rolling_usage: rolling_usage.get(&account.id),
                    }
                })
                .collect::<Vec<_>>();
            let results = super::peer_link::upstream::read_quotas(
                self.upstream_info.as_deref(),
                provider.as_ref(),
                &requests,
            )
            .await;
            if results.len() != indices.len() {
                tracing::warn!(
                    provider = %kind,
                    expected = indices.len(),
                    actual = results.len(),
                    "account directory quota batch has invalid length; showing empty quota"
                );
                return Vec::new();
            }
            indices
                .into_iter()
                .zip(results)
                .map(|(index, result)| {
                    let quota = result.unwrap_or_else(|error| {
                        tracing::warn!(
                            account_id = %items[index].account.id,
                            error = %error,
                            "account directory quota projection failed; showing empty quota"
                        );
                        empty_quota()
                    });
                    (index, quota)
                })
                .collect::<Vec<_>>()
        });
        // Provider 可独立完成，回填原页顺序并保留未注册或失败账号的位置
        let mut quotas = vec![empty_quota(); items.len()];
        for (index, quota) in futures::future::join_all(batches)
            .await
            .into_iter()
            .flatten()
        {
            quotas[index] = quota;
        }
        quotas
    }

    async fn load_account(
        &self,
        account_id: &ProviderAccountId,
    ) -> Result<AccountPageItem, AdminError> {
        let runtime = self
            .account_runtime
            .account_runtime(&[account_id.as_str().to_owned()])
            .await
            .map_err(|error| map_store_error(error, "account runtime"))?;
        self.accounts
            .load_account(account_id.as_str(), runtime)
            .await
            .map_err(|error| map_store_error(error, "provider account"))?
            .ok_or_else(|| AdminError::not_found("服务商账号不存在"))
    }

    async fn provider_for_account(
        &self,
        account_id: &ProviderAccountId,
    ) -> Result<
        (
            AccountPageItem,
            std::sync::Arc<dyn crate::ports::provider::ProviderAdmin>,
        ),
        AdminError,
    > {
        let item = self.load_account(account_id).await?;
        let provider = self
            .providers
            .require(&item.account.provider_kind)
            .map_err(|error| map_provider_error(error, "provider account"))?;
        Ok((item, provider))
    }

    async fn attach_quota_local_usage(
        &self,
        accounts: &[AccountPageItem],
        quotas: &mut [ProviderQuota],
    ) -> Result<(), AdminError> {
        let windows = accounts
            .iter()
            .zip(quotas.iter())
            .flat_map(|(item, quota)| {
                quota
                    .windows
                    .iter()
                    .filter(|window| window.local_usage.is_none())
                    .filter_map(|window| quota_usage_window(&item.account.id, window))
            })
            .collect::<Vec<_>>();
        if windows.is_empty() {
            return Ok(());
        }
        let usage_by_window = self
            .accounts
            .load_account_usage_by_windows(&windows)
            .await
            .map_err(|error| map_store_error(error, "quota window usage"))?
            .into_iter()
            .map(|result| ((result.account_id, result.key), result.usage))
            .collect::<BTreeMap<_, _>>();
        for (item, quota) in accounts.iter().zip(quotas) {
            for window in &mut quota.windows {
                if window.local_usage.is_none()
                    && window.local_usage_attribution == QuotaLocalUsageAttribution::AccountWide
                {
                    let key = (item.account.id.clone(), window.key.clone());
                    if let Some(usage) = usage_by_window.get(&key) {
                        window.local_usage = Some(usage.clone());
                    }
                }
            }
        }
        Ok(())
    }

    async fn load_api_key_usage(
        &self,
        accounts: &[AccountPageItem],
        quotas: &[ProviderQuota],
    ) -> Result<BTreeMap<String, AccountUsage>, AdminError> {
        let now = Utc::now();
        let mut usage = BTreeMap::new();
        // 互联账号复用已聚合的最长 Key 窗口，普通 API Key 保留累计口径
        let windows = accounts
            .iter()
            .zip(quotas)
            .filter(|(item, _)| item.account.authentication_kind == "api_key")
            .filter_map(|(item, quota)| {
                if quota
                    .upstream
                    .as_ref()
                    .is_some_and(|upstream| upstream.discovered)
                {
                    if let Some(local_usage) = quota
                        .upstream_usage_window()
                        .and_then(|window| window.local_usage.as_ref())
                    {
                        usage.insert(item.account.id.clone(), local_usage.clone());
                    }
                    return None;
                }
                Some(AccountUsageWindowQuery {
                    account_id: item.account.id.clone(),
                    key: "account-lifetime".to_owned(),
                    range: TimeRange {
                        start: item.account.created_at,
                        end: now,
                    },
                })
            })
            .collect::<Vec<_>>();
        if windows.is_empty() {
            return Ok(usage);
        }
        usage.extend(
            self.accounts
                .load_account_usage_by_windows(&windows)
                .await
                .map_err(|error| map_store_error(error, "API Key account usage"))?
                .into_iter()
                .map(|result| (result.account_id, result.usage)),
        );
        Ok(usage)
    }

    async fn load_directory_item(
        &self,
        account_id: &ProviderAccountId,
        refresh_quota: bool,
    ) -> Result<AccountDirectoryItem, AdminError> {
        let (stored, provider) = self.provider_for_account(account_id).await?;
        let account = &stored.account;
        let now = Utc::now();
        let rolling_range = TimeRange {
            start: now - Duration::hours(24),
            end: now,
        };
        let ids = vec![account.id.clone()];
        let rolling_usage = self
            .accounts
            .load_account_usage(rolling_range, &ids)
            .await
            .map_err(|error| map_store_error(error, "rolling account usage"))?;
        let rolling_usage = rolling_usage.into_iter().next();
        let mut quota = match super::peer_link::upstream::read_quota(
            self.upstream_info.as_deref(),
            provider.as_ref(),
            account,
            ProviderQuotaRequest {
                account_id: account_id.clone(),
                refresh: refresh_quota,
                rolling_usage: rolling_usage.clone(),
            },
        )
        .await
        {
            Ok(quota) => quota,
            // 凭据更新后的账号投影不要求 Provider 提供额度；显式刷新仍须支持该操作
            Err(error)
                if !refresh_quota
                    && error.kind()
                        == crate::ports::provider::ProviderAdminErrorKind::Unsupported =>
            {
                empty_quota()
            }
            Err(error) => return Err(map_provider_error(error, "provider quota")),
        };
        let mut stored = if refresh_quota {
            self.load_account(account_id).await?
        } else {
            stored
        };
        self.attach_quota_local_usage(
            std::slice::from_ref(&stored),
            std::slice::from_mut(&mut quota),
        )
        .await?;
        let usage = self
            .load_api_key_usage(std::slice::from_ref(&stored), std::slice::from_ref(&quota))
            .await?
            .remove(&stored.account.id)
            .or_else(|| {
                quota
                    .usage_window()
                    .and_then(|(window, _)| window.local_usage.clone())
            });
        Ok(AccountDirectoryItem {
            protection_rules: stored.protection_rules,
            capacity: super::peer_link::upstream::account_capacity(
                &stored.account,
                stored.capacity,
                &quota,
            ),
            capabilities: provider
                .account_capabilities(account_id, &stored.account.authentication_kind),
            plan_type_display: self.providers.resolve_account_plan(
                stored.account.provider_kind.as_str(),
                &mut stored.account.plan_type,
                Some(&quota),
            ),
            projection: stored.projection,
            usage,
            account: stored.account,
            quota,
        })
    }
}

#[async_trait]
impl AccountsService for DefaultAccountsService {
    async fn concurrency(
        &self,
        account_id: ProviderAccountId,
        page: u32,
        page_size: u32,
    ) -> Result<crate::model::accounts::AccountConcurrencyPage, AdminError> {
        let offset = page
            .checked_sub(1)
            .and_then(|page| page.checked_mul(page_size))
            .filter(|_| (1..=100).contains(&page_size))
            .ok_or_else(|| AdminError::invalid("并发明细分页参数无效"))?;
        if !self
            .accounts
            .account_exists(account_id.as_str())
            .await
            .map_err(|error| map_store_error(error, "account concurrency"))?
        {
            return Err(AdminError::not_found("账号不存在"));
        }
        self.account_runtime
            .account_concurrency(account_id.as_str(), u64::from(offset), page_size)
            .await
            .map_err(|error| map_store_error(error, "account concurrency"))
    }

    async fn list(&self, query: AccountListQuery) -> Result<AccountDirectoryPage, AdminError> {
        let providers = &self.providers;
        let runtime = self
            .account_runtime
            .active_rate_limits()
            .await
            .map_err(|error| map_store_error(error, "account runtime"))?;
        let page = self
            .accounts
            .list_accounts(query, runtime)
            .await
            .map_err(|error| map_store_error(error, "account directory"))?;
        let now = Utc::now();
        let rolling_range = TimeRange {
            start: now - Duration::hours(24),
            end: now,
        };
        let ids = page
            .items
            .iter()
            .map(|item| item.account.id.clone())
            .collect::<Vec<_>>();
        // 只读取当前页的租约占用；观测失败不能把账号误报为空闲或拖垮目录
        let in_flight = if ids.is_empty() {
            None
        } else {
            match self.account_runtime.account_runtime(&ids).await {
                Ok(runtime) => runtime.in_flight,
                Err(error) => {
                    tracing::warn!(error = %error, "account capacity projection is unavailable");
                    None
                }
            }
        };
        let rolling_usage = self
            .accounts
            .load_account_usage(rolling_range, &ids)
            .await
            .map_err(|error| map_store_error(error, "rolling account usage"))?;
        let rolling_usage = rolling_usage
            .into_iter()
            .map(|usage| (usage.account_id.clone(), usage))
            .collect::<BTreeMap<_, _>>();
        let mut quotas = self.read_quotas(&page.items, &rolling_usage).await;
        self.attach_quota_local_usage(&page.items, &mut quotas)
            .await?;
        let mut api_key_usage = self.load_api_key_usage(&page.items, &quotas).await?;
        let items = page
            .items
            .into_iter()
            .zip(quotas)
            .map(|(mut item, quota)| {
                let id = ProviderAccountId::new(item.account.id.clone())
                    .map_err(|_| AdminError::invalid("服务商账号 ID 不合法"))?;
                let capabilities = providers
                    .require(&item.account.provider_kind)
                    .map(|provider| {
                        provider.account_capabilities(&id, &item.account.authentication_kind)
                    })
                    .unwrap_or_default();
                let usage = api_key_usage.remove(&item.account.id).or_else(|| {
                    quota
                        .usage_window()
                        .and_then(|(window, _)| window.local_usage.clone())
                });
                Ok(AccountDirectoryItem {
                    protection_rules: item.protection_rules,
                    capacity: crate::model::accounts::AccountCapacity {
                        used_slots: in_flight
                            .as_ref()
                            .map(|counts| counts.get(&item.account.id).copied().unwrap_or(0)),
                        ..super::peer_link::upstream::account_capacity(
                            &item.account,
                            item.capacity,
                            &quota,
                        )
                    },
                    capabilities,
                    plan_type_display: providers.resolve_account_plan(
                        item.account.provider_kind.as_str(),
                        &mut item.account.plan_type,
                        Some(&quota),
                    ),
                    usage,
                    account: item.account,
                    projection: item.projection,
                    quota,
                })
            })
            .collect::<Result<Vec<_>, AdminError>>()?;
        Ok(AccountDirectoryPage {
            config_revision: page.config_revision,
            items,
            total: page.total,
            summary: page.summary,
        })
    }

    async fn export(
        &self,
        context: &MutationContext,
        account_ids: Vec<ProviderAccountId>,
    ) -> Result<AccountExportBundle, AdminError> {
        let providers = &self.providers;
        if account_ids.is_empty() || account_ids.len() > 200 {
            return Err(AdminError::invalid("账号导出数量必须在 1 到 200 之间"));
        }
        let exported_ids = account_ids.clone();
        let mut grouped = BTreeMap::<ProviderKind, Vec<ProviderAccountId>>::new();
        for account_id in account_ids {
            let account = self.load_account(&account_id).await?;
            grouped
                .entry(account.account.provider_kind)
                .or_default()
                .push(account_id);
        }
        if grouped.values().any(|ids| {
            let unique = ids.iter().collect::<std::collections::BTreeSet<_>>();
            unique.len() != ids.len()
        }) {
            return Err(AdminError::invalid("账号导出列表包含重复 ID"));
        }
        // 混选时先确认全部 Provider 已注册，拒绝路径不读取任何一组明文凭据
        let export_groups = grouped
            .into_iter()
            .map(|(provider_kind, ids)| {
                let provider = providers
                    .require(&provider_kind)
                    .map_err(|error| map_provider_error(error, "provider account export"))?;
                Ok((provider_kind, provider, ids))
            })
            .collect::<Result<Vec<_>, AdminError>>()?;
        let mut documents = Vec::with_capacity(export_groups.len());
        for (provider_kind, provider, ids) in export_groups {
            let credentials = self
                .accounts
                .load_credentials_for_export(&provider_kind, &ids)
                .await
                .map_err(|error| map_store_error(error, "provider account export"))?;
            documents.push(
                provider
                    .export_credentials(credentials)
                    .await
                    .map_err(|error| map_provider_error(error, "provider account export"))?,
            );
        }
        self.accounts
            .record_credential_export(&exported_ids, context)
            .await
            .map_err(|error| map_store_error(error, "provider account export audit"))?;
        Ok(AccountExportBundle {
            exported_at: Utc::now(),
            documents,
        })
    }

    async fn refresh(
        &self,
        context: &MutationContext,
        account_id: ProviderAccountId,
    ) -> Result<AccountRefreshResult, AdminError> {
        let (stored, provider) = self.provider_for_account(&account_id).await?;
        let account = stored.account;
        let prepared = provider
            .prepare_refresh(PrepareCredentialRefresh {
                account: account.clone(),
            })
            .await
            .map_err(|error| map_provider_error(error, "provider credential refresh"))?;
        validate_prepared_rotation(&account, &prepared, "provider credential refresh")?;
        let result = commit_credential_refresh(
            self.accounts.as_ref(),
            prepared,
            context,
            "provider credential refresh",
        )
        .await?;
        super::notify_account_facts_changed(
            self.upstream_info.as_deref(),
            provider.as_ref(),
            std::slice::from_ref(&result.account_id),
        )
        .await;
        publish_committed(self.snapshot.as_ref(), result.config_revision).await?;
        let account = self.load_directory_item(&result.account_id, false).await?;
        Ok(AccountRefreshResult {
            config_revision: result.config_revision,
            account,
        })
    }

    async fn recover(
        &self,
        context: &MutationContext,
        account_id: ProviderAccountId,
    ) -> Result<AccountRefreshResult, AdminError> {
        let (stored, provider) = self.provider_for_account(&account_id).await?;
        let config_revision = if stored.account.enabled {
            self.accounts
                .recover_account(&account_id, context)
                .await
                .map_err(|error| map_store_error(error, "provider account recovery"))?
                .config_revision
        } else {
            // 停用只表示不参与调度，重新启用不能抹除已观测的额度、凭据或冷却事实
            self.accounts
                .batch_update_accounts(
                    BatchUpdateAccounts {
                        quota_limits: None,
                        auto_use_quota_credits: None,
                        account_ids: vec![account_id.to_string()],
                        enabled: Some(true),
                        concurrency_limit: None,
                        weight: None,
                        model_access: None,
                        group_ids: None,
                        outbound_proxy: None,
                    },
                    Default::default(),
                    context,
                )
                .await
                .map_err(|error| map_store_error(error, "enable provider account"))?
                .config_revision
        };
        super::notify_account_facts_changed(
            self.upstream_info.as_deref(),
            provider.as_ref(),
            std::slice::from_ref(&account_id),
        )
        .await;
        publish_committed(self.snapshot.as_ref(), config_revision).await?;
        let account = self.load_directory_item(&account_id, false).await?;
        Ok(AccountRefreshResult {
            config_revision,
            account,
        })
    }

    async fn update(
        &self,
        context: &MutationContext,
        command: UpdateAccount,
    ) -> Result<AccountUpdateResult, AdminError> {
        let account_id = ProviderAccountId::new(command.account_id.clone())
            .map_err(|_| AdminError::invalid("服务商账号 ID 不合法"))?;
        let (_, provider) = self.provider_for_account(&account_id).await?;
        let enabled = command.enabled;
        let result = self
            .accounts
            .update_account(command, context)
            .await
            .map_err(|error| map_store_error(error, "provider account"))?;
        if !enabled {
            super::notify_account_unavailable(
                self.upstream_info.as_deref(),
                provider.as_ref(),
                &account_id,
            )
            .await;
        }
        super::notify_account_facts_changed(
            self.upstream_info.as_deref(),
            provider.as_ref(),
            std::slice::from_ref(&account_id),
        )
        .await;
        publish_committed(self.snapshot.as_ref(), result.config_revision).await?;
        Ok(result)
    }

    async fn batch_update(
        &self,
        context: &MutationContext,
        command: BatchUpdateAccounts,
    ) -> Result<AccountsUpdateResult, AdminError> {
        let account_ids = command
            .account_ids
            .iter()
            .map(|id| {
                ProviderAccountId::new(id.clone())
                    .map_err(|_| AdminError::invalid("服务商账号 ID 不合法"))
            })
            .collect::<Result<Vec<_>, _>>()?;
        let mut providers = BTreeMap::<
            ProviderKind,
            (
                std::sync::Arc<dyn crate::ports::provider::ProviderAdmin>,
                Vec<ProviderAccountId>,
                Vec<ProviderAccountId>,
            ),
        >::new();
        let mut pauses = BTreeMap::new();
        for account_id in &account_ids {
            let (mut item, provider) = self.provider_for_account(account_id).await?;
            if let Some(limits) = &command.quota_limits {
                if !provider
                    .account_capabilities(account_id, &item.account.authentication_kind)
                    .quota_limits_supported
                {
                    return Err(AdminError::invalid("该账号不支持通用额度窗口上限"));
                }
                let new_keys = limits
                    .keys()
                    .filter(|key| !item.account.quota_limits.contains(key))
                    .map(str::to_owned)
                    .collect::<Vec<_>>();
                if !limits.is_empty() {
                    item.account.quota_limits = limits.clone();
                    let quota = provider
                        .read_quotas(&[ProviderQuotaReadRequest {
                            account: &item.account,
                            rolling_usage: None,
                        }])
                        .await
                        .into_iter()
                        .next()
                        .ok_or_else(|| AdminError::invalid("缺少账号额度观测结果"))?
                        .map_err(|error| map_provider_error(error, "provider quota"))?;
                    if new_keys.iter().any(|key| {
                        !quota.windows.iter().any(|window| {
                            window.key == *key
                                && window.local_usage_attribution
                                    == QuotaLocalUsageAttribution::AccountWide
                        })
                    }) {
                        return Err(AdminError::invalid("只能设置已观测的通用额度窗口"));
                    }
                    pauses.insert(
                        item.account.id.clone(),
                        crate::model::accounts::PreparedQuotaPause {
                            revision: item.account.credential_revision,
                            observed_at: quota.observed_at,
                            paused: !quota.paused_windows.is_empty(),
                        },
                    );
                }
            }
            if command.auto_use_quota_credits.is_some()
                && !provider
                    .account_capabilities(account_id, &item.account.authentication_kind)
                    .quota_credits
            {
                return Err(AdminError::invalid("该账号不支持使用额度点数"));
            }
            let (_, selected, exhausted) = providers
                .entry(item.account.provider_kind)
                .or_insert_with(|| (provider, Vec::new(), Vec::new()));
            selected.push(account_id.clone());
            if command.auto_use_quota_credits == Some(true)
                && !item.account.auto_use_quota_credits
                && item.account.quota.is_exhausted()
            {
                exhausted.push(account_id.clone());
            }
        }
        let enabled = command.enabled;
        let result = self
            .accounts
            .batch_update_accounts(command, pauses, context)
            .await
            .map_err(|error| map_store_error(error, "provider accounts"))?;
        for (provider, provider_ids, _) in providers.values() {
            if enabled == Some(false) {
                for account_id in provider_ids {
                    super::notify_account_unavailable(
                        self.upstream_info.as_deref(),
                        provider.as_ref(),
                        account_id,
                    )
                    .await;
                }
            }
            super::notify_account_facts_changed(
                self.upstream_info.as_deref(),
                provider.as_ref(),
                provider_ids,
            )
            .await;
        }
        publish_committed(self.snapshot.as_ref(), result.config_revision).await?;
        for (provider, _, exhausted) in providers.into_values() {
            if exhausted.is_empty() {
                continue;
            }
            super::credential_mutation::observe_account_quotas(
                self.upstream_info.as_ref(),
                &provider,
                &self.accounts,
                &exhausted,
                context.request_id.as_str(),
            );
        }
        Ok(result)
    }

    async fn account_configuration(
        &self,
        account_id: &ProviderAccountId,
    ) -> Result<Option<crate::model::provider_credentials::ProviderDocument>, AdminError> {
        let (_, provider) = self.provider_for_account(account_id).await?;
        provider
            .account_configuration(account_id)
            .await
            .map_err(|error| map_provider_error(error, "provider account configuration"))
    }

    async fn quota(
        &self,
        account_id: &ProviderAccountId,
        refresh: bool,
    ) -> Result<AccountDirectoryItem, AdminError> {
        self.load_directory_item(account_id, refresh).await
    }

    async fn quota_forecast(
        &self,
        account_id: &ProviderAccountId,
    ) -> Result<AccountQuotaForecastReport, AdminError> {
        let (stored, provider) = self.provider_for_account(account_id).await?;
        let quota = super::peer_link::upstream::read_quota(
            self.upstream_info.as_deref(),
            provider.as_ref(),
            &stored.account,
            ProviderQuotaRequest {
                account_id: account_id.clone(),
                refresh: false,
                rolling_usage: None,
            },
        )
        .await
        .map_err(|error| map_provider_error(error, "forecast quota snapshot"))?;
        let now = Utc::now();
        let mut samples = Vec::new();
        let mut selected_keys = BTreeSet::new();
        for period in [AccountUsagePeriod::Weekly, AccountUsagePeriod::Monthly] {
            let Some((window, _)) = quota_forecast_source_window(&quota, period) else {
                continue;
            };
            // 缺少一个周期时两个结果会复用同一窗口，只查询一次历史快照
            if !selected_keys.insert(window.key.as_str()) {
                continue;
            }
            let (Some(mut query), Some(observed), Some(percent)) = (
                quota_usage_window(account_id.as_str(), window),
                quota.observed_at,
                window.used_percent,
            ) else {
                continue;
            };
            query.range.start = query.range.start.max(stored.account.created_at);
            if query.range.start >= observed
                || observed > now
                || now >= query.range.end
                || !percent.is_finite()
                || !(0.0..=100.0).contains(&percent)
            {
                continue;
            }
            let reset_at = query.range.end;
            query.range.end = observed;
            let history = self
                .accounts
                .load_quota_forecast_history(&query)
                .await
                .map_err(|error| map_store_error(error, "forecast paired usage"))?;
            let mut points = Vec::new();
            let mut interrupted = false;
            for point in history.points {
                let Some(fact) =
                    provider.quota_forecast_observation(&point.provider_observation, window)
                else {
                    continue;
                };
                let same_plan = quota
                    .plan_type
                    .as_deref()
                    .zip(fact.plan_type.as_deref())
                    .is_some_and(|(current, previous)| current.eq_ignore_ascii_case(previous));
                // 仅容纳已观测到的秒级量化抖动，不用宽时间容差合并实际重置
                // 不匹配的段截断基线；之后的有效观测可以重新积累
                if !same_plan || (fact.reset_at - reset_at).abs() > Duration::seconds(2) {
                    points.clear();
                    interrupted = true;
                    continue;
                }
                points.push(QuotaForecastPoint {
                    observed_at: point.completed_at,
                    used_percent: fact.used_percent,
                    usage: point.usage,
                });
            }
            let sample = select_forecast_sample(
                window.key.clone(),
                query.range.start,
                QuotaForecastPoint {
                    observed_at: observed,
                    used_percent: percent,
                    usage: history.usage,
                },
                points,
                history.pending_request_count,
                interrupted,
            );
            samples.push(sample);
        }
        Ok(AccountQuotaForecastReport {
            account_id: account_id.to_string(),
            generated_at: now,
            forecasts: account_quota_forecasts(&quota, stored.account.created_at, now, &samples),
        })
    }

    async fn personal_info(
        &self,
        account_id: &ProviderAccountId,
    ) -> Result<AccountPersonalInfo, AdminError> {
        let (initial, provider) = self.provider_for_account(account_id).await?;
        // 两项读取相互独立；不因其中一项失败而取消另一项，也不触发凭据或额度刷新
        let (profile, subscription) = futures::join!(
            provider.profile_statistics(account_id),
            provider.subscription(account_id),
        );
        let profile =
            profile.map_err(|error| map_provider_error(error, "provider profile statistics"));
        let subscription = subscription
            .map_err(|error| map_provider_error(error, "provider subscription"))
            .ok()
            .flatten();

        // 汇聚等待期间发生重新授权、换绑或删除时，不返回混合身份的数据
        let current = self.load_account(account_id).await?;
        if current.account.provider_kind != initial.account.provider_kind
            || current.account.credential_revision != initial.account.credential_revision
            || current.account.upstream_user_id != initial.account.upstream_user_id
            || current.account.upstream_account_id != initial.account.upstream_account_id
        {
            return Err(AdminError::conflict("账号身份已变化，请刷新信息后重试"));
        }
        Ok(AccountPersonalInfo {
            profile,
            subscription,
        })
    }

    async fn profile_avatar(
        &self,
        account_id: &ProviderAccountId,
    ) -> Result<ProviderProfileAvatar, AdminError> {
        let (_, provider) = self.provider_for_account(account_id).await?;
        provider
            .profile_avatar(account_id)
            .await
            .map_err(|error| map_provider_error(error, "provider profile avatar"))
    }

    async fn reset_credit_automation_status(
        &self,
        account_id: ProviderAccountId,
    ) -> Result<crate::model::reset_credit_automation::ResetCreditAutomationStatus, AdminError>
    {
        self.automation_status(&account_id).await
    }
    async fn set_reset_credit_automation(
        &self,
        context: &MutationContext,
        account_id: ProviderAccountId,
        enabled: bool,
    ) -> Result<crate::model::reset_credit_automation::ResetCreditAutomationStatus, AdminError>
    {
        self.configure_automation(context, &account_id, enabled)
            .await
    }
    async fn reconcile_reset_credit_automation(
        &self,
        account_id: ProviderAccountId,
    ) -> Result<(), AdminError> {
        self.reconcile_automation(&account_id).await
    }

    async fn reset_credits(
        &self,
        context: &MutationContext,
        account_id: ProviderAccountId,
    ) -> Result<ProviderResetCredits, AdminError> {
        let lock = self.reset_credit_lock(&account_id).await;
        let _guard = lock.lock().await;
        let credits = self
            .reset_credits_upstream(context, account_id.clone())
            .await?;
        if let Err(error) = self.remember_reset_credits(&account_id, &credits).await {
            tracing::warn!(
                account_id = account_id.as_str(),
                error_kind = error.kind().as_str(),
                "保存重置卡计划失败"
            );
        }
        Ok(credits)
    }

    async fn consume_reset_credit(
        &self,
        context: &MutationContext,
        command: ConsumeProviderResetCredit,
    ) -> Result<ProviderResetCreditResult, AdminError> {
        let lock = self.reset_credit_lock(&command.account_id).await;
        let _guard = lock.lock().await;
        if self
            .accounts
            .reset_credit_automation(command.account_id.as_str())
            .await
            .map_err(|e| map_store_error(e, "reset-credit automation"))?
            .is_some_and(|record| {
                record
                    .state
                    .pending
                    .is_some_and(|pending| pending.credit.expires_at > Utc::now())
            })
        {
            return Err(AdminError::new(
                crate::model::AdminErrorKind::Conflict,
                "自动重置结果待确认，请稍后刷新",
            ));
        }
        self.consume_reset_credit_upstream(context, command).await
    }

    async fn models(
        &self,
        account_id: &ProviderAccountId,
        refresh: bool,
    ) -> Result<ProviderModels, AdminError> {
        let (_, provider) = self.provider_for_account(account_id).await?;
        provider
            .models(account_id, refresh)
            .await
            .map_err(|error| map_provider_error(error, "provider model catalog"))
    }

    async fn model_catalog_document(
        &self,
        account_id: &ProviderAccountId,
    ) -> Result<ProviderModelCatalogDocument, AdminError> {
        let (_, provider) = self.provider_for_account(account_id).await?;
        provider
            .model_catalog_document(account_id)
            .await
            .map_err(|error| map_provider_error(error, "provider model catalog document"))
    }

    async fn test_connection(
        &self,
        target: AccountProbeTarget,
        upstream_model: UpstreamModelId,
    ) -> Result<AccountConnectionTestEventStream, AdminError> {
        let (stored, provider) = self.provider_for_account(target.account_id()).await?;
        let account = stored.account;
        let model = upstream_model.as_str().to_owned();
        let operation = provider
            .connection_test_operation(&upstream_model, CONNECTION_TEST_INPUT)
            .await
            .map_err(|error| map_provider_error(error, "provider connection test"))?;
        let initial = vec![
            AccountConnectionTestEvent::Started {
                model: model.clone(),
            },
            AccountConnectionTestEvent::Request {
                model,
                input_text: CONNECTION_TEST_INPUT.to_owned(),
                stream: true,
                store: false,
            },
        ];
        let probe = Arc::clone(&self.probe);
        let terminal = futures::stream::once(async move {
            let result = probe
                .probe(
                    AccountProbeRequest {
                        target,
                        provider_kind: account.provider_kind,
                        upstream_model,
                        operation,
                    },
                    None,
                )
                .await;
            match result {
                Ok(result) => result
                    .text
                    .into_iter()
                    .map(|text| AccountConnectionTestEvent::Content { text })
                    .chain(std::iter::once(AccountConnectionTestEvent::Completed))
                    .collect(),
                Err(error) => {
                    let upstream_status = error
                        .upstream_response()
                        .map(gateway_core::engine::probe::AccountProbeUpstreamResponse::status);
                    let upstream_content_type = error
                        .upstream_response()
                        .and_then(|response| response.content_type())
                        .and_then(|value| std::str::from_utf8(value).ok())
                        .map(ToOwned::to_owned);
                    let upstream_body = error
                        .upstream_response()
                        .map(|response| String::from_utf8_lossy(response.body()).into_owned());
                    let message = error.client_message().to_owned();
                    vec![AccountConnectionTestEvent::Failed {
                        source: error.source(),
                        gateway_error_code: error.kind(),
                        proxy_hint: error.proxy_hint(),
                        send_state: error.send_state(),
                        message,
                        provider_error_code: error.client_error_code().map(ToOwned::to_owned),
                        provider_error_type: error.client_error_type().map(ToOwned::to_owned),
                        upstream_status,
                        upstream_content_type,
                        upstream_body,
                    }]
                }
            }
        })
        .flat_map(futures::stream::iter);
        Ok(Box::pin(futures::stream::iter(initial).chain(terminal)))
    }
}

fn map_reset_credits_error_after_refresh(
    error: crate::ports::provider::ProviderAdminError,
) -> AdminError {
    if error.kind() == crate::ports::provider::ProviderAdminErrorKind::CredentialRefreshRequired {
        return AdminError::bad_gateway("上游服务拒绝了刷新后的凭据");
    }
    map_provider_error(error, "provider reset credits")
}

/// 账号目录中单个账号 quota 读取失败时使用的空额度投影
fn empty_quota() -> ProviderQuota {
    ProviderQuota::default()
}

fn quota_usage_window(
    account_id: &str,
    window: &ProviderQuotaWindow,
) -> Option<AccountUsageWindowQuery> {
    if window.local_usage_attribution != QuotaLocalUsageAttribution::AccountWide {
        return None;
    }
    let reset_at = window.reset_at?;
    let seconds = i64::try_from(window.window_seconds?).ok()?;
    let start = reset_at.checked_sub_signed(Duration::try_seconds(seconds)?)?;
    let range = TimeRange::new(start, reset_at).ok()?;
    // 上游百分比以该 reset 边界定义；以当前时间回推会让本地 Token 属于另一窗口
    Some(AccountUsageWindowQuery {
        account_id: account_id.to_owned(),
        key: window.key.clone(),
        range,
    })
}
