//! 账号出站代理的持久化、导入占用与连通性探测端口

use async_trait::async_trait;
use gateway_core::account::{OutboundProxy, ProviderAccountId};

use super::store::AdminStoreResult;
use crate::model::{
    AdminError, MutationContext, Revision,
    proxies::{
        ImportProxyBinding, NewProxy, ProxyAccountListQuery, ProxyAccountPage, ProxyListQuery,
        ProxyMutation, ProxyPage, ProxyRecord, ProxyTestResult, UpdateProxy,
    },
};

/// 插件受管网络读取代理的窄端口，连接配置仅供宿主发送请求
#[async_trait]
pub trait PluginProxyAccess: Send + Sync {
    async fn list(&self, query: ProxyListQuery) -> Result<ProxyPage, AdminError>;
    async fn resolve(&self, id: &str) -> Result<OutboundProxy, AdminError>;
}

#[async_trait]
pub trait ProxyStore: Send + Sync {
    /// 在凭据交换到提交期间保护选定代理的连接配置和测试结果
    async fn reserve_import(&self, id: &str) -> AdminStoreResult<ProxyImportReservation>;
    async fn list(&self, query: ProxyListQuery) -> AdminStoreResult<ProxyPage>;
    async fn list_accounts(
        &self,
        query: ProxyAccountListQuery,
    ) -> AdminStoreResult<ProxyAccountPage>;
    async fn get(&self, id: &str) -> AdminStoreResult<ProxyRecord>;
    /// 仅在账号仍绑定指定代理时解除关联，并清除账号保存的连接地址
    async fn remove_account(
        &self,
        proxy_id: &str,
        account_id: &ProviderAccountId,
        context: &MutationContext,
    ) -> AdminStoreResult<Revision>;
    async fn create(
        &self,
        command: NewProxy,
        context: &MutationContext,
    ) -> AdminStoreResult<ProxyMutation>;
    async fn update(
        &self,
        command: UpdateProxy,
        context: &MutationContext,
    ) -> AdminStoreResult<ProxyMutation>;
    async fn delete(
        &self,
        id: &str,
        revision: Revision,
        context: &MutationContext,
    ) -> AdminStoreResult<Revision>;
    async fn record_test(
        &self,
        id: &str,
        revision: Revision,
        result: ProxyTestResult,
        context: &MutationContext,
    ) -> AdminStoreResult<ProxyMutation>;
}

/// 离开作用域时释放保护，错误返回和请求取消也遵循相同规则
pub trait ProxyImportGuard: Send + Sync {}

pub struct ProxyImportReservation {
    pub binding: ImportProxyBinding,
    pub guard: Box<dyn ProxyImportGuard>,
}

#[derive(Clone, Copy)]
pub enum ProbeRoute<'a> {
    Direct,
    Deployment,
    Proxy(&'a OutboundProxy),
}

#[async_trait]
pub trait ProxyProbe: Send + Sync {
    async fn test(&self, proxy: ProbeRoute<'_>, detect_location: bool) -> ProxyTestResult;
}
