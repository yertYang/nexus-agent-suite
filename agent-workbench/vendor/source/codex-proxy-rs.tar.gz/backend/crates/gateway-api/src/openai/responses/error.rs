//! OpenAI Responses adapter 的稳定错误 contract

use crate::client_error::{ProtocolError, ProtocolErrorBody};
use thiserror::Error;

/// Responses 请求解码错误
#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum RequestDecodeError {
    /// 请求不是合法 JSON
    #[error("request body must be valid JSON")]
    MalformedJson,
    /// 请求体解压后超过允许上限
    #[error("decompressed request body is too large")]
    DecompressedBodyTooLarge {
        /// 当前请求快照中的解压输出上限
        limit_bytes: usize,
    },
    /// 请求使用了网关不支持的 `Content-Encoding`
    #[error("request content-encoding `{encoding}` is not supported")]
    UnsupportedContentEncoding {
        /// Content-Encoding 标识
        encoding: String,
    },
    /// 顶层不是 object
    #[error("request body must be a JSON object")]
    ExpectedObject,
    /// 缺少必填字段
    #[error("required field `{field}` is missing")]
    MissingField {
        /// 字段路径
        field: String,
    },
    /// 字段类型错误
    #[error("field `{field}` has an invalid type; expected {expected}")]
    InvalidType {
        /// 字段路径
        field: String,
        /// 安全的期望类型
        expected: &'static str,
    },
    /// 字段为空
    #[error("field `{field}` must not be empty")]
    EmptyField {
        /// 字段路径
        field: String,
    },
    /// 字段值不满足稳定约束
    #[error("field `{field}` has an invalid value")]
    InvalidValue {
        /// 字段路径；不保存原始值
        field: String,
    },
    /// 未知字段
    #[error("unknown field `{field}`")]
    UnknownField {
        /// 字段路径；不保存字段值
        field: String,
    },
    /// 已知但尚未实现的语义
    #[error("field `{field}` is not supported by this gateway")]
    UnsupportedField {
        /// 字段路径
        field: String,
    },
    /// 两个参数的要求无法同时满足
    #[error("requested `{field}` is not supported with `{other}`")]
    UnsupportedCombination {
        /// 返回给客户端的参数路径
        field: &'static str,
        /// 与之冲突的参数路径
        other: &'static str,
    },
    /// Core operation 拒绝规范化后的字段
    #[error("field `{field}` violates the canonical operation contract")]
    CanonicalContract {
        /// 字段路径
        field: String,
    },
}

impl RequestDecodeError {
    /// 转换为 OpenAI 风格且不泄露正文的错误 payload
    #[must_use]
    pub fn protocol_body(&self) -> ProtocolErrorBody {
        let (code, message, param) = match self {
            Self::MalformedJson => (
                "invalid_json",
                "Request body must be valid JSON.".to_owned(),
                None,
            ),
            Self::DecompressedBodyTooLarge { limit_bytes } => (
                "request_too_large",
                format!(
                    "Decompressed request body exceeds the allowed size ({limit_bytes} bytes)."
                ),
                None,
            ),
            Self::UnsupportedContentEncoding { encoding } => (
                "unsupported_content_encoding",
                format!("Content-Encoding `{encoding}` is not supported."),
                None,
            ),
            Self::ExpectedObject => (
                "invalid_request_body",
                "Request body must be a JSON object.".to_owned(),
                None,
            ),
            Self::MissingField { field } => (
                "missing_required_parameter",
                format!("Required parameter `{field}` is missing."),
                Some(field.clone()),
            ),
            Self::InvalidType { field, expected } => (
                "invalid_type",
                format!("Parameter `{field}` must be {expected}."),
                Some(field.clone()),
            ),
            Self::EmptyField { field } => (
                "invalid_value",
                format!("Parameter `{field}` must not be empty."),
                Some(field.clone()),
            ),
            Self::InvalidValue { field } | Self::CanonicalContract { field } => (
                "invalid_value",
                format!("Parameter `{field}` has an invalid value."),
                Some(field.clone()),
            ),
            Self::UnknownField { field } => (
                "unknown_parameter",
                format!("Unknown parameter `{field}`."),
                Some(field.clone()),
            ),
            Self::UnsupportedField { field } => (
                "unsupported_parameter",
                format!("Parameter `{field}` is not supported by this gateway."),
                Some(field.clone()),
            ),
            Self::UnsupportedCombination { field, other } => (
                "unsupported_parameter",
                format!("The requested `{field}` is not supported with `{other}`."),
                Some((*field).to_owned()),
            ),
        };
        ProtocolErrorBody {
            error: ProtocolError {
                kind: "invalid_request_error",
                code,
                message,
                param,
            },
        }
    }
}

/// OpenAI Responses 原生 wire 转发错误
#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum ResponseEncodeError {
    /// 协议原生流缺少可返回的终态 response object
    #[error("responses wire stream has no terminal response")]
    MissingWireTerminal,
    /// 缺少完整终态输出，已交付的完成项也存在缺项或冲突，不能伪造完整结果
    #[error("responses wire stream has inconsistent output items")]
    InvalidOutputItems,
    /// 终态 response object 无法序列化为完整 HTTP JSON 响应
    #[error("responses wire terminal serialization failed")]
    Serialization,
}

impl ResponseEncodeError {
    /// 转换为不包含生成内容的 OpenAI 风格错误 payload
    #[must_use]
    pub fn protocol_body(&self) -> ProtocolErrorBody {
        ProtocolErrorBody {
            error: ProtocolError {
                kind: "server_error",
                code: "invalid_upstream_response",
                message: "The gateway could not forward the upstream response.".to_owned(),
                param: None,
            },
        }
    }
}
