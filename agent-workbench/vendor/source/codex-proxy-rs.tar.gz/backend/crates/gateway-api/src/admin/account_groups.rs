//! 账号分组管理的 HTTP 数据合同与固定路由

use crate::auth::SessionState;

use std::collections::BTreeMap;

use axum::{
    Router,
    extract::State,
    http::StatusCode,
    response::IntoResponse,
    routing::{get, post},
};
use chrono::{DateTime, Utc};
use gateway_admin::model::{
    PageSize,
    account_groups::{
        AccountGroupAccountSummary, AccountGroupCapacity, AccountGroupColor, AccountGroupListQuery,
        AccountGroupMutation, AccountGroupOptionsPage, AccountGroupPage, AccountGroupRecord,
        AccountGroupUsage, CreateAccountGroup, DeleteAccountGroup, SetAccountGroupEnabled,
        UpdateAccountGroup,
    },
};
use gateway_core::{account::FastMode, routing::AccountGroupId};
use serde::{Deserialize, Serialize};

use super::{
    AdminAuth, AdminEnvelope, AdminError, AdminJson, AdminQuery, AdminResponse, PageMeta,
    WireValidationError, wire::map_admin_service_error,
};

/// 账号、代理与 Client Key 共用的分组引用
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountGroupRefView {
    pub id: String,
    pub name: String,
    pub color: String,
    pub enabled: bool,
}

impl From<gateway_admin::model::account_groups::AccountGroupRef> for AccountGroupRefView {
    fn from(group: gateway_admin::model::account_groups::AccountGroupRef) -> Self {
        Self {
            id: group.id.to_string(),
            name: group.name,
            color: group.color.as_str().to_owned(),
            enabled: group.enabled,
        }
    }
}

const DEFAULT_PAGE_SIZE: u32 = 50;
const MAX_PAGE_SIZE: u32 = 200;

#[derive(Debug, Clone, Default, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct ListAccountGroupsQuery {
    page: Option<u32>,
    page_size: Option<u32>,
    search: Option<String>,
    enabled: Option<bool>,
}

impl ListAccountGroupsQuery {
    fn into_command(self) -> Result<AccountGroupListQuery, WireValidationError> {
        let page = self.page.unwrap_or(1);
        let page_size = self.page_size.unwrap_or(DEFAULT_PAGE_SIZE);
        if page == 0 || page_size == 0 || page_size > MAX_PAGE_SIZE {
            return Err(WireValidationError::new("page"));
        }
        let search = self
            .search
            .map(|value| value.trim().to_owned())
            .filter(|value| !value.is_empty());
        if search
            .as_deref()
            .is_some_and(|value| value.len() > 256 || value.chars().any(char::is_control))
        {
            return Err(WireValidationError::new("search"));
        }
        Ok(AccountGroupListQuery {
            page,
            page_size: PageSize::new(
                u16::try_from(page_size).map_err(|_| WireValidationError::new("pageSize"))?,
            )
            .map_err(|_| WireValidationError::new("pageSize"))?,
            search,
            enabled: self.enabled,
        })
    }
}

const fn default_allow_image_generation() -> bool {
    true
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct CreateAccountGroupRequest {
    #[serde(default = "default_allow_image_generation")]
    allow_image_generation: bool,
    #[serde(default)]
    fast_mode: FastMode,
    name: String,
    description: Option<String>,
    color: String,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct UpdateAccountGroupRequest {
    allow_image_generation: Option<bool>,
    fast_mode: Option<FastMode>,
    id: String,
    name: String,
    description: Option<String>,
    color: String,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct AccountGroupIdRequest {
    id: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
struct AccountGroupView {
    allow_image_generation: bool,
    fast_mode: FastMode,
    id: String,
    name: String,
    description: Option<String>,
    color: String,
    enabled: bool,
    member_count: u64,
    provider_counts: BTreeMap<String, u64>,
    client_key_count: u64,
    account_summary: AccountGroupAccountSummaryView,
    capacity: AccountGroupCapacityView,
    usage: AccountGroupUsageView,
    created_at: DateTime<Utc>,
    created_at_display: String,
    updated_at: DateTime<Utc>,
    updated_at_display: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
struct AccountGroupAccountSummaryView {
    available: u64,
    limited: u64,
    total: u64,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
struct AccountGroupCapacityView {
    used_slots: Option<u64>,
    total_slots: Option<u64>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
struct AccountGroupUsageView {
    today_usd: String,
    retained_total_usd: String,
}

impl From<(AccountGroupRecord, crate::time::TimePresenter)> for AccountGroupView {
    fn from((record, time): (AccountGroupRecord, crate::time::TimePresenter)) -> Self {
        Self {
            id: record.id.to_string(),
            name: record.name,
            description: record.description,
            fast_mode: record.fast_mode,
            allow_image_generation: record.allow_image_generation,
            color: record.color.as_str().to_owned(),
            enabled: record.enabled,
            member_count: record.member_count,
            provider_counts: record.provider_counts,
            client_key_count: record.client_key_count,
            account_summary: account_summary_view(record.account_summary),
            capacity: capacity_view(record.capacity),
            usage: usage_view(record.usage),
            created_at_display: time.datetime(&record.created_at),
            created_at: record.created_at,
            updated_at_display: time.datetime(&record.updated_at),
            updated_at: record.updated_at,
        }
    }
}

fn account_summary_view(summary: AccountGroupAccountSummary) -> AccountGroupAccountSummaryView {
    AccountGroupAccountSummaryView {
        available: summary.available,
        limited: summary.limited,
        total: summary.total,
    }
}

fn capacity_view(capacity: AccountGroupCapacity) -> AccountGroupCapacityView {
    AccountGroupCapacityView {
        used_slots: capacity.used_slots,
        total_slots: capacity.total_slots,
    }
}

fn usage_view(usage: AccountGroupUsage) -> AccountGroupUsageView {
    AccountGroupUsageView {
        today_usd: usage.today_usd.to_string(),
        retained_total_usd: usage.retained_total_usd.to_string(),
    }
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
struct AccountGroupPageData {
    items: Vec<AccountGroupView>,
    page: PageMeta,
    config_revision: u64,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
struct AccountGroupOptionsPageData {
    items: Vec<AccountGroupRefView>,
    page: PageMeta,
    config_revision: u64,
}

impl From<AccountGroupOptionsPage> for AccountGroupOptionsPageData {
    fn from(page: AccountGroupOptionsPage) -> Self {
        let total_pages = if page.total == 0 {
            0
        } else {
            page.total.div_ceil(u64::from(page.page_size))
        };
        Self {
            items: page
                .items
                .into_iter()
                .map(AccountGroupRefView::from)
                .collect(),
            page: PageMeta::new(
                page.page,
                u32::from(page.page_size),
                page.total,
                u32::try_from(total_pages).unwrap_or(u32::MAX),
            ),
            config_revision: page.config_revision.get(),
        }
    }
}

impl From<(AccountGroupPage, crate::time::TimePresenter)> for AccountGroupPageData {
    fn from((page, time): (AccountGroupPage, crate::time::TimePresenter)) -> Self {
        let total_pages = if page.total == 0 {
            0
        } else {
            page.total.div_ceil(u64::from(page.page_size))
        };
        Self {
            items: page
                .items
                .into_iter()
                .map(|value| AccountGroupView::from((value, time)))
                .collect(),
            page: PageMeta::new(
                page.page,
                u32::from(page.page_size),
                page.total,
                u32::try_from(total_pages).unwrap_or(u32::MAX),
            ),
            config_revision: page.config_revision.get(),
        }
    }
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
struct AccountGroupMutationData {
    id: String,
    record: Option<AccountGroupView>,
    config_revision: u64,
}

impl From<(AccountGroupMutation, crate::time::TimePresenter)> for AccountGroupMutationData {
    fn from((mutation, time): (AccountGroupMutation, crate::time::TimePresenter)) -> Self {
        Self {
            id: mutation.id.to_string(),
            record: mutation
                .record
                .map(|value| AccountGroupView::from((value, time))),
            config_revision: mutation.config_revision.get(),
        }
    }
}

/// 构造账号分组管理的固定路由
pub fn router<S>() -> Router<S>
where
    S: SessionState + Clone + Send + Sync + 'static,
{
    Router::new()
        .route("/api/admin/account-groups", get(list::<S>))
        .route("/api/admin/account-groups/options", get(list_options::<S>))
        .route("/api/admin/account-groups/create", post(create::<S>))
        .route("/api/admin/account-groups/update", post(update::<S>))
        .route("/api/admin/account-groups/enable", post(enable::<S>))
        .route("/api/admin/account-groups/disable", post(disable::<S>))
        .route("/api/admin/account-groups/delete", post(delete::<S>))
}

async fn list_options<S>(
    _auth: AdminAuth,
    State(state): State<S>,
    AdminQuery(query): AdminQuery<ListAccountGroupsQuery>,
) -> Result<impl IntoResponse, AdminError>
where
    S: SessionState + Send + Sync,
{
    let result = state
        .admin_services()
        .account_groups()
        .list_options(query.into_command().map_err(map_wire_error)?)
        .await
        .map_err(map_service_error)?;
    Ok(AdminResponse::new(
        StatusCode::OK,
        AdminEnvelope::ok(AccountGroupOptionsPageData::from(result)),
    ))
}

async fn list<S>(
    _auth: AdminAuth,
    State(state): State<S>,
    AdminQuery(query): AdminQuery<ListAccountGroupsQuery>,
) -> Result<impl IntoResponse, AdminError>
where
    S: SessionState + Send + Sync,
{
    let time = crate::time::TimePresenter::new(state.admin_services().timezone());
    let result = state
        .admin_services()
        .account_groups()
        .list(query.into_command().map_err(map_wire_error)?)
        .await
        .map_err(map_service_error)?;
    Ok(AdminResponse::new(
        StatusCode::OK,
        AdminEnvelope::ok(AccountGroupPageData::from((result, time))),
    ))
}

async fn create<S>(
    auth: AdminAuth,
    State(state): State<S>,
    AdminJson(request): AdminJson<CreateAccountGroupRequest>,
) -> Result<impl IntoResponse, AdminError>
where
    S: SessionState + Send + Sync,
{
    validate_group_fields(&request.name, request.description.as_deref())?;
    mutation_response(
        StatusCode::CREATED,
        state
            .admin_services()
            .account_groups()
            .create(
                &auth.context().mutation_context(),
                CreateAccountGroup {
                    allow_image_generation: request.allow_image_generation,
                    name: request.name,
                    description: request.description,
                    fast_mode: request.fast_mode,
                    color: group_color(&request.color)?,
                },
            )
            .await,
        crate::time::TimePresenter::new(state.admin_services().timezone()),
    )
}

async fn update<S>(
    auth: AdminAuth,
    State(state): State<S>,
    AdminJson(request): AdminJson<UpdateAccountGroupRequest>,
) -> Result<impl IntoResponse, AdminError>
where
    S: SessionState + Send + Sync,
{
    validate_group_fields(&request.name, request.description.as_deref())?;
    mutation_response(
        StatusCode::OK,
        state
            .admin_services()
            .account_groups()
            .update(
                &auth.context().mutation_context(),
                UpdateAccountGroup {
                    allow_image_generation: request.allow_image_generation,
                    id: group_id(request.id)?,
                    name: request.name,
                    description: request.description,
                    fast_mode: request.fast_mode,
                    color: group_color(&request.color)?,
                },
            )
            .await,
        crate::time::TimePresenter::new(state.admin_services().timezone()),
    )
}

async fn enable<S>(
    auth: AdminAuth,
    State(state): State<S>,
    AdminJson(request): AdminJson<AccountGroupIdRequest>,
) -> Result<impl IntoResponse, AdminError>
where
    S: SessionState + Send + Sync,
{
    set_enabled(auth, state, request, true).await
}

async fn disable<S>(
    auth: AdminAuth,
    State(state): State<S>,
    AdminJson(request): AdminJson<AccountGroupIdRequest>,
) -> Result<impl IntoResponse, AdminError>
where
    S: SessionState + Send + Sync,
{
    set_enabled(auth, state, request, false).await
}

async fn set_enabled<S>(
    auth: AdminAuth,
    state: S,
    request: AccountGroupIdRequest,
    enabled: bool,
) -> Result<AdminResponse<AdminEnvelope<AccountGroupMutationData>>, AdminError>
where
    S: SessionState + Send + Sync,
{
    mutation_response(
        StatusCode::OK,
        state
            .admin_services()
            .account_groups()
            .set_enabled(
                &auth.context().mutation_context(),
                SetAccountGroupEnabled {
                    id: group_id(request.id)?,
                    enabled,
                },
            )
            .await,
        crate::time::TimePresenter::new(state.admin_services().timezone()),
    )
}

async fn delete<S>(
    auth: AdminAuth,
    State(state): State<S>,
    AdminJson(request): AdminJson<AccountGroupIdRequest>,
) -> Result<impl IntoResponse, AdminError>
where
    S: SessionState + Send + Sync,
{
    mutation_response(
        StatusCode::OK,
        state
            .admin_services()
            .account_groups()
            .delete(
                &auth.context().mutation_context(),
                DeleteAccountGroup {
                    id: group_id(request.id)?,
                },
            )
            .await,
        crate::time::TimePresenter::new(state.admin_services().timezone()),
    )
}

fn mutation_response(
    status: StatusCode,
    result: Result<AccountGroupMutation, gateway_admin::model::AdminError>,
    time: crate::time::TimePresenter,
) -> Result<AdminResponse<AdminEnvelope<AccountGroupMutationData>>, AdminError> {
    let result = result.map_err(map_service_error)?;
    Ok(AdminResponse::new(
        status,
        AdminEnvelope::ok(AccountGroupMutationData::from((result, time))),
    ))
}

fn group_id(value: String) -> Result<AccountGroupId, AdminError> {
    AccountGroupId::new(value).map_err(|_| AdminError::bad_request("账号组 ID 不合法"))
}

fn group_color(value: &str) -> Result<AccountGroupColor, AdminError> {
    AccountGroupColor::parse(value).ok_or_else(|| AdminError::bad_request("账号组颜色不合法"))
}

fn validate_group_fields(name: &str, description: Option<&str>) -> Result<(), AdminError> {
    gateway_admin::model::account_groups::validate_group_fields(name, description)
        .map_err(|_| AdminError::bad_request("账号组请求不合法"))
}

fn map_wire_error(_: WireValidationError) -> AdminError {
    AdminError::bad_request("账号组查询参数不合法")
}

fn map_service_error(error: gateway_admin::model::AdminError) -> AdminError {
    map_admin_service_error(error)
}
