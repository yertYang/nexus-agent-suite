//! 响应 DTO 与固定 wire 形状

use super::*;

/// 观测列表响应数据
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PageData<T> {
    pub items: Vec<T>,
    pub current_page: u32,
    pub page_size: u16,
    pub total: u64,
}

/// Token 详情展示
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct TokenDetailsView {
    pub input_tokens: Option<u64>,
    pub output_tokens: Option<u64>,
    pub cached_input_tokens: Option<u64>,
    pub cache_write_input_tokens: Option<u64>,
    pub reasoning_output_tokens: Option<u64>,
    pub image_input_tokens: Option<u64>,
    pub image_output_tokens: Option<u64>,
    pub total_tokens: Option<u64>,
    pub input_tokens_display: String,
    pub output_tokens_display: String,
    pub cached_input_tokens_display: String,
    pub cache_write_input_tokens_display: String,
    pub reasoning_output_tokens_display: String,
    pub image_input_tokens_display: String,
    pub image_output_tokens_display: String,
    pub total_tokens_display: String,
}

/// 按货币展示的成本
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CostView {
    pub currency: String,
    pub estimated_amount: String,
}

/// 成本覆盖状态计数
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CostCoverageView {
    pub known: u64,
    pub partial: u64,
    pub unknown: u64,
    pub not_billable: u64,
}

/// Provider 受控价格规则生成的单次请求费用明细展示
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BillingView {
    pub long_context_billing_applied: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub image: Option<ImageBillingView>,
    pub input_amount_display: String,
    pub output_amount_display: String,
    pub cache_read_amount_display: String,
    pub cache_write_amount_display: String,
    pub standard_amount_display: String,
    pub total_amount_display: String,
    pub input_price_display: String,
    pub output_price_display: String,
    pub cache_read_price_display: String,
    pub cache_write_price_display: String,
    pub service_tier_display: String,
    pub multiplier_display: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ImageBillingView {
    pub input_amount_display: String,
    pub cache_read_amount_display: String,
    pub input_price_display: String,
    pub cache_read_price_display: String,
}

/// 使用记录表格的窄展示
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct UsageListRecordView {
    pub error_origin: &'static str,
    pub client_status_code: Option<u16>,
    pub upstream_status_code: Option<u16>,
    pub error_code: Option<String>,
    pub error_message: Option<String>,
    pub error_kind: Option<String>,
    pub websocket_close_code: Option<u16>,
    pub continuation_unavailable_reason: Option<String>,
    pub upstream_connection_exit_reason: Option<String>,
    pub recovered: bool,
    pub logical_outcome: String,
    pub client_api_key_name: Option<String>,
    pub id: String,
    pub provider: Option<String>,
    pub authentication_kind: Option<String>,
    pub account_id: Option<String>,
    pub account_email: Option<String>,
    pub account_name: Option<String>,
    pub account_notes: Option<String>,
    pub account_plan_type: Option<String>,
    pub account_plan_type_display: Option<String>,
    pub account_upstream_peer: Option<bool>,
    pub route: String,
    pub model: Option<String>,
    pub requested_model: Option<String>,
    pub upstream_model: Option<String>,
    pub service_tier: Option<String>,
    pub client_transport: String,
    pub upstream_transport: Option<String>,
    pub reasoning_effort: Option<String>,
    pub reasoning_preset: Option<String>,
    pub subagent_kind: Option<String>,
    pub compact: bool,
    pub token_details: TokenDetailsView,
    pub billing: Option<BillingView>,
    pub latency_details: UsageLatencyDetailsView,
    pub first_token_latency_ms: Option<u64>,
    pub latency_ms: Option<u64>,
    pub created_at: DateTime<Utc>,
    pub created_at_display: String,
    pub client_ip: Option<String>,
    pub user_agent: Option<String>,
}

/// 受控详情中的原始上游错误字段
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct UsageUpstreamErrorView {
    pub code: Option<String>,
    pub error_type: Option<String>,
    pub message: Option<String>,
    pub param: Option<String>,
    pub close_reason: Option<String>,
    pub last_event_type: Option<String>,
}

/// 单条逻辑请求详情展示
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct UsageRecordView {
    pub error_origin: &'static str,
    pub upstream_error: Option<UsageUpstreamErrorView>,
    pub retry_after_ms: Option<u64>,
    pub error_code: Option<String>,
    pub error_kind: Option<String>,
    pub websocket_close_code: Option<u16>,
    pub continuation_unavailable_reason: Option<String>,
    pub upstream_connection_exit_reason: Option<String>,
    pub recovered: bool,
    pub id: String,
    pub request_id: String,
    pub client_api_key_id: Option<String>,
    pub routing_scope: String,
    pub routing_group_refs: Vec<String>,
    pub routing_group_names_snapshot: Vec<String>,
    pub kind: String,
    pub provider: Option<String>,
    pub authentication_kind: Option<String>,
    pub account_id: Option<String>,
    pub account_email: Option<String>,
    pub account_name: Option<String>,
    pub route: String,
    pub model: Option<String>,
    pub requested_model: Option<String>,
    pub upstream_model: Option<String>,
    pub service_tier: Option<String>,
    pub status_code: Option<i64>,
    pub client_transport: String,
    pub upstream_transport: Option<String>,
    pub protocol: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub http_version: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub client_status_code: Option<i64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub upstream_status_code: Option<i64>,
    pub websocket_pool: Option<WebSocketPoolMetadataView>,
    pub image_generation_requested: bool,
    pub image_generation_succeeded: Option<bool>,
    pub latency_details: UsageLatencyDetailsView,
    pub attempt_index: Option<i64>,
    pub attempt_count: u64,
    pub response_id: Option<String>,
    pub upstream_request_id: Option<String>,
    pub latency_ms: Option<u64>,
    pub input_tokens: Option<u64>,
    pub output_tokens: Option<u64>,
    pub cached_input_tokens: Option<u64>,
    pub cache_write_input_tokens: Option<u64>,
    pub reasoning_output_tokens: Option<u64>,
    pub image_input_tokens: Option<u64>,
    pub image_output_tokens: Option<u64>,
    pub message: String,
    /// Provider 安全观测；Core 字段由顶层字段提供，不再复制进 metadata
    pub metadata: BTreeMap<String, Value>,
    pub created_at: DateTime<Utc>,
    pub created_at_display: String,
    pub client_ip: Option<String>,
    pub user_agent: Option<String>,
    pub reasoning_effort: Option<String>,
    pub reasoning_preset: Option<String>,
    pub compact: Option<bool>,
    pub request_kind: Option<String>,
    pub subagent_kind: Option<String>,
    pub token_details: TokenDetailsView,
    pub billing: Option<BillingView>,
    pub costs: Vec<CostView>,
    pub cost_coverage: CostCoverageView,
    pub first_token_latency_ms: Option<u64>,
    pub latency_ms_display: String,
    pub logical_outcome: String,
}

/// WebSocket 池决策的稳定形状；与 Provider 选择逻辑无关
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct WebSocketPoolMetadataView {
    pub kind: String,
}

/// 逻辑请求在上游和输出阶段测得的时延事实
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct UsageLatencyDetailsView {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub admission_decision_ms: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub account_selection_wait_ms: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub capacity_used_slots: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub capacity_total_slots: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub transport_decision_wait_ms: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub ws_connect_ms: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub upstream_headers_ms: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub first_event_ms: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub first_reasoning_ms: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub first_text_ms: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub openai_processing_ms: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub upstream_response_ms: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub upstream_api_overhead_ms: Option<f64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub upstream_engine_ms: Option<f64>,
}

/// 单次上游尝试展示
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct UsageAttemptView {
    pub id: String,
    pub attempt_index: u32,
    pub trigger: String,
    pub provider: String,
    pub model: Option<String>,
    pub transport: String,
    pub send_state: String,
    pub outcome: String,
    pub downstream_committed: Option<bool>,
    pub status_code: Option<u16>,
    pub provider_error_code: Option<String>,
    pub failure_class: Option<String>,
    pub cost_estimate_status: String,
    pub estimated_cost_amount: Option<String>,
    pub estimated_cost_currency: Option<String>,
    pub input_tokens: Option<u64>,
    pub output_tokens: Option<u64>,
    pub cached_input_tokens: Option<u64>,
    pub total_tokens: Option<u64>,
    pub first_token_ms: Option<u64>,
    pub latency_ms: Option<u64>,
    pub credential_name: Option<String>,
    pub account_id: Option<String>,
    pub account_name: Option<String>,
    pub account_email: Option<String>,
    pub authentication_kind: Option<String>,
    pub started_at: DateTime<Utc>,
    pub completed_at: Option<DateTime<Utc>>,
}

/// 逻辑请求详情与其尝试列表
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct UsageRecordDetailView {
    #[serde(flatten)]
    pub request: UsageRecordView,
    pub attempts: Vec<UsageAttemptView>,
    /// 尝试列表是否完整；best-effort 下恒为 false
    pub attempts_complete: bool,
}

/// Dashboard 趋势数据
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct TrendData {
    pub analytics: AnalyticsView,
    pub kind: TrendKind,
    pub points: Vec<TrendPointView>,
    pub summary: Vec<TrendSummaryView>,
}

/// Dashboard 单个趋势桶
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct TrendPointView {
    pub time: String,
    pub bucket: DateTime<Utc>,
    pub label: String,
    pub requests: String,
    pub requests_value: u64,
    pub input_tokens: String,
    pub input_tokens_value: u64,
    pub output_tokens: String,
    pub output_tokens_value: u64,
    pub cached_input_tokens: String,
    pub cached_input_tokens_value: u64,
    pub cache_hit_rate_value: f64,
    pub tokens_value: u64,
    pub errors: String,
    pub errors_value: u64,
    pub latency_value: Option<u64>,
    pub success_rate: String,
    pub success_rate_value: Option<f64>,
    pub first_token_p95_ms: Option<f64>,
    pub latency_p95_ms: Option<f64>,
    pub output_throughput_p50: Option<u64>,
}

/// 趋势指标的稳定身份，展示名称由管理端本地化
#[derive(Debug, Clone, Copy, Serialize)]
#[serde(rename_all = "camelCase")]
pub enum TrendMetric {
    InputTokens,
    OutputTokens,
    CachedInputTokens,
    FirstTokenP95Ms,
    LatencyP95Ms,
    OutputThroughputP50,
    Errors,
    SuccessRate,
    Requests,
}

/// Dashboard 趋势摘要
#[derive(Debug, Serialize)]
pub struct TrendSummaryView {
    pub metric: TrendMetric,
    pub value: String,
    pub ratio: Option<String>,
}

/// Dashboard 卡片集合
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DashboardCardsView {
    pub credentials: DashboardCredentialsCardView,
    pub traffic: DashboardTrafficCardView,
    pub tokens: DashboardTokensCardView,
    pub cache: DashboardCacheCardView,
}

/// Dashboard 上游凭据卡片
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DashboardCredentialsCardView {
    pub total: String,
    pub total_value: u64,
    pub available: String,
    pub available_value: u64,
    pub unavailable: String,
    pub unavailable_value: u64,
}

/// Dashboard 流量卡片
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DashboardTrafficCardView {
    pub today_requests: String,
    pub today_requests_value: u64,
    pub yesterday_requests_value: u64,
    pub total_requests: String,
}

/// Dashboard token 卡片
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DashboardTokensCardView {
    pub today_tokens: String,
    pub today_tokens_value: u64,
    pub yesterday_tokens_value: u64,
    pub total_tokens: String,
    pub total_billing_amount_usd: String,
}

/// Dashboard 缓存卡片
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DashboardCacheCardView {
    pub today_hit_rate: String,
    pub today_hit_rate_value: Option<f64>,
    pub yesterday_hit_rate_value: Option<f64>,
    pub total_hit_rate: String,
    pub total_cached_input_tokens: String,
    pub average_first_token_latency_ms: String,
}

/// Dashboard 账号概览指标的稳定标识
#[derive(Debug, Clone, Copy, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum DashboardAccountMetric {
    Requests,
    Tokens,
}

/// Dashboard 账号概览卡片所需的 Provider 安全投影
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DashboardAccountUsageView {
    pub upstream: Option<crate::admin::accounts::AccountUpstreamInfoView>,
    pub id: String,
    pub provider: String,
    pub authentication_kind: String,
    pub email: String,
    pub notes: Option<String>,
    pub plan_type: Option<String>,
    pub plan_type_display: String,
    pub tokens: String,
    pub request_count: u64,
    pub request_buckets: Vec<crate::time::RequestBucketView>,
    pub quota_used_percent: Option<f64>,
    pub usage_window: Option<crate::admin::accounts::AccountQuotaWindowView>,
    pub metric: DashboardAccountMetric,
    pub metric_value_raw: Option<u64>,
    pub metric_label: String,
    pub metric_value: String,
    pub last_used_at: Option<DateTime<Utc>>,
    pub last_used_relative: Option<crate::time::RelativeTimeView>,
    pub last_used: String,
}

/// Provider 账号池的持久事实汇总
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DashboardPoolSummaryView {
    pub total: u64,
    pub normal: u64,
    pub quota_paused: u64,
    pub quota_exhausted: u64,
    pub rate_limited: u64,
    pub disabled: u64,
    pub error: u64,
}

/// 同 target 账号调度容量；Redis 未提供聚合事实时运行中槽位保持空值
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DashboardCapacityInfoView {
    pub max_concurrent_per_account: u64,
    pub total_slots: Option<u64>,
    pub used_slots: Option<u64>,
    pub available_slots: Option<u64>,
}

/// 逻辑请求指标展示
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct RequestMetricsView {
    pub request_count: u64,
    pub success_count: u64,
    pub failure_count: u64,
    pub cancelled_count: u64,
    pub incomplete_count: u64,
    pub caller_error_count: u64,
    pub input_tokens: u64,
    pub output_tokens: u64,
    pub cached_input_tokens: u64,
    pub cache_write_input_tokens: u64,
    pub reasoning_output_tokens: u64,
    pub total_tokens: u64,
}

/// 上游尝试指标展示
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AttemptMetricsView {
    pub attempt_count: u64,
    pub success_count: u64,
    pub failure_count: u64,
    pub cancelled_count: u64,
    pub incomplete_count: u64,
    pub rate_limited_count: u64,
    pub auth_failure_count: u64,
    pub provider5xx_count: u64,
    pub cost_coverage: CostCoverageView,
    pub costs: Vec<CostView>,
}

/// 健康时间线单点
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct HealthTimelinePointView {
    pub bucket_start: DateTime<Utc>,
    pub time: String,
    pub status: String,
    pub reliability_display: String,
    pub success_requests: u64,
    pub failed_requests: u64,
    pub cancelled_requests: u64,
    pub incomplete_requests: u64,
    pub caller_error_requests: u64,
}

/// Dashboard 健康时间线
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct HealthTimelineView {
    pub title: String,
    pub description: String,
    pub reliability_display: String,
    pub status: String,
    pub success_requests: u64,
    pub failed_requests: u64,
    pub cancelled_requests: u64,
    pub incomplete_requests: u64,
    pub caller_error_requests: u64,
    pub points: Vec<HealthTimelinePointView>,
}

/// Dashboard 展示的实际 Provider 上游请求身份
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DashboardWireProfileView {
    pub provider: String,
    pub product: String,
    pub version: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub build: Option<String>,
    pub target: DashboardWireTargetView,
    pub user_agent: String,
    pub attributes: Vec<DashboardWireAttributeView>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub verified_at: Option<DateTime<Utc>>,
    pub verified_at_display: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub release: Option<DashboardDesktopReleaseView>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DashboardWireAttributeView {
    pub key: String,
    pub value: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DashboardWireTargetView {
    pub os_type: String,
    pub os_version: String,
    pub arch: String,
    pub terminal: String,
}

/// 发布检查与启动画像分离；未检查时使用明确的 `unchecked` 状态
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DashboardDesktopReleaseView {
    pub status: DashboardDesktopReleaseStatusView,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub checked_at: Option<DateTime<Utc>>,
    pub checked_at_display: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub latest_version: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub latest_build: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub error: Option<String>,
}

/// Dashboard 发布检查的稳定 wire 状态
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum DashboardDesktopReleaseStatusView {
    Unchecked,
    Aligned,
    ReviewRequired,
    CheckFailed,
}

impl From<domain::DesktopReleaseStatus> for DashboardDesktopReleaseStatusView {
    fn from(status: domain::DesktopReleaseStatus) -> Self {
        match status {
            domain::DesktopReleaseStatus::Unchecked => Self::Unchecked,
            domain::DesktopReleaseStatus::Current => Self::Aligned,
            domain::DesktopReleaseStatus::UpdateAvailable => Self::ReviewRequired,
            domain::DesktopReleaseStatus::Failed => Self::CheckFailed,
        }
    }
}

/// Dashboard 汇总响应数据
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DashboardDataView {
    pub analytics: AnalyticsView,
    pub as_of: DateTime<Utc>,
    pub as_of_display: String,
    pub cards: DashboardCardsView,
    pub trend: TrendData,
    pub health_timeline: HealthTimelineView,
    pub wire_profiles: Vec<DashboardWireProfileView>,
    pub account_usage: Vec<DashboardAccountUsageView>,
    pub usage_records: Vec<UsageListRecordView>,
    pub pool_summary: DashboardPoolSummaryView,
    pub capacity_info: DashboardCapacityInfoView,
    pub rotation_strategy: String,
}

/// 用量汇总响应数据
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct UsageSummaryView {
    pub analytics: AnalyticsView,
    pub total_requests: String,
    pub input_tokens: String,
    pub output_tokens: String,
    pub cached_input_tokens: String,
    pub cache_write_input_tokens: String,
    pub total_tokens: String,
    pub average_latency_ms: String,
    pub average_latency_ms_value: Option<u64>,
    pub logical_requests: RequestMetricsView,
    pub attempts: AttemptMetricsView,
}

/// 洞察健康趋势点
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct OverviewHealthPointView {
    pub bucket: DateTime<Utc>,
    pub label: String,
    pub total_requests: u64,
    pub success_requests: u64,
    pub failed_requests: u64,
    pub cancelled_requests: u64,
    pub incomplete_requests: u64,
    pub caller_error_requests: u64,
    pub error_rate: Option<f64>,
}

/// 洞察健康摘要
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct OverviewHealthView {
    pub total_requests: u64,
    pub success_requests: u64,
    pub failed_requests: u64,
    pub cancelled_requests: u64,
    pub incomplete_requests: u64,
    pub caller_error_requests: u64,
    pub success_rate: Option<f64>,
    pub completion_rate: f64,
    pub request_change_rate: Option<f64>,
    pub success_rate_change: Option<f64>,
    pub points: Vec<OverviewHealthPointView>,
}

/// 并发与调度等待的负载指标
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct OverviewLoadView {
    pub average_concurrency: f64,
    pub peak_concurrency: u64,
    pub admission_decision_p95_ms: Option<f64>,
    pub account_selection_wait_p95_ms: Option<f64>,
}

/// 洞察性能趋势点
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct OverviewPerformancePointView {
    pub bucket: DateTime<Utc>,
    pub label: String,
    pub latency_p50_ms: Option<f64>,
    pub latency_p95_ms: Option<f64>,
    pub latency_p99_ms: Option<f64>,
    pub first_token_p50_ms: Option<f64>,
    pub first_token_p95_ms: Option<f64>,
    pub first_token_p99_ms: Option<f64>,
    pub output_throughput_p10: Option<u64>,
    pub output_throughput_p50: Option<u64>,
    pub output_throughput_p90: Option<u64>,
    pub load: OverviewLoadView,
}

/// 洞察性能摘要
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct OverviewPerformanceView {
    pub latency_p50_ms: Option<f64>,
    pub latency_p95_ms: Option<f64>,
    pub latency_p99_ms: Option<f64>,
    pub first_token_p50_ms: Option<f64>,
    pub first_token_p95_ms: Option<f64>,
    pub first_token_p99_ms: Option<f64>,
    pub output_throughput_p10: Option<u64>,
    pub output_throughput_p50: Option<u64>,
    pub output_throughput_p90: Option<u64>,
    pub load: OverviewLoadView,
    pub points: Vec<OverviewPerformancePointView>,
}

/// 洞察成本趋势点
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct OverviewCostPointView {
    pub bucket: DateTime<Utc>,
    pub label: String,
    pub input_tokens: u64,
    pub output_tokens: u64,
    pub cached_input_tokens: u64,
    pub total_tokens: u64,
    pub estimated_cost: Option<String>,
    pub standard_cost: Option<String>,
    pub no_cache_cost: Option<String>,
    pub cache_savings: Option<String>,
    pub cached_token_rate: f64,
    pub cache_hit_request_rate: Option<f64>,
}

/// 洞察成本摘要
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct OverviewCostView {
    pub estimated_cost: Option<String>,
    pub standard_cost: Option<String>,
    pub no_cache_cost: Option<String>,
    pub cache_savings: Option<String>,
    pub tier_premium: Option<String>,
    pub cost_per_request: Option<String>,
    pub cost_per_successful_request: Option<String>,
    pub tokens_per_request: f64,
    pub cached_token_rate: f64,
    pub cache_hit_request_rate: Option<f64>,
    pub input_tokens: u64,
    pub output_tokens: u64,
    pub cached_input_tokens: u64,
    pub total_tokens: u64,
    pub points: Vec<OverviewCostPointView>,
    pub costs: Vec<CostView>,
    pub coverage: CostCoverageView,
}

/// Provider 维度洞察摘要
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ProviderOverviewView {
    pub provider: String,
    pub request_count: u64,
    pub attempt_count: u64,
    pub failure_count: u64,
    pub total_tokens: u64,
}

/// 用量洞察总响应
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct UsageInsightsOverviewView {
    pub analytics: AnalyticsView,
    pub granularity: String,
    pub health: OverviewHealthView,
    pub performance: OverviewPerformanceView,
    pub cost: OverviewCostView,
    pub attempts: AttemptMetricsView,
    pub providers: Vec<ProviderOverviewView>,
}

/// 单项洞察响应
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct UsageMetricView {
    pub analytics: AnalyticsView,
    pub granularity: String,
    #[serde(flatten)]
    pub data: UsageMetricDataView,
}

/// 指标标签与响应字段一一对应，未查询的数据不会出现在响应中
#[derive(Debug, Serialize)]
#[serde(tag = "metric", content = "data", rename_all = "camelCase")]
pub enum UsageMetricDataView {
    Health(OverviewHealthView),
    Latency(UsageMetricSeriesView<UsageLatencyView>),
    FirstToken(UsageMetricSeriesView<UsageLatencyView>),
    Throughput(UsageMetricSeriesView<UsageThroughputView>),
    Load(UsageMetricSeriesView<OverviewLoadView>),
    Cost(UsageMetricSeriesView<UsageCostSummaryView, UsageCostComparisonView>),
    Savings(UsageMetricSeriesView<UsageCostSummaryView, Option<String>>),
    Cache(UsageMetricSeriesView<UsageCostSummaryView, UsageCacheView>),
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct UsageMetricSeriesView<S, P = S> {
    pub summary: S,
    pub points: Vec<UsageMetricPointView<P>>,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct UsageMetricPointView<P> {
    pub bucket: DateTime<Utc>,
    pub label: String,
    pub request_count: u64,
    pub value: P,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct UsageLatencyView {
    pub p50_ms: Option<f64>,
    pub p95_ms: Option<f64>,
    pub p99_ms: Option<f64>,
}

#[derive(Debug, Serialize)]
pub struct UsageThroughputView {
    pub p10: Option<u64>,
    pub p50: Option<u64>,
    pub p90: Option<u64>,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct UsageCostSummaryView {
    pub estimated_cost: Option<String>,
    pub cache_savings: Option<String>,
    pub tier_premium: Option<String>,
    pub cost_per_successful_request: Option<String>,
    pub coverage: CostCoverageView,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct UsageCostComparisonView {
    pub estimated_cost: Option<String>,
    pub no_cache_cost: Option<String>,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct UsageCacheView {
    pub input_tokens: u64,
    pub cached_token_rate: f64,
    pub cache_hit_request_rate: Option<f64>,
}

/// 诊断聚合项目
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DiagnosticItemView {
    pub key: String,
    pub name: String,
    pub authentication_kind: Option<String>,
    pub account_plan_type: Option<String>,
    pub account_plan_type_display: Option<String>,
    pub account_upstream_peer: Option<bool>,
    pub request_count: u64,
    pub success_count: u64,
    pub error_count: u64,
    pub error_rate: Option<f64>,
    pub request_share: f64,
    pub average_latency_ms: Option<u64>,
    pub latency_p95_ms: Option<u64>,
    pub first_token_p95_ms: Option<u64>,
    pub non_completion_count: u64,
    pub non_completion_rate: f64,
    pub retry_count: u64,
    pub retry_rate: f64,
    pub estimated_cost: Option<String>,
    pub attempt_count: u64,
    pub total_tokens: u64,
}

/// 诊断聚合响应
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DiagnosticsView {
    pub analytics: AnalyticsView,
    pub dimension: String,
    pub items: Vec<DiagnosticItemView>,
}

/// 运维错误项目
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct OpsErrorView {
    pub client_api_key_name: Option<String>,
    pub id: String,
    pub request_id: Option<String>,
    pub client_api_key_id: Option<String>,
    pub kind: String,
    pub operation: String,
    pub protocol: Option<String>,
    pub client_transport: Option<String>,
    pub provider: Option<String>,
    pub authentication_kind: Option<String>,
    pub account_id: Option<String>,
    pub account_name: Option<String>,
    pub account_email: Option<String>,
    pub account_plan_type: Option<String>,
    pub account_plan_type_display: Option<String>,
    pub route: String,
    pub model: Option<String>,
    pub requested_model: Option<String>,
    pub upstream_model: Option<String>,
    pub service_tier: Option<String>,
    pub client_status_code: Option<i64>,
    pub upstream_status_code: Option<i64>,
    pub transport: Option<String>,
    pub attempt_index: Option<u32>,
    pub failure_class: String,
    pub upstream_send_state: Option<String>,
    pub provider_error_code: Option<String>,
    pub response_id: Option<String>,
    pub upstream_request_id: Option<String>,
    pub latency_ms: Option<u64>,
    pub client_ip: Option<String>,
    pub user_agent: Option<String>,
    pub reasoning_effort: Option<String>,
    pub reasoning_preset: Option<String>,
    pub request_kind: Option<String>,
    pub subagent_kind: Option<String>,
    pub compact: Option<bool>,
    pub message: String,
    /// 受控错误详情，分别承载本地原因链与上游错误正文
    pub error_details: Option<String>,
    pub metadata: OpsErrorMetadataView,
    pub created_at: DateTime<Utc>,
    pub created_at_display: String,
}

/// 运维错误安全元数据；只保留可查询的标识，不回显秘密材料
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct OpsErrorMetadataView {
    pub source: String,
    pub component: String,
    pub attempt_id: Option<String>,
    pub account_label: Option<String>,
    pub continuation_affinity_hash: Option<String>,
    pub continuation_previous_response_id_hash: Option<String>,
    pub continuation_unavailable_reason: Option<String>,
    pub upstream_connection_id: Option<String>,
    pub upstream_connection_exit_reason: Option<String>,
    pub upstream_connection_age_ms: Option<u64>,
    pub upstream_connection_idle_ms: Option<u64>,
    pub recovery_request_id: Option<String>,
    pub recovered_at: Option<DateTime<Utc>>,
    pub recovery_attempt_count: u32,
    pub recovery_retry_delay_ms: Option<u64>,
    pub recovery_total_latency_ms: Option<u64>,
}

/// 统计覆盖、新鲜度与近似口径，时间文案使用部署时区
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AnalyticsView {
    pub coverage_start: Option<DateTime<Utc>>,
    pub coverage_start_display: Option<String>,
    pub coverage_end: Option<DateTime<Utc>>,
    pub coverage_end_display: Option<String>,
    pub generated_at: DateTime<Utc>,
    pub generated_at_display: String,
    pub lag_seconds: u64,
    pub state: String,
    pub percentiles_approximate: bool,
    pub schema_version: u32,
    pub histogram_version: u32,
}
