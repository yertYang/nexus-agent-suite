//! 系统管理接口的查询与请求 wire contract

//!
//! 这里不依赖更新服务或进程控制；应用层通过窄端口提供系统操作事实

use crate::auth::SessionState;

use std::convert::Infallible;

use axum::{
    Router,
    extract::State,
    http::StatusCode,
    response::{
        IntoResponse,
        sse::{Event, KeepAlive, Sse},
    },
    routing::{get, post},
};
use futures::{Stream, StreamExt};
use gateway_admin::model::system::{
    SystemOperationAccepted, SystemOperationKind, SystemOperationState, SystemOperationStatus,
    SystemRestartPlan, SystemUpdateChannel, SystemUpdateCheck, SystemUpdateDetail,
    SystemUpdateEvent, SystemUpdateEventLevel, SystemUpdatePolicy, SystemUpdateStatus,
    SystemVersion,
};
use serde::{Deserialize, Serialize};

use super::{
    AdminAuth, AdminEnvelope, AdminError, AdminJson, AdminQuery, AdminResponse,
    wire::map_admin_service_error,
};

/// 更新详情查询参数
#[derive(Debug, Clone, Default, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct UpdateDetailQuery {
    #[serde(default)]
    refresh: bool,
    #[serde(default)]
    summary_only: bool,
    channel: Option<SystemUpdateChannel>,
}

impl UpdateDetailQuery {
    #[must_use]
    pub const fn channel(&self) -> Option<SystemUpdateChannel> {
        self.channel
    }

    /// 摘要只读取发布索引；手动刷新有独立的最短间隔
    #[must_use]
    pub const fn check(&self) -> SystemUpdateCheck {
        if self.summary_only {
            SystemUpdateCheck::Summary
        } else if self.refresh {
            SystemUpdateCheck::Refresh
        } else {
            SystemUpdateCheck::Detail
        }
    }
}

/// 执行更新请求
#[derive(Debug, Clone, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct UpdateRequest {
    target_version: String,
    channel: Option<SystemUpdateChannel>,
}

impl UpdateRequest {
    /// 取出确认的目标版本原值，由更新领域负责版本规范化和校验
    #[must_use]
    pub fn into_target_version(self) -> String {
        self.target_version
    }
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct SystemVersionView {
    version: String,
    git_sha: String,
    build_time: String,
    deployment_mode: String,
    deployment_mode_label: String,
    update_channel: String,
    latest_version: String,
    has_update: bool,
    update_cached: bool,
    update_warning: Option<String>,
}

impl From<SystemVersion> for SystemVersionView {
    fn from(version: SystemVersion) -> Self {
        Self {
            deployment_mode_label: deployment_mode_label(&version.deployment_mode).to_owned(),
            version: version.version,
            git_sha: version.git_sha,
            build_time: version.build_time,
            deployment_mode: version.deployment_mode,
            update_channel: version.update_channel,
            latest_version: version.latest_version,
            has_update: version.has_update,
            update_cached: version.update_cached,
            update_warning: version.update_warning,
        }
    }
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct SystemUpdateDetailView {
    policy: SystemUpdatePolicy,
    current_version: String,
    latest_version: String,
    has_update: bool,
    deployment_mode: String,
    deployment_mode_label: String,
    build_type: String,
    build_type_label: String,
    release_url: Option<String>,
    notes: Option<String>,
    cached: bool,
    update_supported: bool,
    unsupported_reason: Option<String>,
    warning: Option<String>,
    retry_at: Option<String>,
    retry_at_display: Option<String>,
}

impl From<(SystemUpdateDetail, crate::time::TimePresenter)> for SystemUpdateDetailView {
    fn from((detail, time): (SystemUpdateDetail, crate::time::TimePresenter)) -> Self {
        Self {
            deployment_mode_label: deployment_mode_label(&detail.deployment_mode).to_owned(),
            build_type_label: build_type_label(&detail.build_type),
            policy: detail.policy,
            current_version: detail.current_version,
            latest_version: detail.latest_version,
            has_update: detail.has_update,
            deployment_mode: detail.deployment_mode,
            build_type: detail.build_type,
            release_url: detail.release_url,
            notes: detail.notes,
            cached: detail.cached,
            update_supported: detail.update_supported,
            unsupported_reason: detail.unsupported_reason,
            warning: detail.warning,
            retry_at: detail.retry_at.map(|at| at.to_rfc3339()),
            retry_at_display: detail.retry_at.map(|at| time.label(at, "%m-%d %H:%M:%S")),
        }
    }
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct SystemOperationStateView {
    operation_id: Option<String>,
    kind: Option<&'static str>,
    status: &'static str,
    target_version: Option<String>,
    message: Option<String>,
    error: Option<String>,
    started_at: Option<String>,
    started_at_display: Option<String>,
    finished_at: Option<String>,
    finished_at_display: Option<String>,
}

impl From<(SystemOperationState, crate::time::TimePresenter)> for SystemOperationStateView {
    fn from((operation, time): (SystemOperationState, crate::time::TimePresenter)) -> Self {
        Self {
            operation_id: operation.operation_id,
            kind: operation.kind.map(operation_kind_name),
            status: operation_status_name(operation.status),
            target_version: operation.target_version,
            message: operation.message,
            error: operation.error,
            started_at_display: operation
                .started_at
                .as_ref()
                .map(|value| time.datetime(value)),
            started_at: operation.started_at.map(|value| value.to_rfc3339()),
            finished_at_display: operation
                .finished_at
                .as_ref()
                .map(|value| time.datetime(value)),
            finished_at: operation.finished_at.map(|value| value.to_rfc3339()),
        }
    }
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct SystemUpdateStatusView {
    previous_version: Option<String>,
    current_version: Option<String>,
    need_restart: bool,
    operation: SystemOperationStateView,
}

impl From<(SystemUpdateStatus, crate::time::TimePresenter)> for SystemUpdateStatusView {
    fn from((status, time): (SystemUpdateStatus, crate::time::TimePresenter)) -> Self {
        Self {
            previous_version: status.previous_version,
            current_version: status.current_version,
            need_restart: status.need_restart,
            operation: SystemOperationStateView::from((status.operation, time)),
        }
    }
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct UpdateAcceptedView {
    operation_id: String,
    deployment_mode: String,
    message: String,
    target_version: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct RollbackAcceptedView {
    message: String,
    need_restart: bool,
    operation_id: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct RestartAcceptedView {
    message: String,
    operation_id: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct SystemUpdateEventView {
    id: String,
    operation_id: Option<String>,
    level: &'static str,
    step: Option<String>,
    message: String,
    terminal: bool,
    progress_percent: Option<u8>,
    at: String,
    at_display: String,
}

/// 构造固定 GET/POST 系统管理路由
pub fn router<S>() -> Router<S>
where
    S: SessionState + Clone + Send + Sync + 'static,
{
    Router::new()
        .route("/api/admin/system/version", get(version::<S>))
        .route("/api/admin/system/update/detail", get(update_detail::<S>))
        .route(
            "/api/admin/system/update/events",
            get(update_event_stream::<S>),
        )
        .route("/api/admin/system/update", post(perform_update::<S>))
        .route("/api/admin/system/update/status", get(update_status::<S>))
        .route("/api/admin/system/rollback", post(rollback::<S>))
        .route("/api/admin/system/restart/check", get(restart_plan::<S>))
        .route("/api/admin/system/restart", post(restart::<S>))
}

async fn version<S>(
    _auth: AdminAuth,
    State(state): State<S>,
) -> Result<impl IntoResponse, AdminError>
where
    S: SessionState + Send + Sync,
{
    let version = state
        .admin_services()
        .system()
        .version()
        .await
        .map_err(map_system_error)?;
    Ok(AdminResponse::new(
        StatusCode::OK,
        AdminEnvelope::ok(SystemVersionView::from(version)),
    ))
}

async fn update_detail<S>(
    _auth: AdminAuth,
    State(state): State<S>,
    AdminQuery(query): AdminQuery<UpdateDetailQuery>,
) -> Result<impl IntoResponse, AdminError>
where
    S: SessionState + Send + Sync,
{
    let detail = state
        .admin_services()
        .system()
        .update_detail(query.check(), query.channel())
        .await
        .map_err(map_system_error)?;
    Ok(AdminResponse::new(
        StatusCode::OK,
        AdminEnvelope::ok(SystemUpdateDetailView::from((
            detail,
            crate::time::TimePresenter::new(state.admin_services().timezone()),
        ))),
    ))
}

async fn update_event_stream<S>(
    _auth: AdminAuth,
    State(state): State<S>,
) -> Result<Sse<impl Stream<Item = Result<Event, Infallible>>>, AdminError>
where
    S: SessionState + Send + Sync,
{
    let time = crate::time::TimePresenter::new(state.admin_services().timezone());
    let stream = state
        .admin_services()
        .system()
        .update_events()
        .map(move |message| {
            let id = message.id.clone();
            let data = SystemUpdateEventView::from((message, time))
                .into_json()
                .to_string();
            Ok(Event::default().event("update").id(id).data(data))
        });
    Ok(Sse::new(stream).keep_alive(KeepAlive::default()))
}

async fn perform_update<S>(
    _auth: AdminAuth,
    State(state): State<S>,
    payload: Option<AdminJson<UpdateRequest>>,
) -> Result<impl IntoResponse, AdminError>
where
    S: SessionState + Send + Sync,
{
    let (target, channel) = payload.map_or((None, None), |AdminJson(value)| {
        (Some(value.target_version), value.channel)
    });
    let result = state
        .admin_services()
        .system()
        .perform_update(target, channel)
        .await
        .map_err(map_system_error)?;
    let SystemOperationAccepted::Update {
        operation_id,
        deployment_mode,
        message,
        target_version,
    } = result
    else {
        return Err(AdminError::internal());
    };
    Ok(AdminResponse::new(
        StatusCode::ACCEPTED,
        AdminEnvelope::ok(UpdateAcceptedView {
            operation_id,
            deployment_mode,
            message,
            target_version,
        }),
    ))
}

async fn update_status<S>(
    _auth: AdminAuth,
    State(state): State<S>,
) -> Result<impl IntoResponse, AdminError>
where
    S: SessionState + Send + Sync,
{
    let time = crate::time::TimePresenter::new(state.admin_services().timezone());
    let status = state
        .admin_services()
        .system()
        .update_status()
        .await
        .map_err(map_system_error)?;
    Ok(AdminResponse::new(
        StatusCode::OK,
        AdminEnvelope::ok(SystemUpdateStatusView::from((status, time))),
    ))
}

async fn rollback<S>(
    _auth: AdminAuth,
    State(state): State<S>,
) -> Result<impl IntoResponse, AdminError>
where
    S: SessionState + Send + Sync,
{
    let result = state
        .admin_services()
        .system()
        .rollback()
        .await
        .map_err(map_system_error)?;
    let SystemOperationAccepted::Rollback {
        operation_id,
        message,
        need_restart,
    } = result
    else {
        return Err(AdminError::internal());
    };
    Ok(AdminResponse::new(
        StatusCode::OK,
        AdminEnvelope::ok(RollbackAcceptedView {
            message,
            need_restart,
            operation_id,
        }),
    ))
}

async fn restart_plan<S>(
    _auth: AdminAuth,
    State(state): State<S>,
) -> Result<impl IntoResponse, AdminError>
where
    S: SessionState + Send + Sync,
{
    let plan = state
        .admin_services()
        .system()
        .restart_plan()
        .await
        .map_err(map_system_error)?;
    Ok(AdminResponse::new(StatusCode::OK, AdminEnvelope::ok(plan)))
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct RestartRequest {
    confirmation: Option<SystemRestartPlan>,
}

async fn restart<S>(
    auth: AdminAuth,
    State(state): State<S>,
    payload: Option<AdminJson<RestartRequest>>,
) -> Result<impl IntoResponse, AdminError>
where
    S: SessionState + Send + Sync,
{
    let result = state
        .admin_services()
        .system()
        .restart(
            payload.and_then(|AdminJson(request)| request.confirmation),
            &auth.context().mutation_context(),
        )
        .await
        .map_err(map_system_error)?;
    let SystemOperationAccepted::Restart {
        operation_id,
        message,
    } = result
    else {
        return Err(AdminError::internal());
    };
    Ok(AdminResponse::new(
        StatusCode::OK,
        AdminEnvelope::ok(RestartAcceptedView {
            message,
            operation_id,
        }),
    ))
}

impl From<(SystemUpdateEvent, crate::time::TimePresenter)> for SystemUpdateEventView {
    fn from((event, time): (SystemUpdateEvent, crate::time::TimePresenter)) -> Self {
        Self {
            id: event.id,
            operation_id: event.operation_id,
            level: update_event_level_name(event.level),
            step: event.step,
            message: event.message,
            terminal: event.terminal,
            progress_percent: event.progress_percent,
            at_display: time.time(&event.occurred_at),
            at: event.occurred_at.to_rfc3339(),
        }
    }
}

impl SystemUpdateEventView {
    fn into_json(self) -> serde_json::Value {
        serde_json::json!({
            "id": self.id,
            "operationId": self.operation_id,
            "level": self.level,
            "step": self.step,
            "message": self.message,
            "terminal": self.terminal,
            "progressPercent": self.progress_percent,
            "at": self.at, "atDisplay": self.at_display,
        })
    }
}

fn deployment_mode_label(mode: &str) -> &'static str {
    match mode {
        "docker" => "Docker",
        "binary" => "二进制",
        _ => "源码运行",
    }
}

fn build_type_label(build_type: &str) -> String {
    match build_type {
        "release" => "正式构建",
        "source" => "源码构建",
        "dev" => "开发构建",
        value => value,
    }
    .to_owned()
}

const fn operation_kind_name(kind: SystemOperationKind) -> &'static str {
    match kind {
        SystemOperationKind::Update => "update",
        SystemOperationKind::Rollback => "rollback",
        SystemOperationKind::Restart => "restart",
    }
}

const fn operation_status_name(status: SystemOperationStatus) -> &'static str {
    match status {
        SystemOperationStatus::Idle => "idle",
        SystemOperationStatus::Running => "running",
        SystemOperationStatus::Succeeded => "succeeded",
        SystemOperationStatus::Failed => "failed",
    }
}

const fn update_event_level_name(level: SystemUpdateEventLevel) -> &'static str {
    match level {
        SystemUpdateEventLevel::Info => "info",
        SystemUpdateEventLevel::Warning => "warning",
        SystemUpdateEventLevel::Success => "success",
        SystemUpdateEventLevel::Error => "error",
    }
}

fn map_system_error(error: gateway_admin::model::AdminError) -> AdminError {
    map_admin_service_error(error)
}
