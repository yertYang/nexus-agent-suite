//! 管理端 HTTP adapter、wire contract 与固定路由

use crate::auth::SessionState;

use axum::{
    Router,
    http::{HeaderValue, header},
    middleware,
    response::Response,
    routing::any,
};
use tower_http::compression::{CompressionLayer, CompressionLevel};

pub mod account_groups;
pub mod accounts;
pub mod auth;
pub mod backups;
pub mod client_keys;
mod compression;
pub(crate) mod diagnostics;
mod extract;
pub mod observability;
mod plugins;
pub mod presenter;
pub mod proxies;
pub mod settings;
pub mod system;
pub mod wire;

pub use auth::AdminAuth;
pub use extract::{AdminJson, AdminQuery};
pub use wire::{
    ADMIN_OK_CODE, ADMIN_OK_MESSAGE, AdminEnvelope, AdminError, AdminErrorBody, AdminErrorCode,
    AdminPageData, AdminResponse, PageMeta, WireValidationError,
};

pub(crate) fn model_router() -> Router<crate::ApiState> {
    plugins::model_router().layer(middleware::map_response(no_store))
}

/// 构造管理用例路由；模型执行桥由完整 API 组合单独装配
pub fn router<S>() -> Router<S>
where
    S: SessionState + Clone + Send + Sync + 'static,
{
    Router::new()
        .merge(account_groups::router::<S>())
        .merge(proxies::router::<S>())
        .merge(plugins::router::<S>())
        .merge(accounts::router::<S>())
        .merge(backups::router::<S>())
        .merge(client_keys::router::<S>())
        .merge(observability::router::<S>())
        .merge(settings::router::<S>())
        .merge(system::router::<S>())
        .method_not_allowed_fallback(method_not_allowed)
        .route("/api/admin", any(admin_not_found))
        .route("/api/admin/{*path}", any(admin_not_found))
        .layer(
            CompressionLayer::new()
                .quality(CompressionLevel::Fastest)
                .compress_when(compression::AdminJson),
        )
        .merge(plugins::public_router().method_not_allowed_fallback(method_not_allowed))
        .layer(middleware::map_response(no_store))
}

async fn method_not_allowed() -> AdminError {
    AdminError::method_not_allowed()
}

async fn admin_not_found() -> AdminError {
    AdminError::admin_route_not_found()
}

async fn no_store(mut response: Response) -> Response {
    response
        .headers_mut()
        .entry(header::CACHE_CONTROL)
        .or_insert(HeaderValue::from_static("no-store"));
    response
}
