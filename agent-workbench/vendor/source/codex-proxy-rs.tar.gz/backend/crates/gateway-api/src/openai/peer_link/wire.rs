//! 将已脱敏的互联领域观测投影为版本化协议

use chrono::{DateTime, Utc};
use gateway_admin::model::peer_link::{PeerLinkExport, PeerModelState as ModelState};
use gateway_core::{engine::budget::ClientBudgetWindow, metering::Decimal};
use gateway_protocol::peer::{
    OBJECT, PeerBudgetWindow, PeerComponentStatus, PeerKeyLimits, PeerKeyUsage, PeerLink,
    PeerModelAvailability, PeerModelCoverage, PeerModelState, PeerPlanCount, PeerPool,
    PeerPoolStates, PeerQuota, PeerQuotaAccount, PeerQuotaWindow, PeerUsage, SCHEMA_VERSION,
};

pub(super) fn response(export: PeerLinkExport) -> PeerLink {
    let mut capabilities = vec!["key_usage".to_owned(), "key_limits".to_owned()];
    let pool = export.pool.map(|pool| {
        capabilities.push("pool_summary".to_owned());
        PeerPool {
            observed_at: Some(export.observed_at.to_rfc3339()),
            account_count: pool.ready
                + pool.cooldown
                + pool.exhausted
                + pool.disabled
                + pool.error
                + pool.unknown,
            states: PeerPoolStates {
                ready: pool.ready,
                cooldown: pool.cooldown,
                exhausted: pool.exhausted,
                disabled: pool.disabled,
                error: pool.error,
                unknown: pool.unknown,
            },
            plans: pool.plans.map(|plans| {
                plans
                    .into_iter()
                    .map(|(name, count)| PeerPlanCount { name, count })
                    .collect()
            }),
        }
    });
    let quota = export.quota.map(|accounts| {
        capabilities.extend(["quota_windows".to_owned(), "model_availability".to_owned()]);
        PeerQuota {
            accounts: accounts
                .into_iter()
                .map(|account| PeerQuotaAccount {
                    id: account.id,
                    models: account.models,
                    observed_at: account.observed_at.map(|time| time.to_rfc3339()),
                    expires_at: account.expires_at.map(|time| time.to_rfc3339()),
                    windows: account
                        .windows
                        .into_iter()
                        .map(|window| PeerQuotaWindow {
                            key: window.key,
                            group: Some(window.group),
                            label: Some(window.label),
                            limit_id: window.limit_id,
                            limit_name: window.limit_name,
                            role: window.role.map(|role| role.as_str().to_owned()),
                            window_seconds: window.window_seconds,
                            used_percent: window.used_percent,
                            reset_at: window.reset_at.map(|time| time.to_rfc3339()),
                            limit_reached: window.limit_reached,
                        })
                        .collect(),
                })
                .collect(),
        }
    });
    PeerLink {
        object: OBJECT.to_owned(),
        schema_version: SCHEMA_VERSION,
        capabilities,
        observed_at: export.observed_at.to_rfc3339(),
        expires_at: export.expires_at.to_rfc3339(),
        key_limits: Some(PeerKeyLimits {
            max_concurrency: Some(export.key_limits.max_concurrency),
            requests_per_minute: Some(export.key_limits.requests_per_minute),
        }),
        usage: Some(PeerUsage {
            status: PeerComponentStatus::Available,
            observed_at: Some(export.budget_observed_at.to_rfc3339()),
            data: Some(PeerKeyUsage {
                unit: Some("USD".to_owned()),
                allowed: Some(export.budget_access.allowed()),
                windows: vec![
                    budget_window(
                        "daily",
                        "日额度",
                        export.budget.limits.daily_usd,
                        export.budget.daily_used_usd,
                        export.budget.daily_window,
                        export.budget_access.daily_limit_reached,
                    ),
                    budget_window(
                        "weekly",
                        "周额度",
                        export.budget.limits.weekly_usd,
                        export.budget.weekly_used_usd,
                        export.budget.weekly_window,
                        export.budget_access.weekly_limit_reached,
                    ),
                ],
            }),
        }),
        pool,
        quota,
        models: export
            .models
            .into_iter()
            .map(|model| PeerModelAvailability {
                model: model.model,
                coverage: if model.complete {
                    PeerModelCoverage::Complete
                } else {
                    PeerModelCoverage::Partial
                },
                state: match model.state {
                    ModelState::Available => PeerModelState::Available,
                    ModelState::Exhausted => PeerModelState::Exhausted,
                    ModelState::Unknown => PeerModelState::Unknown,
                },
                observed_at: model.observed_at.map(|time| time.to_rfc3339()),
                expires_at: model.expires_at.map(|time| time.to_rfc3339()),
            })
            .collect(),
    }
}

fn budget_window(
    key: &str,
    label: &str,
    total: Decimal,
    used: Decimal,
    window: Option<ClientBudgetWindow>,
    limit_reached: bool,
) -> PeerBudgetWindow {
    let limited = total != Decimal::ZERO;
    let window = window.filter(|w| w.start < w.end);
    PeerBudgetWindow {
        key: key.to_owned(),
        label: Some(label.to_owned()),
        window_seconds: window.and_then(|w| {
            let duration = w.end.duration_since(w.start).ok()?;
            (duration.subsec_nanos() == 0).then_some(duration.as_secs())
        }),
        limit_reached: Some(limit_reached),
        total: limited.then(|| total.canonical()),
        used: used.canonical(),
        remaining: limited.then(|| total.saturating_sub(used).canonical()),
        reset_at: window.map(|w| DateTime::<Utc>::from(w.end).to_rfc3339()),
    }
}
