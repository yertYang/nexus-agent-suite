//! 数据面客户端 Bearer 与 x-api-key 认证

use axum::{
    http::{HeaderMap, header::AUTHORIZATION},
    response::{IntoResponse, Response},
};
use gateway_core::engine::{
    authentication::ClientAuthenticationRequest, execution::AuthenticatedClient,
};
use gateway_core::policy::{ClientVersionRejection, CodexClientKind, CodexClientVersion};

use super::{
    error::{
        client_version_rejection_response, missing_client_api_key_response,
        runtime_unavailable_response,
    },
    service::OpenAiService,
};

/// Client API key 鉴权失败原因
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ClientApiKeyAuthError {
    /// 缺失 Authorization 头
    MissingAuthorization,
    /// Authorization 头不是合法的 Bearer token
    MalformedAuthorization,
    /// Bearer token 不是 client API key 格式
    InvalidKeyFormat,
    /// Key 不存在、已禁用或 wire 格式无效
    InvalidKey,
    /// RuntimeSnapshot 一致性保护暂停接收新请求
    RuntimeUnavailable,
}

/// Client API Key 或最低版本准入失败
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ClientAccessError {
    Authentication(ClientApiKeyAuthError),
    Version(ClientVersionRejection),
}

impl From<ClientApiKeyAuthError> for ClientAccessError {
    fn from(error: ClientApiKeyAuthError) -> Self {
        Self::Authentication(error)
    }
}

impl From<ClientVersionRejection> for ClientAccessError {
    fn from(error: ClientVersionRejection) -> Self {
        Self::Version(error)
    }
}

/// 从有界请求头中识别出的客户端及其可选合法版本
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct IdentifiedCodexClient {
    kind: CodexClientKind,
    version: Option<CodexClientVersion>,
}

impl IdentifiedCodexClient {
    #[must_use]
    pub const fn kind(&self) -> CodexClientKind {
        self.kind
    }

    #[must_use]
    pub const fn version(&self) -> Option<&CodexClientVersion> {
        self.version.as_ref()
    }
}

impl ClientApiKeyAuthError {
    /// 返回可用于日志和指标的稳定失败原因
    #[must_use]
    pub const fn reason(self) -> &'static str {
        match self {
            Self::MissingAuthorization => "missing_authorization",
            Self::MalformedAuthorization => "malformed_authorization",
            Self::InvalidKeyFormat => "invalid_key_format",
            Self::InvalidKey => "invalid_key",
            Self::RuntimeUnavailable => "runtime_unavailable",
        }
    }
}

pub(crate) async fn authenticate_client(
    service: &OpenAiService,
    headers: &HeaderMap,
    accepted: ClientKeyHeaders,
) -> Result<AuthenticatedClient, ClientAccessError> {
    let request = client_authentication_request(headers, accepted)?;
    let client = service.authenticate(request).await?;
    if let Some(identified) = identify_codex_client(headers) {
        client
            .snapshot()
            .min_codex_client_versions()
            .enforce(identified.kind(), identified.version())?;
    }
    Ok(client)
}

/// 复用数据面入口认证计划，但不记录 Key 使用事实或执行推理准入
pub(crate) async fn verify_client(
    service: &OpenAiService,
    headers: &HeaderMap,
) -> Result<AuthenticatedClient, ClientApiKeyAuthError> {
    let request = client_authentication_request(headers, ClientKeyHeaders::Bearer)?;
    service.verify(request).await
}

/// 入口声明其认证头合同，所有形式仍进入同一 Client Key 认证链路
#[derive(Clone, Copy)]
pub(crate) enum ClientKeyHeaders {
    Bearer,
    Anthropic,
}

fn client_authentication_request(
    headers: &HeaderMap,
    accepted: ClientKeyHeaders,
) -> Result<ClientAuthenticationRequest, ClientApiKeyAuthError> {
    let raw = if let Some(authorization) = headers.get(AUTHORIZATION) {
        authorization
            .to_str()
            .map_err(|_| ClientApiKeyAuthError::MalformedAuthorization)?
            .to_owned()
    } else if matches!(accepted, ClientKeyHeaders::Anthropic)
        && let Some(key) = headers.get("x-api-key")
    {
        format!(
            "Bearer {}",
            key.to_str()
                .map_err(|_| ClientApiKeyAuthError::MalformedAuthorization)?
        )
    } else {
        return Err(ClientApiKeyAuthError::MissingAuthorization);
    };
    let request = ClientAuthenticationRequest::new(raw)
        .map_err(|_| ClientApiKeyAuthError::MalformedAuthorization)?;
    let request = request.with_request_context(
        crate::middleware::current().and_then(|context| context.extensions.shared_request()),
    );
    Ok(match crate::middleware::current_settings() {
        Some(settings) => request.with_settings(settings),
        None => request,
    })
}

pub(crate) fn client_access_error_response(error: ClientAccessError) -> Response {
    let code = match &error {
        ClientAccessError::Authentication(error) => error.reason(),
        ClientAccessError::Version(error) if error.current().is_some() => "client_version_too_old",
        ClientAccessError::Version(_) => "client_version_unavailable",
    };
    let mut response = match error {
        ClientAccessError::Authentication(error) => {
            log_client_api_key_auth_failure(error);
            if error == ClientApiKeyAuthError::RuntimeUnavailable {
                runtime_unavailable_response().into_response()
            } else {
                missing_client_api_key_response().into_response()
            }
        }
        ClientAccessError::Version(error) => {
            tracing::info!(
                client = error.kind().as_str(),
                current_version = error.current().map(ToString::to_string),
                min_version = %error.min(),
                "Codex client version requirement rejected request"
            );
            client_version_rejection_response(&error).into_response()
        }
    };
    response
        .extensions_mut()
        .insert(crate::client_error::AccessRejection(code));
    response
}

/// Desktop 优先于内嵌 CLI/Core；未知客户端及未提供应用版本的手机远程客户端返回 `None`
#[must_use]
pub fn identify_codex_client(headers: &HeaderMap) -> Option<IdentifiedCodexClient> {
    const MAXIMUM_HEADER_LENGTH: usize = 4096;
    // 官方 CLI、IDE、SDK 与 App Server 的 UA 产品版本均来自所运行的 Codex Core
    const CORE_CLIENT_PRODUCTS: &[&str] = &[
        "codex_cli_rs",
        "codex-cli",
        "codex-tui",
        "codex_exec",
        "codex_vscode",
        "codex_sdk_ts",
        "codex_python_sdk",
        "codex-app-server",
        "codex-app-server-sdk",
        "codex_mcp_server",
    ];

    let originator = bounded_ascii_header(headers, "originator", MAXIMUM_HEADER_LENGTH);
    let user_agent = bounded_ascii_header(headers, "user-agent", MAXIMUM_HEADER_LENGTH);
    let is_desktop = originator.is_some_and(|value| value.eq_ignore_ascii_case("Codex Desktop"))
        || user_agent.is_some_and(|value| contains_ascii_case_insensitive(value, "Codex Desktop"));
    if is_desktop {
        let explicit_version = bounded_ascii_header(headers, "version", MAXIMUM_HEADER_LENGTH);
        let user_agent_version = user_agent.and_then(desktop_version_from_user_agent);
        // 手机远程初始化会覆盖进程级 UA 后缀，保留的 Desktop/Core 前缀不代表应用版本
        // 仅缺失版本信息时免于门禁；已提供的版本即使非法，也继续按 Desktop 校验
        if !headers.contains_key("version")
            && user_agent_version.is_none()
            && headers
                .get("user-agent")
                .is_some_and(|value| value.as_bytes().len() <= MAXIMUM_HEADER_LENGTH)
            && user_agent.is_some_and(has_chatgpt_remote_user_agent_suffix)
        {
            return None;
        }
        let version = match explicit_version {
            Some(value) => CodexClientVersion::parse(value).ok(),
            None => user_agent_version.and_then(|value| CodexClientVersion::parse(value).ok()),
        };
        return Some(IdentifiedCodexClient {
            kind: CodexClientKind::Desktop,
            version,
        });
    }

    let user_agent = user_agent?;
    for product in user_agent.split(|character: char| {
        character.is_ascii_whitespace() || matches!(character, '(' | ')' | ';' | ',' | '[' | ']')
    }) {
        let (name, version) = product
            .split_once('/')
            .map_or((product, None), |(name, version)| (name, Some(version)));
        if CORE_CLIENT_PRODUCTS
            .iter()
            .any(|known| name.eq_ignore_ascii_case(known))
        {
            return Some(IdentifiedCodexClient {
                kind: CodexClientKind::Cli,
                version: version.and_then(|value| CodexClientVersion::parse(value).ok()),
            });
        }
    }
    None
}

fn bounded_ascii_header<'a>(
    headers: &'a HeaderMap,
    name: &'static str,
    maximum_length: usize,
) -> Option<&'a str> {
    let value = headers.get(name)?.to_str().ok()?;
    if !value.is_ascii() {
        return None;
    }
    Some(&value[..value.len().min(maximum_length)])
}

fn desktop_version_from_user_agent(user_agent: &str) -> Option<&str> {
    let marker = "Codex Desktop;";
    let start = find_ascii_case_insensitive(user_agent, marker)? + marker.len();
    // 空候选也代表已提供应用版本，不能被手机远程的缺失版本规则放行
    user_agent[start..]
        .trim_start()
        .split([')', ' ', ';', ','])
        .next()
}

fn has_chatgpt_remote_user_agent_suffix(user_agent: &str) -> bool {
    let Some((_, suffix)) = user_agent
        .strip_suffix(')')
        .and_then(|value| value.rsplit_once(" ("))
    else {
        return false;
    };
    let Some((name, version)) = suffix.split_once("; ") else {
        return false;
    };
    let Some(platform) = name
        .strip_prefix("codex_chatgpt_")
        .and_then(|value| value.strip_suffix("_remote"))
    else {
        return false;
    };
    [platform, version].into_iter().all(|value| {
        !value.is_empty()
            && !value.contains(['(', ')', ';'])
            && !value.bytes().any(|byte| byte.is_ascii_whitespace())
    })
}

fn contains_ascii_case_insensitive(haystack: &str, needle: &str) -> bool {
    find_ascii_case_insensitive(haystack, needle).is_some()
}

fn find_ascii_case_insensitive(haystack: &str, needle: &str) -> Option<usize> {
    haystack
        .as_bytes()
        .windows(needle.len())
        .position(|window| window.eq_ignore_ascii_case(needle.as_bytes()))
}

fn log_client_api_key_auth_failure(error: ClientApiKeyAuthError) {
    match error {
        ClientApiKeyAuthError::RuntimeUnavailable => {
            tracing::warn!(
                auth_failure = error.reason(),
                "Client API key authorization failed"
            );
        }
        _ => {
            tracing::info!(
                auth_failure = error.reason(),
                "Client API key authorization failed"
            );
        }
    }
}
