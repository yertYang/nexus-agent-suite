//! Admin 领域结果到安全 HTTP wire 的展示投影

use super::*;
use gateway_admin::model::quota_forecast::{AccountQuotaForecast, AccountQuotaForecastReport};

pub(super) fn account_page_data(
    result: AccountDirectoryPage,
    page: u32,
    page_size: u16,
    now: DateTime<Utc>,
    time: crate::time::TimePresenter,
) -> AccountPageData {
    let total_pages = if result.total == 0 {
        0
    } else {
        u32::try_from(result.total.div_ceil(u64::from(page_size))).unwrap_or(u32::MAX)
    };
    AccountPageData {
        items: result
            .items
            .into_iter()
            .map(|item| account_view(item, now, time))
            .collect(),
        page: PageMeta::new(page, u32::from(page_size), result.total, total_pages),
        summary: AccountSummaryView {
            total: result.summary.total,
            normal: result.summary.normal,
            quota_paused: result.summary.quota_paused,
            quota_exhausted: result.summary.quota_exhausted,
            rate_limited: result.summary.rate_limited,
            disabled: result.summary.disabled,
            error: result.summary.error,
        },
    }
}

pub(super) fn account_refresh_data(
    result: AccountRefreshResult,
    now: DateTime<Utc>,
    time: crate::time::TimePresenter,
) -> AccountRefreshData {
    AccountRefreshData {
        account: account_view(result.account, now, time),
    }
}

pub(super) fn account_models_data(
    result: ProviderModels,
    time: crate::time::TimePresenter,
) -> AccountModelsData {
    let observed_at = result.observed_at;
    AccountModelsData {
        models: result
            .models
            .into_iter()
            .map(|model| {
                let id = model.id.to_string();
                AccountModelView {
                    label: id.clone(),
                    id,
                }
            })
            .collect(),
        observed_at: observed_at.map(|value| time.rfc3339(&value)),
        observed_at_display: observed_at
            .map_or_else(|| "—".to_owned(), |value| time.datetime(&value)),
    }
}

pub(super) fn account_view(
    item: AccountDirectoryItem,
    now: DateTime<Utc>,
    time: crate::time::TimePresenter,
) -> AccountView {
    let AccountDirectoryItem {
        account,
        capacity,
        capabilities,
        plan_type_display,
        projection,
        usage,
        quota,
        protection_rules,
    } = item;
    let status = projection.status.as_str().to_owned();
    let cooldown = projection.cooldown;
    let expires_at = account
        .access_token_expires_at
        .as_ref()
        .map(|value| time.rfc3339(value));
    let added_at = time.rfc3339(&account.created_at);
    let updated_at = time.rfc3339(&account.updated_at);
    let usage_period = quota.usage_window().map(|(_, period)| period);
    let mut usage = account_usage_view(usage, usage_period, now, time);
    if account.authentication_kind == "api_key" {
        usage.window_kind = if quota
            .upstream
            .as_ref()
            .is_some_and(|upstream| upstream.discovered)
        {
            match quota
                .upstream_usage_window()
                .and_then(|window| window.window_seconds)
            {
                Some(86_400) => AccountUsageWindowKind::Daily,
                Some(604_800) => AccountUsageWindowKind::Weekly,
                _ => AccountUsageWindowKind::Quota,
            }
        } else {
            AccountUsageWindowKind::General
        };
    }
    let upstream = quota
        .upstream
        .clone()
        .map(|value| super::upstream_info::view(value, now, time));
    let (mut quota, refresh_token_expires_at) = account_quota_view(quota, cooldown, now, time);
    quota.protection_rules = protection_rules;
    AccountView {
        quota_limits: account.quota_limits,
        auto_use_quota_credits: account.auto_use_quota_credits,
        upstream,
        capabilities: capabilities.into(),
        id: account.id.clone(),
        name: account.name,
        notes: account.notes,
        provider: account.provider_kind.to_string(),
        groups: account
            .groups
            .into_iter()
            .map(AccountGroupRefView::from)
            .collect(),
        resource_ref: account.id,
        email: account.email,
        account_id: account.upstream_account_id,
        user_id: account.upstream_user_id,
        label: None,
        plan_type: account.plan_type,
        plan_type_display: plan_type_display.unwrap_or_else(|| "未知套餐".to_owned()),
        authentication_kind: account.authentication_kind,
        has_refresh_token: account.has_refresh_token,
        status,
        error_reason: projection
            .error_reason
            .map(|reason| reason.as_str().to_owned()),
        error_message: projection.error_message,
        enabled: account.enabled,
        concurrency_limit: account.concurrency_limit.map(|limit| limit.get()),
        capacity: AccountCapacityView {
            used_slots: capacity.used_slots,
            total_slots: capacity.total_slots,
        },
        weight: account.weight.get(),
        model_access: account.model_access,
        outbound_proxy_id: account.outbound_proxy_id,
        outbound_proxy_endpoint: account
            .outbound_proxy
            .as_ref()
            .map(|proxy| proxy.endpoint()),
        access_token_expires_at: expires_at,
        access_token_expires_at_display: account
            .access_token_expires_at
            .as_ref()
            .map(|value| time.datetime(value)),
        refresh_token_expires_at,
        next_refresh_at: account.next_refresh_at.map(|value| time.rfc3339(&value)),
        next_refresh_at_display: account.next_refresh_at.map(|value| time.datetime(&value)),
        added_at,
        added_at_display: time.datetime(&account.created_at),
        updated_at,
        updated_at_display: time.datetime(&account.updated_at),
        quota,
        usage,
    }
}

impl From<(AccountQuotaForecastReport, crate::time::TimePresenter)> for AccountQuotaForecastData {
    fn from((report, time): (AccountQuotaForecastReport, crate::time::TimePresenter)) -> Self {
        Self {
            account_id: report.account_id,
            generated_at: time.rfc3339(&report.generated_at),
            forecasts: report
                .forecasts
                .into_iter()
                .map(|value| quota_forecast_view(value, time))
                .collect(),
        }
    }
}

fn quota_forecast_view(
    forecast: AccountQuotaForecast,
    time: crate::time::TimePresenter,
) -> AccountQuotaForecastView {
    AccountQuotaForecastView {
        period: match forecast.period {
            AccountUsagePeriod::Weekly => "weekly",
            AccountUsagePeriod::Monthly => "monthly",
            AccountUsagePeriod::Daily => "daily",
        },
        target_days: forecast.target_seconds as f64 / 86_400.0,
        extrapolated: forecast.extrapolated,
        source: forecast.source.map(|source| QuotaForecastSourceView {
            label: source.label,
            used_percent: source.used_percent,
            used_percent_display: source
                .used_percent
                .map_or_else(|| "—".to_owned(), |value| format!("{value:.1}%")),
            observed_at: source.observed_at.map(|value| time.rfc3339(&value)),
            observed_at_display: source
                .observed_at
                .map_or_else(|| "—".to_owned(), |value| time.datetime(&value)),
            reset_at: time.rfc3339(&source.reset_at),
            tokens_display: display_optional_tokens(source.tokens),
            usd_display: forecast_usd_display(source.usd),
        }),
        unavailable_reason: forecast.unavailable_reason,
        low_sample: forecast.low_sample,
        incomplete_cost: forecast.incomplete_cost,
        incomplete_tokens: forecast.incomplete_tokens,
        estimated_tokens: forecast.estimated_tokens,
        estimated_tokens_display: display_optional_tokens(forecast.estimated_tokens),
        estimated_usd: forecast.estimated_usd,
        estimated_usd_display: forecast_usd_display(forecast.estimated_usd),
    }
}

fn forecast_usd_display(value: Option<f64>) -> String {
    value.map_or_else(
        || "—".to_owned(),
        |value| format_decimal_currency(&format!("{value:.10}"), "USD"),
    )
}

pub(super) fn account_quota_view(
    mut quota: ProviderQuota,
    cooldown: Option<gateway_core::account::AccountCooldown>,
    now: DateTime<Utc>,
    time: crate::time::TimePresenter,
) -> (AccountQuotaView, Option<String>) {
    quota.apply_limit_reached_display();
    let refresh_token_expires_at = quota
        .refresh_token_expires_at
        .map(|value| time.rfc3339(&value));
    let refreshed_at_display = quota
        .observed_at
        .map_or_else(|| "—".to_owned(), |value| time.relative(value, now));
    let windows = quota
        .windows
        .into_iter()
        .map(|value| quota_window_view(value, time))
        .collect();
    let rate_limited_until = cooldown.map(|value| time.rfc3339(&value.until.into()));
    let rate_limit_recovery_display = cooldown.map(|value| {
        let until = DateTime::<Utc>::from(value.until);
        if value.kind.requires_probe() && until <= now {
            return "等待探测成功".to_owned();
        }
        let minutes = (until - now).num_seconds().saturating_add(30) / 60;
        match minutes {
            ..1 => time.datetime(&until),
            1..60 => format!("剩余 {minutes} 分钟"),
            _ if minutes % 60 == 0 => format!("剩余 {} 小时", minutes / 60),
            _ => format!("剩余 {} 小时 {} 分", minutes / 60, minutes % 60),
        }
    });
    let rate_limit_reason = cooldown.map(|value| {
        if value.kind.is_error_protection() {
            "error_protection".to_owned()
        } else {
            "upstream_rate_limit".to_owned()
        }
    });
    let recovery_probe_required = cooldown.is_some_and(|value| value.kind.requires_probe());
    (
        AccountQuotaView {
            paused_windows: quota.paused_windows,
            refreshed_at: quota.observed_at.map(|value| time.rfc3339(&value)),
            refreshed_at_relative: quota
                .observed_at
                .map(|value| time.relative_view(value, now)),
            refreshed_at_display,
            limit_reached: quota.limit_reached,
            rate_limited_until,
            rate_limit_recovery_display,
            rate_limit_reason,
            recovery_probe_required,
            protection_rules: Vec::new(),
            windows,
            credits: quota.credits.map(|credits| AccountQuotaCreditsView {
                has_credits: credits.has_credits,
                unlimited: credits.unlimited,
                balance: credits.balance,
            }),
        },
        refresh_token_expires_at,
    )
}

pub(crate) fn quota_window_view(
    window: ProviderQuotaWindow,
    time: crate::time::TimePresenter,
) -> AccountQuotaWindowView {
    let ProviderQuotaWindow {
        upstream,
        key,
        group,
        label,
        limit_id,
        limit_name,
        role,
        local_usage_attribution,
        window_seconds,
        used_percent,
        reset_at,
        limit_reached,
        local_usage,
        provider_data: _,
    } = window;
    let label_display = limit_name
        .as_ref()
        .map_or_else(|| label.clone(), |name| format!("{name} · {label}"));
    AccountQuotaWindowView {
        account_wide: local_usage_attribution
            == gateway_admin::model::provider_credentials::QuotaLocalUsageAttribution::AccountWide,
        source_account_id: upstream.as_ref().and_then(|value| value.account_id.clone()),
        amount: upstream
            .as_ref()
            .and_then(|value| value.amount.as_ref())
            .map(super::upstream_info::amount_view),
        observed_at_display: upstream
            .as_ref()
            .and_then(|value| value.observed_at)
            .map(|value| time.datetime(&value)),
        stale: upstream.as_ref().is_some_and(|value| value.stale),
        label_display,
        window_label_display: label,
        key,
        group,
        limit_id,
        limit_name,
        role: role.map(|value| value.as_str().to_owned()),
        window_seconds,
        used_percent,
        used_percent_display: used_percent.map_or_else(|| "—".to_owned(), format_percentage),
        limit_reached,
        local_usage: local_usage
            .as_ref()
            .map(|value| quota_local_usage(value, time)),
        reset_at_display: reset_at.map_or_else(|| "—".to_owned(), |value| time.datetime(&value)),
    }
}

pub(super) fn quota_local_usage(usage: &AccountUsage, time: crate::time::TimePresenter) -> Value {
    let total_tokens = usage.total_tokens.unwrap_or_default();
    serde_json::json!({
        "requestCount": usage.request_count,
        "requestCountDisplay": format_number(usage.request_count),
        "inputTokens": usage.input_tokens.unwrap_or_default(),
        "inputTokensDisplay": display_optional_tokens(usage.input_tokens),
        "outputTokens": usage.output_tokens.unwrap_or_default(),
        "outputTokensDisplay": display_optional_tokens(usage.output_tokens),
        "cachedInputTokens": usage.cached_input_tokens.unwrap_or_default(),
        "cachedInputTokensDisplay": display_optional_tokens(usage.cached_input_tokens),
        "imageInputTokens": usage.image_input_tokens.unwrap_or_default(),
        "imageInputTokensDisplay": display_optional_tokens(usage.image_input_tokens),
        "imageOutputTokens": usage.image_output_tokens.unwrap_or_default(),
        "imageOutputTokensDisplay": display_optional_tokens(usage.image_output_tokens),
        "imageRequestCount": usage.image_request_count,
        "imageRequestFailedCount": usage.image_request_failed_count,
        "totalTokens": total_tokens,
        "totalTokensDisplay": format_compact_number(total_tokens),
        "requestBuckets": time.request_buckets(usage.request_buckets.iter().map(|bucket| (bucket.bucket_start, bucket.request_count))),
    })
}

pub(super) fn account_usage_view(
    usage: Option<AccountUsage>,
    period: Option<AccountUsagePeriod>,
    now: DateTime<Utc>,
    time: crate::time::TimePresenter,
) -> AccountUsageView {
    let Some(usage) = usage else {
        return empty_account_usage();
    };
    let known_count = usage
        .cost_coverage
        .provider_reported_count
        .saturating_add(usage.cost_coverage.calculated_count);
    let cost_estimate_status = if known_count == 0 {
        "unknown"
    } else if usage.cost_coverage.unavailable_count > 0 {
        "partial"
    } else {
        "known"
    };
    AccountUsageView {
        window_kind: match period {
            Some(AccountUsagePeriod::Daily) => AccountUsageWindowKind::Daily,
            Some(AccountUsagePeriod::Weekly) => AccountUsageWindowKind::Weekly,
            Some(AccountUsagePeriod::Monthly) => AccountUsageWindowKind::Monthly,
            None => AccountUsageWindowKind::Quota,
        },
        request_count: Some(usage.request_count),
        request_count_display: format_number(usage.request_count),
        input_tokens: usage.input_tokens,
        input_tokens_display: display_optional_tokens(usage.input_tokens),
        output_tokens: usage.output_tokens,
        output_tokens_display: display_optional_tokens(usage.output_tokens),
        cached_input_tokens: usage.cached_input_tokens,
        cached_input_tokens_display: display_optional_tokens(usage.cached_input_tokens),
        reasoning_output_tokens: usage.reasoning_output_tokens,
        reasoning_output_tokens_display: display_optional_tokens(usage.reasoning_output_tokens),
        image_input_tokens: usage.image_input_tokens,
        image_input_tokens_display: display_optional_tokens(usage.image_input_tokens),
        image_output_tokens: usage.image_output_tokens,
        image_output_tokens_display: display_optional_tokens(usage.image_output_tokens),
        image_request_count: Some(usage.image_request_count),
        image_request_count_display: format_number(usage.image_request_count),
        image_request_failed_count: Some(usage.image_request_failed_count),
        image_request_failed_count_display: format_number(usage.image_request_failed_count),
        total_tokens: usage.total_tokens,
        total_tokens_display: display_optional_tokens(usage.total_tokens),
        cache_write_input_tokens: usage.cache_write_input_tokens,
        cache_write_input_tokens_display: display_optional_tokens(usage.cache_write_input_tokens),
        last_used_at: usage.last_used_at.map(|value| time.rfc3339(&value)),
        last_used_at_full_display: usage.last_used_at.map(|value| time.datetime(&value)),
        last_used_at_display: usage
            .last_used_at
            .map_or_else(|| "—".to_owned(), |value| time.relative(value, now)),
        cost_estimate_status: cost_estimate_status.to_owned(),
        known_cost_count: Some(known_count),
        partial_cost_count: Some(u64::from(cost_estimate_status == "partial")),
        unknown_cost_count: Some(usage.cost_coverage.unavailable_count),
        costs: usage.costs.iter().map(account_currency_cost_view).collect(),
        models: usage
            .models
            .into_iter()
            .map(|model| account_model_usage_view(model, now, time))
            .collect(),
    }
}

pub(super) fn account_model_usage_view(
    usage: AccountModelUsage,
    now: DateTime<Utc>,
    time: crate::time::TimePresenter,
) -> ModelUsageView {
    let known_count = usage
        .cost_coverage
        .provider_reported_count
        .saturating_add(usage.cost_coverage.calculated_count);
    let cost_estimate_status = if known_count == 0 {
        "unknown"
    } else if usage.cost_coverage.unavailable_count > 0 {
        "partial"
    } else {
        "known"
    };
    let usd = usage
        .costs
        .iter()
        .find(|cost| cost.currency.eq_ignore_ascii_case("USD"));
    let success_rate = usage.health.success_rate();
    ModelUsageView {
        model: usage.model,
        request_count: usage.request_count,
        request_count_display: format_number(usage.request_count),
        success_rate,
        success_rate_display: success_rate
            .map_or_else(|| "—".to_owned(), |rate| format!("{rate:.1}%")),
        input_tokens: usage.input_tokens,
        input_tokens_display: display_optional_tokens(usage.input_tokens),
        output_tokens: usage.output_tokens,
        output_tokens_display: display_optional_tokens(usage.output_tokens),
        cached_input_tokens: usage.cached_input_tokens,
        cached_input_tokens_display: display_optional_tokens(usage.cached_input_tokens),
        image_input_tokens: usage.image_input_tokens,
        image_input_tokens_display: display_optional_tokens(usage.image_input_tokens),
        image_output_tokens: usage.image_output_tokens,
        image_output_tokens_display: display_optional_tokens(usage.image_output_tokens),
        image_request_count: usage.image_request_count,
        image_request_count_display: format_number(usage.image_request_count),
        image_request_failed_count: usage.image_request_failed_count,
        image_request_failed_count_display: format_number(usage.image_request_failed_count),
        total_tokens: usage.total_tokens,
        total_tokens_display: display_optional_tokens(usage.total_tokens),
        billing_amount_usd: usd.map(|cost| cost.amount.as_str().to_owned()),
        billing_amount_usd_display: usd.map_or_else(
            || "—".to_owned(),
            |cost| format_decimal_currency(cost.amount.as_str(), "USD"),
        ),
        cost_estimate_status: cost_estimate_status.to_owned(),
        known_cost_count: known_count,
        partial_cost_count: u64::from(cost_estimate_status == "partial"),
        unknown_cost_count: usage.cost_coverage.unavailable_count,
        costs: usage.costs.iter().map(account_currency_cost_view).collect(),
        last_used_at: usage.last_used_at.map(|value| time.rfc3339(&value)),
        last_used_at_full_display: usage.last_used_at.map(|value| time.datetime(&value)),
        last_used_at_display: usage
            .last_used_at
            .map_or_else(|| "—".to_owned(), |value| time.relative(value, now)),
    }
}

pub(super) fn account_currency_cost_view(cost: &AccountCost) -> CurrencyCostView {
    CurrencyCostView {
        currency: cost.currency.clone(),
        estimated_amount: cost.amount.as_str().to_owned(),
        estimated_amount_display: format_decimal_currency(cost.amount.as_str(), &cost.currency),
    }
}

pub(super) fn display_optional_tokens(value: Option<u64>) -> String {
    value.map_or_else(|| "—".to_owned(), format_compact_number)
}

pub(super) fn empty_account_usage() -> AccountUsageView {
    AccountUsageView {
        window_kind: AccountUsageWindowKind::Quota,
        request_count: None,
        request_count_display: "—".to_owned(),
        input_tokens: None,
        input_tokens_display: "—".to_owned(),
        output_tokens: None,
        output_tokens_display: "—".to_owned(),
        cached_input_tokens: None,
        cached_input_tokens_display: "—".to_owned(),
        reasoning_output_tokens: None,
        reasoning_output_tokens_display: "—".to_owned(),
        image_input_tokens: None,
        image_input_tokens_display: "—".to_owned(),
        image_output_tokens: None,
        image_output_tokens_display: "—".to_owned(),
        image_request_count: None,
        image_request_count_display: "—".to_owned(),
        image_request_failed_count: None,
        image_request_failed_count_display: "—".to_owned(),
        total_tokens: None,
        total_tokens_display: "—".to_owned(),
        cache_write_input_tokens: None,
        cache_write_input_tokens_display: "—".to_owned(),
        last_used_at: None,
        last_used_at_full_display: None,
        last_used_at_display: "—".to_owned(),
        cost_estimate_status: "unavailable".to_owned(),
        known_cost_count: None,
        partial_cost_count: None,
        unknown_cost_count: None,
        costs: Vec::new(),
        models: Vec::new(),
    }
}

pub(super) fn map_wire_error(error: WireValidationError) -> AdminError {
    AdminError::bad_request(format!("{} 字段不合法", error.field()))
}

pub(super) fn map_service_error(error: AdminServiceError) -> AdminError {
    super::super::wire::map_admin_service_error(error)
}
