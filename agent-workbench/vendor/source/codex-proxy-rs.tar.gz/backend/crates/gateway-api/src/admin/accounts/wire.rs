//! 账号管理请求、响应与查询 wire contract

use super::*;

#[derive(Debug, Clone)]
pub struct AccountProxyUpdate(pub Option<gateway_core::account::OutboundProxy>);

impl<'de> Deserialize<'de> for AccountProxyUpdate {
    fn deserialize<D: serde::Deserializer<'de>>(deserializer: D) -> Result<Self, D::Error> {
        let value = String::deserialize(deserializer)?;
        if value.is_empty() {
            return Ok(Self(None));
        }
        gateway_core::account::OutboundProxy::parse(&value)
            .map(|proxy| Self(Some(proxy)))
            .map_err(serde::de::Error::custom)
    }
}

pub(super) fn proxy_selection(
    id: Option<String>,
    url: Option<AccountProxyUpdate>,
) -> Result<Option<gateway_admin::model::proxies::AccountProxySelection>, WireValidationError> {
    use gateway_admin::model::proxies::AccountProxySelection;
    match (id, url) {
        (Some(_), Some(_)) => Err(WireValidationError::new("outboundProxyId")),
        (Some(id), None) if id.is_empty() => Ok(Some(AccountProxySelection::Direct)),
        (Some(id), None) => {
            if id.len() > 128
                || !id
                    .bytes()
                    .all(|byte| byte.is_ascii_alphanumeric() || matches!(byte, b'_' | b'-'))
            {
                return Err(WireValidationError::new("outboundProxyId"));
            }
            Ok(Some(AccountProxySelection::Saved(id)))
        }
        (None, Some(value)) => Ok(Some(
            value
                .0
                .map_or(AccountProxySelection::Direct, AccountProxySelection::Url),
        )),
        (None, None) => Ok(None),
    }
}

/// 账号列表查询参数
#[derive(Debug, Clone, Default, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ListQuery {
    pub page: Option<u32>,
    pub page_size: Option<u32>,
    pub provider: Option<String>,
    pub group_id: Option<String>,
    pub search: Option<String>,
    pub status: Option<String>,
    pub sort_by: Option<String>,
    pub sort_direction: Option<String>,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct BatchUpdateAccountsRequest {
    pub quota_limits: Option<gateway_core::account::AccountQuotaLimits>,
    pub auto_use_quota_credits: Option<bool>,
    pub outbound_proxy_id: Option<String>,
    pub outbound_proxy_url: Option<AccountProxyUpdate>,
    pub account_ids: Vec<String>,
    pub enabled: Option<bool>,
    #[serde(default, deserialize_with = "deserialize_optional_nullable_limit")]
    pub concurrency_limit: Option<Option<u64>>,
    pub weight: Option<u64>,
    pub model_access: Option<gateway_core::account::AccountModelAccess>,
    pub group_ids: Option<Vec<String>>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub(super) struct BatchUpdatedAccountsData {
    account_ids: Vec<String>,
    config_revision: u64,
}

impl From<AccountsUpdateResult> for BatchUpdatedAccountsData {
    fn from(result: AccountsUpdateResult) -> Self {
        Self {
            account_ids: result
                .account_ids
                .into_iter()
                .map(|id| id.to_string())
                .collect(),
            config_revision: result.config_revision.get(),
        }
    }
}

fn deserialize_optional_nullable_limit<'de, D: serde::Deserializer<'de>>(
    deserializer: D,
) -> Result<Option<Option<u64>>, D::Error> {
    Option::<u64>::deserialize(deserializer).map(Some)
}

impl BatchUpdateAccountsRequest {
    pub fn validate(&self) -> Result<(), WireValidationError> {
        if self.account_ids.is_empty()
            || self.account_ids.len() > MAX_ACCOUNT_GROUP_BATCH
            || self
                .account_ids
                .iter()
                .any(|id| require_account_id(id, "accountIds").is_err())
            || self.account_ids.iter().collect::<BTreeSet<_>>().len() != self.account_ids.len()
        {
            return Err(WireValidationError::new("accountIds"));
        }
        if let Some(group_ids) = &self.group_ids {
            validate_wire_group_ids(group_ids)?;
        }
        self.concurrency_limit
            .map(parse_concurrency_limit)
            .transpose()?;
        self.weight.map(parse_account_weight).transpose()?;
        if self.quota_limits.is_none()
            && self.auto_use_quota_credits.is_none()
            && self.enabled.is_none()
            && self.concurrency_limit.is_none()
            && self.weight.is_none()
            && self.group_ids.is_none()
            && self.model_access.is_none()
            && self.outbound_proxy_id.is_none()
            && self.outbound_proxy_url.is_none()
        {
            return Err(WireValidationError::new("accountSettings"));
        }
        Ok(())
    }

    pub(super) fn into_command(self) -> Result<BatchUpdateAccounts, WireValidationError> {
        self.validate()?;
        Ok(BatchUpdateAccounts {
            quota_limits: self.quota_limits,
            auto_use_quota_credits: self.auto_use_quota_credits,
            outbound_proxy: proxy_selection(self.outbound_proxy_id, self.outbound_proxy_url)?,
            account_ids: self.account_ids,
            enabled: self.enabled,
            concurrency_limit: self
                .concurrency_limit
                .map(parse_concurrency_limit)
                .transpose()?,
            weight: self.weight.map(parse_account_weight).transpose()?,
            model_access: self.model_access,
            group_ids: self
                .group_ids
                .as_deref()
                .map(validate_wire_group_ids)
                .transpose()?,
        })
    }
}

impl ListQuery {
    /// 解析并校验全部 wire 字段，生成 Admin 查询命令
    pub fn validate(self) -> Result<AccountListQuery, WireValidationError> {
        let page = self.page.unwrap_or(1);
        if page == 0 {
            return Err(WireValidationError::new("page"));
        }
        let page_size = self.page_size.unwrap_or(DEFAULT_PAGE_SIZE);
        if page_size == 0 || page_size > MAX_PAGE_SIZE {
            return Err(WireValidationError::new("pageSize"));
        }
        let provider_kind = parse_provider(self.provider.as_deref().unwrap_or_default())?;
        let group_filter = match self.group_id.as_deref().map(str::trim) {
            None | Some("") => None,
            Some("ungrouped") => Some(AccountGroupFilter::Ungrouped),
            Some(value) => Some(AccountGroupFilter::Group(
                AccountGroupId::new(value.to_owned())
                    .map_err(|_| WireValidationError::new("groupId"))?,
            )),
        };
        let search = self
            .search
            .map(|value| value.trim().to_owned())
            .filter(|value| !value.is_empty());
        if search.as_deref().is_some_and(|value| {
            value.len() > MAX_SEARCH_BYTES || value.chars().any(char::is_control)
        }) {
            return Err(WireValidationError::new("search"));
        }
        let status = match self.status.as_deref().map(str::trim) {
            None | Some("") => None,
            Some(value) => Some(
                DomainAccountStatus::parse(&value.to_ascii_lowercase())
                    .ok_or_else(|| WireValidationError::new("status"))?,
            ),
        };
        let sort = match (self.sort_by.as_deref(), self.sort_direction.as_deref()) {
            (None, None) => None,
            (Some(field), Some(direction)) => Some(AccountSort {
                field: parse_sort_field(field).ok_or_else(|| WireValidationError::new("sortBy"))?,
                direction: parse_sort_direction(direction)
                    .ok_or_else(|| WireValidationError::new("sortDirection"))?,
            }),
            _ => return Err(WireValidationError::new("sort")),
        };
        Ok(AccountListQuery {
            page,
            page_size: PageSize::new(
                u16::try_from(page_size).map_err(|_| WireValidationError::new("pageSize"))?,
            )
            .map_err(|_| WireValidationError::new("pageSize"))?,
            provider_kind,
            group_filter,
            search,
            status,
            sort,
        })
    }
}

fn parse_provider(value: &str) -> Result<Option<ProviderKind>, WireValidationError> {
    let value = value.trim();
    if value.is_empty() {
        return Ok(None);
    }
    ProviderKind::new(value.to_owned())
        .map(Some)
        .map_err(|_| WireValidationError::new("provider"))
}

fn parse_sort_field(value: &str) -> Option<AccountSortField> {
    match value.trim() {
        "email" => Some(AccountSortField::Email),
        "status" => Some(AccountSortField::Status),
        "planType" => Some(AccountSortField::PlanType),
        "usage" => Some(AccountSortField::Usage),
        "lastUsedAt" => Some(AccountSortField::LastUsedAt),
        "expiresAt" => Some(AccountSortField::ExpiresAt),
        _ => None,
    }
}

fn parse_sort_direction(value: &str) -> Option<SortDirection> {
    match value.trim().to_ascii_lowercase().as_str() {
        "asc" => Some(SortDirection::Asc),
        "desc" => Some(SortDirection::Desc),
        _ => None,
    }
}

/// 账号列表响应数据
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountPageData {
    pub items: Vec<AccountView>,
    pub page: PageMeta,
    pub summary: AccountSummaryView,
}

/// 账号概览计数
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountSummaryView {
    pub total: u64,
    pub normal: u64,
    pub quota_paused: u64,
    pub quota_exhausted: u64,
    pub rate_limited: u64,
    pub disabled: u64,
    pub error: u64,
}

/// 一条安全账号视图
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountView {
    pub quota_limits: gateway_core::account::AccountQuotaLimits,
    pub auto_use_quota_credits: bool,
    pub upstream: Option<super::AccountUpstreamInfoView>,
    pub capabilities: AccountCapabilitiesView,
    pub outbound_proxy_id: Option<String>,
    pub outbound_proxy_endpoint: Option<String>,
    pub id: String,
    pub name: String,
    pub notes: Option<String>,
    pub provider: String,
    pub groups: Vec<AccountGroupRefView>,
    pub resource_ref: String,
    pub email: Option<String>,
    pub account_id: Option<String>,
    pub user_id: Option<String>,
    pub label: Option<String>,
    pub plan_type: Option<String>,
    /// 后端生成的套餐展示名称；缺失套餐时为“未知套餐”
    pub plan_type_display: String,
    pub authentication_kind: String,
    pub has_refresh_token: bool,
    pub status: String,
    /// `status == "error"` 时的具体原因；其余状态为 `null`
    pub error_reason: Option<String>,
    /// 最近一次失败的上游错误描述；仅错误状态存在
    pub error_message: Option<String>,
    pub enabled: bool,
    pub concurrency_limit: Option<u32>,
    pub capacity: AccountCapacityView,
    pub weight: u16,
    pub model_access: gateway_core::account::AccountModelAccess,
    pub access_token_expires_at: Option<String>,
    pub access_token_expires_at_display: Option<String>,
    pub refresh_token_expires_at: Option<String>,
    pub next_refresh_at: Option<String>,
    pub next_refresh_at_display: Option<String>,
    pub added_at: String,
    pub added_at_display: String,
    pub updated_at: String,
    pub updated_at_display: String,
    pub quota: AccountQuotaView,
    pub usage: AccountUsageView,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountCapacityView {
    pub used_slots: Option<u64>,
    pub total_slots: Option<u64>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountCapabilitiesView {
    pub quota_limits_supported: bool,
    pub quota_credits: bool,
    pub quota: bool,
    pub quota_refresh: bool,
    pub profile: bool,
    pub subscription: bool,
    pub avatar: bool,
    pub reset_credits: bool,
    pub consume_reset_credit: bool,
}

impl From<gateway_admin::model::accounts::ProviderAccountCapabilities> for AccountCapabilitiesView {
    fn from(value: gateway_admin::model::accounts::ProviderAccountCapabilities) -> Self {
        Self {
            quota: value.quota,
            quota_refresh: value.quota_refresh,
            profile: value.profile,
            subscription: value.subscription,
            avatar: value.avatar,
            reset_credits: value.reset_credits,
            quota_limits_supported: value.quota_limits_supported,
            quota_credits: value.quota_credits,
            consume_reset_credit: value.consume_reset_credit,
        }
    }
}

/// 容量估算仅供管理端展示；金额不是订阅账单或可消费余额
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountQuotaForecastData {
    pub account_id: String,
    pub generated_at: String,
    pub forecasts: Vec<AccountQuotaForecastView>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountQuotaForecastView {
    pub period: &'static str,
    pub target_days: f64,
    pub extrapolated: bool,
    pub source: Option<QuotaForecastSourceView>,
    pub unavailable_reason: Option<&'static str>,
    pub low_sample: bool,
    pub incomplete_cost: bool,
    pub incomplete_tokens: bool,
    pub estimated_tokens: Option<u64>,
    pub estimated_tokens_display: String,
    pub estimated_usd: Option<f64>,
    pub estimated_usd_display: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct QuotaForecastSourceView {
    pub label: String,
    pub used_percent: Option<f64>,
    pub used_percent_display: String,
    pub observed_at: Option<String>,
    pub observed_at_display: String,
    pub reset_at: String,
    pub tokens_display: String,
    pub usd_display: String,
}

pub use crate::admin::account_groups::AccountGroupRefView;

/// Provider quota 安全视图
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountQuotaView {
    pub paused_windows: Vec<String>,
    pub refreshed_at: Option<String>,
    pub refreshed_at_relative: Option<crate::time::RelativeTimeView>,
    pub refreshed_at_display: String,
    pub limit_reached: bool,
    /// 冷却到期或可开始恢复探测的时间；非限流中为 `null`
    pub rate_limited_until: Option<String>,
    pub rate_limit_recovery_display: Option<String>,
    pub rate_limit_reason: Option<String>,
    pub recovery_probe_required: bool,
    pub protection_rules: Vec<gateway_core::account::AccountProtectionMatch>,
    pub windows: Vec<AccountQuotaWindowView>,
    pub credits: Option<AccountQuotaCreditsView>,
}

/// 上游点数安全视图，不透出额度响应中的其他 Provider 字段
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountQuotaCreditsView {
    pub has_credits: bool,
    pub unlimited: bool,
    pub balance: Option<String>,
}

/// 一个 quota 时间窗口
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountQuotaWindowView {
    pub account_wide: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub source_account_id: Option<String>,
    pub amount: Option<super::AccountQuotaAmountView>,
    pub observed_at_display: Option<String>,
    pub stale: bool,
    pub key: String,
    pub group: String,
    pub limit_id: Option<String>,
    pub limit_name: Option<String>,
    pub role: Option<String>,
    pub window_seconds: Option<u64>,
    pub label_display: String,
    pub window_label_display: String,
    pub used_percent: Option<f64>,
    pub used_percent_display: String,
    pub limit_reached: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub local_usage: Option<serde_json::Value>,
    pub reset_at_display: String,
}

/// 账号用量窗口的语义标识，展示名称由管理端本地化
#[derive(Debug, Clone, Copy, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum AccountUsageWindowKind {
    General,
    Daily,
    Weekly,
    Monthly,
    Quota,
}

/// 账号观测用量
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountUsageView {
    pub window_kind: AccountUsageWindowKind,
    pub request_count: Option<u64>,
    pub request_count_display: String,
    pub input_tokens: Option<u64>,
    pub input_tokens_display: String,
    pub output_tokens: Option<u64>,
    pub output_tokens_display: String,
    pub cached_input_tokens: Option<u64>,
    pub cached_input_tokens_display: String,
    pub reasoning_output_tokens: Option<u64>,
    pub reasoning_output_tokens_display: String,
    pub image_input_tokens: Option<u64>,
    pub image_input_tokens_display: String,
    pub image_output_tokens: Option<u64>,
    pub image_output_tokens_display: String,
    pub image_request_count: Option<u64>,
    pub image_request_count_display: String,
    pub image_request_failed_count: Option<u64>,
    pub image_request_failed_count_display: String,
    pub total_tokens: Option<u64>,
    pub total_tokens_display: String,
    pub cache_write_input_tokens: Option<u64>,
    pub cache_write_input_tokens_display: String,
    pub last_used_at: Option<String>,
    pub last_used_at_display: String,
    pub last_used_at_full_display: Option<String>,
    pub cost_estimate_status: String,
    pub known_cost_count: Option<u64>,
    pub partial_cost_count: Option<u64>,
    pub unknown_cost_count: Option<u64>,
    pub costs: Vec<CurrencyCostView>,
    pub models: Vec<ModelUsageView>,
}

/// 凭据在单个上游模型上的观测用量
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ModelUsageView {
    pub model: String,
    pub request_count: u64,
    pub request_count_display: String,
    pub success_rate: Option<f64>,
    pub success_rate_display: String,
    pub input_tokens: Option<u64>,
    pub input_tokens_display: String,
    pub output_tokens: Option<u64>,
    pub output_tokens_display: String,
    pub cached_input_tokens: Option<u64>,
    pub cached_input_tokens_display: String,
    pub image_input_tokens: Option<u64>,
    pub image_input_tokens_display: String,
    pub image_output_tokens: Option<u64>,
    pub image_output_tokens_display: String,
    pub image_request_count: u64,
    pub image_request_count_display: String,
    pub image_request_failed_count: u64,
    pub image_request_failed_count_display: String,
    pub total_tokens: Option<u64>,
    pub total_tokens_display: String,
    pub billing_amount_usd: Option<String>,
    pub billing_amount_usd_display: String,
    pub cost_estimate_status: String,
    pub known_cost_count: u64,
    pub partial_cost_count: u64,
    pub unknown_cost_count: u64,
    pub costs: Vec<CurrencyCostView>,
    pub last_used_at: Option<String>,
    pub last_used_at_display: String,
    pub last_used_at_full_display: Option<String>,
}

/// 单一货币的可查询成本
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CurrencyCostView {
    pub currency: String,
    pub estimated_amount: String,
    pub estimated_amount_display: String,
}

/// 账号详情类 GET 的固定 ID query
#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct AccountIdQuery {
    pub account_id: String,
}

impl AccountIdQuery {
    pub fn validate(&self) -> Result<(), WireValidationError> {
        require_account_id(&self.account_id, "accountId")
    }

    pub(super) fn into_id(self) -> Result<ProviderAccountId, WireValidationError> {
        self.validate()?;
        ProviderAccountId::new(self.account_id).map_err(|_| WireValidationError::new("accountId"))
    }
}

/// 头像 GET 的固定 query；`version` 只参与浏览器缓存键，不进入上游请求
#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct AccountProfileAvatarQuery {
    pub account_id: String,
    pub version: Option<String>,
}

impl AccountProfileAvatarQuery {
    pub fn validate(&self) -> Result<(), WireValidationError> {
        require_account_id(&self.account_id, "accountId")?;
        if self.version.as_deref().is_some_and(|version| {
            version.is_empty()
                || version.len() > MAX_AVATAR_VERSION_BYTES
                || !version.bytes().all(|byte| byte.is_ascii_alphanumeric())
        }) {
            return Err(WireValidationError::new("version"));
        }
        Ok(())
    }

    pub(super) fn into_id(self) -> Result<ProviderAccountId, WireValidationError> {
        self.validate()?;
        ProviderAccountId::new(self.account_id).map_err(|_| WireValidationError::new("accountId"))
    }
}

/// 敏感导出的固定 query；IDs 使用逗号分隔，禁止隐式导出全部账号
#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct AccountExportQuery {
    pub account_ids: String,
    pub confirm: String,
}

impl AccountExportQuery {
    pub fn into_ids(self) -> Result<Vec<ProviderAccountId>, WireValidationError> {
        if self.confirm != "export_sensitive_accounts" {
            return Err(WireValidationError::new("confirm"));
        }
        let ids = self
            .account_ids
            .split(',')
            .map(str::trim)
            .filter(|id| !id.is_empty())
            .map(ToOwned::to_owned)
            .collect::<Vec<_>>();
        if ids.is_empty()
            || ids.len() > 200
            || ids
                .iter()
                .any(|id| require_account_id(id, "accountIds").is_err())
        {
            return Err(WireValidationError::new("accountIds"));
        }
        let unique = ids.iter().collect::<BTreeSet<_>>();
        if unique.len() != ids.len() {
            return Err(WireValidationError::new("accountIds"));
        }
        ids.into_iter()
            .map(|id| {
                ProviderAccountId::new(id).map_err(|_| WireValidationError::new("accountIds"))
            })
            .collect()
    }
}

/// 账号运行期动作
#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct AccountActionRequest {
    pub account_id: String,
}

impl AccountActionRequest {
    pub fn validate(&self) -> Result<(), WireValidationError> {
        require_account_id(&self.account_id, "accountId")
    }

    pub(super) fn into_id(self) -> Result<ProviderAccountId, WireValidationError> {
        self.validate()?;
        ProviderAccountId::new(self.account_id).map_err(|_| WireValidationError::new("accountId"))
    }
}

/// 主动额度重置卡消费请求
/// 幂等键由 UI 生成并在不确定重试时复用，与官方一致
#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct AccountResetCreditConsumeRequest {
    pub account_id: String,
    #[serde(default)]
    pub credit_id: Option<String>,
    pub redeem_request_id: String,
}

impl AccountResetCreditConsumeRequest {
    pub fn validate(&self) -> Result<(), WireValidationError> {
        require_account_id(&self.account_id, "accountId")?;
        if self.credit_id.as_deref().is_some_and(|value| {
            let value = value.trim();
            value.is_empty() || value.len() > 512 || value.chars().any(char::is_control)
        }) {
            return Err(WireValidationError::new("creditId"));
        }
        let value = self.redeem_request_id.trim();
        let redeem_request_id =
            Uuid::parse_str(value).map_err(|_| WireValidationError::new("redeemRequestId"))?;
        if redeem_request_id.get_version() != Some(Version::Random)
            || redeem_request_id.hyphenated().to_string() != value
        {
            return Err(WireValidationError::new("redeemRequestId"));
        }
        Ok(())
    }

    pub(super) fn into_command(self) -> Result<ConsumeProviderResetCredit, WireValidationError> {
        self.validate()?;
        Ok(ConsumeProviderResetCredit {
            account_id: ProviderAccountId::new(self.account_id)
                .map_err(|_| WireValidationError::new("accountId"))?,
            credit_id: self.credit_id.map(|value| value.trim().to_owned()),
            redeem_request_id: Uuid::parse_str(&self.redeem_request_id)
                .map_err(|_| WireValidationError::new("redeemRequestId"))?,
        })
    }
}

/// 手工 OAuth 刷新会变更持久 credential
#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct AccountRefreshRequest {
    pub account_id: String,
}

impl AccountRefreshRequest {
    pub fn validate(&self) -> Result<(), WireValidationError> {
        require_account_id(&self.account_id, "accountId")
    }

    pub(super) fn into_command(self) -> Result<ProviderAccountId, WireValidationError> {
        self.validate()?;
        ProviderAccountId::new(self.account_id).map_err(|_| WireValidationError::new("accountId"))
    }
}

/// 连接测试 query；测试仍经唯一 Core/Provider 模型请求路径执行
#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct AccountTestQuery {
    pub account_id: String,
    pub model_id: String,
}

impl AccountTestQuery {
    pub fn validate(&self) -> Result<(), WireValidationError> {
        require_account_id(&self.account_id, "accountId")?;
        if self.model_id.trim().is_empty() || self.model_id.chars().any(char::is_control) {
            return Err(WireValidationError::new("modelId"));
        }
        Ok(())
    }

    pub(super) fn into_command(
        self,
    ) -> Result<(ProviderAccountId, UpstreamModelId), WireValidationError> {
        self.validate()?;
        Ok((
            ProviderAccountId::new(self.account_id)
                .map_err(|_| WireValidationError::new("accountId"))?,
            UpstreamModelId::new(self.model_id).map_err(|_| WireValidationError::new("modelId"))?,
        ))
    }
}

#[derive(Debug, Clone, Serialize)]
pub struct AccountModelView {
    pub id: String,
    pub label: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountModelsData {
    pub models: Vec<AccountModelView>,
    pub observed_at: Option<String>,
    pub observed_at_display: String,
}

/// 账号模型目录文件；`catalog` 直接作为 Codex `model_catalog_json` 的文件正文落盘
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountModelCatalogData {
    pub model_count: usize,
    pub observed_at: String,
    pub catalog: Value,
}

/// Provider 未给出 Codex 原生目录正文；该结果不能作为客户端目录文件返回
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct UnsupportedModelCatalogDocument;

impl TryFrom<ProviderModelCatalogDocument> for AccountModelCatalogData {
    type Error = UnsupportedModelCatalogDocument;

    /// 目录正文由 Provider 按官方 wire 组装；这里只解析一次用于 JSON 响应，不改写字段
    fn try_from(result: ProviderModelCatalogDocument) -> Result<Self, Self::Error> {
        if result.document.protocol() != "codex" {
            return Err(UnsupportedModelCatalogDocument);
        }
        let catalog = serde_json::from_slice(result.document.body())
            .map_err(|_| UnsupportedModelCatalogDocument)?;
        Ok(Self {
            model_count: result.model_count,
            observed_at: result.observed_at.to_rfc3339(),
            catalog,
        })
    }
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountRefreshData {
    pub account: AccountView,
}

#[derive(Debug, Clone, Serialize)]
pub struct AccountQuotaData {
    pub account: AccountView,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountDetailData {
    pub account: AccountView,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub credential_configuration: Option<serde_json::Value>,
}

/// 个人资料、累计统计与订阅的统一响应
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountPersonalInfoData {
    pub profile: Option<AccountProfileStatisticsData>,
    pub profile_error: Option<String>,
    pub subscription: Option<AccountSubscriptionData>,
}

impl From<(AccountPersonalInfo, crate::time::TimePresenter)> for AccountPersonalInfoData {
    fn from((info, time): (AccountPersonalInfo, crate::time::TimePresenter)) -> Self {
        let (profile, profile_error) = match info.profile {
            Ok(profile) => (
                Some(AccountProfileStatisticsData::from((profile, time))),
                None,
            ),
            Err(error) => (None, Some(error.message().to_owned())),
        };
        Self {
            profile,
            profile_error,
            subscription: info
                .subscription
                .map(|value| AccountSubscriptionData::from((value, time))),
        }
    }
}

/// 按需读取的订阅安全字段，不暴露原始上游响应
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountSubscriptionData {
    pub starts_at: Option<String>,
    pub starts_at_display: Option<String>,
    pub expires_at: String,
    pub expires_at_display: String,
    pub will_renew: Option<bool>,
    pub billing_period: Option<String>,
    pub billing_currency: Option<String>,
    pub observed_at: String,
    pub observed_at_display: String,
}

impl From<(ProviderSubscription, crate::time::TimePresenter)> for AccountSubscriptionData {
    fn from((subscription, time): (ProviderSubscription, crate::time::TimePresenter)) -> Self {
        Self {
            starts_at_display: subscription
                .starts_at
                .as_ref()
                .map(|value| time.datetime(value)),
            starts_at: subscription.starts_at.map(|value| value.to_rfc3339()),
            expires_at_display: time.datetime(&subscription.expires_at),
            expires_at: subscription.expires_at.to_rfc3339(),
            will_renew: subscription.will_renew,
            billing_period: subscription.billing_period,
            billing_currency: subscription.billing_currency,
            observed_at_display: time.datetime(&subscription.observed_at),
            observed_at: subscription.observed_at.to_rfc3339(),
        }
    }
}

/// Provider 官方个人资料统计响应
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountProfileStatisticsData {
    pub activity_calendar: Option<ProfileActivityCalendar>,
    pub display_name: Option<String>,
    pub username: Option<String>,
    pub image_url: Option<String>,
    pub has_stats_error: bool,
    pub summary: AccountProfileStatisticsSummaryView,
    pub daily_usage: Option<Vec<AccountProfileDailyUsageView>>,
    pub activity_insights: AccountProfileActivityInsightsView,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountProfileStatisticsSummaryView {
    pub total_text_tokens: Option<u64>,
    pub peak_tokens: Option<u64>,
    pub longest_task_duration_ms: Option<u64>,
    pub current_streak_days: Option<u64>,
    pub longest_streak_days: Option<u64>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountProfileDailyUsageView {
    pub date: String,
    pub tokens: u64,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountProfileActivityInsightsView {
    pub fast_mode_percent: Option<f64>,
    pub reasoning_effort: Option<String>,
    pub reasoning_effort_percent: Option<f64>,
    pub skills_explored: Option<u64>,
    pub total_skills_used: Option<u64>,
    pub total_threads: Option<u64>,
    pub invocations: Option<Vec<AccountProfileInvocationView>>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountProfileInvocationView {
    #[serde(rename = "type")]
    pub invocation_type: String,
    pub plugin_id: Option<String>,
    pub plugin_name: Option<String>,
    pub skill_id: Option<String>,
    pub skill_name: Option<String>,
    pub usage_count: Option<u64>,
}

impl From<(ProviderProfileStatistics, crate::time::TimePresenter)>
    for AccountProfileStatisticsData
{
    fn from((statistics, time): (ProviderProfileStatistics, crate::time::TimePresenter)) -> Self {
        Self {
            activity_calendar: statistics
                .daily_usage
                .as_deref()
                .and_then(|daily| profile_activity_calendar(daily, time.today())),
            display_name: statistics.display_name,
            username: statistics.username,
            image_url: statistics.image_url,
            has_stats_error: statistics.has_stats_error,
            summary: profile_statistics_summary_view(statistics.summary),
            daily_usage: statistics
                .daily_usage
                .map(|daily| daily.into_iter().map(profile_daily_usage_view).collect()),
            activity_insights: profile_activity_insights_view(statistics.activity_insights),
        }
    }
}

const fn profile_statistics_summary_view(
    summary: ProviderProfileStatisticsSummary,
) -> AccountProfileStatisticsSummaryView {
    AccountProfileStatisticsSummaryView {
        total_text_tokens: summary.total_text_tokens,
        peak_tokens: summary.peak_tokens,
        longest_task_duration_ms: summary.longest_task_duration_ms,
        current_streak_days: summary.current_streak_days,
        longest_streak_days: summary.longest_streak_days,
    }
}

fn profile_daily_usage_view(daily: ProviderProfileDailyUsage) -> AccountProfileDailyUsageView {
    AccountProfileDailyUsageView {
        date: daily.date.to_string(),
        tokens: daily.tokens,
    }
}

fn profile_activity_insights_view(
    insights: ProviderProfileActivityInsights,
) -> AccountProfileActivityInsightsView {
    AccountProfileActivityInsightsView {
        fast_mode_percent: insights.fast_mode_percent,
        reasoning_effort: insights.reasoning_effort,
        reasoning_effort_percent: insights.reasoning_effort_percent,
        skills_explored: insights.skills_explored,
        total_skills_used: insights.total_skills_used,
        total_threads: insights.total_threads,
        invocations: insights.invocations.map(|invocations| {
            invocations
                .into_iter()
                .map(profile_invocation_view)
                .collect()
        }),
    }
}

fn profile_invocation_view(invocation: ProviderProfileInvocation) -> AccountProfileInvocationView {
    AccountProfileInvocationView {
        invocation_type: invocation.invocation_type,
        plugin_id: invocation.plugin_id,
        plugin_name: invocation.plugin_name,
        skill_id: invocation.skill_id,
        skill_name: invocation.skill_name,
        usage_count: invocation.usage_count,
    }
}

/// 主动额度重置卡列表响应
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountResetCreditsData {
    pub available_count: u64,
    pub credits: Vec<AccountResetCreditView>,
}

/// 一张安全主动额度重置卡视图
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountResetCreditView {
    pub id: String,
    pub status: Option<String>,
    pub title: Option<String>,
    pub expires_at: Option<String>,
    pub expires_at_display: Option<String>,
    pub reset_type: Option<String>,
}

/// 主动额度重置卡消费响应
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountResetCreditResultData {
    pub code: String,
    pub credit: Option<AccountResetCreditView>,
}

impl From<(ProviderResetCredit, crate::time::TimePresenter)> for AccountResetCreditView {
    fn from((credit, time): (ProviderResetCredit, crate::time::TimePresenter)) -> Self {
        Self {
            id: credit.id,
            status: credit.status,
            title: credit.title,
            expires_at_display: credit.expires_at.as_ref().map(|value| time.datetime(value)),
            expires_at: credit.expires_at.map(|value| value.to_rfc3339()),
            reset_type: credit.reset_type,
        }
    }
}

impl From<(ProviderResetCredits, crate::time::TimePresenter)> for AccountResetCreditsData {
    fn from((credits, time): (ProviderResetCredits, crate::time::TimePresenter)) -> Self {
        Self {
            available_count: credits.available_count,
            credits: credits
                .credits
                .into_iter()
                .map(|value| AccountResetCreditView::from((value, time)))
                .collect(),
        }
    }
}

impl From<(ProviderResetCreditResult, crate::time::TimePresenter)>
    for AccountResetCreditResultData
{
    fn from((result, time): (ProviderResetCreditResult, crate::time::TimePresenter)) -> Self {
        Self {
            code: result.code,
            credit: result
                .credit
                .map(|value| AccountResetCreditView::from((value, time))),
        }
    }
}

/// Provider-owned 明文导出文档；Debug 永远不输出内部 JSON
#[derive(Serialize)]
#[serde(transparent)]
pub struct AccountExportData(Value);

impl AccountExportData {
    #[must_use]
    pub const fn new(value: Value) -> Self {
        Self(value)
    }

    pub(super) fn from_result(
        bundle: AccountExportBundle,
        time: crate::time::TimePresenter,
    ) -> Self {
        let filename = format!(
            "cpr-accounts-{}.json",
            time.label(bundle.exported_at, "%Y-%m-%d")
        );
        let documents = bundle
            .documents
            .into_iter()
            .map(|document| {
                serde_json::json!({
                    "provider": document.provider_kind.to_string(),
                    "document": provider_document_value(document.document),
                })
            })
            .collect::<Vec<_>>();
        Self::new(serde_json::json!({
            "exportedAt": bundle.exported_at.to_rfc3339(),
            "fileName": filename,
            "documents": documents,
        }))
    }
}

impl fmt::Debug for AccountExportData {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("AccountExportData(<redacted>)")
    }
}

pub struct AccountConnectionTestEvent {
    pub data: Value,
}

impl From<(DomainConnectionTestEvent, crate::time::TimePresenter)> for AccountConnectionTestEvent {
    fn from((event, time): (DomainConnectionTestEvent, crate::time::TimePresenter)) -> Self {
        let mut data = match event {
            DomainConnectionTestEvent::Started { model } => serde_json::json!({
                "type": "test_start",
                "model": model,
                "text": "正在连接上游"
            }),
            DomainConnectionTestEvent::Request {
                model,
                input_text,
                stream,
                store,
            } => serde_json::json!({
                "type": "request",
                "payload": {
                    "model": model,
                    "input": [{
                        "role": "user",
                        "content": [{ "type": "input_text", "text": input_text }]
                    }],
                    "stream": stream,
                    "store": store
                }
            }),
            DomainConnectionTestEvent::Content { text } => {
                serde_json::json!({ "type": "content", "text": text })
            }
            DomainConnectionTestEvent::Completed => serde_json::json!({
                "type": "test_complete",
                "success": true
            }),
            DomainConnectionTestEvent::Failed {
                source,
                gateway_error_code,
                proxy_hint,
                send_state,
                message,
                provider_error_code,
                provider_error_type,
                upstream_status,
                upstream_content_type,
                upstream_body,
            } => serde_json::json!({
                "type": "error",
                "source": source.as_str(),
                "gatewayErrorCode": gateway_error_code.as_str(),
                "proxyHint": proxy_hint.map(gateway_core::error::ProxyConnectionHint::as_str),
                "sendState": send_state.map(gateway_core::upstream::UpstreamSendState::as_str),
                "error": message,
                "providerErrorCode": provider_error_code,
                "providerErrorType": provider_error_type,
                "upstreamStatus": upstream_status,
                "upstreamContentType": upstream_content_type,
                "upstreamBody": upstream_body
            }),
        };
        let now = Utc::now();
        data["occurredAt"] = now.to_rfc3339().into();
        data["occurredAtDisplay"] = time.datetime(&now).into();
        data["timeDisplay"] = time.time(&now).into();
        Self { data }
    }
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ProfileActivityCalendar {
    pub range_label: String,
    pub weeks: Vec<ProfileActivityWeek>,
}
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ProfileActivityWeek {
    pub key: String,
    pub month_label: Option<String>,
    pub cells: Vec<ProfileActivityCell>,
}
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ProfileActivityCell {
    pub date: String,
    pub date_display: String,
    pub tokens: u64,
    pub is_future: bool,
}
fn profile_activity_calendar(
    daily: &[ProviderProfileDailyUsage],
    today: chrono::NaiveDate,
) -> Option<ProfileActivityCalendar> {
    use chrono::{Datelike as _, Days};
    let week_start =
        today.checked_sub_days(Days::new(u64::from(today.weekday().num_days_from_sunday())))?;
    let start = week_start.checked_sub_days(Days::new(51 * 7))?;
    let mut counts = std::collections::BTreeMap::<_, u64>::new();
    for entry in daily {
        if entry.date >= start && entry.date <= today {
            let value = counts.entry(entry.date).or_default();
            *value = value.saturating_add(entry.tokens);
        }
    }
    let mut weeks = Vec::with_capacity(52);
    for index in 0..52 {
        let mut cells = Vec::with_capacity(7);
        let mut month_label = None;
        let week = start.checked_add_days(Days::new(index * 7))?;
        for day in 0..7 {
            let date = week.checked_add_days(Days::new(day))?;
            if date.day() == 1 {
                month_label = Some(format!("{}月", date.month()));
            }
            cells.push(ProfileActivityCell {
                date: date.to_string(),
                date_display: format!("{}年{}月{}日", date.year(), date.month(), date.day()),
                tokens: counts.get(&date).copied().unwrap_or_default(),
                is_future: date > today,
            });
        }
        weeks.push(ProfileActivityWeek {
            key: week.to_string(),
            month_label,
            cells,
        });
    }
    Some(ProfileActivityCalendar {
        range_label: format!("{start} 至 {today}"),
        weeks,
    })
}

/// 账号自动使用临期重置卡开关
#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct AccountResetCreditAutomationRequest {
    pub account_id: String,
    pub enabled: bool,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountResetCreditAutomationData {
    pub enabled: bool,
    pub lead_minutes: u32,
    pub weekly_trigger_remaining_percent: Option<u32>,
    pub next_discovery_at_display: Option<String>,
    pub next_consume_at_display: Option<String>,
    pub last_result: Option<String>,
}

impl
    From<(
        gateway_admin::model::reset_credit_automation::ResetCreditAutomationStatus,
        crate::time::TimePresenter,
    )> for AccountResetCreditAutomationData
{
    fn from(
        (status, time): (
            gateway_admin::model::reset_credit_automation::ResetCreditAutomationStatus,
            crate::time::TimePresenter,
        ),
    ) -> Self {
        Self {
            enabled: status.enabled,
            lead_minutes: status.lead_minutes,
            weekly_trigger_remaining_percent: status.weekly_trigger_remaining_percent,
            next_discovery_at_display: status
                .next_discovery_at
                .as_ref()
                .map(|value| time.datetime(value)),
            next_consume_at_display: status
                .next_consume_at
                .as_ref()
                .map(|value| time.datetime(value)),
            last_result: status.last_result,
        }
    }
}
