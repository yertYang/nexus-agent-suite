//! 观测领域事实到管理页面的展示投影

use super::*;
use gateway_core::metering::Usage;

pub(crate) fn display_duration(value: Option<u64>) -> String {
    let Some(value) = value.and_then(|value| i64::try_from(value).ok()) else {
        return "—".to_owned();
    };
    if value < 1_000 {
        format!("{value} ms")
    } else if value < 60_000 {
        format!("{:.2} s", value as f64 / 1_000.0)
    } else if value < 3_600_000 {
        format!("{:.1} min", value as f64 / 60_000.0)
    } else {
        format!("{:.1} h", value as f64 / 3_600_000.0)
    }
}

fn display_duration_f64(value: Option<f64>) -> String {
    let Some(value) = value.filter(|value| value.is_finite() && *value >= 0.0) else {
        return "—".to_owned();
    };
    if value < 1_000.0 {
        format!("{value:.0} ms")
    } else if value < 60_000.0 {
        format!("{:.2} s", value / 1_000.0)
    } else if value < 3_600_000.0 {
        format!("{:.1} min", value / 60_000.0)
    } else {
        format!("{:.1} h", value / 3_600_000.0)
    }
}

pub(crate) fn display_rate(value: f64) -> String {
    if value.is_finite() {
        format!("{:.1}%", value * 100.0)
    } else {
        "—".to_owned()
    }
}

pub(crate) fn outcome_name(outcome: &domain::RequestOutcome) -> &str {
    outcome.as_str()
}

fn request_summary_metrics_view(metrics: &domain::RequestSummaryMetrics) -> RequestMetricsView {
    RequestMetricsView {
        request_count: metrics.request_count,
        success_count: metrics.success_count,
        failure_count: metrics.failure_count,
        cancelled_count: metrics.cancelled_count,
        incomplete_count: metrics.incomplete_count,
        caller_error_count: metrics.caller_error_count,
        input_tokens: metrics.input_tokens,
        output_tokens: metrics.output_tokens,
        cached_input_tokens: metrics.cached_input_tokens,
        cache_write_input_tokens: metrics.cache_write_input_tokens,
        reasoning_output_tokens: metrics.reasoning_output_tokens,
        total_tokens: metrics.total_tokens,
    }
}

pub(crate) fn cost_coverage_view(coverage: &domain::CostCoverage) -> CostCoverageView {
    CostCoverageView {
        known: coverage.known_count(),
        partial: coverage.partial_count,
        unknown: coverage.unavailable_count,
        not_billable: coverage.not_billable_count,
    }
}

pub(crate) fn cost_views(costs: &[domain::CurrencyCost]) -> Vec<CostView> {
    costs
        .iter()
        .map(|cost| CostView {
            currency: cost.currency.clone(),
            estimated_amount: cost.amount.as_str().to_owned(),
        })
        .collect()
}

pub(crate) fn attempt_metrics_view(metrics: &domain::AttemptMetrics) -> AttemptMetricsView {
    AttemptMetricsView {
        attempt_count: metrics.attempt_count,
        success_count: metrics.success_count,
        failure_count: metrics.failure_count,
        cancelled_count: metrics.cancelled_count,
        incomplete_count: metrics.incomplete_count,
        rate_limited_count: metrics.rate_limited_count,
        auth_failure_count: metrics.auth_failure_count,
        provider5xx_count: metrics.provider_5xx_count,
        cost_coverage: cost_coverage_view(&metrics.cost_coverage),
        costs: cost_views(&metrics.costs),
    }
}

pub(crate) fn token_details(record: &domain::UsageRecord) -> TokenDetailsView {
    token_details_view(&Usage {
        input_tokens: record.input_tokens,
        output_tokens: record.output_tokens,
        cached_input_tokens: record.cached_input_tokens,
        cache_write_input_tokens: record.cache_write_input_tokens,
        reasoning_output_tokens: record.reasoning_output_tokens,
        image_input_tokens: record.image_input_tokens,
        image_output_tokens: record.image_output_tokens,
        total_tokens: record.total_tokens,
    })
}

pub(crate) fn usage_list_token_details(record: &domain::UsageListRecord) -> TokenDetailsView {
    token_details_view(&Usage {
        input_tokens: record.input_tokens,
        output_tokens: record.output_tokens,
        cached_input_tokens: record.cached_input_tokens,
        cache_write_input_tokens: record.cache_write_input_tokens,
        reasoning_output_tokens: record.reasoning_output_tokens,
        image_input_tokens: record.image_input_tokens,
        image_output_tokens: record.image_output_tokens,
        total_tokens: record.total_tokens,
    })
}

fn token_details_view(usage: &Usage) -> TokenDetailsView {
    TokenDetailsView {
        input_tokens: usage.input_tokens,
        output_tokens: usage.output_tokens,
        cached_input_tokens: usage.cached_input_tokens,
        cache_write_input_tokens: usage.cache_write_input_tokens,
        reasoning_output_tokens: usage.reasoning_output_tokens,
        image_input_tokens: usage.image_input_tokens,
        image_output_tokens: usage.image_output_tokens,
        total_tokens: usage.total_tokens,
        input_tokens_display: usage
            .input_tokens
            .map_or_else(|| "-".to_owned(), format_number),
        output_tokens_display: usage
            .output_tokens
            .map_or_else(|| "-".to_owned(), format_number),
        cached_input_tokens_display: usage
            .cached_input_tokens
            .map_or_else(|| "-".to_owned(), format_compact_number),
        cache_write_input_tokens_display: usage
            .cache_write_input_tokens
            .map_or_else(|| "-".to_owned(), format_compact_number),
        reasoning_output_tokens_display: usage
            .reasoning_output_tokens
            .map_or_else(|| "-".to_owned(), format_number),
        image_input_tokens_display: usage
            .image_input_tokens
            .map_or_else(|| "-".to_owned(), format_number),
        image_output_tokens_display: usage
            .image_output_tokens
            .map_or_else(|| "-".to_owned(), format_number),
        total_tokens_display: usage
            .total_tokens
            .map_or_else(|| "-".to_owned(), format_number),
    }
}

pub(crate) fn format_money(cost: &domain::CurrencyCost) -> String {
    format_decimal_currency(cost.amount.as_str(), &cost.currency)
}

pub(crate) fn format_token_price(cost: &domain::CurrencyCost) -> String {
    if cost.currency != "USD" {
        return format!("{} {} / 1M Token", cost.currency, cost.amount.as_str());
    }
    format!("${} / 1M Token", cost.amount.as_str())
}

pub(crate) fn format_service_tier(service_tier: Option<&str>) -> String {
    match service_tier {
        Some("priority" | "fast") => "Fast".to_owned(),
        Some("flex") => "Flex".to_owned(),
        Some("default" | "standard") | None => "Standard".to_owned(),
        Some(other) => capitalize_first(other),
    }
}

fn capitalize_first(value: &str) -> String {
    let mut chars = value.chars();
    chars
        .next()
        .map(|first| first.to_uppercase().chain(chars).collect())
        .unwrap_or_default()
}

pub(crate) fn billing_view(billing: Option<&domain::UsageBilling>) -> Option<BillingView> {
    match billing? {
        domain::UsageBilling::Total { source, total } => Some(BillingView {
            long_context_billing_applied: false,
            image: None,
            input_amount_display: "—".to_owned(),
            output_amount_display: "—".to_owned(),
            cache_read_amount_display: "—".to_owned(),
            cache_write_amount_display: "—".to_owned(),
            standard_amount_display: "—".to_owned(),
            total_amount_display: if source == "calculated" {
                format!("≈ {}", format_money(total))
            } else {
                format_money(total)
            },
            input_price_display: "—".to_owned(),
            output_price_display: "—".to_owned(),
            cache_read_price_display: "—".to_owned(),
            cache_write_price_display: "—".to_owned(),
            service_tier_display: "—".to_owned(),
            multiplier_display: "—".to_owned(),
        }),
        domain::UsageBilling::Calculated(value) => Some(BillingView {
            long_context_billing_applied: value.long_context_billing_applied,
            image: value
                .image
                .as_ref()
                .map(|image| super::wire::ImageBillingView {
                    input_amount_display: format_money(&image.input_amount),
                    cache_read_amount_display: format_money(&image.cache_read_amount),
                    input_price_display: format_token_price(&image.input_price_per_million),
                    cache_read_price_display: format_token_price(
                        &image.cache_read_price_per_million,
                    ),
                }),
            input_amount_display: format_money(&value.input_amount),
            output_amount_display: format_money(&value.output_amount),
            cache_read_amount_display: format_money(&value.cache_read_amount),
            cache_write_amount_display: format_money(&value.cache_write_amount),
            standard_amount_display: format_money(&value.standard_amount),
            total_amount_display: format_money(&value.total_amount),
            input_price_display: format_token_price(&value.input_price_per_million),
            output_price_display: format_token_price(&value.output_price_per_million),
            cache_read_price_display: format_token_price(&value.cache_read_price_per_million),
            cache_write_price_display: format_token_price(&value.cache_write_price_per_million),
            service_tier_display: format_service_tier(value.service_tier.as_deref()),
            multiplier_display: if value.custom_multiplier_bps == 10_000 {
                format!("{:.2}x", f64::from(value.multiplier_percent) / 100.0)
            } else {
                format!(
                    "档位 {:.2}x · 自定义 {:.4}x",
                    f64::from(value.multiplier_percent) / 100.0,
                    f64::from(value.custom_multiplier_bps) / 10_000.0
                )
            },
        }),
    }
}

pub(crate) fn usage_list_record_view(
    record: domain::UsageListRecord,
    time: crate::time::TimePresenter,
) -> UsageListRecordView {
    let token_details = usage_list_token_details(&record);
    let billing = billing_view(record.billing.as_ref());
    let created_at_display = time.datetime(&record.started_at);
    let model = record
        .upstream_model_id
        .clone()
        .or_else(|| record.requested_model_id.clone());
    UsageListRecordView {
        error_origin: record.error_origin().as_str(),
        client_status_code: record.client_status_code,
        upstream_status_code: record.upstream_status_code,
        error_code: record.error_code,
        error_message: record.error_message,
        error_kind: record.error_kind,
        websocket_close_code: record.websocket_close_code,
        continuation_unavailable_reason: record.continuation_unavailable_reason,
        upstream_connection_exit_reason: record.upstream_connection_exit_reason,
        recovered: record.recovered,
        logical_outcome: record.outcome.as_str().to_owned(),
        client_api_key_name: record.client_api_key_name,
        id: record.id,
        provider: record.provider_kind,
        authentication_kind: record.provider_account_authentication_kind,
        account_id: record.provider_account_ref,
        account_email: record.provider_account_email,
        account_name: record.provider_account_name,
        account_notes: record.provider_account_notes,
        account_plan_type: record.provider_account_plan_type,
        account_plan_type_display: record.provider_account_plan_type_display,
        account_upstream_peer: record.provider_account_upstream_peer,
        route: record.endpoint,
        model,
        requested_model: record.requested_model_id,
        upstream_model: record.upstream_model_id,
        service_tier: record.service_tier,
        client_transport: record.client_transport,
        upstream_transport: record.upstream_transport,
        reasoning_effort: record.reasoning_effort,
        reasoning_preset: record.reasoning_preset,
        subagent_kind: record.subagent_kind,
        compact: record.compact,
        token_details,
        billing,
        latency_details: UsageLatencyDetailsView {
            admission_decision_ms: record.admission_decision_ms,
            account_selection_wait_ms: record.account_selection_wait_ms,
            capacity_used_slots: record.capacity_used_slots,
            capacity_total_slots: record.capacity_total_slots,
            transport_decision_wait_ms: record.transport_decision_wait_ms,
            ws_connect_ms: record.connect_ms,
            upstream_headers_ms: record.headers_ms,
            first_event_ms: record.first_event_ms,
            first_reasoning_ms: record.first_reasoning_ms,
            first_text_ms: record.first_text_ms,
            openai_processing_ms: record.provider_processing_ms,
            upstream_response_ms: record.upstream_response_ms,
            upstream_api_overhead_ms: record.upstream_api_overhead_ms,
            upstream_engine_ms: record.upstream_engine_ms,
        },
        first_token_latency_ms: record.first_token_ms,
        latency_ms: record.latency_ms,
        created_at: record.started_at,
        created_at_display,
        client_ip: record.client_ip,
        user_agent: record.user_agent,
    }
}

pub(crate) fn usage_record_view(
    record: domain::UsageRecord,
    time: crate::time::TimePresenter,
) -> UsageRecordView {
    let tokens = token_details(&record);
    let billing = billing_view(record.billing.as_ref());
    let costs = record
        .cost_amount
        .as_ref()
        .zip(record.cost_currency.as_ref())
        .map(|(amount, currency)| {
            vec![CostView {
                currency: currency.clone(),
                estimated_amount: amount.as_str().to_owned(),
            }]
        })
        .unwrap_or_default();
    let status_code = record
        .client_status_code
        .or(record.upstream_status_code)
        .map(i64::from);
    let outcome = outcome_name(&record.outcome).to_owned();
    let message = record
        .error_message
        .clone()
        .unwrap_or_else(|| outcome.clone());
    let latency_display = display_duration(record.latency_ms);
    let cost_coverage = match record.cost_source.as_str() {
        "provider_reported" | "calculated" => CostCoverageView {
            known: 1,
            partial: 0,
            unknown: 0,
            not_billable: 0,
        },
        _ => CostCoverageView {
            known: 0,
            partial: 0,
            unknown: 1,
            not_billable: 0,
        },
    };
    let model = record
        .upstream_model_id
        .clone()
        .or_else(|| record.requested_model_id.clone());
    let metadata = provider_metadata_fields(record.provider_metadata_json.as_deref());
    UsageRecordView {
        error_origin: record.error_origin().as_str(),
        upstream_error: record
            .upstream_error
            .map(|error| super::wire::UsageUpstreamErrorView {
                code: error.code,
                error_type: error.error_type,
                message: error.message,
                param: error.param,
                close_reason: error.close_reason,
                last_event_type: error.last_event_type,
            }),
        retry_after_ms: record.retry_after_ms,
        error_code: record.provider_error_code,
        error_kind: record.error_kind,
        websocket_close_code: record.websocket_close_code,
        continuation_unavailable_reason: record.continuation_unavailable_reason,
        upstream_connection_exit_reason: record.upstream_connection_exit_reason,
        recovered: record.recovered,
        id: record.id.clone(),
        request_id: record.id,
        client_api_key_id: Some(record.client_api_key_ref),
        routing_scope: record.routing_scope,
        routing_group_refs: record.routing_group_refs,
        routing_group_names_snapshot: record.routing_group_names_snapshot,
        kind: record.operation,
        provider: record.provider_kind,
        authentication_kind: record.provider_account_authentication_kind,
        account_id: record.provider_account_ref,
        account_email: record.provider_account_email,
        account_name: record.provider_account_name,
        route: record.endpoint,
        model,
        requested_model: record.requested_model_id,
        upstream_model: record.upstream_model_id,
        service_tier: record.service_tier,
        status_code,
        client_transport: record.client_transport,
        upstream_transport: record.upstream_transport,
        protocol: record.protocol.clone(),
        http_version: record.http_version.clone(),
        client_status_code: record.client_status_code.map(i64::from),
        upstream_status_code: record.upstream_status_code.map(i64::from),
        websocket_pool: record
            .websocket_pool
            .clone()
            .map(|kind| WebSocketPoolMetadataView { kind }),
        image_generation_requested: record.image_generation_requested,
        image_generation_succeeded: record.image_generation_succeeded,
        latency_details: UsageLatencyDetailsView {
            admission_decision_ms: record.admission_decision_ms,
            account_selection_wait_ms: record.account_selection_wait_ms,
            capacity_used_slots: record.capacity_used_slots,
            capacity_total_slots: record.capacity_total_slots,
            transport_decision_wait_ms: record.transport_decision_wait_ms,
            ws_connect_ms: record.connect_ms,
            upstream_headers_ms: record.headers_ms,
            first_event_ms: record.first_event_ms,
            first_reasoning_ms: record.first_reasoning_ms,
            first_text_ms: record.first_text_ms,
            openai_processing_ms: record.provider_processing_ms,
            upstream_response_ms: record.upstream_response_ms,
            upstream_api_overhead_ms: record.upstream_api_overhead_ms,
            upstream_engine_ms: record.upstream_engine_ms,
        },
        attempt_index: None,
        attempt_count: u64::from(record.attempt_count),
        response_id: record.client_response_id,
        upstream_request_id: record.upstream_request_id,
        latency_ms: record.latency_ms,
        input_tokens: record.input_tokens,
        output_tokens: record.output_tokens,
        cached_input_tokens: record.cached_input_tokens,
        cache_write_input_tokens: record.cache_write_input_tokens,
        reasoning_output_tokens: record.reasoning_output_tokens,
        image_input_tokens: record.image_input_tokens,
        image_output_tokens: record.image_output_tokens,
        message,
        metadata,
        created_at: record.started_at,
        created_at_display: time.datetime(&record.started_at),
        client_ip: record.client_ip,
        user_agent: record.user_agent,
        reasoning_effort: record.reasoning_effort,
        reasoning_preset: record.reasoning_preset,
        compact: Some(record.compact),
        request_kind: record.request_kind,
        subagent_kind: record.subagent_kind,
        token_details: tokens,
        billing,
        costs,
        cost_coverage,
        first_token_latency_ms: record.first_token_ms,
        latency_ms_display: latency_display,
        logical_outcome: outcome,
    }
}

pub(crate) fn provider_metadata_fields(value: Option<&str>) -> BTreeMap<String, Value> {
    const CORE_METADATA_FIELDS: &[&str] = &[
        "protocol",
        "logicalOutcome",
        "attemptCount",
        "requestedModel",
        "upstreamModel",
        "clientIp",
        "userAgent",
        "reasoningEffort",
        "reasoningPreset",
        "compact",
        "requestKind",
        "subagentKind",
        "transport",
        "clientTransport",
        "upstreamTransport",
        "httpVersion",
        "clientStatusCode",
        "upstreamStatusCode",
        "responseId",
        "upstreamRequestId",
        "websocketPool",
        "imageGenerationRequested",
        "imageGenerationSucceeded",
        "latencyDetails",
    ];
    let Some(Ok(Value::Object(fields))) = value.map(serde_json::from_str::<Value>) else {
        return BTreeMap::new();
    };
    fields
        .into_iter()
        .filter(|(field, _)| !CORE_METADATA_FIELDS.contains(&field.as_str()))
        .collect()
}

pub(crate) fn usage_attempt_view(attempt: domain::UsageAttempt) -> UsageAttemptView {
    let occurred_at = attempt.occurred_at;
    let credential_name = attempt
        .provider_account_name
        .as_ref()
        .or(attempt.provider_account_ref.as_ref())
        .cloned();
    UsageAttemptView {
        id: attempt.id,
        attempt_index: attempt.attempt_index,
        trigger: attempt.source,
        provider: attempt
            .provider_kind
            .unwrap_or_else(|| "unknown".to_owned()),
        model: attempt.upstream_model_id,
        transport: attempt
            .upstream_transport
            .unwrap_or_else(|| "unknown".to_owned()),
        send_state: attempt
            .upstream_send_state
            .unwrap_or_else(|| "unknown".to_owned()),
        outcome: outcome_name(&attempt.outcome).to_owned(),
        downstream_committed: attempt.downstream_committed,
        status_code: attempt.status_code,
        provider_error_code: attempt.provider_error_code,
        failure_class: attempt.failure_kind,
        cost_estimate_status: attempt
            .cost_source
            .clone()
            .unwrap_or_else(|| "unavailable".to_owned()),
        estimated_cost_amount: attempt.cost_amount.map(|amount| amount.as_str().to_owned()),
        estimated_cost_currency: attempt.cost_currency,
        input_tokens: attempt.input_tokens,
        output_tokens: attempt.output_tokens,
        cached_input_tokens: attempt.cached_input_tokens,
        total_tokens: attempt.total_tokens,
        first_token_ms: None,
        latency_ms: attempt.latency_ms,
        credential_name,
        account_id: attempt.provider_account_ref,
        account_name: attempt.provider_account_name,
        account_email: attempt.provider_account_email,
        authentication_kind: attempt.provider_account_authentication_kind,
        started_at: occurred_at,
        completed_at: Some(occurred_at),
    }
}

pub(crate) fn usage_detail_view(
    detail: domain::UsageDetail,
    time: crate::time::TimePresenter,
) -> UsageRecordDetailView {
    UsageRecordDetailView {
        request: usage_record_view(detail.request, time),
        attempts: detail
            .attempts
            .into_iter()
            .map(usage_attempt_view)
            .collect(),
        attempts_complete: false,
    }
}

pub(crate) fn usage_page_view(
    page: domain::UsagePage,
    time: crate::time::TimePresenter,
) -> PageData<UsageListRecordView> {
    PageData {
        items: page
            .items
            .into_iter()
            .map(|value| usage_list_record_view(value, time))
            .collect(),
        current_page: page.current_page,
        page_size: page.page_size,
        total: page.total,
    }
}

pub(crate) fn ops_error_view(
    error: domain::OpsError,
    time: crate::time::TimePresenter,
) -> OpsErrorView {
    let account_label = error
        .provider_account_email
        .as_ref()
        .or(error.provider_account_name.as_ref())
        .or(error.provider_account_ref.as_ref())
        .cloned();
    let model = error
        .upstream_model_id
        .clone()
        .or_else(|| error.requested_model_id.clone());
    OpsErrorView {
        client_api_key_name: error.client_api_key_name,
        id: error.event_id,
        request_id: error.request_id,
        client_api_key_id: error.client_api_key_ref,
        kind: error.component.clone(),
        operation: error.operation,
        protocol: error.protocol,
        client_transport: error.client_transport,
        provider: error.provider_kind,
        authentication_kind: error.provider_account_authentication_kind,
        account_id: error.provider_account_ref,
        account_name: error.provider_account_name,
        account_email: error.provider_account_email,
        account_plan_type: error.provider_account_plan_type,
        account_plan_type_display: error.provider_account_plan_type_display,
        route: error.endpoint.unwrap_or_else(|| "—".to_owned()),
        model,
        requested_model: error.requested_model_id,
        upstream_model: error.upstream_model_id,
        service_tier: error.service_tier,
        client_status_code: error.client_status_code.map(i64::from),
        upstream_status_code: error.upstream_status_code.map(i64::from),
        transport: error.upstream_transport,
        attempt_index: error.attempt_index,
        failure_class: error.failure_kind,
        upstream_send_state: error.upstream_send_state,
        provider_error_code: error.provider_error_code,
        response_id: error.client_response_id,
        upstream_request_id: error.upstream_request_id,
        latency_ms: error.latency_ms,
        client_ip: error.client_ip,
        user_agent: error.user_agent,
        reasoning_effort: error.reasoning_effort,
        reasoning_preset: error.reasoning_preset,
        request_kind: error.request_kind,
        subagent_kind: error.subagent_kind,
        compact: error.compact,
        message: error.message,
        error_details: error.error_details.map(error_details_view),
        metadata: OpsErrorMetadataView {
            source: error.source,
            component: error.component,
            attempt_id: None,
            account_label,
            continuation_affinity_hash: error.continuation_affinity_hash,
            continuation_previous_response_id_hash: error.continuation_previous_response_id_hash,
            continuation_unavailable_reason: error.continuation_unavailable_reason,
            upstream_connection_id: error.upstream_connection_id,
            upstream_connection_exit_reason: error.upstream_connection_exit_reason,
            upstream_connection_age_ms: error.upstream_connection_age_ms,
            upstream_connection_idle_ms: error.upstream_connection_idle_ms,
            recovery_request_id: error.recovery_request_id,
            recovered_at: error.recovered_at,
            recovery_attempt_count: error.recovery_attempt_count,
            recovery_retry_delay_ms: error.recovery_retry_delay_ms,
            recovery_total_latency_ms: error.recovery_total_latency_ms,
        },
        created_at: error.occurred_at,
        created_at_display: time.datetime(&error.occurred_at),
    }
}

// 受控错误正文保持原文语义，嵌套 JSON 只在展示投影中展开缩进
fn error_details_view(raw: String) -> String {
    let Ok(mut value) = serde_json::from_str::<Value>(&raw) else {
        return raw;
    };
    if let Some(upstream) = value.get_mut("upstream")
        && let Some(text) = upstream.as_str()
        && let Ok(parsed) = serde_json::from_str::<Value>(text)
    {
        *upstream = parsed;
    }
    serde_json::to_string_pretty(&value).unwrap_or(raw)
}

pub(crate) fn ops_page_view(
    page: domain::OpsErrorPage,
    time: crate::time::TimePresenter,
) -> PageData<OpsErrorView> {
    PageData {
        items: page
            .items
            .into_iter()
            .map(|value| ops_error_view(value, time))
            .collect(),
        current_page: page.current_page,
        page_size: page.page_size,
        total: page.total,
    }
}

pub(crate) fn trend_point_view(
    point: domain::TrendPoint,
    time: crate::time::TimePresenter,
) -> TrendPointView {
    let local_time = time.label(point.bucket_start, "%H:%M");
    let label = time.label(point.bucket_start, "%m-%d %H:%M");
    let success_rate_value = point.success_rate.map(|value| value * 100.0);
    TrendPointView {
        time: local_time,
        bucket: point.bucket_start,
        label,
        requests: format_compact_number(point.metrics.request_count),
        requests_value: point.metrics.request_count,
        input_tokens: format_compact_number(point.metrics.input_tokens),
        input_tokens_value: point.metrics.input_tokens,
        output_tokens: format_compact_number(point.metrics.output_tokens),
        output_tokens_value: point.metrics.output_tokens,
        cached_input_tokens: format_compact_number(point.metrics.cached_input_tokens),
        cached_input_tokens_value: point.metrics.cached_input_tokens,
        cache_hit_rate_value: point.cached_token_rate,
        tokens_value: point.metrics.total_tokens,
        errors: format_compact_number(point.error_count),
        errors_value: point.error_count,
        latency_value: point.average_latency_ms,
        success_rate: success_rate_value
            .map_or_else(|| "—".to_owned(), |value| format!("{value:.1}%")),
        success_rate_value,
        first_token_p95_ms: point
            .metrics
            .first_token_latency_percentiles
            .p95_ms
            .map(|value| value.as_f64()),
        latency_p95_ms: point
            .metrics
            .latency_percentiles
            .p95_ms
            .map(|value| value.as_f64()),
        output_throughput_p50: point.metrics.output_throughput_p50,
    }
}

pub(crate) fn trend_summary_view(
    kind: TrendKind,
    summary: &domain::TrendSummary,
) -> Vec<TrendSummaryView> {
    match kind {
        TrendKind::Usage => vec![
            TrendSummaryView {
                metric: TrendMetric::InputTokens,
                value: format_compact_number(summary.input_tokens),
                ratio: None,
            },
            TrendSummaryView {
                metric: TrendMetric::OutputTokens,
                value: format_compact_number(summary.output_tokens),
                ratio: None,
            },
            TrendSummaryView {
                metric: TrendMetric::CachedInputTokens,
                value: format_compact_number(summary.cached_input_tokens),
                ratio: None,
            },
        ],
        TrendKind::Latency => vec![
            TrendSummaryView {
                metric: TrendMetric::FirstTokenP95Ms,
                value: display_duration_f64(summary.peak_first_token_p95_ms),
                ratio: None,
            },
            TrendSummaryView {
                metric: TrendMetric::LatencyP95Ms,
                value: display_duration_f64(summary.peak_latency_p95_ms),
                ratio: None,
            },
            TrendSummaryView {
                metric: TrendMetric::OutputThroughputP50,
                value: summary
                    .minimum_output_throughput_p50
                    .map_or_else(|| "—".to_owned(), |value| format!("{value} tok/s")),
                ratio: None,
            },
        ],
        TrendKind::Errors => vec![
            TrendSummaryView {
                metric: TrendMetric::Errors,
                value: format_compact_number(summary.error_count),
                ratio: None,
            },
            TrendSummaryView {
                metric: TrendMetric::SuccessRate,
                value: "—".to_owned(),
                ratio: summary
                    .success_rate
                    .map(|value| format!("{:.1}%", value * 100.0)),
            },
            TrendSummaryView {
                metric: TrendMetric::Requests,
                value: format_compact_number(summary.request_count),
                ratio: None,
            },
        ],
    }
}

pub(crate) fn trend_view(
    trend: domain::Trend,
    kind: TrendKind,
    time: crate::time::TimePresenter,
) -> TrendData {
    TrendData {
        analytics: analytics_view(trend.analytics, time),
        kind,
        summary: trend_summary_view(kind, &trend.summary),
        points: trend
            .points
            .into_iter()
            .map(|value| trend_point_view(value, time))
            .collect(),
    }
}

pub(crate) fn health_status_name(status: domain::HealthStatus) -> &'static str {
    match status {
        domain::HealthStatus::Future => "future",
        domain::HealthStatus::NoData => "no_data",
        domain::HealthStatus::Unavailable => "unavailable",
        domain::HealthStatus::LowSample => "low_sample",
        domain::HealthStatus::Unstable => "unstable",
        domain::HealthStatus::Stable => "stable",
    }
}

pub(crate) fn reliability_display(value: Option<f64>) -> String {
    value.map_or_else(|| "-".to_owned(), |value| format!("{value:.1}%"))
}

pub(crate) fn health_timeline_view(
    timeline: domain::HealthTimeline,
    time: crate::time::TimePresenter,
) -> HealthTimelineView {
    HealthTimelineView {
        title: "请求健康时间线".to_owned(),
        description: "有效请求可用性".to_owned(),
        reliability_display: reliability_display(timeline.reliability_percent),
        status: health_status_name(timeline.status).to_owned(),
        success_requests: timeline.success_requests,
        failed_requests: timeline.failed_requests,
        cancelled_requests: timeline.cancelled_requests,
        incomplete_requests: timeline.incomplete_requests,
        caller_error_requests: timeline.caller_error_requests,
        points: timeline
            .points
            .into_iter()
            .map(|point| HealthTimelinePointView {
                bucket_start: point.bucket_start,
                time: time.label(point.bucket_start, "%H:%M"),
                status: health_status_name(point.status).to_owned(),
                reliability_display: reliability_display(point.reliability_percent),
                success_requests: point.success_requests,
                failed_requests: point.failed_requests,
                cancelled_requests: point.cancelled_requests,
                incomplete_requests: point.incomplete_requests,
                caller_error_requests: point.caller_error_requests,
            })
            .collect(),
    }
}

pub(crate) fn wire_profile_view(
    profile: domain::DashboardWireProfile,
    time: crate::time::TimePresenter,
) -> DashboardWireProfileView {
    DashboardWireProfileView {
        provider: profile.provider,
        product: profile.product,
        version: profile.version,
        build: profile.build,
        target: DashboardWireTargetView {
            os_type: profile.target.os_type,
            os_version: profile.target.os_version,
            arch: profile.target.arch,
            terminal: profile.target.terminal,
        },
        user_agent: profile.user_agent,
        attributes: profile
            .attributes
            .into_iter()
            .map(|attribute| DashboardWireAttributeView {
                key: attribute.key,
                value: attribute.value,
            })
            .collect(),
        verified_at_display: profile.verified_at.map(|value| time.datetime(&value)),
        verified_at: profile.verified_at,
        release: profile.release.map(|release| DashboardDesktopReleaseView {
            status: release.status.into(),
            checked_at_display: release.checked_at.map(|value| time.datetime(&value)),
            checked_at: release.checked_at,
            latest_version: release.latest_version,
            latest_build: release.latest_build,
            error: release.error,
        }),
    }
}

pub(crate) fn dashboard_view(
    result: domain::DashboardResult,
    kind: TrendKind,
    time: crate::time::TimePresenter,
) -> DashboardDataView {
    let domain::DashboardResult {
        observation,
        today,
        yesterday,
        total_billing_usd,
        total_cached_token_rate,
        average_first_token_latency_ms,
        trend,
        health_timeline,
        wire_profiles,
        capacity,
        rotation_strategy,
    } = result;
    let domain::DashboardObservation {
        analytics,
        runtime_slots: _,
        range,
        totals,
        provider_accounts,
        account_usage,
        recent_requests,
        ..
    } = observation;
    let mut account_usage_views = Vec::with_capacity(account_usage.len());
    for credential in account_usage {
        let local_requests = credential
            .quota_window
            .as_ref()
            .filter(|window| window.used_percent.is_none())
            .and_then(|window| window.local_usage.as_ref())
            .map(|usage| usage.request_count);
        let (metric, metric_value_raw, metric_label, metric_value) = match local_requests {
            Some(count) => (
                DashboardAccountMetric::Requests,
                Some(count),
                "次数".to_owned(),
                if count > 0 {
                    format_compact_number(count)
                } else {
                    "—".to_owned()
                },
            ),
            None => (
                DashboardAccountMetric::Tokens,
                credential.total_tokens,
                "今日 Token".to_owned(),
                credential
                    .total_tokens
                    .map_or_else(|| "—".to_owned(), format_compact_number),
            ),
        };
        account_usage_views.push(DashboardAccountUsageView {
            upstream: credential.upstream.map(|info| {
                crate::admin::accounts::upstream_info_view(info, chrono::Utc::now(), time)
            }),
            id: credential.account_id.clone(),
            provider: credential.provider_kind.clone(),
            authentication_kind: credential.authentication_kind.clone(),
            email: credential
                .email
                .clone()
                .unwrap_or_else(|| credential.name.clone()),
            notes: credential.notes,
            plan_type: credential.plan_type.clone(),
            plan_type_display: credential
                .plan_type_display
                .clone()
                .unwrap_or_else(|| "未知套餐".to_owned()),
            tokens: credential
                .total_tokens
                .map_or_else(|| "—".to_owned(), format_compact_number),
            request_count: credential.request_count,
            request_buckets: time.request_buckets(
                credential
                    .request_buckets
                    .iter()
                    .map(|bucket| (bucket.bucket_start, bucket.request_count)),
            ),
            quota_used_percent: credential.quota_used_percent,
            usage_window: credential
                .quota_window
                .map(|window| crate::admin::accounts::quota_window_view(window, time)),
            metric,
            metric_value_raw,
            metric_label,
            metric_value,
            last_used_at: credential.last_used_at,
            last_used_relative: credential
                .last_used_at
                .map(|value| time.relative_view(value, range.end)),
            last_used: time.relative_optional(credential.last_used_at, range.end),
        });
    }
    let unavailable_accounts = provider_accounts
        .total
        .saturating_sub(provider_accounts.normal);

    DashboardDataView {
        analytics: analytics_view(analytics, time),
        as_of: range.end,
        as_of_display: time.datetime(&range.end),
        cards: DashboardCardsView {
            credentials: DashboardCredentialsCardView {
                total: provider_accounts.total.to_string(),
                total_value: provider_accounts.total,
                available: provider_accounts.normal.to_string(),
                available_value: provider_accounts.normal,
                unavailable: unavailable_accounts.to_string(),
                unavailable_value: unavailable_accounts,
            },
            traffic: DashboardTrafficCardView {
                today_requests: format_compact_number(today.request_count),
                today_requests_value: today.request_count,
                yesterday_requests_value: yesterday.request_count,
                total_requests: format_compact_number(totals.request_count),
            },
            tokens: DashboardTokensCardView {
                today_tokens: format_compact_number(today.total_tokens),
                today_tokens_value: today.total_tokens,
                yesterday_tokens_value: yesterday.total_tokens,
                total_tokens: format_compact_number(totals.total_tokens),
                total_billing_amount_usd: total_billing_usd
                    .as_ref()
                    .map_or_else(|| "—".to_owned(), |amount| format!("${}", amount.as_str())),
            },
            cache: DashboardCacheCardView {
                today_hit_rate: display_rate(today.cached_token_rate),
                today_hit_rate_value: today.observed_cached_token_rate,
                yesterday_hit_rate_value: yesterday.observed_cached_token_rate,
                total_hit_rate: display_rate(total_cached_token_rate),
                total_cached_input_tokens: format_compact_number(totals.cached_input_tokens),
                average_first_token_latency_ms: display_duration(average_first_token_latency_ms),
            },
        },
        trend: trend_view(trend, kind, time),
        health_timeline: health_timeline_view(health_timeline, time),
        wire_profiles: wire_profiles
            .into_iter()
            .map(|value| wire_profile_view(value, time))
            .collect(),
        account_usage: account_usage_views,
        usage_records: recent_requests
            .into_iter()
            .map(|value| usage_list_record_view(value, time))
            .collect(),
        pool_summary: DashboardPoolSummaryView {
            total: provider_accounts.total,
            normal: provider_accounts.normal,
            quota_paused: provider_accounts.quota_paused,
            quota_exhausted: provider_accounts.quota_exhausted,
            rate_limited: provider_accounts.rate_limited,
            disabled: provider_accounts.disabled,
            error: provider_accounts.error,
        },
        capacity_info: DashboardCapacityInfoView {
            max_concurrent_per_account: capacity.max_concurrent_per_account,
            total_slots: capacity.total_slots,
            used_slots: capacity.used_slots,
            available_slots: capacity.available_slots,
        },
        rotation_strategy: rotation_strategy.as_str().to_owned(),
    }
}

pub(crate) fn usage_summary_view(
    summary: domain::UsageSummary,
    time: crate::time::TimePresenter,
) -> UsageSummaryView {
    let overview = summary.observation;
    UsageSummaryView {
        analytics: analytics_view(overview.analytics, time),
        total_requests: format_compact_number(overview.requests.request_count),
        input_tokens: format_compact_number(overview.requests.input_tokens),
        output_tokens: format_compact_number(overview.requests.output_tokens),
        cached_input_tokens: format_compact_number(overview.requests.cached_input_tokens),
        cache_write_input_tokens: format_compact_number(overview.requests.cache_write_input_tokens),
        total_tokens: format_compact_number(overview.requests.total_tokens),
        average_latency_ms: display_duration(summary.average_latency_ms),
        average_latency_ms_value: summary.average_latency_ms,
        logical_requests: request_summary_metrics_view(&overview.requests),
        attempts: attempt_metrics_view(&overview.attempts),
    }
}

fn overview_load_view(load: &domain::UsageInsightsLoad) -> OverviewLoadView {
    OverviewLoadView {
        average_concurrency: load.average_concurrency,
        peak_concurrency: load.peak_concurrency,
        admission_decision_p95_ms: load.admission_decision_p95_ms.map(|value| value.as_f64()),
        account_selection_wait_p95_ms: load
            .account_selection_wait_p95_ms
            .map(|value| value.as_f64()),
    }
}

pub(crate) fn usage_insights_view(
    insights: domain::UsageInsights,
    time: crate::time::TimePresenter,
) -> UsageInsightsOverviewView {
    let performance_points = insights
        .performance
        .points
        .iter()
        .map(|point| OverviewPerformancePointView {
            bucket: point.bucket_start,
            label: time.label(point.bucket_start, "%m-%d %H:%M"),
            latency_p50_ms: point.latency_percentiles.p50_ms.map(|value| value.as_f64()),
            latency_p95_ms: point.latency_percentiles.p95_ms.map(|value| value.as_f64()),
            latency_p99_ms: point.latency_percentiles.p99_ms.map(|value| value.as_f64()),
            first_token_p50_ms: point
                .first_token_latency_percentiles
                .p50_ms
                .map(|value| value.as_f64()),
            first_token_p95_ms: point
                .first_token_latency_percentiles
                .p95_ms
                .map(|value| value.as_f64()),
            first_token_p99_ms: point
                .first_token_latency_percentiles
                .p99_ms
                .map(|value| value.as_f64()),
            output_throughput_p10: point.output_throughput_p10,
            output_throughput_p50: point.output_throughput_p50,
            output_throughput_p90: point.output_throughput_p90,
            load: overview_load_view(&point.load),
        })
        .collect();
    let cost_points = insights
        .cost
        .points
        .iter()
        .map(|point| OverviewCostPointView {
            bucket: point.bucket_start,
            label: time.label(point.bucket_start, "%m-%d %H:%M"),
            input_tokens: point.input_tokens,
            output_tokens: point.output_tokens,
            cached_input_tokens: point.cached_input_tokens,
            total_tokens: point.total_tokens,
            estimated_cost: point.estimated_cost.as_ref().map(ToString::to_string),
            standard_cost: point.standard_cost.as_ref().map(ToString::to_string),
            no_cache_cost: point.no_cache_cost.as_ref().map(ToString::to_string),
            cache_savings: point.cache_savings.as_ref().map(ToString::to_string),
            cached_token_rate: point.cached_token_rate,
            cache_hit_request_rate: point.cache_hit_request_rate,
        })
        .collect();
    UsageInsightsOverviewView {
        analytics: analytics_view(insights.analytics, time),
        granularity: granularity_name(insights.granularity).to_owned(),
        health: overview_health_view(&insights.health, time),
        performance: OverviewPerformanceView {
            latency_p50_ms: insights
                .performance
                .latency_percentiles
                .p50_ms
                .map(|value| value.as_f64()),
            latency_p95_ms: insights
                .performance
                .latency_percentiles
                .p95_ms
                .map(|value| value.as_f64()),
            latency_p99_ms: insights
                .performance
                .latency_percentiles
                .p99_ms
                .map(|value| value.as_f64()),
            first_token_p50_ms: insights
                .performance
                .first_token_latency_percentiles
                .p50_ms
                .map(|value| value.as_f64()),
            first_token_p95_ms: insights
                .performance
                .first_token_latency_percentiles
                .p95_ms
                .map(|value| value.as_f64()),
            first_token_p99_ms: insights
                .performance
                .first_token_latency_percentiles
                .p99_ms
                .map(|value| value.as_f64()),
            output_throughput_p10: insights.performance.output_throughput_p10,
            output_throughput_p50: insights.performance.output_throughput_p50,
            output_throughput_p90: insights.performance.output_throughput_p90,
            load: overview_load_view(&insights.performance.load),
            points: performance_points,
        },
        cost: OverviewCostView {
            estimated_cost: insights
                .cost
                .estimated_cost
                .as_ref()
                .map(ToString::to_string),
            standard_cost: insights
                .cost
                .standard_cost
                .as_ref()
                .map(ToString::to_string),
            no_cache_cost: insights
                .cost
                .no_cache_cost
                .as_ref()
                .map(ToString::to_string),
            cache_savings: insights
                .cost
                .cache_savings
                .as_ref()
                .map(ToString::to_string),
            tier_premium: insights.cost.tier_premium.as_ref().map(ToString::to_string),
            cost_per_request: insights
                .cost
                .cost_per_request
                .as_ref()
                .map(ToString::to_string),
            cost_per_successful_request: insights
                .cost
                .cost_per_successful_request
                .as_ref()
                .map(ToString::to_string),
            tokens_per_request: insights.cost.tokens_per_request,
            cached_token_rate: insights.cost.cached_token_rate,
            cache_hit_request_rate: insights.cost.cache_hit_request_rate,
            input_tokens: insights.cost.input_tokens,
            output_tokens: insights.cost.output_tokens,
            cached_input_tokens: insights.cost.cached_input_tokens,
            total_tokens: insights.cost.total_tokens,
            points: cost_points,
            costs: cost_views(&insights.cost.costs),
            coverage: cost_coverage_view(&insights.cost.coverage),
        },
        attempts: attempt_metrics_view(&insights.attempts),
        providers: insights
            .providers
            .into_iter()
            .map(|provider| ProviderOverviewView {
                provider: provider.provider_kind,
                request_count: provider.request_count,
                attempt_count: provider.attempt_count,
                failure_count: provider.failure_count,
                total_tokens: provider.total_tokens,
            })
            .collect(),
    }
}

pub(crate) fn usage_metric_view(
    insight: domain::UsageInsight,
    time: crate::time::TimePresenter,
) -> UsageMetricView {
    use domain::UsageInsightData;
    let data = match insight.data {
        UsageInsightData::Health(health) => {
            UsageMetricDataView::Health(overview_health_view(&health, time))
        }
        UsageInsightData::Latency(series) => UsageMetricDataView::Latency(metric_series_view(
            series,
            time,
            metric_latency_view,
            metric_latency_view,
        )),
        UsageInsightData::FirstToken(series) => UsageMetricDataView::FirstToken(
            metric_series_view(series, time, metric_latency_view, metric_latency_view),
        ),
        UsageInsightData::Throughput(series) => UsageMetricDataView::Throughput(
            metric_series_view(series, time, metric_throughput_view, metric_throughput_view),
        ),
        UsageInsightData::Load(series) => UsageMetricDataView::Load(metric_series_view(
            series,
            time,
            |value| overview_load_view(&value),
            |value| overview_load_view(&value),
        )),
        UsageInsightData::Cost(series) => UsageMetricDataView::Cost(metric_series_view(
            series,
            time,
            metric_cost_summary_view,
            |value| UsageCostComparisonView {
                estimated_cost: value.estimated_cost.as_ref().map(ToString::to_string),
                no_cache_cost: value.no_cache_cost.as_ref().map(ToString::to_string),
            },
        )),
        UsageInsightData::Savings(series) => UsageMetricDataView::Savings(metric_series_view(
            series,
            time,
            metric_cost_summary_view,
            |value| value.as_ref().map(ToString::to_string),
        )),
        UsageInsightData::Cache(series) => UsageMetricDataView::Cache(metric_series_view(
            series,
            time,
            metric_cost_summary_view,
            |value| UsageCacheView {
                input_tokens: value.input_tokens,
                cached_token_rate: value.cached_token_rate,
                cache_hit_request_rate: value.cache_hit_request_rate,
            },
        )),
    };
    UsageMetricView {
        analytics: analytics_view(insight.analytics, time),
        granularity: granularity_name(insight.granularity).to_owned(),
        data,
    }
}

fn metric_series_view<S, P, SV, PV>(
    series: domain::UsageMetricSeries<S, P>,
    time: crate::time::TimePresenter,
    summary: impl FnOnce(S) -> SV,
    point: impl Fn(P) -> PV,
) -> UsageMetricSeriesView<SV, PV> {
    UsageMetricSeriesView {
        summary: summary(series.summary),
        points: series
            .points
            .into_iter()
            .map(|value| UsageMetricPointView {
                bucket: value.bucket_start,
                label: time.label(value.bucket_start, "%m-%d %H:%M"),
                request_count: value.request_count,
                value: point(value.value),
            })
            .collect(),
    }
}

fn metric_latency_view(value: domain::LatencyPercentiles) -> UsageLatencyView {
    UsageLatencyView {
        p50_ms: value.p50_ms.map(|value| value.as_f64()),
        p95_ms: value.p95_ms.map(|value| value.as_f64()),
        p99_ms: value.p99_ms.map(|value| value.as_f64()),
    }
}

fn metric_throughput_view(value: domain::UsageThroughputPercentiles) -> UsageThroughputView {
    UsageThroughputView {
        p10: value.p10,
        p50: value.p50,
        p90: value.p90,
    }
}

fn metric_cost_summary_view(value: domain::UsageCostSummary) -> UsageCostSummaryView {
    UsageCostSummaryView {
        estimated_cost: value.estimated_cost.as_ref().map(ToString::to_string),
        cache_savings: value.cache_savings.as_ref().map(ToString::to_string),
        tier_premium: value.tier_premium.as_ref().map(ToString::to_string),
        cost_per_successful_request: value
            .cost_per_successful_request
            .as_ref()
            .map(ToString::to_string),
        coverage: cost_coverage_view(&value.coverage),
    }
}

pub(crate) fn granularity_name(granularity: domain::Granularity) -> &'static str {
    match granularity {
        domain::Granularity::FifteenMinutes => "15m",
        domain::Granularity::Hour => "1h",
        domain::Granularity::Day => "1d",
    }
}

pub(crate) fn diagnostics_view(
    result: domain::DiagnosticsResult,
    dimension: DiagnosticDimension,
    time: crate::time::TimePresenter,
) -> DiagnosticsView {
    DiagnosticsView {
        analytics: analytics_view(result.analytics, time),
        dimension: dimension.display_name().to_owned(),
        items: result
            .items
            .into_iter()
            .map(|item| DiagnosticItemView {
                key: item.key,
                authentication_kind: item.account_authentication_kind,
                name: if item.name == "__none__" {
                    "未知".to_owned()
                } else {
                    item.name
                },
                request_count: item.request_count,
                account_plan_type: item.account_plan_type,
                account_plan_type_display: item.account_plan_type_display,
                account_upstream_peer: item.account_upstream_peer,
                success_count: item.success_count,
                error_count: item.error_count,
                error_rate: item.error_rate,
                request_share: item.request_share,
                average_latency_ms: item.average_latency_ms,
                latency_p95_ms: item.latency_p95_ms,
                first_token_p95_ms: item.first_token_p95_ms,
                non_completion_count: item.non_completion_count,
                non_completion_rate: item.non_completion_rate,
                retry_count: item.retry_count,
                retry_rate: item.retry_rate,
                estimated_cost: item.estimated_cost.as_ref().map(ToString::to_string),
                attempt_count: item.attempt_count,
                total_tokens: item.total_tokens,
            })
            .collect(),
    }
}

pub(crate) fn map_wire_error(error: WireValidationError) -> AdminError {
    if error.field() == "timeRange" {
        return AdminError::invalid_time_range();
    }
    let message = match error.field() {
        "statusCode" => "statusCode 必须在 100 到 599 之间",
        "attemptIndex" => "attemptIndex 超出有效范围",
        "kind" => "Dashboard 趋势类型不合法",
        "dimension" => "诊断维度不合法",
        "id" => "用量记录 ID 不能为空",
        "cursor" => "观测数据游标不合法",
        _ => "观测查询参数不合法",
    };
    AdminError::bad_request(message)
}

pub(crate) fn map_service_error(error: gateway_admin::model::AdminError) -> AdminError {
    map_admin_service_error(error)
}

pub(crate) fn analytics_view(
    metadata: domain::AnalyticsMetadata,
    time: crate::time::TimePresenter,
) -> AnalyticsView {
    AnalyticsView {
        coverage_start: metadata.coverage_start,
        coverage_start_display: metadata.coverage_start.map(|value| time.datetime(&value)),
        coverage_end: metadata.coverage_end,
        coverage_end_display: metadata.coverage_end.map(|value| time.datetime(&value)),
        generated_at: metadata.generated_at,
        generated_at_display: time.datetime(&metadata.generated_at),
        lag_seconds: metadata.lag_seconds,
        state: metadata.state.as_str().to_owned(),
        percentiles_approximate: metadata.percentiles_approximate,
        schema_version: metadata.schema_version,
        histogram_version: metadata.histogram_version,
    }
}

fn overview_health_view(
    health: &domain::UsageInsightsHealth,
    time: crate::time::TimePresenter,
) -> OverviewHealthView {
    let health_points = health
        .points
        .iter()
        .map(|point| OverviewHealthPointView {
            bucket: point.bucket_start,
            label: time.label(point.bucket_start, "%m-%d %H:%M"),
            total_requests: point.total_requests,
            success_requests: point.success_requests,
            failed_requests: point.failed_requests,
            cancelled_requests: point.cancelled_requests,
            incomplete_requests: point.incomplete_requests,
            caller_error_requests: point.caller_error_requests,
            error_rate: point.error_rate,
        })
        .collect();
    OverviewHealthView {
        total_requests: health.total_requests,
        success_requests: health.success_requests,
        failed_requests: health.failed_requests,
        cancelled_requests: health.cancelled_requests,
        incomplete_requests: health.incomplete_requests,
        caller_error_requests: health.caller_error_requests,
        success_rate: health.success_rate,
        completion_rate: health.completion_rate,
        request_change_rate: None,
        success_rate_change: None,
        points: health_points,
    }
}
