//! OpenAI wire adapter 到 Core 执行用例的唯一映射

use std::net::IpAddr;
use std::sync::Arc;

use gateway_core::engine::authentication::ClientAuthenticationRequest;
use gateway_core::engine::continuation::PreviousResponseId;
use gateway_core::engine::execution::{
    AuthenticatedClient, ClientAuthenticationError, ClientTransport, ExecutionRequestMetadata,
    ExecutionService, PreparedExecutionRequest, PreparedRootExecution, StartProviderExecution,
    StartedExecution,
};
use gateway_core::error::{GatewayError, GatewayErrorKind};
use gateway_core::lifecycle::{ConnectionDraining, ConnectionGuard, ConnectionLifecycle};
use gateway_core::routing::{
    ProviderCatalogUnavailable, ProviderKind, PublicModelDescriptor, PublicModelId, UpstreamModelId,
};
use gateway_protocol::openai::OPENAI_PROTOCOL;
use uuid::Uuid;

use super::auth::ClientApiKeyAuthError;
use super::responses::{ContinuationIntent, DecodedGenerationRequest};

/// OpenAI HTTP/WS adapter 共享的 Core 与连接生命周期能力
#[derive(Clone)]
pub(crate) struct OpenAiService {
    execution: Arc<dyn ExecutionService>,
    lifecycle: Arc<dyn ConnectionLifecycle>,
}

impl OpenAiService {
    pub(crate) fn execution(&self) -> Arc<dyn ExecutionService> {
        Arc::clone(&self.execution)
    }

    #[must_use]
    pub(crate) const fn new(
        execution: Arc<dyn ExecutionService>,
        lifecycle: Arc<dyn ConnectionLifecycle>,
    ) -> Self {
        Self {
            execution,
            lifecycle,
        }
    }

    pub(crate) async fn authenticate(
        &self,
        request: ClientAuthenticationRequest,
    ) -> Result<AuthenticatedClient, ClientApiKeyAuthError> {
        self.execution
            .authenticate_request(request)
            .await
            .map_err(map_authentication_error)
    }

    pub(crate) async fn verify(
        &self,
        request: ClientAuthenticationRequest,
    ) -> Result<AuthenticatedClient, ClientApiKeyAuthError> {
        self.execution
            .verify_request(request)
            .await
            .map_err(map_authentication_error)
    }

    pub(crate) fn public_models(&self, client: &AuthenticatedClient) -> Vec<String> {
        self.execution
            .public_models(client)
            .into_iter()
            .map(|model| model.as_str().to_owned())
            .collect()
    }

    pub(crate) async fn client_model_catalog(
        &self,
        client: &AuthenticatedClient,
        client_version: &str,
    ) -> Result<Vec<PublicModelDescriptor>, ProviderCatalogUnavailable> {
        let context = crate::middleware::current();
        self.execution
            .client_model_catalog(
                client,
                "codex",
                client_version,
                context.as_ref().and_then(|ctx| ctx.extensions.peer_route()),
            )
            .await
    }

    pub(crate) fn contains_public_model(
        &self,
        client: &AuthenticatedClient,
        model: &PublicModelId,
    ) -> bool {
        self.execution.contains_public_model(client, model)
    }

    pub(crate) async fn start_prepared_generation(
        &self,
        prepared: PreparedRootExecution,
        request: DecodedGenerationRequest,
        transport: ClientTransport,
        endpoint: &'static str,
    ) -> Result<StartedExecution, GatewayError> {
        let (operation, metadata) = request.into_parts();
        let protocol = operation.protocol().to_owned();
        let public_model = PublicModelId::from_client_wire(metadata.requested_model().to_owned())
            .map_err(|_| {
            GatewayError::new(
                GatewayErrorKind::ModelNotFound,
                "Requested model was not found.",
            )
        })?;
        let previous_response_id = match metadata.continuation() {
            ContinuationIntent::None => None,
            ContinuationIntent::PreviousResponseId(value) => {
                Some(PreviousResponseId::new(value.clone()))
            }
        };
        self.execution
            .start_prepared(
                prepared,
                PreparedExecutionRequest {
                    public_model,
                    operation,
                    metadata: ExecutionRequestMetadata {
                        protocol,
                        endpoint: endpoint.to_owned(),
                        transport,
                        stream: metadata.stream(),
                        client_ip: metadata.client_ip(),
                        user_agent: metadata.user_agent().map(str::to_owned),
                        previous_response_id,
                    },
                },
            )
            .await
    }

    pub(crate) async fn start_prepared_provider_endpoint(
        &self,
        prepared: PreparedRootExecution,
        operation: gateway_core::operation::Operation,
        upstream_model: Option<UpstreamModelId>,
        client_ip: Option<IpAddr>,
        user_agent: Option<String>,
        endpoint: String,
    ) -> Result<StartedExecution, GatewayError> {
        let provider = ProviderKind::new("openai").map_err(|_| {
            GatewayError::new(
                GatewayErrorKind::Internal,
                "OpenAI provider identifier is invalid.",
            )
        })?;
        self.execution
            .start_prepared_provider_endpoint(
                prepared,
                provider,
                upstream_model,
                operation,
                ExecutionRequestMetadata {
                    protocol: OPENAI_PROTOCOL.to_owned(),
                    endpoint,
                    transport: ClientTransport::HttpJson,
                    stream: false,
                    client_ip,
                    user_agent,
                    previous_response_id: None,
                },
            )
            .await
    }

    pub(crate) async fn start_bound_provider_endpoint(
        &self,
        request: StartProviderExecution,
    ) -> Result<StartedExecution, GatewayError> {
        self.execution.start_provider_endpoint(request).await
    }

    /// Live 语音 sideband 能力；组合未提供时协议层回退到稳定 501。
    #[must_use]
    pub(crate) fn live_gateway(&self) -> Option<Arc<dyn gateway_core::live::LiveGateway>> {
        self.execution.live_gateway()
    }

    pub(crate) fn try_register_connection(
        &self,
    ) -> Result<Box<dyn ConnectionGuard>, ConnectionDraining> {
        self.lifecycle.try_register()
    }

    #[must_use]
    pub(crate) fn lifecycle(&self) -> Arc<dyn ConnectionLifecycle> {
        Arc::clone(&self.lifecycle)
    }

    #[must_use]
    pub(crate) fn next_request_id(&self) -> String {
        format!("req_{}", Uuid::now_v7().simple())
    }
}

const fn map_authentication_error(error: ClientAuthenticationError) -> ClientApiKeyAuthError {
    match error {
        ClientAuthenticationError::InvalidKey => ClientApiKeyAuthError::InvalidKey,
        ClientAuthenticationError::SnapshotUnavailable => ClientApiKeyAuthError::RuntimeUnavailable,
        ClientAuthenticationError::ProviderUnavailable => ClientApiKeyAuthError::RuntimeUnavailable,
    }
}
