//! OpenAI Responses WebSocket 的升级、连接与串行 session 编排

pub mod connection;
mod forward;
mod interrupt;
mod protocol;

use std::{
    net::{IpAddr, SocketAddr},
    sync::Arc,
};

use axum::{
    extract::{Extension, State, connect_info::ConnectInfo},
    http::{HeaderMap, StatusCode},
    response::{IntoResponse, Response},
};
use bytes::Bytes;
use gateway_core::{
    diagnostics::{TraceContext, diagnostic_json},
    engine::{
        execution::{AuthenticatedClient, ClientTransport},
        middleware::{FrozenMiddlewarePlan, MiddlewareError},
        response_control::ResponseControl,
    },
    lifecycle::{ConnectionGuard, ConnectionLifecycle},
    operation::OperationKind,
};
use gateway_protocol::openai::OPENAI_PROTOCOL;

use crate::middleware::headers::encode_headers;
use crate::{
    ApiState,
    openai::middleware::{RequestInput, invoke_request, request_parts},
    openai::{
        auth::{ClientKeyHeaders, authenticate_client, client_access_error_response},
        error::runtime_unavailable_response,
        service::OpenAiService,
    },
};

use super::{
    request::OpenAiRequestHeaders, request_client_context, validation::ResponseValidationFacts,
};
use connection::{
    ConnectionEvent, FramePhase, ResponsesWebSocketConnection, Socket, Upgrade, WriteContext,
};
use forward::{
    ConnectionReplaySnapshot, ForwardOutcome, execution_response, forward_control_event,
    forward_response, new_replay_capture, send_control, send_gateway_error, send_middleware_error,
    send_protocol_error,
};
pub use protocol::{ResponseCreateFrameError, decode_response_create_with_context};
use protocol::{connection_limit_event, is_response_create};

const TEXT_FRAMES_ONLY: &str = "Responses WebSocket accepts text frames only.";
const CONNECTION_LIMIT_CLOSE_REASON: &str = "Responses websocket connection limit reached";

/// 将已认证的 `GET /v1/responses` 升级为 Responses WebSocket
pub(crate) async fn responses_websocket(
    State(state): State<ApiState>,
    connect_info: Option<Extension<ConnectInfo<SocketAddr>>>,
    middleware: Option<Extension<FrozenMiddlewarePlan>>,
    lifetime: Option<Extension<Arc<crate::middleware::CallLifetime>>>,
    headers: HeaderMap,
    websocket: Upgrade,
) -> Response {
    let service = state.openai().clone();
    let client = match authenticate_client(&service, &headers, ClientKeyHeaders::Bearer).await {
        Ok(client) => client,
        Err(error) => return client_access_error_response(error),
    };
    let (client_ip, user_agent) = request_client_context(
        &headers,
        connect_info.map(|Extension(ConnectInfo(address))| address),
    );
    let request_headers = OpenAiRequestHeaders::from_headers(&headers);
    ResponsesWebSocketAdapter::new(service).upgrade_with_client_context(
        websocket,
        client,
        client_ip,
        user_agent,
        request_headers,
        headers,
        middleware.map(|Extension(plan)| plan),
        lifetime.map(|Extension(lifetime)| lifetime),
    )
}

/// 已鉴权 Responses WebSocket 升级边界
#[derive(Clone)]
pub(crate) struct ResponsesWebSocketAdapter {
    service: OpenAiService,
}

impl ResponsesWebSocketAdapter {
    /// 绑定应用提供的唯一 OpenAI 客户端服务端口
    #[must_use]
    pub const fn new(service: OpenAiService) -> Self {
        Self { service }
    }

    #[expect(clippy::too_many_arguments)]
    fn upgrade_with_client_context(
        &self,
        websocket: Upgrade,
        client: AuthenticatedClient,
        client_ip: Option<IpAddr>,
        user_agent: Option<String>,
        request_headers: OpenAiRequestHeaders,
        raw_headers: HeaderMap,
        middleware: Option<FrozenMiddlewarePlan>,
        lifetime: Option<Arc<crate::middleware::CallLifetime>>,
    ) -> Response {
        let connection_guard = match self.service.try_register_connection() {
            Ok(guard) => guard,
            Err(_) => return runtime_unavailable_response().into_response(),
        };
        let connection_id = self.service.next_request_id().replacen("req_", "ws_", 1);
        TraceContext::new(&connection_id).headers(
            "client.connection.headers",
            serde_json::json!({"transport": "websocket", "method": "GET", "path": crate::openai::router::RESPONSES_PATH}),
            raw_headers
                .iter()
                .map(|(name, value)| (name.as_str(), value.as_bytes())),
        );
        let session = ResponsesWebSocketSession {
            service: self.service.clone(),
            client,
            connection_id,
            client_ip,
            user_agent,
            request_headers,
            raw_headers,
            lifecycle: self.service.lifecycle(),
            connection_guard,
            middleware,
        };
        let origin = crate::middleware::current();
        websocket.on_upgrade(move |socket| async move {
            let _lifetime = lifetime;
            crate::middleware::scope(origin, serve_responses_websocket(socket, session)).await;
        })
    }
}

struct ResponsesWebSocketSession {
    service: OpenAiService,
    client: AuthenticatedClient,
    connection_id: String,
    client_ip: Option<IpAddr>,
    user_agent: Option<String>,
    request_headers: OpenAiRequestHeaders,
    raw_headers: HeaderMap,
    lifecycle: Arc<dyn ConnectionLifecycle>,
    connection_guard: Box<dyn ConnectionGuard>,
    middleware: Option<FrozenMiddlewarePlan>,
}

async fn serve_responses_websocket(socket: Socket, session: ResponsesWebSocketSession) {
    let ResponsesWebSocketSession {
        service,
        client,
        connection_id,
        client_ip,
        user_agent,
        request_headers,
        raw_headers,
        lifecycle,
        connection_guard,
        middleware,
    } = session;
    tracing::info!(
        websocket_connection_id = %connection_id,
        "Responses WebSocket connected"
    );
    let _connection_guard = connection_guard;
    let cancellation = lifecycle.cancellation().child_token();
    let _connection_cancellation =
        crate::middleware::websocket::CancelOnDrop(Some(cancellation.clone()));
    let request_headers =
        request_headers.with_downstream_websocket_connection_id(connection_id.clone());
    // 帧中间件可能改写终态，此时不能据原始响应关闭下游连接
    let reconnect_for_replay = !middleware
        .as_ref()
        .is_some_and(FrozenMiddlewarePlan::has_websocket);
    let mut connection = ResponsesWebSocketConnection::new(
        socket,
        connection_id,
        cancellation.clone(),
        middleware,
        encode_headers(&raw_headers).into(),
    );
    let mut request_count = 0_u64;
    let mut replay = ConnectionReplaySnapshot::default();
    let mut response_control = ResponseControl::default();

    loop {
        let event = tokio::select! {
            event = connection.next_event() => {
                let Some(event) = event else { break };
                event
            }
            event = response_control.receive() => {
                let outcome = forward_control_event(&mut connection, &response_control, event).await;
                if disconnect_after_forward(&mut connection, outcome, reconnect_for_replay).await {
                    break;
                }
                continue;
            }
        };
        let payload = match event {
            ConnectionEvent::Text(payload) => payload,
            ConnectionEvent::Binary => {
                connection.close_policy(TEXT_FRAMES_ONLY, None).await;
                break;
            }
            ConnectionEvent::Expired => {
                expire_connection(&mut connection).await;
                break;
            }
            ConnectionEvent::Exited(_) => break,
        };
        if connection.is_expired() {
            expire_connection(&mut connection).await;
            break;
        }
        let correlation_id = Arc::<str>::from(service.next_request_id());
        if !is_response_create(&payload) {
            if send_control(
                &mut connection,
                &response_control,
                &payload,
                &correlation_id,
            )
            .await
                == ForwardOutcome::Disconnect
            {
                break;
            }
            continue;
        }
        request_count = request_count.saturating_add(1);
        // 初步解码只保留路由事实，避免整份正文跨越准入等待和响应交付
        let model_hint = match decode_response_create_with_context(&payload, &request_headers) {
            Ok(decoded) => Some(decoded.metadata().requested_model().to_owned()),
            Err(error) => {
                trace_rejected_request(
                    &correlation_id,
                    connection.id(),
                    &payload,
                    "decode",
                    &error.to_string(),
                );
                if send_protocol_error(
                    &mut connection,
                    StatusCode::BAD_REQUEST,
                    error.protocol_body(),
                    &correlation_id,
                )
                .await
                    == ForwardOutcome::Disconnect
                {
                    break;
                }
                continue;
            }
        };
        // deadline 与 Text 可能同时就绪；在任何上游执行开始前再次封住该竞争窗口
        if connection.is_expired() {
            trace_rejected_request(
                &correlation_id,
                connection.id(),
                &payload,
                "connection_expired",
                "",
            );
            expire_connection(&mut connection).await;
            break;
        }
        response_control.clear();
        let execution = service.execution();
        let preparation = async {
            // 握手的显式改写可继承，Key 策略与宿主设置仍在每轮执行前刷新
            let mut client = client.clone();
            if let Some(settings) = client.request_settings() {
                let current = execution.request_settings().ok_or_else(|| {
                    gateway_core::error::GatewayError::new(
                        gateway_core::error::GatewayErrorKind::Internal,
                        "Gateway configuration is unavailable.",
                    )
                })?;
                let rebased = settings.rebase(current.snapshot()).map_err(|_| {
                    gateway_core::error::GatewayError::new(
                        gateway_core::error::GatewayErrorKind::InvalidRequest,
                        "Request settings are invalid.",
                    )
                })?;
                client = client.with_request_settings(rebased);
            }
            execution.prepare_execution(client).await
        };
        let prepared = match tokio::select! {
            biased;
            _ = connection.wait_for_exit() => break,
            prepared = preparation => prepared,
        } {
            Ok(prepared) => prepared,
            Err(error) => {
                trace_rejected_request(
                    &correlation_id,
                    connection.id(),
                    &payload,
                    "start",
                    &error.to_string(),
                );
                if send_gateway_error(&mut connection, &error, &correlation_id).await
                    == ForwardOutcome::Disconnect
                {
                    break;
                }
                continue;
            }
        };
        let prepared = prepared.with_connection_cancellation(cancellation.clone());
        let request_id = Arc::<str>::from(prepared.request_id().to_string());
        response_control = prepared.response_control();
        let capture = new_replay_capture();
        let validation = ResponseValidationFacts::default();
        let input = RequestInput {
            endpoint: crate::openai::router::RESPONSES_PATH.to_owned(),
            protocol: OPENAI_PROTOCOL.to_owned(),
            operation: Some(OperationKind::Generate),
            transport: ClientTransport::WebSocket,
            model_hint,
            headers: encode_headers(&raw_headers),
            body: Bytes::from(payload),
        };
        let service_for_terminal = service.clone();
        let replay_for_terminal = replay.clone();
        let connection_id_for_terminal = connection.id().to_owned();
        let user_agent_for_terminal = user_agent.clone();
        let request_id_for_terminal = Arc::clone(&request_id);
        let capture_for_terminal = Arc::clone(&capture);
        let validation_for_terminal = validation.clone();
        let invoke = invoke_request(
            execution,
            prepared,
            input,
            Box::new(move |prepared, request| {
                Box::pin(async move {
                    let (protocol, headers, body) = request_parts(request.clone())?;
                    if protocol != OPENAI_PROTOCOL {
                        return Err(MiddlewareError::Rejected);
                    }
                    let payload =
                        std::str::from_utf8(&body).map_err(|_| MiddlewareError::Rejected)?;
                    let request_headers = OpenAiRequestHeaders::from_headers(&headers)
                        .with_downstream_websocket_connection_id(
                            connection_id_for_terminal.clone(),
                        );
                    let decoded = decode_response_create_with_context(payload, &request_headers)
                        .map_err(|_| MiddlewareError::Rejected)?
                        .with_client_context(client_ip, user_agent_for_terminal);
                    let decoded = replay_for_terminal
                        .prepare(decoded)
                        .with_middleware_capabilities(&request)?;
                    let started = service_for_terminal
                        .start_prepared_generation(
                            prepared,
                            decoded,
                            ClientTransport::WebSocket,
                            crate::openai::router::RESPONSES_PATH,
                        )
                        .await
                        .map_err(MiddlewareError::Gateway)?;
                    started.session.trace().record(
                        "client.connection",
                        serde_json::json!({
                            "transport": "websocket",
                            "connectionId": connection_id_for_terminal,
                            "correlationId": request_id_for_terminal.as_ref(),
                            "requestIndex": request_count,
                        }),
                    );
                    started
                        .session
                        .trace()
                        .capture("client.request.body", &body);
                    execution_response(started, capture_for_terminal, validation_for_terminal).await
                })
            }),
        );
        let response = tokio::select! {
            biased;
            _ = connection.wait_for_exit() => break,
            response = invoke => response,
        };
        let response = match response {
            Ok(response) => response,
            Err(error) => {
                if send_middleware_error(&mut connection, error, &request_id).await
                    == ForwardOutcome::Disconnect
                {
                    break;
                }
                continue;
            }
        };
        let outcome = forward_response(
            &mut connection,
            response,
            request_id,
            &mut replay,
            capture,
            validation,
            &response_control,
        )
        .await;
        if disconnect_after_forward(&mut connection, outcome, reconnect_for_replay).await {
            break;
        }
        if connection.is_expired() {
            expire_connection(&mut connection).await;
            break;
        }
    }

    connection.log_summary(request_count);
}

async fn disconnect_after_forward(
    connection: &mut ResponsesWebSocketConnection,
    outcome: ForwardOutcome,
    reconnect_for_replay: bool,
) -> bool {
    outcome == ForwardOutcome::Disconnect
        || (outcome == ForwardOutcome::ReconnectIfIdle
            && reconnect_for_replay
            && !connection.is_expired()
            && connection.close_for_replay_if_idle().await)
}

// 尚未建立模型请求的拒绝也保留原文入口，用返回给客户端的 correlation ID 检索
fn trace_rejected_request(
    correlation_id: &str,
    connection_id: &str,
    payload: &str,
    phase: &'static str,
    error: &str,
) {
    let trace = TraceContext::new(correlation_id);
    trace.record(
        "client.connection",
        serde_json::json!({"connectionId": connection_id}),
    );
    trace.capture("client.request.body", payload.as_bytes());
    trace.record(
        "client.request.rejected",
        serde_json::json!({
            "phase": phase, "detail": diagnostic_json(&serde_json::json!({"message": error})),
        }),
    );
}

async fn expire_connection(connection: &mut ResponsesWebSocketConnection) {
    if connection
        .send_text(
            connection_limit_event(),
            WriteContext::connection(FramePhase::ConnectionLimit),
        )
        .await
        .is_ok()
    {
        connection
            .close_for_connection_limit(CONNECTION_LIMIT_CLOSE_REASON)
            .await;
    }
}
