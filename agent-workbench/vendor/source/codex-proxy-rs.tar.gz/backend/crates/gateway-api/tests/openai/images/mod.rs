//! 图像生成与编辑 HTTP 接口的请求传递和响应交付测试

mod request;

use std::sync::{
    Arc, Mutex,
    atomic::{AtomicBool, Ordering},
};
use std::time::SystemTime;

use axum::{
    body::{Body, to_bytes},
    http::{Request, StatusCode, header::AUTHORIZATION},
};
use base64::{Engine as _, engine::general_purpose::STANDARD};
use bytes::Bytes;
use futures::future::BoxFuture;
use gateway_core::engine::execution::{
    AuthenticatedClient, ClientAuthenticationError, ClientTransport, ExecutionService,
    ExecutionSession, StartExecution, StartProviderExecution, StartedExecution,
};
use gateway_core::engine::{CoordinatedEvent, EngineError, ModelRequestId};
use gateway_core::error::{
    ClientVisibleUpstreamResponse, GatewayError, GatewayErrorKind, ProviderError, ProviderErrorKind,
};
use gateway_core::event::{ProtocolWireEvent, ProviderEvent, ProviderResponseHeader};
use gateway_core::operation::{ImageRequestKind, Operation, OperationKind};
use gateway_core::routing::PublicModelId;
use gateway_core::upstream::UpstreamSendState;
use serde_json::{Value, json};
use tower::ServiceExt;

use super::{api_router, authenticated_client};

const IMAGE_RESPONSE: &[u8] =
    br#"{ "created": 1787212800, "data": [{"b64_json":"AAEC"}], "future": 9007199254740993 }"#;

#[derive(Debug, Clone, PartialEq)]
struct CapturedImageRequest {
    provider: String,
    endpoint: String,
    transport: ClientTransport,
    kind: ImageRequestKind,
    body: Bytes,
    context: Value,
}

struct ImageExecution {
    client: AuthenticatedClient,
    captured: Arc<Mutex<Vec<CapturedImageRequest>>>,
    committed_statuses: Arc<Mutex<Vec<u16>>>,
    error_statuses: Arc<Mutex<Vec<u16>>>,
    fail_with_upstream_response: bool,
    middleware: Option<Arc<crate::openai::middleware::RequestMiddleware>>,
}

impl ImageExecution {
    fn new() -> Arc<Self> {
        Arc::new(Self {
            client: authenticated_client("sk_images_test"),
            captured: Arc::new(Mutex::new(Vec::new())),
            committed_statuses: Arc::new(Mutex::new(Vec::new())),
            error_statuses: Arc::new(Mutex::new(Vec::new())),
            fail_with_upstream_response: false,
            middleware: None,
        })
    }

    fn failing() -> Arc<Self> {
        Arc::new(Self {
            client: authenticated_client("sk_images_test"),
            captured: Arc::new(Mutex::new(Vec::new())),
            committed_statuses: Arc::new(Mutex::new(Vec::new())),
            error_statuses: Arc::new(Mutex::new(Vec::new())),
            fail_with_upstream_response: true,
            middleware: None,
        })
    }

    fn captured(&self) -> Vec<CapturedImageRequest> {
        self.captured.lock().expect("capture lock").clone()
    }

    fn committed_statuses(&self) -> Vec<u16> {
        self.committed_statuses
            .lock()
            .expect("committed status lock")
            .clone()
    }
}

impl ExecutionService for ImageExecution {
    fn middleware_plan(
        &self,
        _: &gateway_core::engine::execution::PreparedRootExecution,
    ) -> Option<gateway_core::engine::middleware::FrozenMiddlewarePlan> {
        self.middleware.as_ref().map(|plan| plan.frozen())
    }

    fn authenticate(
        &self,
        plaintext: &str,
    ) -> Result<AuthenticatedClient, ClientAuthenticationError> {
        (plaintext == "sk_images_test")
            .then(|| self.client.clone())
            .ok_or(ClientAuthenticationError::InvalidKey)
    }

    fn public_models(&self, _: &AuthenticatedClient) -> Vec<PublicModelId> {
        Vec::new()
    }

    fn contains_public_model(&self, _: &AuthenticatedClient, _: &PublicModelId) -> bool {
        false
    }

    fn start(&self, _: StartExecution) -> BoxFuture<'_, Result<StartedExecution, GatewayError>> {
        Box::pin(async {
            Err(GatewayError::new(
                GatewayErrorKind::Internal,
                "images test must use provider endpoint execution",
            ))
        })
    }

    fn start_provider_endpoint(
        &self,
        request: StartProviderExecution,
    ) -> BoxFuture<'_, Result<StartedExecution, GatewayError>> {
        Box::pin(async move {
            let Operation::GenerateImage(image) = &request.operation else {
                return Err(GatewayError::new(
                    GatewayErrorKind::Internal,
                    "images test received a non-image operation",
                ));
            };
            let payload = image.payload();
            self.captured
                .lock()
                .expect("capture lock")
                .push(CapturedImageRequest {
                    provider: request.provider.as_str().to_owned(),
                    endpoint: request.metadata.endpoint,
                    transport: request.metadata.transport,
                    kind: image.kind(),
                    body: payload.body().clone(),
                    context: Value::Object(payload.context().clone()),
                });
            Ok(StartedExecution {
                request_id: ModelRequestId::new("req_images_test").expect("request ID"),
                created_at: SystemTime::now(),
                stream: false,
                session: Box::new(ImageSession {
                    response: Some(Bytes::from_static(IMAGE_RESPONSE)),
                    response_headers: vec![ProviderResponseHeader::new(
                        "x-image-rate-limit",
                        Bytes::from_static(b"42"),
                    )],
                    committed_statuses: Arc::clone(&self.committed_statuses),
                    error_statuses: Arc::clone(&self.error_statuses),
                    finalized: Arc::new(AtomicBool::new(false)),
                    fail_with_upstream_response: self.fail_with_upstream_response,
                }),
            })
        })
    }
}

struct ImageSession {
    response: Option<Bytes>,
    response_headers: Vec<ProviderResponseHeader>,
    committed_statuses: Arc<Mutex<Vec<u16>>>,
    error_statuses: Arc<Mutex<Vec<u16>>>,
    finalized: Arc<AtomicBool>,
    fail_with_upstream_response: bool,
}

impl ExecutionSession for ImageSession {
    fn next_event(&mut self) -> BoxFuture<'_, Result<Option<CoordinatedEvent>, EngineError>> {
        Box::pin(async { unreachable!("buffered image delivery does not stream") })
    }

    fn collect_uncommitted(&mut self) -> BoxFuture<'_, Result<Vec<ProviderEvent>, EngineError>> {
        Box::pin(async move {
            if self.fail_with_upstream_response {
                return Err(EngineError::Provider(
                    ProviderError::new(
                        ProviderErrorKind::InvalidRequest,
                        UpstreamSendState::Sent,
                    )
                    .with_status(StatusCode::UNPROCESSABLE_ENTITY.as_u16())
                    .with_client_visible_upstream_response(
                        ClientVisibleUpstreamResponse::new(
                            StatusCode::UNPROCESSABLE_ENTITY.as_u16(),
                            Some(b"application/problem+json".to_vec()),
                            Bytes::from_static(
                                br#"{ "error":{"message":"future image validation"}, "future":9007199254740993 }"#,
                            ),
                        )
                        .with_headers(vec![ProviderResponseHeader::new(
                            "x-future-image-error",
                            Bytes::from_static(b"preserved"),
                        )]),
                    ),
                ));
            }
            Ok(vec![ProviderEvent::wire(
                ProtocolWireEvent::raw_json(
                    "openai",
                    self.response.take().expect("single image response"),
                )
                .expect("OpenAI protocol"),
            )])
        })
    }

    fn response_headers(&self) -> &[ProviderResponseHeader] {
        &self.response_headers
    }

    fn response_status_code(&self) -> Option<u16> {
        Some(StatusCode::CREATED.as_u16())
    }

    fn commit_downstream(
        &mut self,
        client_status_code: Option<u16>,
    ) -> BoxFuture<'_, Result<(), EngineError>> {
        Box::pin(async move {
            self.committed_statuses
                .lock()
                .expect("committed status lock")
                .push(client_status_code.expect("image response status"));
            self.finalized.store(true, Ordering::Release);
            Ok(())
        })
    }

    fn record_client_status(&mut self, status: u16) -> BoxFuture<'_, Result<(), EngineError>> {
        Box::pin(async move {
            self.error_statuses
                .lock()
                .expect("error status lock")
                .push(status);
            Ok(())
        })
    }

    fn is_finalized(&self) -> bool {
        self.finalized.load(Ordering::Acquire)
    }

    fn cancel(&self) {
        self.finalized.store(true, Ordering::Release);
    }

    fn detach_finalize(self: Box<Self>) -> BoxFuture<'static, ()> {
        Box::pin(async move {
            self.finalized.store(true, Ordering::Release);
        })
    }
}

#[tokio::test]
async fn image_json_routes_should_preserve_both_directions_without_decoding() {
    let mut execution = ImageExecution::new();
    let middleware = Arc::new(crate::openai::middleware::RequestMiddleware {
        expected_operation: Some(OperationKind::GenerateImage),
        committed_statuses: Some(execution.committed_statuses.clone()),
        ..Default::default()
    });
    Arc::get_mut(&mut execution).unwrap().middleware = Some(middleware.clone());
    let router = api_router(execution.clone()).await;
    let cases = [
        (
            "/v1/images/generations",
            ImageRequestKind::Generation,
            "application/json",
            br#"{ "model":"gpt-image-future", "prompt":"a lighthouse", "future":9007199254740993 }"#.as_slice(),
        ),
        (
            "/v1/images/edits",
            ImageRequestKind::Edit,
            "application/json",
            br#"{"model":"gpt-image-2","images":[{"image_url":"data:image/png;base64,AAEC"}],"prompt":"add fog","prompt":"duplicate stays raw"}"#.as_slice(),
        ),
    ];

    for (path, _, content_type, body) in &cases {
        let response = router
            .clone()
            .oneshot(
                Request::post(*path)
                    .header(AUTHORIZATION, "Bearer sk_images_test")
                    .header("x-request-id", "caller-image-request")
                    .header("content-type", *content_type)
                    .header("x-codex-image-turn-id", "turn_image_route")
                    .header("session-id", "root-image-session")
                    .header("thread-id", "child-image-thread")
                    .header("x-future-business", "first")
                    .header("x-future-business", "second")
                    .header("cookie", "client-secret")
                    .header("connection", "x-private-hop")
                    .header("x-private-hop", "client-hop")
                    .body(Body::from(body.to_vec()))
                    .expect("image request"),
            )
            .await
            .expect("image response");
        assert_eq!(response.status(), StatusCode::CREATED);
        assert_eq!(response.headers()["x-request-middleware"], "applied");
        assert_eq!(response.headers()["x-request-id"], "req_images_test");
        assert_eq!(
            response.headers()["x-gateway-request-id"],
            "req_images_test"
        );
        assert_eq!(
            response.headers().get("x-image-rate-limit"),
            Some(&"42".parse().expect("header value"))
        );
        let response_body = to_bytes(response.into_body(), usize::MAX)
            .await
            .expect("read image response");
        assert_eq!(response_body.as_ref(), IMAGE_RESPONSE);
    }

    let captured = execution.captured();
    assert_eq!(captured.len(), cases.len());
    assert_eq!(
        *middleware.endpoints.lock().unwrap(),
        vec!["/v1/images/generations", "/v1/images/edits"]
    );
    for (captured, (endpoint, kind, _, body)) in captured.iter().zip(cases.iter()) {
        assert_eq!(captured.provider, "openai");
        assert_eq!(captured.endpoint, *endpoint);
        assert_eq!(captured.transport, ClientTransport::HttpJson);
        assert_eq!(captured.kind, *kind);
        assert_eq!(captured.body.as_ref(), *body);
        let mut context = captured.context.clone();
        let headers = context
            .as_object_mut()
            .unwrap()
            .remove("opaque_request_headers")
            .unwrap();
        let headers: Vec<_> = headers
            .as_array()
            .unwrap()
            .iter()
            .map(|entry| {
                (
                    entry[0].as_str().unwrap(),
                    STANDARD.decode(entry[1].as_str().unwrap()).unwrap(),
                )
            })
            .collect();
        assert_eq!(
            headers
                .iter()
                .filter(|(name, _)| *name == "x-future-business")
                .map(|(_, value)| value.as_slice())
                .collect::<Vec<_>>(),
            [b"first".as_slice(), b"second".as_slice()]
        );
        assert!(!headers.iter().any(|(name, _)| matches!(
            *name,
            "authorization" | "cookie" | "connection" | "x-private-hop"
        )));
        assert_eq!(
            context,
            json!({"image_turn_id": "turn_image_route", "session_id": "root-image-session", "thread_id": "child-image-thread"})
        );
    }
    assert_eq!(
        execution.committed_statuses(),
        vec![StatusCode::CREATED.as_u16(); cases.len()]
    );
}

#[tokio::test]
async fn image_route_should_return_the_exact_upstream_error_response() {
    let execution = ImageExecution::failing();
    let response = api_router(execution.clone())
        .await
        .oneshot(
            Request::post("/v1/images/edits")
                .header(AUTHORIZATION, "Bearer sk_images_test")
                .header("content-type", "application/json")
                .body(Body::from(
                    br#"{ "model":"gpt-image-2", "future_invalid":9007199254740993 }"#.to_vec(),
                ))
                .expect("image request"),
        )
        .await
        .expect("image response");

    assert_eq!(response.status(), StatusCode::UNPROCESSABLE_ENTITY);
    assert_eq!(response.headers()["x-request-id"], "req_images_test");
    assert_eq!(
        response.headers()["x-gateway-request-id"],
        "req_images_test"
    );
    assert_eq!(
        response.headers().get("content-type"),
        Some(&"application/problem+json".parse().expect("content type"))
    );
    assert_eq!(
        response.headers().get("x-future-image-error"),
        Some(&"preserved".parse().expect("header value"))
    );
    let body = to_bytes(response.into_body(), usize::MAX)
        .await
        .expect("read image response");
    assert_eq!(
        body.as_ref(),
        br#"{ "error":{"message":"future image validation"}, "future":9007199254740993 }"#
    );
    assert!(execution.committed_statuses().is_empty());
    assert_eq!(
        *execution.error_statuses.lock().expect("error status lock"),
        vec![422]
    );
}
