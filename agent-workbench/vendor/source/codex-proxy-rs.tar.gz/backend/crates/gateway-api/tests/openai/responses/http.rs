//! Responses HTTP 流式交付、错误、取消与计量边界测试

use std::collections::VecDeque;
use std::io::Read;
use std::net::{IpAddr, SocketAddr};
use std::sync::{
    Arc, Mutex,
    atomic::{AtomicBool, AtomicUsize, Ordering},
};
use std::time::Duration;

use axum::{
    body::{Body, to_bytes},
    extract::connect_info::ConnectInfo,
    http::{
        HeaderMap, HeaderValue, Request, StatusCode,
        header::{AUTHORIZATION, CONTENT_ENCODING, CONTENT_LENGTH, CONTENT_TYPE},
    },
};
use base64::{Engine as _, engine::general_purpose::STANDARD};
use bytes::Bytes;
use futures::StreamExt;
use futures::future::{BoxFuture, pending};
use gateway_core::engine::execution::{
    AuthenticatedClient, ClientAuthenticationError, ExecutionService, ExecutionSession,
    ResponseCommit, StartExecution, StartProviderExecution, StartedExecution,
};
use gateway_core::engine::middleware::{FrozenMiddlewarePlan, MiddlewareHeader};
use gateway_core::engine::{CommitRequirement, CoordinatedEvent, EngineError, ModelRequestId};
use gateway_core::error::{
    ClientVisibleUpstreamError, ClientVisibleUpstreamResponse, GatewayError, GatewayErrorKind,
    ProviderError, ProviderErrorKind,
};
use gateway_core::event::{
    ContentItem, ContentKind, GatewayEvent, ProtocolWireEvent, ProviderEvent,
    ProviderResponseHeader, ResponseMeta, TextDelta,
};
use gateway_core::operation::{Operation, OperationKind};
use gateway_core::routing::PublicModelId;
use gateway_core::upstream::{OpaqueUpstreamValue, UpstreamSendState};
use gateway_protocol::openai::sse::{encode_sse_event, parse_sse_events};
use serde_json::{Value, json};

use gateway_api::openai::responses::{collect_execution_response, stream_execution_response};
use tower::ServiceExt;

use crate::openai::middleware::{RequestMiddleware, ResponseFrameAction};
use crate::openai::{
    api_router, authenticated_client_for_provider, authenticated_client_with_min_versions,
};

fn responses_middleware() -> RequestMiddleware {
    RequestMiddleware {
        expected_operation: Some(OperationKind::Generate),
        ..RequestMiddleware::default()
    }
}

#[derive(Default)]
struct Trace {
    response_commit: ResponseCommit,
    events: Mutex<Vec<&'static str>>,
    client_statuses: Mutex<Vec<u16>>,
    cancelled: AtomicBool,
    detached_finalizations: AtomicUsize,
}

impl Trace {
    fn push(&self, event: &'static str) {
        self.events.lock().expect("trace lock").push(event);
    }

    fn snapshot(&self) -> Vec<&'static str> {
        self.events.lock().expect("trace lock").clone()
    }

    fn record_client_status(&self, status: u16) {
        self.client_statuses
            .lock()
            .expect("client status lock")
            .push(self.response_commit.status_code().unwrap_or(status));
    }

    fn client_statuses(&self) -> Vec<u16> {
        self.client_statuses
            .lock()
            .expect("client status lock")
            .clone()
    }

    fn cancel(&self) {
        self.cancelled.store(true, Ordering::Release);
    }

    fn is_cancelled(&self) -> bool {
        self.cancelled.load(Ordering::Acquire)
    }

    fn detached_finalizations(&self) -> usize {
        self.detached_finalizations.load(Ordering::Acquire)
    }
}

enum NextStep {
    Event(CoordinatedEvent),
    DelayedEvent(Duration, CoordinatedEvent),
    Error(EngineError),
    DelayedError(Duration, EngineError),
    FinalizeCancelled,
    FinalizeSuccess,
    End,
}

struct FakeSession {
    trace: Arc<Trace>,
    next: VecDeque<NextStep>,
    collected: Option<Vec<ProviderEvent>>,
    collect_error: Option<EngineError>,
    collect_pending: bool,
    finalize_on_commit: bool,
    fail_commit: bool,
    finalized: bool,
    response_headers: Vec<ProviderResponseHeader>,
}

#[derive(Clone)]
struct ContextCaptureExecution {
    observed: Arc<Mutex<Option<CapturedClientContext>>>,
    client: AuthenticatedClient,
}

#[derive(Debug, Clone, PartialEq)]
struct CapturedClientContext {
    public_model: String,
    wire_model: Option<String>,
    client_ip: Option<IpAddr>,
    user_agent: Option<String>,
    endpoint: String,
    operation_kind: OperationKind,
    input: Option<Value>,
    client_metadata: Option<Value>,
    protocol_context: Option<Value>,
    prompt_cache_key: Option<String>,
    previous_response_id: Option<String>,
}

impl ExecutionService for ContextCaptureExecution {
    fn authenticate(
        &self,
        plaintext: &str,
    ) -> Result<AuthenticatedClient, ClientAuthenticationError> {
        if plaintext == "sk_context_test" {
            Ok(self.client.clone())
        } else {
            Err(ClientAuthenticationError::InvalidKey)
        }
    }

    fn public_models(&self, _: &AuthenticatedClient) -> Vec<PublicModelId> {
        ["model-a", "model-b"]
            .into_iter()
            .map(|model| PublicModelId::new(model).expect("catalog model"))
            .collect()
    }

    fn contains_public_model(&self, _: &AuthenticatedClient, model: &PublicModelId) -> bool {
        matches!(model.as_str(), "model-a" | "model-b")
    }

    fn start(
        &self,
        request: StartExecution,
    ) -> BoxFuture<'_, Result<StartedExecution, GatewayError>> {
        Box::pin(async move {
            let public_model = request.public_model.as_str().to_owned();
            let operation_kind = request.operation.kind();
            let generation = match &request.operation {
                Operation::Generate(generation) => Some(generation),
                _ => None,
            };
            let wire_model = generation
                .and_then(|generation| generation.protocol_payload().body().get("model"))
                .and_then(Value::as_str)
                .map(ToOwned::to_owned);
            let (client_metadata, protocol_context, prompt_cache_key, input) =
                generation.map_or((None, None, None, None), |generation| {
                    let payload = generation.protocol_payload();
                    (
                        payload.body().get("client_metadata").cloned(),
                        (!payload.context().is_empty())
                            .then(|| Value::Object(payload.context().clone())),
                        generation.prompt_cache_key().map(ToOwned::to_owned),
                        payload.body().get("input").cloned(),
                    )
                });
            let previous_response_id = request
                .metadata
                .previous_response_id
                .as_ref()
                .map(|value| value.as_str().to_owned());
            *self.observed.lock().expect("context capture lock") = Some(CapturedClientContext {
                public_model,
                wire_model,
                client_ip: request.metadata.client_ip,
                user_agent: request.metadata.user_agent,
                endpoint: request.metadata.endpoint,
                operation_kind,
                input,
                client_metadata,
                protocol_context,
                prompt_cache_key,
                previous_response_id,
            });
            Err(GatewayError::new(
                GatewayErrorKind::Internal,
                "context capture completed",
            ))
        })
    }

    fn start_provider_endpoint(
        &self,
        _: StartProviderExecution,
    ) -> BoxFuture<'_, Result<StartedExecution, GatewayError>> {
        Box::pin(async {
            Err(GatewayError::new(
                GatewayErrorKind::Internal,
                "responses context test must not start a provider endpoint",
            ))
        })
    }
}

impl FakeSession {
    fn streaming(trace: Arc<Trace>, next: Vec<NextStep>) -> Self {
        Self {
            trace,
            next: VecDeque::from(next),
            collected: None,
            collect_error: None,
            collect_pending: false,
            finalize_on_commit: false,
            fail_commit: false,
            finalized: false,
            response_headers: Vec::new(),
        }
    }

    fn buffered(trace: Arc<Trace>, events: Vec<GatewayEvent>) -> Self {
        Self::buffered_provider(
            trace,
            events.into_iter().map(provider_event_for_fact).collect(),
        )
    }

    fn buffered_provider(trace: Arc<Trace>, events: Vec<ProviderEvent>) -> Self {
        Self {
            trace,
            next: VecDeque::from([NextStep::FinalizeCancelled]),
            collected: Some(events),
            collect_error: None,
            collect_pending: false,
            finalize_on_commit: true,
            fail_commit: false,
            finalized: false,
            response_headers: Vec::new(),
        }
    }

    fn pending_buffered(trace: Arc<Trace>) -> Self {
        Self {
            trace,
            next: VecDeque::from([NextStep::FinalizeCancelled]),
            collected: None,
            collect_error: None,
            collect_pending: true,
            finalize_on_commit: true,
            fail_commit: false,
            finalized: false,
            response_headers: Vec::new(),
        }
    }

    fn with_commit_failure(mut self) -> Self {
        self.fail_commit = true;
        self.finalize_on_commit = false;
        self
    }

    fn with_collect_error(mut self, error: EngineError) -> Self {
        self.collect_error = Some(error);
        self
    }

    fn with_response_headers(mut self, response_headers: Vec<ProviderResponseHeader>) -> Self {
        self.response_headers = response_headers;
        self
    }
}

impl ExecutionSession for FakeSession {
    fn response_commit(&self) -> ResponseCommit {
        self.trace.response_commit.clone()
    }

    fn next_event(&mut self) -> BoxFuture<'_, Result<Option<CoordinatedEvent>, EngineError>> {
        Box::pin(async move {
            match self.next.pop_front().unwrap_or(NextStep::End) {
                NextStep::Event(event) => {
                    self.trace.push("next_event");
                    Ok(Some(event))
                }
                NextStep::DelayedEvent(delay, event) => {
                    self.trace.push("wait_event");
                    tokio::time::sleep(delay).await;
                    self.trace.push("next_event");
                    Ok(Some(event))
                }
                NextStep::DelayedError(delay, error) => {
                    self.trace.push("wait_error");
                    tokio::time::sleep(delay).await;
                    self.trace.push("next_error");
                    self.finalized = true;
                    Err(error)
                }
                NextStep::Error(error) => {
                    self.trace.push("next_error");
                    self.finalized = true;
                    Err(error)
                }
                NextStep::FinalizeCancelled => {
                    self.trace.push("cancel_finalize");
                    self.finalized = true;
                    Err(EngineError::Cancelled)
                }
                NextStep::FinalizeSuccess => {
                    self.trace.push("next_end");
                    self.finalized = true;
                    Ok(None)
                }
                NextStep::End => {
                    self.trace.push("next_end");
                    Ok(None)
                }
            }
        })
    }

    fn collect_uncommitted(&mut self) -> BoxFuture<'_, Result<Vec<ProviderEvent>, EngineError>> {
        Box::pin(async move {
            self.trace.push("collect");
            if self.collect_pending {
                pending::<()>().await;
            }
            if let Some(error) = self.collect_error.take() {
                self.finalized = true;
                return Err(error);
            }
            Ok(self.collected.take().unwrap_or_default())
        })
    }

    fn response_headers(&self) -> &[ProviderResponseHeader] {
        &self.response_headers
    }

    fn discard_pending_delivery(&mut self) -> Result<(), EngineError> {
        self.trace.push("discard");
        Ok(())
    }

    fn commit_downstream(
        &mut self,
        client_status_code: Option<u16>,
    ) -> BoxFuture<'_, Result<(), EngineError>> {
        Box::pin(async move {
            self.trace.push("commit");
            if self.fail_commit {
                return Err(EngineError::ProviderMetadataMismatch);
            }
            if let Some(status) = client_status_code {
                self.trace.record_client_status(status);
            }
            self.finalized = self.finalize_on_commit;
            Ok(())
        })
    }

    fn record_client_status(
        &mut self,
        client_status_code: u16,
    ) -> BoxFuture<'_, Result<(), EngineError>> {
        Box::pin(async move {
            self.trace.record_client_status(client_status_code);
            Ok(())
        })
    }

    fn is_finalized(&self) -> bool {
        self.finalized
    }

    fn cancel(&self) {
        self.trace.cancel();
    }

    fn detach_finalize(mut self: Box<Self>) -> BoxFuture<'static, ()> {
        Box::pin(async move {
            self.trace
                .detached_finalizations
                .fetch_add(1, Ordering::AcqRel);
            if !self.finalized {
                let _ = self.next_event().await;
            }
        })
    }
}

fn started() -> GatewayEvent {
    GatewayEvent::Started(ResponseMeta::new("resp_test", "public-model"))
}

fn completed() -> GatewayEvent {
    GatewayEvent::Completed(ResponseMeta::new("resp_test", "public-model"))
}

fn delivery(event: GatewayEvent, commit_requirement: CommitRequirement) -> CoordinatedEvent {
    delivery_provider(provider_event_for_fact(event), commit_requirement)
}

fn delivery_provider(
    event: ProviderEvent,
    commit_requirement: CommitRequirement,
) -> CoordinatedEvent {
    CoordinatedEvent::single(event, commit_requirement)
}

fn provider_event_for_fact(event: GatewayEvent) -> ProviderEvent {
    let (GatewayEvent::Started(meta) | GatewayEvent::Completed(meta)) = &event else {
        return ProviderEvent::canonical(event);
    };
    let event_type = if matches!(&event, GatewayEvent::Started(_)) {
        "response.created"
    } else {
        "response.completed"
    };
    let response = json!({
        "id": meta.response_id(),
        "model": meta.model(),
        "status": if event_type == "response.created" { "in_progress" } else { "completed" },
        "output": []
    });
    ProviderEvent::canonical_with_wire(
        vec![event],
        ProtocolWireEvent::json(
            "openai",
            Some(event_type.to_owned()),
            json!({"type": event_type, "response": response}),
        )
        .expect("fixture OpenAI wire event"),
    )
}

fn mismatched_terminal_event() -> ProviderEvent {
    let meta = ResponseMeta::new("resp_other", "public-model");
    ProviderEvent::canonical_with_wire(
        vec![GatewayEvent::Completed(meta)],
        ProtocolWireEvent::json(
            "openai",
            Some("response.completed".to_owned()),
            json!({
                "type": "response.completed",
                "response": {"id": "resp_other", "status": "completed", "output": []}
            }),
        )
        .expect("fixture mismatched terminal"),
    )
}

async fn captured_client_context(
    headers: HeaderMap,
    peer_address: SocketAddr,
) -> CapturedClientContext {
    captured_http_request(
        "openai",
        json!({"model": "smart-code", "input": "hello"}),
        headers,
        Some(peer_address),
    )
    .await
}

async fn captured_http_request(
    provider_name: &str,
    body: Value,
    headers: HeaderMap,
    peer_address: Option<SocketAddr>,
) -> CapturedClientContext {
    let (response, observed) = http_request_with_body(
        provider_name,
        body.to_string().into(),
        headers,
        peer_address,
    )
    .await;
    assert_eq!(response.status(), StatusCode::INTERNAL_SERVER_ERROR);
    observed.expect("captured request context")
}

async fn http_request_with_body(
    provider_name: &str,
    body: Bytes,
    mut headers: HeaderMap,
    peer_address: Option<SocketAddr>,
) -> (axum::response::Response, Option<CapturedClientContext>) {
    headers.insert(
        AUTHORIZATION,
        "Bearer sk_context_test".parse().expect("authorization"),
    );
    let observed = Arc::new(Mutex::new(None));
    let execution = Arc::new(ContextCaptureExecution {
        observed: Arc::clone(&observed),
        client: authenticated_client_for_provider("sk_context_test", provider_name),
    });
    let mut request = Request::post("/v1/responses")
        .body(Body::from(body))
        .expect("context request");
    *request.headers_mut() = headers;
    if let Some(peer_address) = peer_address {
        request.extensions_mut().insert(ConnectInfo(peer_address));
    }
    let response = api_router(execution)
        .await
        .oneshot(request)
        .await
        .expect("context response");
    let observed = observed.lock().expect("context capture lock").clone();
    (response, observed)
}

#[tokio::test]
async fn http_requests_should_honor_stream_preference() {
    let admin = crate::admin::AdminTestFixture::new().await.services;
    for stream in [None, Some(false), Some(true)] {
        let trace = Arc::new(Trace::default());
        let streaming = stream == Some(true);
        let session = if streaming {
            FakeSession::streaming(
                Arc::clone(&trace),
                vec![
                    NextStep::Event(delivery(started(), CommitRequirement::CommitBeforeDelivery)),
                    NextStep::Event(delivery(completed(), CommitRequirement::AlreadyCommitted)),
                    NextStep::FinalizeSuccess,
                ],
            )
        } else {
            FakeSession::buffered(Arc::clone(&trace), vec![started(), completed()])
        };
        let execution = Arc::new(SessionExecution {
            client: authenticated_client_for_provider("sk_stream_test", "openai"),
            session: Mutex::new(Some(Box::new(session))),
            middleware: None,
        });
        let mut body = json!({"model": "model-a", "input": "hello"});
        if let Some(stream) = stream {
            body["stream"] = json!(stream);
        }
        let response = crate::openai::api_router_with_admin_and_execution(admin.clone(), execution)
            .oneshot(
                Request::post("/v1/responses")
                    .header(AUTHORIZATION, "Bearer sk_stream_test")
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(body.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap();

        assert_eq!(response.status(), StatusCode::OK, "stream={stream:?}");
        assert_eq!(
            response.headers()[CONTENT_TYPE],
            if streaming {
                "text/event-stream"
            } else {
                "application/json"
            },
            "stream={stream:?}",
        );
        let body = to_bytes(response.into_body(), usize::MAX).await.unwrap();
        if streaming {
            let body = String::from_utf8(body.to_vec()).unwrap();
            assert!(body.contains("event: response.completed\n"));
            assert!(body.ends_with("data: [DONE]\n\n"));
        } else {
            assert_eq!(
                serde_json::from_slice::<Value>(&body).unwrap(),
                json!({
                    "id": "resp_test", "model": "public-model", "status": "completed", "output": []
                }),
            );
            assert_eq!(trace.snapshot(), vec!["collect", "commit"]);
        }
        assert!(!trace.is_cancelled());
    }
}

#[tokio::test]
async fn compressed_http_requests_should_preserve_execution_context_without_transport_headers() {
    let body = json!({
        "model": "model-a", "input": "hello", "previous_response_id": "resp_previous",
        "prompt_cache_key": "cache-key", "client_metadata": {"source": "test"}
    });
    let mut headers = HeaderMap::new();
    headers.insert(CONTENT_TYPE, HeaderValue::from_static("application/json"));
    headers.insert("session_id", HeaderValue::from_static("session-test"));
    let expected = captured_http_request("openai", body.clone(), headers.clone(), None).await;
    for encoding in ["gzip", "deflate", "zstd"] {
        let compressed = super::request::encode_body(encoding, body.to_string().as_bytes());
        let mut headers = headers.clone();
        headers.insert(CONTENT_ENCODING, HeaderValue::from_static(encoding));
        headers.insert(
            CONTENT_LENGTH,
            HeaderValue::from_str(&compressed.len().to_string()).expect("compressed length"),
        );
        let (response, observed) =
            http_request_with_body("openai", compressed.into(), headers, None).await;
        // 捕获执行器在解码成功后主动返回 500；正文和业务头应与未压缩请求一致，
        // 压缩编码及长度不能泄漏到已解压正文的上游协议上下文
        assert_eq!(response.status(), StatusCode::INTERNAL_SERVER_ERROR);
        assert_eq!(observed.as_ref(), Some(&expected), "{encoding}");
    }
}

#[tokio::test]
async fn invalid_compressed_http_requests_should_fail_before_execution() {
    for (encoding, body, code, message) in [
        (
            "gzip",
            Bytes::from_static(b"broken gzip"),
            "invalid_json",
            "Request body must be valid JSON.",
        ),
        (
            "br",
            Bytes::from_static(b"{}"),
            "unsupported_content_encoding",
            "Content-Encoding `br` is not supported.",
        ),
        (
            "zstd",
            super::request::encode_body("zstd", std::io::repeat(0).take(64 * 1024 * 1024 + 1))
                .into(),
            "request_too_large",
            "Decompressed request body exceeds the allowed size (67108864 bytes).",
        ),
    ] {
        let headers = HeaderMap::from_iter([
            (CONTENT_ENCODING, HeaderValue::from_static(encoding)),
            (CONTENT_TYPE, HeaderValue::from_static("application/json")),
        ]);
        let (response, observed) = http_request_with_body("openai", body, headers, None).await;
        assert_eq!(response.status(), StatusCode::BAD_REQUEST, "{encoding}");
        assert!(observed.is_none(), "invalid body must not start execution");
        let body = to_bytes(response.into_body(), 4096)
            .await
            .expect("error body");
        assert_eq!(
            serde_json::from_slice::<Value>(&body).expect("error JSON"),
            json!({"error": {"type": "invalid_request_error", "code": code, "message": message}})
        );
    }
}

async fn captured_http_compaction(provider_name: &str) -> CapturedClientContext {
    captured_http_request(
        provider_name,
        json!({
            "model": "smart-code",
            "input": [
                {"type": "message", "role": "user", "content": "history"},
                {"type": "compaction_trigger"}
            ],
            "stream": true
        }),
        HeaderMap::new(),
        None,
    )
    .await
}

#[tokio::test]
async fn openai_http_should_preserve_compaction_trigger_as_generate() {
    let captured = captured_http_compaction("openai").await;

    assert_eq!(
        (captured.operation_kind, captured.input),
        (
            OperationKind::Generate,
            Some(json!([
                {"type": "message", "role": "user", "content": "history"},
                {"type": "compaction_trigger"}
            ])),
        )
    );
}

#[tokio::test]
async fn xai_http_should_leave_compaction_trigger_for_the_xai_provider_adapter() {
    let captured = captured_http_compaction("xai").await;

    assert_eq!(
        (captured.operation_kind, captured.input),
        (
            OperationKind::Generate,
            Some(json!([
                {"type": "message", "role": "user", "content": "history"},
                {"type": "compaction_trigger"}
            ])),
        )
    );
}

#[tokio::test]
async fn request_context_should_resolve_forwarded_precedence_and_peer_fallback() {
    let peer = "192.0.2.10:443".parse().expect("peer address");

    let mut headers = HeaderMap::new();
    headers.insert("cf-connecting-ip", "198.51.100.1".parse().expect("CF IP"));
    headers.insert("x-real-ip", "198.51.100.2".parse().expect("real IP"));
    headers.insert(
        "x-forwarded-for",
        "10.0.0.2, 203.0.113.3".parse().expect("forwarded IPs"),
    );
    headers.insert("user-agent", " Codex-CLI/1.0 ".parse().expect("user agent"));
    assert_eq!(
        captured_client_context(headers, peer).await,
        CapturedClientContext {
            public_model: "smart-code".to_owned(),
            wire_model: Some("smart-code".to_owned()),
            client_ip: Some("198.51.100.1".parse().expect("expected IP")),
            user_agent: Some("Codex-CLI/1.0".to_owned()),
            endpoint: "/v1/responses".to_owned(),
            operation_kind: OperationKind::Generate,
            input: Some(json!("hello")),
            client_metadata: None,
            // 客户端 User-Agent 仅用于本地展示，不再透传给上游指纹上下文
            protocol_context: Some(json!({"opaque_request_headers": [
                ["cf-connecting-ip", STANDARD.encode(b"198.51.100.1")],
                ["x-real-ip", STANDARD.encode(b"198.51.100.2")],
                ["x-forwarded-for", STANDARD.encode(b"10.0.0.2, 203.0.113.3")]
            ]})),
            prompt_cache_key: None,
            previous_response_id: None,
        }
    );

    let mut headers = HeaderMap::new();
    headers.insert(
        "x-forwarded-for",
        "10.0.0.2, 203.0.113.3".parse().expect("forwarded IPs"),
    );
    assert_eq!(
        captured_client_context(headers, peer).await.client_ip,
        Some("203.0.113.3".parse().expect("expected IP"))
    );

    assert_eq!(
        captured_client_context(HeaderMap::new(), peer)
            .await
            .client_ip,
        Some("192.0.2.10".parse().expect("expected peer IP"))
    );
}

#[tokio::test]
async fn opaque_client_headers_should_not_change_local_client_observation() {
    let mut headers = HeaderMap::new();
    headers.insert("user-agent", "pi/synthetic".parse().unwrap());
    headers.insert("x-stainless-runtime", "node".parse().unwrap());
    headers.insert("origin", "https://synthetic.invalid".parse().unwrap());
    let captured = captured_client_context(headers, "192.0.2.10:443".parse().unwrap()).await;
    assert_eq!(captured.user_agent.as_deref(), Some("pi/synthetic"));
    assert_eq!(captured.client_ip, Some("192.0.2.10".parse().unwrap()));
    assert_eq!(
        captured.protocol_context,
        Some(json!({
            "opaque_request_headers": [
                ["x-stainless-runtime", STANDARD.encode(b"node")],
                ["origin", STANDARD.encode(b"https://synthetic.invalid")]
            ]
        }))
    );
}

#[tokio::test]
async fn stale_model_catalog_should_not_block_a_new_model_request() {
    let model = "  gpt-future-codex  ";
    let captured = captured_http_request(
        "openai",
        json!({"model": model, "input": "hello"}),
        HeaderMap::new(),
        None,
    )
    .await;

    assert_eq!(captured.public_model, model);
    assert_eq!(captured.wire_model.as_deref(), Some(model));
}

#[tokio::test]
async fn http_request_should_pass_opaque_previous_response_id_to_core() {
    for response_id in [
        format!("resp_{}", "x".repeat(257)),
        "resp_control\0opaque".to_owned(),
        String::new(),
    ] {
        let captured = captured_http_request(
            "openai",
            json!({
                "model": "smart-code",
                "input": "continue",
                "previous_response_id": response_id.clone()
            }),
            HeaderMap::new(),
            None,
        )
        .await;

        assert_eq!(
            captured.previous_response_id.as_deref(),
            Some(response_id.as_str())
        );
    }
}

#[tokio::test]
async fn http_request_should_forward_codex_headers_without_projecting_xai_headers() {
    let peer = "192.0.2.10:443".parse().expect("peer address");
    let mut headers = HeaderMap::new();
    headers.insert("x-codex-turn-state", "turn-state".parse().expect("header"));
    headers.insert("conversation-id", "conversation-1".parse().expect("header"));
    headers.insert("session-id", "session-1".parse().expect("header"));
    headers.insert("x-grok-turn-idx", "7".parse().expect("header"));
    headers.insert(
        "x-openai-subagent",
        "future_codex_mode".parse().expect("header"),
    );
    headers.insert(
        "x-openai-internal-codex-responses-lite",
        "true".parse().expect("header"),
    );

    let captured = captured_client_context(headers, peer).await;
    let context = captured
        .protocol_context
        .as_ref()
        .and_then(Value::as_object)
        .expect("OpenAI protocol context");
    assert_eq!(context.get("turn_state"), Some(&json!("turn-state")));
    assert_eq!(
        context.get("conversation_id"),
        Some(&json!("conversation-1"))
    );
    assert_eq!(context.get("session_id"), Some(&json!("session-1")));
    assert_eq!(context.get("responses_lite"), Some(&json!("true")));
    assert!(captured.prompt_cache_key.is_none());
    assert!(!context.contains_key("authorization"));
    assert_eq!(
        captured
            .client_metadata
            .as_ref()
            .and_then(|metadata| metadata.get("x-openai-subagent")),
        Some(&json!("future_codex_mode"))
    );
}

#[tokio::test]
async fn subagent_header_should_not_replace_non_object_client_metadata() {
    let mut headers = HeaderMap::new();
    headers.insert(
        "x-openai-subagent",
        "future_codex_mode".parse().expect("header"),
    );

    let captured = captured_http_request(
        "openai",
        json!({
            "model": "smart-code",
            "input": "preserve metadata",
            "client_metadata": "opaque-client-value"
        }),
        headers,
        None,
    )
    .await;

    assert_eq!(captured.client_metadata, Some(json!("opaque-client-value")));
}

#[tokio::test]
async fn xai_private_headers_should_remain_opaque_without_projecting_request_facts() {
    let peer = "192.0.2.10:443".parse().expect("peer address");
    let mut headers = HeaderMap::new();
    headers.insert("x-grok-turn-idx", "7".parse().expect("header"));
    headers.insert("x-grok-conv-id", "private-session".parse().expect("header"));

    let captured = captured_client_context(headers, peer).await;

    assert_eq!(
        captured.protocol_context,
        Some(json!({
            "opaque_request_headers": [
                ["x-grok-turn-idx", STANDARD.encode(b"7")],
                ["x-grok-conv-id", STANDARD.encode(b"private-session")]
            ]
        }))
    );
    assert!(captured.prompt_cache_key.is_none());
}

#[tokio::test]
async fn streaming_encodes_first_frame_before_commit_and_http_delivery() {
    let trace = Arc::new(Trace::default());
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![NextStep::Event(delivery(
            started(),
            CommitRequirement::CommitBeforeDelivery,
        ))],
    );

    let response = stream_execution_response(Box::new(session), None).await;

    assert_eq!(response.status(), axum::http::StatusCode::OK);
    assert_eq!(trace.client_statuses(), vec![200]);
    assert_eq!(trace.snapshot(), vec!["next_event", "commit"]);
    assert!(!trace.is_cancelled());
    std::mem::forget(response);
}

#[tokio::test]
async fn streaming_dropped_unknown_initial_batch_discards_without_committing() {
    let admin = crate::admin::AdminTestFixture::new().await.services;
    let trace = Arc::new(Trace::default());
    let dropped_raw = Bytes::from_static(
        b"event: response.future_metadata\ndata: {\"type\":\"response.future_metadata\",\"dropped\":true}\n\n",
    );
    let dropped = ProviderEvent::wire(
        ProtocolWireEvent::raw_sse("openai", dropped_raw.clone()).expect("future SSE event"),
    );
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![
            NextStep::Event(delivery_provider(
                dropped,
                CommitRequirement::CommitBeforeDelivery,
            )),
            NextStep::Event(delivery(started(), CommitRequirement::CommitBeforeDelivery)),
            NextStep::Event(delivery(completed(), CommitRequirement::AlreadyCommitted)),
            NextStep::FinalizeSuccess,
        ],
    );
    let middleware = Arc::new(responses_middleware().with_response_actions(vec![
        ResponseFrameAction::Drop,
        ResponseFrameAction::Continue,
        ResponseFrameAction::Continue,
        ResponseFrameAction::Continue,
    ]));

    let response =
        response_with_middleware(&admin, "openai", session, true, Some(middleware)).await;
    let body = to_bytes(response.into_body(), usize::MAX)
        .await
        .expect("read filtered SSE response");

    assert!(!body.as_ref().starts_with(dropped_raw.as_ref()));
    assert!(!String::from_utf8_lossy(&body).contains("\"dropped\":true"));
    assert!(String::from_utf8_lossy(&body).contains("response.created"));
    assert!(String::from_utf8_lossy(&body).contains("response.completed"));
    assert!(body.as_ref().ends_with(b"data: [DONE]\n\n"));
    assert_eq!(trace.client_statuses(), vec![200]);
    assert_eq!(
        trace.snapshot(),
        vec![
            "next_event",
            "discard",
            "next_event",
            "commit",
            "next_event",
            "next_end"
        ]
    );
    assert_eq!(trace.detached_finalizations(), 0);
}

#[tokio::test]
async fn streaming_modified_sse_rejects_out_of_order_tool_events_without_replay() {
    let admin = crate::admin::AdminTestFixture::new().await.services;
    let trace = Arc::new(Trace::default());
    let added = super::openai_wire_event(
        vec![],
        "response.output_item.added",
        json!({
            "type": "response.output_item.added",
            "output_index": 0,
            "item": {
                "id": "item_tool", "type": "function_call",
                "call_id": "call_tool", "name": "lookup"
            }
        }),
    );
    let out_of_order = encode_sse_event(
        "response.function_call_arguments.done",
        &json!({
            "type": "response.function_call_arguments.done",
            "output_index": 0, "item_id": "item_tool",
            "call_id": "call_tool", "arguments": "{}"
        })
        .to_string(),
    );
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![
            NextStep::Event(delivery(started(), CommitRequirement::CommitBeforeDelivery)),
            NextStep::Event(delivery_provider(
                added,
                CommitRequirement::AlreadyCommitted,
            )),
            NextStep::FinalizeCancelled,
        ],
    );
    let middleware = Arc::new(responses_middleware().with_response_actions(vec![
        ResponseFrameAction::Continue,
        ResponseFrameAction::Replace(Bytes::from(out_of_order)),
    ]));

    let response =
        response_with_middleware(&admin, "openai", session, true, Some(middleware)).await;
    let body = to_bytes(response.into_body(), usize::MAX)
        .await
        .expect("read rejected transformed SSE");
    tokio::task::yield_now().await;
    let body = String::from_utf8(body.to_vec()).expect("gateway SSE is UTF-8");

    assert_eq!(body.matches("event: response.created").count(), 1);
    assert!(!body.contains("response.function_call_arguments.done"));
    assert!(body.contains("response.failed"));
    assert!(body.ends_with("data: [DONE]\n\n"));
    assert!(trace.is_cancelled());
    assert_eq!(
        trace.snapshot(),
        vec!["next_event", "commit", "next_event", "cancel_finalize"]
    );
}

#[tokio::test]
async fn streaming_modified_sse_rejects_wrong_tool_association_without_replay() {
    let admin = crate::admin::AdminTestFixture::new().await.services;
    let trace = Arc::new(Trace::default());
    let added = super::openai_wire_event(
        vec![],
        "response.output_item.added",
        json!({
            "type": "response.output_item.added",
            "output_index": 0,
            "item": {
                "id": "item_tool", "type": "function_call",
                "call_id": "call_tool", "name": "lookup"
            }
        }),
    );
    let arguments = super::openai_wire_event(
        vec![],
        "response.function_call_arguments.delta",
        json!({
            "type": "response.function_call_arguments.delta",
            "output_index": 0, "item_id": "item_tool",
            "call_id": "call_tool", "delta": "{}"
        }),
    );
    let wrong_association = encode_sse_event(
        "response.function_call_arguments.delta",
        &json!({
            "type": "response.function_call_arguments.delta",
            "output_index": 0, "item_id": "item_tool",
            "call_id": "call_other", "delta": "{}"
        })
        .to_string(),
    );
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![
            NextStep::Event(delivery(started(), CommitRequirement::CommitBeforeDelivery)),
            NextStep::Event(delivery_provider(
                added,
                CommitRequirement::AlreadyCommitted,
            )),
            NextStep::Event(delivery_provider(
                arguments,
                CommitRequirement::AlreadyCommitted,
            )),
            NextStep::FinalizeCancelled,
        ],
    );
    let middleware = Arc::new(responses_middleware().with_response_actions(vec![
        ResponseFrameAction::Continue,
        ResponseFrameAction::Continue,
        ResponseFrameAction::Replace(Bytes::from(wrong_association)),
    ]));

    let response =
        response_with_middleware(&admin, "openai", session, true, Some(middleware)).await;
    let body = to_bytes(response.into_body(), usize::MAX)
        .await
        .expect("read rejected transformed SSE");
    tokio::task::yield_now().await;
    let body = String::from_utf8(body.to_vec()).expect("gateway SSE is UTF-8");

    assert!(!body.contains("call_other"));
    assert!(body.contains("response.failed"));
    assert_eq!(body.matches("event: response.created").count(), 1);
    assert_eq!(
        trace.snapshot(),
        vec![
            "next_event",
            "commit",
            "next_event",
            "next_event",
            "cancel_finalize"
        ]
    );
}

#[tokio::test]
async fn streaming_modified_sse_cannot_change_terminal_classification() {
    let admin = crate::admin::AdminTestFixture::new().await.services;
    let trace = Arc::new(Trace::default());
    let incomplete = encode_sse_event(
        "response.incomplete",
        &json!({
            "type": "response.incomplete",
            "response": {
                "id": "resp_test", "model": "public-model",
                "status": "incomplete", "output": []
            }
        })
        .to_string(),
    );
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![
            NextStep::Event(delivery(started(), CommitRequirement::CommitBeforeDelivery)),
            NextStep::Event(delivery(completed(), CommitRequirement::AlreadyCommitted)),
            NextStep::FinalizeSuccess,
        ],
    );
    let middleware = Arc::new(responses_middleware().with_response_actions(vec![
        ResponseFrameAction::Continue,
        ResponseFrameAction::Replace(Bytes::from(incomplete)),
    ]));

    let response =
        response_with_middleware(&admin, "openai", session, true, Some(middleware)).await;
    let body = to_bytes(response.into_body(), usize::MAX)
        .await
        .expect("read terminal-class rejection");
    tokio::task::yield_now().await;
    let body = String::from_utf8(body.to_vec()).expect("gateway SSE is UTF-8");

    assert!(body.contains("response.failed"));
    assert!(!body.contains("response.incomplete"));
    assert_eq!(body.matches("event: response.created").count(), 1);
    assert_eq!(
        trace.snapshot(),
        vec!["next_event", "commit", "next_event", "next_end"]
    );
    assert!(!trace.is_cancelled());
}

#[tokio::test]
async fn streaming_terminal_drop_fails_before_commit() {
    let admin = crate::admin::AdminTestFixture::new().await.services;
    let trace = Arc::new(Trace::default());
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![
            NextStep::Event(delivery(
                completed(),
                CommitRequirement::CommitBeforeDelivery,
            )),
            NextStep::FinalizeCancelled,
        ],
    );
    let middleware =
        Arc::new(responses_middleware().with_response_actions(vec![ResponseFrameAction::Drop]));

    let response =
        response_with_middleware(&admin, "openai", session, true, Some(middleware)).await;

    assert_eq!(response.status(), StatusCode::BAD_GATEWAY);
    let body = to_bytes(response.into_body(), usize::MAX)
        .await
        .expect("read middleware error response");
    assert_eq!(
        serde_json::from_slice::<Value>(&body).expect("middleware error JSON")["error"]["code"],
        "middleware_failed"
    );
    assert_eq!(trace.client_statuses(), vec![502]);
    assert!(trace.is_cancelled());
    assert!(!trace.snapshot().contains(&"commit"));
}

#[tokio::test(start_paused = true)]
async fn streaming_should_keep_alive_during_silent_compaction_without_restarting_execution() {
    let trace = Arc::new(Trace::default());
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![
            NextStep::Event(delivery(started(), CommitRequirement::CommitBeforeDelivery)),
            NextStep::DelayedEvent(
                Duration::from_secs(240),
                delivery(completed(), CommitRequirement::AlreadyCommitted),
            ),
            NextStep::FinalizeSuccess,
        ],
    );
    let response = stream_execution_response(Box::new(session), None).await;
    let mut body = response.into_body().into_data_stream();
    let first = body.next().await.expect("first frame").expect("body bytes");
    assert!(String::from_utf8_lossy(&first).contains("response.created"));
    let start = tokio::time::Instant::now();

    for heartbeat in 1..16 {
        let chunk = tokio::time::timeout(Duration::from_secs(20), body.next())
            .await
            .expect("silent upstream must not leave the downstream idle")
            .expect("heartbeat frame")
            .expect("heartbeat bytes");
        assert_eq!(chunk, Bytes::from_static(b": keep-alive\n\n"));
        assert_eq!(start.elapsed(), Duration::from_secs(15 * heartbeat));
    }

    let terminal = body
        .next()
        .await
        .expect("terminal frame")
        .expect("body bytes");
    assert!(String::from_utf8_lossy(&terminal).contains("response.completed"));
    assert_eq!(start.elapsed(), Duration::from_secs(240));
    assert_eq!(
        body.next().await.expect("done frame").expect("body bytes"),
        Bytes::from_static(b"data: [DONE]\n\n")
    );
    assert!(body.next().await.is_none());
    assert_eq!(
        trace.snapshot(),
        vec![
            "next_event",
            "commit",
            "wait_event",
            "next_event",
            "next_end"
        ]
    );
    assert!(!trace.is_cancelled());
}

#[tokio::test(start_paused = true)]
async fn dropping_stream_during_keepalive_should_cancel_and_finalize_execution() {
    let trace = Arc::new(Trace::default());
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![
            NextStep::Event(delivery(started(), CommitRequirement::CommitBeforeDelivery)),
            NextStep::DelayedEvent(
                Duration::from_secs(240),
                delivery(completed(), CommitRequirement::AlreadyCommitted),
            ),
            NextStep::FinalizeCancelled,
        ],
    );
    let response = stream_execution_response(Box::new(session), None).await;
    let mut body = response.into_body().into_data_stream();
    let _ = body.next().await.expect("first frame").expect("body bytes");
    let heartbeat = tokio::time::timeout(Duration::from_secs(20), body.next())
        .await
        .expect("heartbeat before client disconnect")
        .expect("heartbeat frame")
        .expect("heartbeat bytes");
    assert_eq!(heartbeat, Bytes::from_static(b": keep-alive\n\n"));

    drop(body);
    tokio::task::yield_now().await;

    assert!(trace.is_cancelled());
    assert_eq!(
        trace.snapshot(),
        vec!["next_event", "commit", "wait_event", "cancel_finalize"]
    );
    assert_eq!(trace.detached_finalizations(), 1);
}

#[tokio::test(start_paused = true)]
async fn streaming_keepalive_should_cover_four_minutes_before_first_event() {
    let trace = Arc::new(Trace::default());
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![
            NextStep::DelayedEvent(
                Duration::from_secs(240),
                delivery(completed(), CommitRequirement::CommitBeforeDelivery),
            ),
            NextStep::FinalizeSuccess,
        ],
    );
    let start = tokio::time::Instant::now();
    let response = tokio::time::timeout(
        Duration::from_secs(20),
        stream_execution_response(Box::new(session), None),
    )
    .await
    .expect("headers and heartbeat must precede the first upstream event");
    assert_eq!(response.status(), StatusCode::OK);
    assert_eq!(response.headers()[CONTENT_TYPE], "text/event-stream");
    assert_eq!(trace.response_commit.status_code(), Some(200));
    let mut body = response.into_body().into_data_stream();
    for heartbeat in 1..16 {
        let chunk = tokio::time::timeout(Duration::from_secs(20), body.next())
            .await
            .expect("first-event wait must stay alive")
            .expect("heartbeat")
            .expect("bytes");
        assert_eq!(chunk, Bytes::from_static(b": keep-alive\n\n"));
        assert_eq!(start.elapsed(), Duration::from_secs(15 * heartbeat));
        assert_eq!(trace.snapshot(), vec!["wait_event"]);
    }
    let terminal = body.next().await.expect("terminal").expect("bytes");
    assert!(String::from_utf8_lossy(&terminal).contains("response.completed"));
    assert_eq!(start.elapsed(), Duration::from_secs(240));
    assert_eq!(
        body.next().await.unwrap().unwrap(),
        Bytes::from_static(b"data: [DONE]\n\n")
    );
    assert!(body.next().await.is_none());
    assert_eq!(
        trace.snapshot(),
        vec!["wait_event", "next_event", "commit", "next_end"]
    );
    assert!(!trace.is_cancelled());
}

#[tokio::test(start_paused = true)]
async fn streaming_error_after_initial_keepalive_should_be_a_terminal_sse_failure() {
    let trace = Arc::new(Trace::default());
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![NextStep::DelayedError(
            Duration::from_secs(45),
            EngineError::Deadline,
        )],
    )
    .with_response_headers(headers(&[("x-codex-turn-state", "private-attempt-state")]));
    let response = stream_execution_response(Box::new(session), None).await;
    assert_eq!(response.status(), StatusCode::OK);
    assert!(!response.headers().contains_key("x-codex-turn-state"));
    let bytes = to_bytes(response.into_body(), usize::MAX).await.unwrap();
    let events = parse_sse_events(std::str::from_utf8(&bytes).unwrap()).unwrap();
    assert!(String::from_utf8_lossy(&bytes).starts_with(": keep-alive\n\n"));
    let failed = events
        .iter()
        .find(|event| event.event.as_deref() == Some("response.failed"))
        .expect("failure event");
    let payload: Value = serde_json::from_str(&failed.data).unwrap();
    assert_eq!(payload["response"]["error"]["code"], "request_timeout");
    assert!(bytes.ends_with(b"data: [DONE]\n\n"));
    assert_eq!(trace.client_statuses(), vec![200]);
    assert_eq!(trace.snapshot(), vec!["wait_error", "next_error"]);
}

#[tokio::test(start_paused = true)]
async fn streaming_late_upstream_error_should_preserve_extended_error_fields() {
    let mut error = json!({
        "type": "invalid_request_error", "code": "misalignment_policy_violation",
        "message": "synthetic policy error", "misalignment": {"category": "synthetic"},
        "extension": {"opaque": true}
    });
    let failure = ProviderError::new(ProviderErrorKind::InvalidRequest, UpstreamSendState::Sent)
        .with_client_visible_upstream_response(
            ClientVisibleUpstreamResponse::new(
                400,
                Some(b"application/json".to_vec()),
                Bytes::from(json!({"error": error}).to_string()),
            )
            .with_headers(headers(&[("retry-after", "7")])),
        );
    error["headers"] = json!({"retry-after": "7"});
    let session = FakeSession::streaming(
        Arc::new(Trace::default()),
        vec![NextStep::DelayedError(
            Duration::from_secs(30),
            EngineError::Provider(failure),
        )],
    );
    let response = stream_execution_response(Box::new(session), None).await;
    assert_eq!(response.status(), StatusCode::OK);
    let bytes = to_bytes(response.into_body(), usize::MAX).await.unwrap();
    let events = parse_sse_events(std::str::from_utf8(&bytes).unwrap()).unwrap();
    let failed = events
        .iter()
        .find(|event| event.event.as_deref() == Some("response.failed"))
        .unwrap();
    let payload: Value = serde_json::from_str(&failed.data).unwrap();
    assert_eq!(payload["response"]["error"], error);
    assert!(bytes.ends_with(b"data: [DONE]\n\n"));
}

#[tokio::test]
async fn responses_http_connection_should_survive_a_shorter_read_idle_timeout() {
    use tokio::io::{AsyncReadExt as _, AsyncWriteExt as _};

    let trace = Arc::new(Trace::default());
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![
            NextStep::DelayedEvent(
                Duration::from_secs(35),
                delivery(completed(), CommitRequirement::CommitBeforeDelivery),
            ),
            NextStep::FinalizeSuccess,
        ],
    );
    let execution = Arc::new(SessionExecution {
        client: authenticated_client_for_provider("sk_correlation_test", "openai"),
        session: Mutex::new(Some(Box::new(session))),
        middleware: Some(Arc::new(responses_middleware()).frozen()),
    });
    let app = api_router(execution).await;
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let address = listener.local_addr().unwrap();
    let server = tokio::spawn(async move { axum::serve(listener, app).await.unwrap() });
    let mut client = tokio::net::TcpStream::connect(address).await.unwrap();
    let body = json!({"model": "model-a", "input": "synthetic", "stream": true}).to_string();
    client.write_all(format!(
        "POST /v1/responses HTTP/1.1\r\nHost: {address}\r\nAuthorization: Bearer sk_correlation_test\r\nUser-Agent: AnotherTerminal/1.0\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{body}", body.len()
    ).as_bytes()).await.unwrap();
    let mut received = Vec::new();
    let result = async {
        loop {
            let mut buffer = [0; 4096];
            // 真实 TCP 每次读取都受空闲期限约束，首个业务事件晚于该期限
            let read =
                tokio::time::timeout(Duration::from_secs(20), client.read(&mut buffer)).await?;
            let count = read.unwrap();
            if count == 0 {
                break;
            }
            received.extend_from_slice(&buffer[..count]);
        }
        Ok::<(), tokio::time::error::Elapsed>(())
    }
    .await;
    server.abort();
    result.expect("HTTP connection must receive keepalive before its read idle deadline");
    let wire = String::from_utf8(received).unwrap();
    assert!(wire.starts_with("HTTP/1.1 200 OK\r\n"));
    assert!(wire.contains("x-accel-buffering: no\r\n"));
    assert_eq!(wire.matches(": keep-alive\n\n").count(), 2);
    assert!(wire.contains("response.completed"));
    assert!(wire.contains("data: [DONE]\n\n"));
    assert!(!trace.is_cancelled());
    assert_eq!(
        trace.snapshot(),
        vec!["wait_event", "next_event", "commit", "next_end"]
    );
}

#[tokio::test(start_paused = true)]
async fn dropping_stream_before_first_event_should_cancel_the_original_wait() {
    let trace = Arc::new(Trace::default());
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![
            NextStep::DelayedEvent(
                Duration::from_secs(240),
                delivery(completed(), CommitRequirement::CommitBeforeDelivery),
            ),
            NextStep::FinalizeCancelled,
        ],
    );
    let response = stream_execution_response(Box::new(session), None).await;
    let mut body = response.into_body().into_data_stream();
    assert_eq!(
        body.next().await.unwrap().unwrap(),
        Bytes::from_static(b": keep-alive\n\n")
    );
    drop(body);
    tokio::task::yield_now().await;
    assert!(trace.is_cancelled());
    assert_eq!(trace.detached_finalizations(), 1);
    assert_eq!(trace.snapshot(), vec!["wait_event", "cancel_finalize"]);
}

#[tokio::test]
async fn streaming_response_should_disable_proxy_buffering_and_cache_transformation() {
    let session = FakeSession::streaming(
        Arc::new(Trace::default()),
        vec![
            NextStep::Event(delivery(started(), CommitRequirement::CommitBeforeDelivery)),
            NextStep::FinalizeCancelled,
        ],
    )
    .with_response_headers(vec![
        ProviderResponseHeader::new("x-accel-buffering", Bytes::from_static(b"yes")),
        ProviderResponseHeader::new("cache-control", Bytes::from_static(b"public, max-age=60")),
    ]);

    let response = stream_execution_response(Box::new(session), None).await;

    assert_eq!(response.headers()["x-accel-buffering"], "no");
    assert_eq!(
        response.headers()["cache-control"],
        "no-cache, no-transform"
    );
    assert_eq!(
        response
            .headers()
            .get_all("x-accel-buffering")
            .iter()
            .count(),
        1
    );
    assert_eq!(
        response.headers().get_all("cache-control").iter().count(),
        1
    );
}

#[tokio::test]
async fn streaming_response_should_append_ordinary_headers_and_skip_unrepresentable_or_sensitive_ones()
 {
    let trace = Arc::new(Trace::default());
    let headers = vec![
        ProviderResponseHeader::new("x-models-etag", Bytes::from_static(b"models-v2")),
        ProviderResponseHeader::new(
            "x-codex-turn-state",
            Bytes::from_static(b"turn-state-from-upstream"),
        ),
        ProviderResponseHeader::new("x-future-multi", Bytes::from_static(b"first")),
        ProviderResponseHeader::new("x-future-multi", Bytes::from_static(b"second")),
        ProviderResponseHeader::new("x-future-bytes", Bytes::from_static(b"\xffopaque")),
        ProviderResponseHeader::new(
            "authorization",
            Bytes::from_static(b"should-not-cross-boundary"),
        ),
        ProviderResponseHeader::new("connection", Bytes::from_static(b"x-hop-secret")),
        ProviderResponseHeader::new("x-hop-secret", Bytes::from_static(b"hop-secret")),
        ProviderResponseHeader::new("content-type", Bytes::from_static(b"application/private")),
        ProviderResponseHeader::new("bad\0name", Bytes::from_static(b"unrepresentable")),
    ];
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![NextStep::Event(delivery(
            started(),
            CommitRequirement::CommitBeforeDelivery,
        ))],
    )
    .with_response_headers(headers);

    let response = stream_execution_response(Box::new(session), None).await;

    assert_eq!(
        response
            .headers()
            .get("x-models-etag")
            .and_then(|value| value.to_str().ok()),
        Some("models-v2")
    );
    assert_eq!(
        response
            .headers()
            .get_all("x-future-multi")
            .iter()
            .map(HeaderValue::as_bytes)
            .collect::<Vec<_>>(),
        vec![b"first".as_slice(), b"second".as_slice()]
    );
    assert_eq!(
        response
            .headers()
            .get("x-future-bytes")
            .map(HeaderValue::as_bytes),
        Some(b"\xffopaque".as_slice())
    );
    assert_eq!(
        response
            .headers()
            .get("x-codex-turn-state")
            .and_then(|value| value.to_str().ok()),
        Some("turn-state-from-upstream")
    );
    assert!(response.headers().get("authorization").is_none());
    assert!(response.headers().get("connection").is_none());
    assert!(response.headers().get("x-hop-secret").is_none());
    assert_eq!(
        response.headers().get(CONTENT_TYPE),
        Some(&HeaderValue::from_static("text/event-stream"))
    );
    std::mem::forget(response);
}

#[tokio::test]
async fn streaming_commit_batch_preserves_pre_identity_wire_before_committing() {
    let trace = Arc::new(Trace::default());
    let metadata = ResponseMeta::new("resp_upstream", "public-model");
    let raw_future = Bytes::from_static(
        b"id: evt_before_identity\r\nevent: response.future_metadata\r\nretry: 3000\r\ndata: { \"type\": \"response.future_metadata\", \"opaque\": true }\r\n\r\n",
    );
    let events = vec![
        ProviderEvent::wire(
            ProtocolWireEvent::json_with_raw_sse_metadata(
                "openai",
                Some("response.future_metadata".to_owned()),
                json!({"type":"response.future_metadata","opaque":true}),
                raw_future.clone(),
                Some("evt_before_identity".to_owned()),
                Some(3_000),
            )
            .expect("future wire event"),
        ),
        ProviderEvent::canonical_with_wire(
            vec![GatewayEvent::Started(metadata.clone())],
            ProtocolWireEvent::json(
                "openai",
                Some("response.created".to_owned()),
                json!({
                    "type":"response.created",
                    "response":{"id":"resp_upstream","model":"public-model","status":"in_progress","output":[]}
                }),
            )
            .expect("created wire event"),
        ),
        ProviderEvent::canonical_with_wire(
            vec![GatewayEvent::Completed(metadata)],
            ProtocolWireEvent::json(
                "openai",
                Some("response.completed".to_owned()),
                json!({
                    "type":"response.completed",
                    "response":{"id":"resp_upstream","model":"public-model","status":"completed","output":[]}
                }),
            )
            .expect("completed wire event"),
        ),
    ];
    let batch = CoordinatedEvent::try_batch(events, CommitRequirement::CommitBeforeDelivery)
        .expect("non-empty commit batch");
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![NextStep::Event(batch), NextStep::FinalizeSuccess],
    );

    let response = stream_execution_response(Box::new(session), None).await;
    let body = to_bytes(response.into_body(), usize::MAX)
        .await
        .expect("read SSE body");
    let body = String::from_utf8(body.to_vec()).expect("SSE is UTF-8");

    let future = body.find("response.future_metadata").expect("future event");
    let created = body.find("response.created").expect("created event");
    let completed = body.find("response.completed").expect("completed event");
    assert!(future < created && created < completed);
    assert!(body.as_bytes().starts_with(raw_future.as_ref()));
    assert!(body.contains("resp_upstream"));
    assert!(body.ends_with("data: [DONE]\n\n"));
    assert_eq!(trace.client_statuses(), vec![200]);
    assert_eq!(trace.snapshot(), vec!["next_event", "commit", "next_end"]);
    assert!(!trace.is_cancelled());
}

#[tokio::test]
async fn streaming_first_frame_encode_failure_cancels_before_commit() {
    let trace = Arc::new(Trace::default());
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![
            NextStep::Event(delivery_provider(
                ProviderEvent::canonical(completed()),
                CommitRequirement::CommitBeforeDelivery,
            )),
            NextStep::FinalizeCancelled,
        ],
    );

    let response = stream_execution_response(Box::new(session), None).await;

    assert_eq!(
        response.status(),
        axum::http::StatusCode::INTERNAL_SERVER_ERROR
    );
    assert_eq!(trace.client_statuses(), vec![500]);
    assert!(trace.is_cancelled());
    assert_eq!(trace.snapshot(), vec!["next_event", "cancel_finalize"]);
}

#[tokio::test]
async fn streaming_rate_limit_before_first_frame_should_persist_the_returned_429_status() {
    let trace = Arc::new(Trace::default());
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![NextStep::Error(EngineError::Provider(
            ProviderError::new(ProviderErrorKind::RateLimited, UpstreamSendState::NotSent)
                .with_status(429),
        ))],
    );

    let response = stream_execution_response(Box::new(session), None).await;

    assert_eq!(response.status(), StatusCode::TOO_MANY_REQUESTS);
    assert_eq!(trace.client_statuses(), vec![429]);
}

#[tokio::test]
async fn streaming_failure_before_first_frame_should_return_safe_observed_headers() {
    let trace = Arc::new(Trace::default());
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![NextStep::Error(EngineError::Provider(ProviderError::new(
            ProviderErrorKind::Unavailable,
            UpstreamSendState::Ambiguous,
        )))],
    )
    .with_response_headers(vec![
        ProviderResponseHeader::new(
            "x-codex-turn-state",
            Bytes::from_static(b"turn-state-before-close"),
        ),
        ProviderResponseHeader::new(
            "authorization",
            Bytes::from_static(b"must-not-cross-boundary"),
        ),
    ]);

    let response = stream_execution_response(Box::new(session), None).await;

    assert_eq!(response.status(), StatusCode::BAD_GATEWAY);
    assert_eq!(
        response
            .headers()
            .get("x-codex-turn-state")
            .and_then(|value| value.to_str().ok()),
        Some("turn-state-before-close")
    );
    assert!(response.headers().get("authorization").is_none());
    assert_eq!(trace.client_statuses(), vec![502]);
}

#[tokio::test]
async fn streaming_upstream_http_failure_before_first_frame_should_preserve_raw_response() {
    let trace = Arc::new(Trace::default());
    let raw_body = Bytes::from_static(
        b"{\"error\":{\"message\":\"rate limited\",\"future_field\":{\"kept\":true}},\"top_level\":17}\x00",
    );
    let error = ProviderError::new(ProviderErrorKind::RateLimited, UpstreamSendState::Sent)
        .with_client_visible_upstream_response(
            ClientVisibleUpstreamResponse::new(
                429,
                Some(b"application/problem+json; charset=utf-8".to_vec()),
                raw_body.clone(),
            )
            .with_headers(vec![
                ProviderResponseHeader::new("retry-after", Bytes::from_static(b"17")),
                ProviderResponseHeader::new("x-request-id", Bytes::from_static(b"req-failure")),
                ProviderResponseHeader::new("x-future-error", Bytes::from_static(b"first")),
                ProviderResponseHeader::new("x-future-error", Bytes::from_static(b"second")),
                ProviderResponseHeader::new("x-future-bytes", Bytes::from_static(b"\xffopaque")),
            ]),
        );
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![NextStep::Error(EngineError::Provider(error))],
    );

    let response = stream_execution_response(Box::new(session), None).await;

    assert_eq!(response.status(), StatusCode::TOO_MANY_REQUESTS);
    assert_eq!(
        response
            .headers()
            .get(CONTENT_TYPE)
            .map(|value| value.as_bytes()),
        Some(b"application/problem+json; charset=utf-8".as_slice())
    );
    assert_eq!(
        response
            .headers()
            .get("retry-after")
            .map(|value| value.as_bytes()),
        Some(b"17".as_slice())
    );
    assert_eq!(
        response
            .headers()
            .get("x-request-id")
            .map(|value| value.as_bytes()),
        Some(b"req-failure".as_slice())
    );
    assert_eq!(
        response
            .headers()
            .get_all("x-future-error")
            .iter()
            .map(|value| value.as_bytes())
            .collect::<Vec<_>>(),
        vec![b"first".as_slice(), b"second".as_slice()]
    );
    assert_eq!(
        response
            .headers()
            .get("x-future-bytes")
            .map(|value| value.as_bytes()),
        Some(b"\xffopaque".as_slice())
    );
    assert_eq!(
        to_bytes(response.into_body(), usize::MAX)
            .await
            .expect("read raw error body"),
        raw_body
    );
    assert_eq!(trace.client_statuses(), vec![429]);
}

#[tokio::test]
async fn buffered_upstream_http_failure_should_preserve_raw_response() {
    let trace = Arc::new(Trace::default());
    let raw_body = Bytes::from_static(b"not-json\xffstill-upstream");
    let error = ProviderError::new(ProviderErrorKind::Unavailable, UpstreamSendState::Sent)
        .with_client_visible_upstream_response(ClientVisibleUpstreamResponse::new(
            503,
            Some(b"application/octet-stream".to_vec()),
            raw_body.clone(),
        ));
    let session = FakeSession::buffered(Arc::clone(&trace), vec![started(), completed()])
        .with_collect_error(EngineError::Provider(error))
        .with_response_headers(vec![
            ProviderResponseHeader::new(
                "x-codex-turn-state",
                Bytes::from_static(b"turn-state-before-close"),
            ),
            ProviderResponseHeader::new(
                "authorization",
                Bytes::from_static(b"must-not-cross-boundary"),
            ),
        ]);

    let response = collect_execution_response(Box::new(session)).await;

    assert_eq!(response.status(), StatusCode::SERVICE_UNAVAILABLE);
    assert_eq!(
        response
            .headers()
            .get("x-codex-turn-state")
            .and_then(|value| value.to_str().ok()),
        Some("turn-state-before-close")
    );
    assert!(response.headers().get("authorization").is_none());
    assert_eq!(
        to_bytes(response.into_body(), usize::MAX)
            .await
            .expect("read raw error body"),
        raw_body
    );
    assert_eq!(trace.client_statuses(), vec![503]);
}

#[tokio::test]
async fn streaming_canonical_identity_change_does_not_interrupt_wire_delivery() {
    let trace = Arc::new(Trace::default());
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![
            NextStep::Event(delivery(started(), CommitRequirement::CommitBeforeDelivery)),
            NextStep::Event(delivery_provider(
                mismatched_terminal_event(),
                CommitRequirement::AlreadyCommitted,
            )),
            NextStep::FinalizeSuccess,
        ],
    );

    let response = stream_execution_response(Box::new(session), None).await;
    let body = to_bytes(response.into_body(), usize::MAX)
        .await
        .expect("read SSE body");

    let body = String::from_utf8_lossy(&body);
    assert!(body.contains("response.completed"));
    assert!(body.contains("resp_other"));
    assert!(!body.contains("response.failed"));
    assert!(body.ends_with("data: [DONE]\n\n"));
    assert_eq!(trace.client_statuses(), vec![200]);
    assert!(!trace.is_cancelled());
    assert_eq!(
        trace.snapshot(),
        vec!["next_event", "commit", "next_event", "next_end"]
    );
}

#[tokio::test]
async fn streaming_success_should_emit_terminal_event_and_done_marker() {
    let trace = Arc::new(Trace::default());
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![
            NextStep::Event(delivery(started(), CommitRequirement::CommitBeforeDelivery)),
            NextStep::Event(delivery(
                GatewayEvent::ContentAdded(ContentItem::new(0, ContentKind::Text)),
                CommitRequirement::AlreadyCommitted,
            )),
            NextStep::Event(delivery(
                GatewayEvent::TextDelta(TextDelta {
                    content_index: 0,
                    text: "hello".to_owned(),
                }),
                CommitRequirement::AlreadyCommitted,
            )),
            NextStep::Event(delivery(completed(), CommitRequirement::AlreadyCommitted)),
            NextStep::FinalizeSuccess,
        ],
    );

    let response = stream_execution_response(Box::new(session), None).await;
    let body = to_bytes(response.into_body(), usize::MAX)
        .await
        .expect("read complete SSE body");
    let body = String::from_utf8(body.to_vec()).expect("SSE is UTF-8");

    assert!(body.contains("event: response.completed"));
    assert!(body.ends_with("data: [DONE]\n\n"));
    assert!(!trace.is_cancelled());
    assert_eq!(
        trace.snapshot(),
        vec![
            "next_event",
            "commit",
            "next_event",
            "next_event",
            "next_event",
            "next_end",
        ]
    );
    assert_eq!(trace.detached_finalizations(), 0);
}

#[tokio::test]
async fn streaming_finalized_unknown_wire_should_end_cleanly_without_synthetic_failure() {
    let trace = Arc::new(Trace::default());
    let raw = Bytes::from_static(
        b"event: response.future_terminal\ndata: {\"type\":\"response.future_terminal\",\"opaque\":true}\n\n",
    );
    let event = ProviderEvent::wire(
        ProtocolWireEvent::raw_sse("openai", raw.clone()).expect("raw future event"),
    );
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![
            NextStep::Event(delivery_provider(
                event,
                CommitRequirement::CommitBeforeDelivery,
            )),
            NextStep::FinalizeSuccess,
        ],
    );

    let response = stream_execution_response(Box::new(session), None).await;
    let body = to_bytes(response.into_body(), usize::MAX)
        .await
        .expect("read transparent SSE body");

    assert!(body.as_ref().starts_with(raw.as_ref()));
    assert!(body.as_ref().ends_with(b"data: [DONE]\n\n"));
    assert!(!String::from_utf8_lossy(&body).contains("response.failed"));
    assert!(!trace.is_cancelled());
    assert_eq!(trace.snapshot(), vec!["next_event", "commit", "next_end"]);
}

#[tokio::test]
async fn streaming_completed_event_without_finalized_execution_should_fail_closed() {
    let trace = Arc::new(Trace::default());
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![
            NextStep::Event(delivery(started(), CommitRequirement::CommitBeforeDelivery)),
            NextStep::Event(delivery(completed(), CommitRequirement::AlreadyCommitted)),
            NextStep::End,
            NextStep::FinalizeCancelled,
        ],
    );

    let response = stream_execution_response(Box::new(session), None).await;
    let body = to_bytes(response.into_body(), usize::MAX)
        .await
        .expect("read failed SSE body");
    tokio::task::yield_now().await;
    let body = String::from_utf8(body.to_vec()).expect("SSE is UTF-8");

    assert!(!body.contains("event: response.completed"));
    assert!(body.contains("response.failed"));
    assert!(body.ends_with("data: [DONE]\n\n"));
    assert!(trace.is_cancelled());
    assert_eq!(
        trace.snapshot(),
        vec![
            "next_event",
            "commit",
            "next_event",
            "next_end",
            "cancel_finalize"
        ]
    );
    assert_eq!(trace.detached_finalizations(), 1);
}

#[tokio::test]
async fn streaming_empty_terminal_should_emit_failure_done_and_cancel_execution() {
    let trace = Arc::new(Trace::default());
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![
            NextStep::Event(delivery(started(), CommitRequirement::CommitBeforeDelivery)),
            NextStep::End,
            NextStep::FinalizeCancelled,
        ],
    );

    let response = stream_execution_response(Box::new(session), None).await;
    let body = to_bytes(response.into_body(), usize::MAX)
        .await
        .expect("read failed SSE body");
    tokio::task::yield_now().await;
    let body = String::from_utf8(body.to_vec()).expect("SSE is UTF-8");

    assert!(body.contains("\"code\":\"internal_error\""));
    assert!(body.ends_with("data: [DONE]\n\n"));
    assert!(trace.is_cancelled());
    assert_eq!(
        trace.snapshot(),
        vec!["next_event", "commit", "next_end", "cancel_finalize"]
    );
}

#[tokio::test]
async fn streaming_error_should_emit_client_visible_upstream_details() {
    let trace = Arc::new(Trace::default());
    let error = ProviderError::new(ProviderErrorKind::RateLimited, UpstreamSendState::Sent)
        .with_client_visible_upstream_error(ClientVisibleUpstreamError::new(
            "Your Codex quota is exhausted",
            Some("quota_exhausted".to_owned()),
            Some("rate_limit_error".to_owned()),
        ));
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![
            NextStep::Event(delivery(started(), CommitRequirement::CommitBeforeDelivery)),
            NextStep::Error(EngineError::Provider(error)),
        ],
    );

    let response = stream_execution_response(Box::new(session), None).await;
    let body = to_bytes(response.into_body(), usize::MAX)
        .await
        .expect("read SSE body");
    let body = String::from_utf8(body.to_vec()).expect("SSE is UTF-8");

    assert!(body.contains("event: response.failed"));
    assert!(body.contains("Your Codex quota is exhausted"));
    assert!(body.contains("\"code\":\"quota_exhausted\""));
    assert!(body.contains("\"type\":\"rate_limit_error\""));
    assert!(body.ends_with("data: [DONE]\n\n"));
}

#[tokio::test]
async fn streaming_upstream_wire_failure_should_not_be_rewritten_as_a_gateway_error() {
    let trace = Arc::new(Trace::default());
    let raw_failure = Bytes::from_static(
        b"event: response.failed\r\ndata: { \"type\": \"response.failed\", \"response\": { \"id\": \"resp_test\", \"status\": \"failed\", \"error\": { \"code\": \"rate_limit_exceeded\", \"message\": \"upstream raw failure marker\" } } }\r\n\r\n",
    );
    let wire_failure = ProviderEvent::wire(
        ProtocolWireEvent::json_with_raw_sse_metadata(
            "openai",
            Some("response.failed".to_owned()),
            json!({
                "type": "response.failed",
                "response": {
                    "id": "resp_test",
                    "status": "failed",
                    "error": {
                        "code": "rate_limit_exceeded",
                        "message": "upstream raw failure marker"
                    }
                }
            }),
            raw_failure.clone(),
            None,
            None,
        )
        .expect("valid upstream failure wire"),
    );
    let started_wire = ProviderEvent::canonical_with_wire(
        vec![started()],
        ProtocolWireEvent::json(
            "openai",
            Some("response.created".to_owned()),
            json!({
                "type": "response.created",
                "response": {
                    "id": "resp_test",
                    "model": "public-model",
                    "status": "in_progress"
                }
            }),
        )
        .expect("valid upstream started wire"),
    );
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![
            NextStep::Event(CoordinatedEvent::single(
                started_wire,
                CommitRequirement::CommitBeforeDelivery,
            )),
            NextStep::Event(CoordinatedEvent::single(
                wire_failure,
                CommitRequirement::AlreadyCommitted,
            )),
            NextStep::Error(EngineError::Provider(ProviderError::new(
                ProviderErrorKind::RateLimited,
                UpstreamSendState::Sent,
            ))),
        ],
    );

    let response = stream_execution_response(Box::new(session), None).await;
    let body = to_bytes(response.into_body(), usize::MAX)
        .await
        .expect("read SSE body");

    assert!(
        body.windows(raw_failure.len())
            .any(|frame| frame == raw_failure.as_ref())
    );
    assert_eq!(
        String::from_utf8_lossy(&body)
            .matches("upstream raw failure marker")
            .count(),
        1
    );
    assert!(!String::from_utf8_lossy(&body).contains("resp_proxy_"));
    assert!(String::from_utf8_lossy(&body).ends_with("data: [DONE]\n\n"));
    assert_eq!(
        trace.snapshot(),
        vec!["next_event", "commit", "next_event", "next_error"]
    );
}

#[tokio::test]
async fn streaming_upstream_error_event_should_be_translated_to_response_failed_for_sse() {
    for (error_type, code, client_code, kind, client_status) in [
        (
            "service_unavailable_error",
            "server_is_overloaded",
            "server_error",
            ProviderErrorKind::UpstreamCapacityUnavailable,
            503,
        ),
        (
            "rate_limit_error",
            "turn_rate_limit_exceeded",
            "turn_rate_limit_exceeded",
            ProviderErrorKind::RateLimited,
            429,
        ),
    ] {
        let trace = Arc::new(Trace::default());
        let error_data = json!({
            "type": "error",
            "status": 429,
            "headers": {"Retry-After": "24"},
            "error": {
                "type": error_type,
                "code": code,
                "message": "Our servers are currently overloaded. Please try again later.",
                "param": null,
                "future_error_field": {"keep": true}
            },
            "sequence_number": 2,
            "future_event_field": {"keep": true}
        });
        let projected_error_frame = Bytes::from(encode_sse_event("error", &error_data.to_string()));
        let error_wire = ProviderEvent::wire(
            ProtocolWireEvent::json_with_raw_sse_metadata(
                "openai",
                Some("error".to_owned()),
                error_data,
                projected_error_frame,
                None,
                None,
            )
            .expect("valid upstream error wire"),
        );
        let started_wire = ProviderEvent::canonical_with_wire(
            vec![started()],
            ProtocolWireEvent::json(
                "openai",
                Some("response.created".to_owned()),
                json!({
                    "type": "response.created",
                    "response": {
                        "id": "resp_test",
                        "model": "public-model",
                        "status": "in_progress",
                        "future_response_field": {"keep": true}
                    }
                }),
            )
            .expect("valid upstream started wire"),
        );
        let session = FakeSession::streaming(
            Arc::clone(&trace),
            vec![
                NextStep::Event(CoordinatedEvent::single(
                    started_wire,
                    CommitRequirement::CommitBeforeDelivery,
                )),
                NextStep::Event(CoordinatedEvent::single(
                    error_wire,
                    CommitRequirement::AlreadyCommitted,
                )),
                NextStep::Error(EngineError::Provider(ProviderError::new(
                    kind,
                    UpstreamSendState::Sent,
                ))),
            ],
        );

        let response = stream_execution_response(Box::new(session), None).await;
        assert_eq!(response.status(), StatusCode::OK);
        let body = to_bytes(response.into_body(), usize::MAX)
            .await
            .expect("read SSE body");
        let body = String::from_utf8(body.to_vec()).expect("SSE is UTF-8");
        let events = parse_sse_events(&body).expect("translated SSE should parse");
        let failed = events
            .iter()
            .find(|event| event.event.as_deref() == Some("response.failed"))
            .expect("translated response.failed event");
        let failed: Value = serde_json::from_str(&failed.data).expect("response.failed JSON");

        assert_eq!(
            (
                failed,
                body.matches("event: response.failed").count(),
                body.contains("event: error\n"),
                body.ends_with("data: [DONE]\n\n"),
            ),
            (
                json!({
                    "type": "response.failed",
                    "status": client_status,
                    "headers": {"Retry-After": "24"},
                    "response": {
                        "id": "resp_test",
                        "model": "public-model",
                        "status": "failed",
                        "error": {
                            "type": error_type,
                            "code": client_code,
                            "message": "Our servers are currently overloaded. Please try again later.",
                            "param": null,
                            "future_error_field": {"keep": true},
                            "headers": {"retry-after": "24"}
                        },
                        "future_response_field": {"keep": true}
                    },
                    "sequence_number": 2,
                    "future_event_field": {"keep": true}
                }),
                1,
                false,
                true,
            )
        );
    }
}

#[tokio::test]
async fn streaming_capacity_error_after_commit_offers_client_retry() {
    for code in ["server_is_overloaded", "slow_down"] {
        let trace = Arc::new(Trace::default());
        let error = ProviderError::new(
            ProviderErrorKind::UpstreamCapacityUnavailable,
            UpstreamSendState::Sent,
        )
        .with_client_visible_upstream_error(ClientVisibleUpstreamError::new(
            "busy",
            Some(code.to_owned()),
            Some("service_unavailable_error".to_owned()),
        ));
        let session = FakeSession::streaming(
            Arc::clone(&trace),
            vec![
                NextStep::Event(delivery(started(), CommitRequirement::CommitBeforeDelivery)),
                NextStep::Error(EngineError::Provider(error)),
            ],
        );
        let response = stream_execution_response(Box::new(session), None).await;
        assert_eq!(response.status(), StatusCode::OK);
        let body = to_bytes(response.into_body(), 16 * 1024)
            .await
            .expect("SSE body");
        let text = std::str::from_utf8(&body).expect("UTF-8");
        let events = parse_sse_events(text).expect("SSE");
        let failed = events
            .iter()
            .find(|event| event.event.as_deref() == Some("response.failed"))
            .expect("failed event");
        let failed: Value = serde_json::from_str(&failed.data).expect("JSON");
        assert_eq!(failed["response"]["error"]["code"], "server_error");
        assert_eq!(failed["response"]["error"]["message"], "busy");
        assert_eq!(text.matches("event: response.failed").count(), 1);
        assert!(text.ends_with("data: [DONE]\n\n"));
    }
}

#[tokio::test]
async fn atomic_uncommitted_upstream_failure_batch_should_be_forwarded_once() {
    let trace = Arc::new(Trace::default());
    let raw_created = Bytes::from_static(
        b"event: response.created\r\ndata: {\"type\":\"response.created\",\"response\":{\"id\":\"resp_atomic_api\",\"model\":\"public-model\",\"status\":\"in_progress\"}}\r\n\r\n",
    );
    let raw_failure = Bytes::from_static(
        b"event: response.failed\r\ndata: {\"type\":\"response.failed\",\"response\":{\"id\":\"resp_atomic_api\",\"status\":\"failed\",\"error\":{\"code\":\"rate_limit_exceeded\",\"message\":\"atomic upstream marker\"}}}\r\n\r\n",
    );
    let started_wire = ProviderEvent::canonical_with_wire(
        vec![started()],
        ProtocolWireEvent::json_with_raw_sse_metadata(
            "openai",
            Some("response.created".to_owned()),
            json!({
                "type": "response.created",
                "response": {
                    "id": "resp_atomic_api",
                    "model": "public-model",
                    "status": "in_progress"
                }
            }),
            raw_created.clone(),
            None,
            None,
        )
        .expect("valid upstream started wire"),
    );
    let failed_wire = ProviderEvent::wire(
        ProtocolWireEvent::json_with_raw_sse_metadata(
            "openai",
            Some("response.failed".to_owned()),
            json!({
                "type": "response.failed",
                "response": {
                    "id": "resp_atomic_api",
                    "status": "failed",
                    "error": {
                        "code": "rate_limit_exceeded",
                        "message": "atomic upstream marker"
                    }
                }
            }),
            raw_failure.clone(),
            None,
            None,
        )
        .expect("valid upstream failure wire"),
    );
    let batch = CoordinatedEvent::try_batch(
        vec![started_wire, failed_wire],
        CommitRequirement::CommitBeforeDelivery,
    )
    .expect("atomic failure delivery");
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![
            NextStep::Event(batch),
            NextStep::Error(EngineError::Provider(ProviderError::new(
                ProviderErrorKind::RateLimited,
                UpstreamSendState::Sent,
            ))),
        ],
    );

    let response = stream_execution_response(Box::new(session), None).await;
    let body = to_bytes(response.into_body(), usize::MAX)
        .await
        .expect("read SSE body");
    let body = String::from_utf8(body.to_vec()).expect("SSE is UTF-8");

    assert_eq!(body.matches("atomic upstream marker").count(), 1);
    assert_eq!(body.matches("event: response.failed").count(), 1);
    assert!(body.contains(std::str::from_utf8(&raw_created).expect("created frame")));
    assert!(body.contains(std::str::from_utf8(&raw_failure).expect("failure frame")));
    assert!(!body.contains("Upstream capacity is temporarily unavailable."));
    assert!(body.ends_with("data: [DONE]\n\n"));
    assert_eq!(trace.snapshot(), vec!["next_event", "commit", "next_error"]);
}

#[tokio::test]
async fn streaming_second_commit_request_should_fail_and_finalize_once() {
    let trace = Arc::new(Trace::default());
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![
            NextStep::Event(delivery(started(), CommitRequirement::CommitBeforeDelivery)),
            NextStep::Event(delivery(
                completed(),
                CommitRequirement::CommitBeforeDelivery,
            )),
            NextStep::FinalizeCancelled,
        ],
    );

    let response = stream_execution_response(Box::new(session), None).await;
    let body = to_bytes(response.into_body(), usize::MAX)
        .await
        .expect("read failed SSE body");
    let body = String::from_utf8(body.to_vec()).expect("SSE is UTF-8");

    assert!(body.contains("response.failed"));
    assert!(body.ends_with("data: [DONE]\n\n"));
    assert!(trace.is_cancelled());
    assert_eq!(
        trace.snapshot(),
        vec!["next_event", "commit", "next_event", "cancel_finalize"]
    );
}

#[tokio::test]
async fn streaming_commit_failure_should_not_deliver_the_prepared_first_frame() {
    let trace = Arc::new(Trace::default());
    let session = FakeSession::streaming(
        Arc::clone(&trace),
        vec![
            NextStep::Event(delivery(started(), CommitRequirement::CommitBeforeDelivery)),
            NextStep::FinalizeCancelled,
        ],
    )
    .with_commit_failure();

    let response = stream_execution_response(Box::new(session), None).await;
    let body = to_bytes(response.into_body(), usize::MAX)
        .await
        .expect("read error response");

    assert_eq!(
        response_status_from_body(&body).as_deref(),
        Some("internal_error")
    );
    assert_eq!(trace.client_statuses(), vec![500]);
    assert!(trace.is_cancelled());
    assert_eq!(
        trace.snapshot(),
        vec!["next_event", "commit", "cancel_finalize"]
    );
}

#[tokio::test]
async fn buffered_response_commits_only_after_complete_json_is_encoded() {
    let trace = Arc::new(Trace::default());
    let session = FakeSession::buffered(Arc::clone(&trace), vec![started(), completed()]);

    let response = collect_execution_response(Box::new(session)).await;
    let body = to_bytes(response.into_body(), usize::MAX)
        .await
        .expect("read JSON body");
    let json: serde_json::Value = serde_json::from_slice(&body).expect("valid response JSON");

    assert_eq!(json["id"], "resp_test");
    assert_eq!(trace.client_statuses(), vec![200]);
    assert_eq!(trace.snapshot(), vec!["collect", "commit"]);
    assert!(!trace.is_cancelled());
}

#[tokio::test]
async fn buffered_response_collects_completed_output_items_without_rewriting_streams() {
    let message = json!({
        "id": "msg_test", "type": "message", "role": "assistant", "status": "completed",
        "phase": "partial_answer",
        "content": [{"type": "output_text", "text": "完整文本", "annotations": []}],
        "future_item_field": {"keep": true}
    });
    let tool = json!({
        "id": "fc_test", "type": "function_call", "call_id": "call_test",
        "name": "calculate", "arguments": "{\"value\":42}", "status": "completed"
    });
    let terminal = json!({
        "id": "resp_test", "status": "completed", "output": [],
        "end_turn": false,
        "usage": {"input_tokens": 20, "output_tokens": 8, "total_tokens": 28},
        "future_terminal_field": {"keep": true}
    });
    let mut events = vec![provider_event_for_fact(started())];
    // 完成顺序不决定输出顺序；相同完成项重传不能产生重复正文
    for (index, item) in [(1, &tool), (0, &message), (0, &message)] {
        events.push(super::openai_wire_event(
            vec![],
            "response.output_item.done",
            json!({"type": "response.output_item.done", "output_index": index, "item": item}),
        ));
    }
    events.push(super::openai_wire_event(
        vec![],
        "response.completed",
        json!({"type": "response.completed", "response": terminal}),
    ));
    let mut sse = super::OpenAiResponsesEncoder::new();
    let mut websocket = super::OpenAiResponsesEncoder::new();
    for event in &events {
        let frames = sse.push_sse(event);
        let messages = websocket.push_websocket(event);
        let wire = event.wire_event().unwrap();
        let parsed = parse_sse_events(std::str::from_utf8(&frames.concat()).unwrap()).unwrap();
        assert_eq!(
            serde_json::from_str::<Value>(&parsed[0].data).unwrap(),
            *wire.data()
        );
        assert_eq!(
            serde_json::from_str::<Value>(&messages[0]).unwrap(),
            *wire.data()
        );
    }
    assert_eq!(sse.finish().unwrap(), terminal);
    assert_eq!(websocket.finish().unwrap(), terminal);

    let trace = Arc::new(Trace::default());
    let session = FakeSession::buffered_provider(Arc::clone(&trace), events);
    let response = collect_execution_response(Box::new(session)).await;
    assert_eq!(response.status(), StatusCode::OK);
    let body = to_bytes(response.into_body(), usize::MAX).await.unwrap();
    let mut expected = terminal;
    expected["output"] = json!([message, tool]);
    assert_eq!(serde_json::from_slice::<Value>(&body).unwrap(), expected);
    assert_eq!(trace.snapshot(), ["collect", "commit"]);
    assert!(!trace.is_cancelled());
}

#[tokio::test]
async fn native_responses_route_preserves_images_and_encrypted_reasoning_in_json_and_sse() {
    let admin = crate::admin::AdminTestFixture::new().await.services;
    let reasoning = json!({
        "id":"rs_native","type":"reasoning","encrypted_content":"opaque-reasoning-for-replay",
        "summary":[{"type":"summary_text","text":"native summary"}],
        "future_reasoning_field":{"keep":true}
    });
    let image = json!({
        "id":"ig_native","type":"image_generation_call","status":"completed",
        "result":"b3BhcXVlLWltYWdl","output_format":"png",
        "future_image_field":{"keep":true}
    });
    let terminal = json!({
        "id":"resp_test","object":"response","model":"public-model","status":"completed",
        "output":[reasoning, image],"future_terminal_field":{"keep":true}
    });
    for streaming in [false, true] {
        let trace = Arc::new(Trace::default());
        let mut expected_sse = Vec::new();
        let mut events = Vec::new();
        for (index, (kind, mut data, facts)) in [
            (
                "response.created",
                json!({"response":{"id":"resp_test","model":"public-model","status":"in_progress","output":[]}}),
                vec![started()],
            ),
            (
                "response.output_item.done",
                json!({"output_index":0,"item":reasoning}),
                vec![],
            ),
            (
                "response.image_generation_call.partial_image",
                json!({"item_id":"ig_native","output_index":1,"partial_image_index":0,"partial_image_b64":"b3BhcXVlLXBhcnRpYWw="}),
                vec![],
            ),
            (
                "response.output_item.done",
                json!({"output_index":1,"item":image}),
                vec![],
            ),
            (
                "response.completed",
                json!({"response":terminal}),
                vec![completed()],
            ),
        ]
        .into_iter()
        .enumerate()
        {
            data["type"] = json!(kind);
            let id = format!("native-boundary-{index}");
            // 保留行结束符、空白和 SSE 元数据，不能仅比较 JSON 后掩盖重编码
            let raw = Bytes::from(format!(
                "id: {id}\r\nevent: {kind}\r\nretry: 1234\r\ndata: {data} \r\n\r\n"
            ));
            expected_sse.extend_from_slice(&raw);
            events.push(ProviderEvent::canonical_with_wire(
                facts,
                ProtocolWireEvent::json_with_raw_sse_metadata(
                    "openai",
                    Some(kind.to_owned()),
                    data,
                    raw,
                    Some(id),
                    Some(1234),
                )
                .unwrap(),
            ));
        }
        let session = if streaming {
            FakeSession::streaming(
                Arc::clone(&trace),
                vec![
                    NextStep::Event(
                        CoordinatedEvent::try_batch(
                            events,
                            CommitRequirement::CommitBeforeDelivery,
                        )
                        .unwrap(),
                    ),
                    NextStep::FinalizeSuccess,
                ],
            )
        } else {
            FakeSession::buffered_provider(Arc::clone(&trace), events)
        };
        // 使用真实 /v1/responses 入口，覆盖共享执行函数的可选适配器为空分支
        let response = response(&admin, "openai", session, streaming).await;
        assert_eq!(response.status(), StatusCode::OK);
        let body = to_bytes(response.into_body(), usize::MAX).await.unwrap();
        if streaming {
            expected_sse.extend_from_slice(b"data: [DONE]\n\n");
            assert_eq!(body.as_ref(), expected_sse.as_slice());
            assert_eq!(trace.snapshot(), ["next_event", "commit", "next_end"]);
        } else {
            assert_eq!(serde_json::from_slice::<Value>(&body).unwrap(), terminal);
            assert_eq!(trace.snapshot(), ["collect", "commit"]);
        }
        assert!(!trace.is_cancelled());
    }
}

#[tokio::test]
async fn buffered_response_keeps_authoritative_terminal_and_supports_omitted_output() {
    let item = json!({"id": "rs_test", "type": "reasoning", "encrypted_content": "opaque"});
    for (terminal, expected_output) in [
        (
            json!({"id": "resp_test", "output": [{"type": "future", "result": "terminal"}]}),
            json!([{"type": "future", "result": "terminal"}]),
        ),
        (
            json!({"id": "resp_test", "status": "incomplete", "incomplete_details": {"reason": "max_output_tokens"}}),
            json!([item]),
        ),
    ] {
        let trace = Arc::new(Trace::default());
        let event_type = if terminal["status"] == "incomplete" {
            "response.incomplete"
        } else {
            "response.completed"
        };
        let session = FakeSession::buffered_provider(
            Arc::clone(&trace),
            vec![
                provider_event_for_fact(started()),
                super::openai_wire_event(
                    vec![],
                    "response.output_item.done",
                    json!({"output_index": 0, "item": item}),
                ),
                super::openai_wire_event(vec![], event_type, json!({"response": terminal})),
            ],
        );
        let response = collect_execution_response(Box::new(session)).await;
        assert_eq!(response.status(), StatusCode::OK);
        let body = to_bytes(response.into_body(), usize::MAX).await.unwrap();
        let mut expected = terminal;
        expected["output"] = expected_output;
        assert_eq!(serde_json::from_slice::<Value>(&body).unwrap(), expected);
        assert_eq!(trace.snapshot(), ["collect", "commit"]);
    }
}

#[tokio::test]
async fn buffered_response_rejects_incomplete_or_conflicting_output_items_before_commit() {
    let item =
        json!({"id": "msg_test", "type": "message", "content": [{"text": "private-output"}]});
    for done_items in [
        vec![json!({"output_index": 1, "item": item})],
        vec![json!({"output_index": u64::MAX, "item": item})],
        vec![json!({"output_index": -1, "item": item})],
        vec![json!({"item": item})],
        vec![json!({"output_index": 0, "item": []})],
        vec![
            json!({"output_index": 0, "item": item}),
            json!({"output_index": 0, "item": {"type": "different"}}),
        ],
    ] {
        let trace = Arc::new(Trace::default());
        let mut events = vec![provider_event_for_fact(started())];
        events.extend(
            done_items
                .into_iter()
                .map(|item| super::openai_wire_event(vec![], "response.output_item.done", item)),
        );
        events.push(super::openai_wire_event(
            vec![],
            "response.completed",
            json!({"response": {"id": "resp_test", "output": []}}),
        ));
        let response = collect_execution_response(Box::new(FakeSession::buffered_provider(
            Arc::clone(&trace),
            events,
        )))
        .await;
        assert_eq!(response.status(), StatusCode::INTERNAL_SERVER_ERROR);
        let body = to_bytes(response.into_body(), usize::MAX).await.unwrap();
        let value: Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(value["error"]["code"], "invalid_upstream_response");
        assert!(!String::from_utf8_lossy(&body).contains("private-output"));
        assert!(!trace.snapshot().contains(&"commit"));
        assert!(trace.is_cancelled());
    }
}

#[tokio::test]
async fn buffered_response_never_merges_items_from_a_different_wire_response() {
    for conflicting_event in [
        json!({"output_index": 0, "item": {"type": "message", "content": [{"text": "earlier-response"}]}}),
        json!({"response_id": "foreign-response", "output_index": 0, "item": {"type": "message", "content": [{"text": "foreign-response"}]}}),
    ] {
        let trace = Arc::new(Trace::default());
        let terminal_id = if conflicting_event.get("response_id").is_some() {
            "resp_test"
        } else {
            "new-response"
        };
        let terminal = json!({"id": terminal_id, "status": "completed", "output": []});
        let events = vec![
            provider_event_for_fact(started()),
            super::openai_wire_event(vec![], "response.output_item.done", conflicting_event),
            super::openai_wire_event(vec![], "response.completed", json!({"response": terminal})),
        ];
        let response = collect_execution_response(Box::new(FakeSession::buffered_provider(
            Arc::clone(&trace),
            events,
        )))
        .await;
        assert_eq!(response.status(), StatusCode::OK);
        let body = to_bytes(response.into_body(), usize::MAX).await.unwrap();
        assert_eq!(serde_json::from_slice::<Value>(&body).unwrap(), terminal);
        assert_eq!(trace.snapshot(), ["collect", "commit"]);
    }
}

#[tokio::test]
async fn buffered_response_middleware_replaces_body_and_preserves_explicit_headers() {
    let admin = crate::admin::AdminTestFixture::new().await.services;
    let trace = Arc::new(Trace::default());
    let session = FakeSession::buffered(Arc::clone(&trace), vec![started(), completed()]);
    let middleware = Arc::new(
        responses_middleware()
            .with_response_actions(vec![ResponseFrameAction::Replace(
            Bytes::from_static(
                b"{\"id\":\"resp_test\",\"status\":\"completed\",\"output\":[],\"future_policy_field\":true}",
            ),
            )])
            .with_response_headers(vec![
                MiddlewareHeader::new("x-policy-result", Bytes::from_static(b"replaced")),
                MiddlewareHeader::new("authorization", Bytes::from_static(b"plugin-value")),
            ]),
    );

    let response =
        response_with_middleware(&admin, "openai", session, false, Some(middleware)).await;
    assert_eq!(response.status(), StatusCode::OK);
    assert_eq!(response.headers()["x-policy-result"], "replaced");
    assert_eq!(response.headers()[AUTHORIZATION], "plugin-value");
    let body = to_bytes(response.into_body(), usize::MAX)
        .await
        .expect("read policy JSON body");
    assert_eq!(
        serde_json::from_slice::<Value>(&body).expect("policy response JSON"),
        json!({
            "id": "resp_test", "status": "completed", "output": [],
            "future_policy_field": true
        })
    );
    assert_eq!(trace.client_statuses(), vec![200]);
    assert_eq!(trace.snapshot(), vec!["collect", "commit"]);
}

#[tokio::test]
async fn buffered_response_middleware_rejects_missing_terminal_fields_or_duplicate_tool_identity() {
    let admin = crate::admin::AdminTestFixture::new().await.services;
    for replacement in [
        json!({"id": "resp_test", "output": []}),
        json!({"id": "resp_test", "status": "incomplete", "output": []}),
        json!({
            "id": "resp_test", "status": "completed", "output": [
                {
                    "id": "item_a", "type": "function_call", "call_id": "call_same",
                    "name": "first", "arguments": "{}"
                },
                {
                    "id": "item_b", "type": "function_call", "call_id": "call_same",
                    "name": "second", "arguments": "{}"
                }
            ]
        }),
    ] {
        let trace = Arc::new(Trace::default());
        let session = FakeSession::buffered(Arc::clone(&trace), vec![started(), completed()]);
        let middleware = Arc::new(responses_middleware().with_response_actions(vec![
            ResponseFrameAction::Replace(Bytes::from(
                serde_json::to_vec(&replacement).expect("replacement JSON"),
            )),
        ]));

        let response =
            response_with_middleware(&admin, "openai", session, false, Some(middleware)).await;
        assert_eq!(response.status(), StatusCode::BAD_GATEWAY);
        let body = to_bytes(response.into_body(), usize::MAX)
            .await
            .expect("read middleware error response");
        assert_eq!(
            serde_json::from_slice::<Value>(&body).expect("middleware error JSON")["error"]["code"],
            "middleware_failed"
        );
        assert_eq!(trace.client_statuses(), vec![502]);
        assert!(!trace.snapshot().contains(&"commit"));
        assert!(trace.is_cancelled());
        assert_eq!(trace.snapshot(), vec!["collect", "cancel_finalize"]);
    }
}

#[tokio::test]
async fn buffered_response_forwards_long_ordinary_provider_header_values() {
    let trace = Arc::new(Trace::default());
    let model = format!("gpt-{}", "x".repeat(512));
    let header = ProviderResponseHeader::new("openai-model", Bytes::from(model.clone()));
    let session = FakeSession::buffered(Arc::clone(&trace), vec![started(), completed()])
        .with_response_headers(vec![header]);

    let response = collect_execution_response(Box::new(session)).await;

    assert_eq!(
        response
            .headers()
            .get("openai-model")
            .and_then(|value| value.to_str().ok()),
        Some(model.as_str())
    );
}

#[tokio::test]
async fn buffered_encode_failure_cancels_without_commit() {
    let trace = Arc::new(Trace::default());
    let session = FakeSession::buffered_provider(
        Arc::clone(&trace),
        vec![ProviderEvent::canonical(completed())],
    );

    let response = collect_execution_response(Box::new(session)).await;

    assert_eq!(
        response.status(),
        axum::http::StatusCode::INTERNAL_SERVER_ERROR
    );
    assert_eq!(trace.client_statuses(), vec![500]);
    assert!(trace.is_cancelled());
    assert_eq!(trace.snapshot(), vec!["collect", "cancel_finalize"]);
}

#[tokio::test]
async fn buffered_commit_failure_should_cancel_after_encoding_without_returning_success() {
    let trace = Arc::new(Trace::default());
    let session = FakeSession::buffered(Arc::clone(&trace), vec![started(), completed()])
        .with_commit_failure();

    let response = collect_execution_response(Box::new(session)).await;
    let status = response.status();

    assert_eq!(status, axum::http::StatusCode::INTERNAL_SERVER_ERROR);
    assert_eq!(trace.client_statuses(), vec![500]);
    assert!(trace.is_cancelled());
    assert_eq!(
        trace.snapshot(),
        vec!["collect", "commit", "cancel_finalize"]
    );
}

#[tokio::test]
async fn dropping_buffered_handler_before_commit_cancels_execution() {
    let trace = Arc::new(Trace::default());
    let session = FakeSession::pending_buffered(Arc::clone(&trace));
    let task = tokio::spawn(async move { collect_execution_response(Box::new(session)).await });
    tokio::task::yield_now().await;

    task.abort();
    let _ = task.await;
    tokio::task::yield_now().await;

    assert!(trace.is_cancelled());
    assert!(!trace.snapshot().contains(&"commit"));
}

#[tokio::test]
async fn buffered_rate_limit_should_persist_the_returned_429_status() {
    let trace = Arc::new(Trace::default());
    let session = FakeSession::buffered(Arc::clone(&trace), Vec::new()).with_collect_error(
        EngineError::Provider(
            ProviderError::new(ProviderErrorKind::RateLimited, UpstreamSendState::NotSent)
                .with_status(429),
        ),
    );

    let response = collect_execution_response(Box::new(session)).await;

    assert_eq!(response.status(), StatusCode::TOO_MANY_REQUESTS);
    assert_eq!(trace.client_statuses(), vec![429]);
}

fn response_status_from_body(body: &[u8]) -> Option<String> {
    let value: serde_json::Value = serde_json::from_slice(body).ok()?;
    value.pointer("/error/code")?.as_str().map(str::to_owned)
}

const MODEL_REQUEST_ID: &str = "req_model_correlation";

struct SessionExecution {
    client: AuthenticatedClient,
    session: Mutex<Option<Box<dyn ExecutionSession>>>,
    middleware: Option<FrozenMiddlewarePlan>,
}

#[tokio::test]
async fn official_core_clients_should_be_version_checked_before_starting_responses() {
    let admin = crate::admin::AdminTestFixture::new().await.services;
    for product in [
        "codex-tui",
        "codex_exec",
        "codex_vscode",
        "codex_sdk_ts",
        "codex_python_sdk",
    ] {
        for (version, allowed) in [("0.158.0", false), ("0.162.0", true)] {
            let trace = Arc::new(Trace::default());
            let execution = Arc::new(SessionExecution {
                client: authenticated_client_with_min_versions(
                    "sk_version_test",
                    None,
                    Some("0.162.0"),
                ),
                session: Mutex::new(Some(Box::new(FakeSession::streaming(
                    Arc::clone(&trace),
                    vec![
                        NextStep::Event(delivery(
                            started(),
                            CommitRequirement::CommitBeforeDelivery,
                        )),
                        NextStep::Event(delivery(completed(), CommitRequirement::AlreadyCommitted)),
                        NextStep::FinalizeSuccess,
                    ],
                )))),
                middleware: None,
            });
            let request = Request::post("/v1/responses")
                .header(AUTHORIZATION, "Bearer sk_version_test")
                .header("user-agent", format!(
                    "{product}/{version} (Mac OS 26.6.2; arm64) Apple_Terminal ({product}; 0.165.0)"
                ))
                .body(Body::from(json!({"model": "model-a", "input": "synthetic", "stream": true}).to_string()))
                .unwrap();
            let response = crate::openai::api_router_with_admin_and_execution(
                admin.clone(),
                execution.clone(),
            )
            .oneshot(request)
            .await
            .unwrap();
            let status = response.status();
            let body = to_bytes(response.into_body(), usize::MAX).await.unwrap();
            if allowed {
                assert_eq!(status, StatusCode::OK, "{product}/{version}");
                assert!(String::from_utf8_lossy(&body).contains("event: response.completed\n"));
                assert!(trace.snapshot().contains(&"commit"));
            } else {
                assert_eq!(status, StatusCode::BAD_REQUEST, "{product}/{version}");
                let value: Value = serde_json::from_slice(&body).unwrap();
                assert_eq!(value["error"]["code"], "client_version_too_old");
                assert_eq!(value["error"]["current_version"], version);
                assert_eq!(value["error"]["min_version"], "0.162.0");
                assert!(execution.session.lock().unwrap().is_some());
            }
        }
    }
}

#[tokio::test]
async fn chatgpt_remote_responses_should_only_skip_missing_desktop_versions() {
    let admin = crate::admin::AdminTestFixture::new().await.services;
    for name in [
        "codex_chatgpt_android_remote",
        "codex_chatgpt_ios_remote",
        "codex_chatgpt_future_os_remote",
    ] {
        for (version, expected_code) in [
            (None, None),
            (Some("26.908.70816"), None),
            (Some("26.1.0"), Some("client_version_too_old")),
            (Some("dev"), Some("client_version_unavailable")),
        ] {
            let trace = Arc::new(Trace::default());
            let execution = Arc::new(SessionExecution {
                client: authenticated_client_with_min_versions(
                    "sk_remote_test",
                    Some("26.908.70816"),
                    Some("0.154.0"),
                ),
                session: Mutex::new(Some(Box::new(FakeSession::streaming(
                    Arc::clone(&trace),
                    vec![
                        NextStep::Event(delivery(
                            started(),
                            CommitRequirement::CommitBeforeDelivery,
                        )),
                        NextStep::Event(delivery(completed(), CommitRequirement::AlreadyCommitted)),
                        NextStep::FinalizeSuccess,
                    ],
                )))),
                middleware: None,
            });
            let mut request = Request::post("/v1/responses")
                .header(AUTHORIZATION, "Bearer sk_remote_test")
                .header("user-agent", format!(
                    "Codex Desktop/0.154.0-alpha.6.2 (Windows 10.0.26200; x86_64) unknown ({name}; dev)"
                ));
            if let Some(version) = version {
                request = request.header("version", version);
            }
            let response = crate::openai::api_router_with_admin_and_execution(
                admin.clone(),
                execution.clone(),
            )
            .oneshot(
                request
                    .body(Body::from(
                        json!({"model": "model-a", "input": "synthetic", "stream": true})
                            .to_string(),
                    ))
                    .unwrap(),
            )
            .await
            .unwrap();
            let status = response.status();
            let body = to_bytes(response.into_body(), usize::MAX).await.unwrap();
            if let Some(code) = expected_code {
                let value: Value = serde_json::from_slice(&body).unwrap();
                assert_eq!(status, StatusCode::BAD_REQUEST, "{name} {version:?}");
                assert_eq!(value["error"]["code"], code);
                assert!(execution.session.lock().unwrap().is_some());
            } else {
                assert_eq!(status, StatusCode::OK, "{name} {version:?}");
                let body = String::from_utf8(body.to_vec()).unwrap();
                assert!(body.contains("event: response.completed\n"));
                assert!(body.ends_with("data: [DONE]\n\n"));
                assert!(trace.snapshot().contains(&"commit"));
            }
        }
    }
}

#[tokio::test]
async fn chatgpt_remote_responses_should_still_require_client_key_authentication() {
    let observed = Arc::new(Mutex::new(None));
    let execution = Arc::new(ContextCaptureExecution {
        observed: Arc::clone(&observed),
        client: authenticated_client_with_min_versions(
            "sk_context_test",
            Some("26.908.70816"),
            None,
        ),
    });
    let router = api_router(execution).await;
    for authorization in [None, Some("Bearer sk_invalid")] {
        let mut request = Request::post("/v1/responses").header(
            "user-agent",
            "Codex Desktop/0.154.0-alpha.6.2 (codex_chatgpt_android_remote; dev)",
        );
        if let Some(authorization) = authorization {
            request = request.header(AUTHORIZATION, authorization);
        }
        let response = router
            .clone()
            .oneshot(
                request
                    .body(Body::from(
                        json!({"model": "model-a", "input": "synthetic"}).to_string(),
                    ))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
        assert!(observed.lock().unwrap().is_none());
    }
}

impl ExecutionService for SessionExecution {
    fn authenticate(&self, _: &str) -> Result<AuthenticatedClient, ClientAuthenticationError> {
        Ok(self.client.clone())
    }

    fn public_models(&self, _: &AuthenticatedClient) -> Vec<PublicModelId> {
        Vec::new()
    }

    fn contains_public_model(&self, _: &AuthenticatedClient, _: &PublicModelId) -> bool {
        true
    }

    fn middleware_plan(
        &self,
        _: &gateway_core::engine::execution::PreparedRootExecution,
    ) -> Option<FrozenMiddlewarePlan> {
        self.middleware.clone()
    }

    fn start(
        &self,
        request: StartExecution,
    ) -> BoxFuture<'_, Result<StartedExecution, GatewayError>> {
        Box::pin(async move {
            Ok(StartedExecution {
                request_id: ModelRequestId::new(MODEL_REQUEST_ID).unwrap(),
                created_at: std::time::SystemTime::now(),
                stream: request.metadata.stream,
                session: self.session.lock().unwrap().take().expect("one execution"),
            })
        })
    }

    fn start_provider_endpoint(
        &self,
        _: StartProviderExecution,
    ) -> BoxFuture<'_, Result<StartedExecution, GatewayError>> {
        Box::pin(async { panic!("Responses must use model execution") })
    }
}

async fn response(
    admin: &gateway_admin::AdminServices,
    provider: &str,
    session: FakeSession,
    streaming: bool,
) -> axum::response::Response {
    response_with_middleware(admin, provider, session, streaming, None).await
}

async fn response_with_middleware(
    admin: &gateway_admin::AdminServices,
    provider: &str,
    session: FakeSession,
    streaming: bool,
    middleware: Option<Arc<RequestMiddleware>>,
) -> axum::response::Response {
    let execution = Arc::new(SessionExecution {
        client: authenticated_client_for_provider("sk_correlation_test", provider),
        session: Mutex::new(Some(Box::new(session))),
        middleware: middleware.map(|middleware| middleware.frozen()),
    });
    crate::openai::api_router_with_admin_and_execution(admin.clone(), execution)
        .oneshot(
            Request::post("/v1/responses")
                .header(AUTHORIZATION, "Bearer sk_correlation_test")
                .header("x-request-id", "caller-chosen-not-a-model-id")
                .header("user-agent", "AnotherTerminal/1.0")
                .body(Body::from(
                    json!({
                        "model": "model-a", "input": "synthetic", "stream": streaming
                    })
                    .to_string(),
                ))
                .unwrap(),
        )
        .await
        .unwrap()
}

fn headers(values: &[(&str, &'static str)]) -> Vec<ProviderResponseHeader> {
    values
        .iter()
        .map(|(name, value)| {
            ProviderResponseHeader::new(*name, Bytes::from_static(value.as_bytes()))
        })
        .collect()
}

fn failed_session(streaming: bool, error: EngineError) -> FakeSession {
    let trace = Arc::new(Trace::default());
    if streaming {
        FakeSession::streaming(trace, vec![NextStep::Error(error)])
    } else {
        FakeSession::buffered(trace, Vec::new()).with_collect_error(error)
    }
}

#[tokio::test]
async fn response_ids_are_provider_and_client_independent() {
    let admin = crate::admin::AdminTestFixture::new().await.services;
    let cases: &[(&[(&str, &str)], &str)] = &[
        (&[], MODEL_REQUEST_ID),
        (&[("x-request-id", "upstream-primary")], "upstream-primary"),
        (&[("x-oai-request-id", "upstream-alias")], "upstream-alias"),
        (
            &[
                ("x-request-id", "upstream-primary"),
                ("x-oai-request-id", "upstream-alias"),
            ],
            "upstream-primary",
        ),
        (
            &[
                ("x-request-id", " "),
                ("x-oai-request-id", "upstream-alias"),
            ],
            "upstream-alias",
        ),
        (&[("x-request-id", "")], MODEL_REQUEST_ID),
    ];
    for provider in ["openai", "xai"] {
        for streaming in [false, true] {
            for (upstream_headers, expected) in cases {
                let trace = Arc::new(Trace::default());
                let session = if streaming {
                    FakeSession::streaming(
                        trace,
                        vec![
                            NextStep::Event(delivery(
                                started(),
                                CommitRequirement::CommitBeforeDelivery,
                            )),
                            NextStep::Event(delivery(
                                completed(),
                                CommitRequirement::AlreadyCommitted,
                            )),
                            NextStep::FinalizeSuccess,
                        ],
                    )
                } else {
                    FakeSession::buffered(trace, vec![started(), completed()])
                }
                .with_response_headers(headers(upstream_headers));
                let response = response(&admin, provider, session, streaming).await;
                assert_eq!(response.status(), StatusCode::OK);
                assert_eq!(response.headers()["x-request-id"], *expected);
                assert_eq!(response.headers()["x-gateway-request-id"], MODEL_REQUEST_ID);
                assert!(
                    !to_bytes(response.into_body(), 64 * 1024)
                        .await
                        .unwrap()
                        .is_empty()
                );
            }
        }
    }
}

#[tokio::test]
async fn failure_ids_prefer_the_actual_error_over_session_headers() {
    let admin = crate::admin::AdminTestFixture::new().await.services;
    for provider in ["openai", "xai"] {
        for streaming in [false, true] {
            for upstream_headers in [vec![], headers(&[("x-oai-request-id", "actual-error")])] {
                let expected = if upstream_headers.is_empty() {
                    MODEL_REQUEST_ID
                } else {
                    "actual-error"
                };
                let raw =
                    Bytes::from_static(br#"{"error":{"message":"synthetic upstream detail"}}"#);
                let error =
                    ProviderError::new(ProviderErrorKind::InvalidRequest, UpstreamSendState::Sent)
                        .with_client_visible_upstream_response(
                            ClientVisibleUpstreamResponse::new(
                                422,
                                Some(b"application/json".to_vec()),
                                raw.clone(),
                            )
                            .with_headers(upstream_headers),
                        );
                let session = failed_session(streaming, EngineError::Provider(error))
                    .with_response_headers(headers(&[("x-request-id", "earlier-session")]));
                let response = response(&admin, provider, session, streaming).await;
                assert_eq!(response.status(), StatusCode::UNPROCESSABLE_ENTITY);
                assert_eq!(response.headers()["x-request-id"], expected);
                assert_eq!(response.headers()["x-gateway-request-id"], MODEL_REQUEST_ID);
                assert_eq!(to_bytes(response.into_body(), 4096).await.unwrap(), raw);
            }

            let error =
                ProviderError::new(ProviderErrorKind::Transport, UpstreamSendState::Ambiguous)
                    .with_status(503)
                    .with_upstream_request_id(OpaqueUpstreamValue::new("body-read-error"));
            let session = failed_session(streaming, EngineError::Provider(error))
                .with_response_headers(headers(&[
                    ("x-request-id", "earlier-session"),
                    ("x-oai-request-id", "earlier-alias"),
                ]));
            let response = response(&admin, provider, session, streaming).await;
            assert_eq!(response.status(), StatusCode::BAD_GATEWAY);
            assert_eq!(response.headers()["x-request-id"], "body-read-error");
            assert_eq!(response.headers().get_all("x-request-id").iter().count(), 1);
            assert!(response.headers().get("x-oai-request-id").is_none());
            assert_eq!(response.headers()["x-gateway-request-id"], MODEL_REQUEST_ID);
        }
    }
}

#[tokio::test]
async fn local_execution_failure_uses_the_existing_model_id() {
    let admin = crate::admin::AdminTestFixture::new().await.services;
    for provider in ["openai", "xai"] {
        for streaming in [false, true] {
            let session =
                failed_session(streaming, EngineError::Deadline).with_response_headers(headers(&[
                    ("x-request-id", "opening-primary"),
                    ("x-oai-request-id", "opening-alias"),
                    ("x-codex-turn-state", "retained-turn-state"),
                ]));
            let response = response(&admin, provider, session, streaming).await;
            assert_eq!(response.headers()["x-request-id"], MODEL_REQUEST_ID);
            assert_eq!(response.headers()["x-gateway-request-id"], MODEL_REQUEST_ID);
            assert!(response.headers().get("x-oai-request-id").is_none());
            assert_eq!(
                response.headers()["x-codex-turn-state"],
                "retained-turn-state"
            );
        }
    }
}

#[tokio::test]
async fn compressed_http_request_above_default_limit_should_reach_execution_after_increase() {
    let admin = crate::admin::AdminTestFixture::new().await.services;
    let body = json!({"model": "model-a", "input": "x".repeat(64 * 1024 * 1024)}).to_string();
    let compressed = super::request::encode_body("zstd", body.as_bytes());
    for limit in [64 * 1024 * 1024, 128 * 1024 * 1024] {
        let observed = Arc::new(Mutex::new(None));
        let execution = Arc::new(ContextCaptureExecution {
            observed: Arc::clone(&observed),
            client: crate::openai::authenticated_client_for_provider_with_limit(
                "sk_context_test",
                "openai",
                limit,
            ),
        });
        let response = crate::openai::api_router_with_admin_and_execution(admin.clone(), execution)
            .oneshot(
                Request::post("/v1/responses")
                    .header(AUTHORIZATION, "Bearer sk_context_test")
                    .header(CONTENT_ENCODING, "zstd")
                    .body(Body::from(compressed.clone()))
                    .unwrap(),
            )
            .await
            .unwrap();
        if limit == 64 * 1024 * 1024 {
            assert_eq!(response.status(), StatusCode::BAD_REQUEST);
            assert!(observed.lock().unwrap().is_none());
            let error: Value =
                serde_json::from_slice(&to_bytes(response.into_body(), usize::MAX).await.unwrap())
                    .unwrap();
            assert_eq!(error["error"]["code"], "request_too_large");
        } else {
            // 捕获执行服务刻意返回 500；断言完整输入到达执行层，而不是只验证路由状态码
            let captured = observed
                .lock()
                .unwrap()
                .take()
                .expect("request reached execution");
            assert_eq!(
                captured.input.unwrap().as_str().unwrap().len(),
                64 * 1024 * 1024
            );
        }
    }
}

#[tokio::test]
async fn streaming_middleware_preserves_heartbeats_before_and_after_rewriting() {
    let admin = crate::admin::AdminTestFixture::new().await.services;
    for opaque in [
        b": ping\n\n".as_slice(),
        b"id: next\nretry: 1000\n\n".as_slice(),
        b"event: vendor.future\ndata: future non-JSON payload\n\n".as_slice(),
    ] {
        let trace = Arc::new(Trace::default());
        let heartbeat = Bytes::copy_from_slice(opaque);
        let future = Bytes::from_static(
            b"event: response.future\ndata: {\"type\":\"response.future\",\"extension\":true}\n\n",
        );
        let session = FakeSession::streaming(
            Arc::clone(&trace),
            vec![
                NextStep::Event(delivery(started(), CommitRequirement::CommitBeforeDelivery)),
                NextStep::Event(delivery_provider(
                    ProviderEvent::wire(
                        ProtocolWireEvent::raw_sse("openai", heartbeat.clone()).unwrap(),
                    ),
                    CommitRequirement::AlreadyCommitted,
                )),
                NextStep::Event(delivery_provider(
                    ProviderEvent::wire(
                        ProtocolWireEvent::raw_sse("openai", future.clone()).unwrap(),
                    ),
                    CommitRequirement::AlreadyCommitted,
                )),
                NextStep::Event(delivery_provider(
                    ProviderEvent::wire(
                        ProtocolWireEvent::raw_sse("openai", heartbeat.clone()).unwrap(),
                    ),
                    CommitRequirement::AlreadyCommitted,
                )),
                NextStep::Event(delivery(completed(), CommitRequirement::AlreadyCommitted)),
                NextStep::FinalizeSuccess,
            ],
        );
        let replacement = Bytes::from_static(b"event: response.future\ndata: {\"type\":\"response.future\",\"extension\":\"changed\"}\n\n");
        let middleware = Arc::new(responses_middleware().with_response_actions(vec![
            ResponseFrameAction::Continue,
            ResponseFrameAction::Continue,
            ResponseFrameAction::Replace(replacement.clone()),
            ResponseFrameAction::Continue,
            ResponseFrameAction::Continue,
            ResponseFrameAction::Continue,
        ]));
        let response =
            response_with_middleware(&admin, "openai", session, true, Some(middleware)).await;
        let body = to_bytes(response.into_body(), usize::MAX).await.unwrap();
        let text = std::str::from_utf8(&body).unwrap();
        assert_eq!(
            text.matches(std::str::from_utf8(opaque).unwrap()).count(),
            2
        );
        assert!(text.contains(std::str::from_utf8(&replacement).unwrap()));
        assert!(text.contains("response.completed"));
        assert!(!text.contains("middleware_failed"));
        assert!(text.ends_with("data: [DONE]\n\n"));
        assert!(!trace.is_cancelled());
    }
}

#[tokio::test(start_paused = true)]
async fn responses_route_should_keep_alive_while_request_middleware_waits_for_first_event() {
    let admin = crate::admin::AdminTestFixture::new().await.services;
    for invalid_output in [false, true] {
        let trace = Arc::new(Trace::default());
        let session = FakeSession::streaming(
            Arc::clone(&trace),
            vec![
                NextStep::DelayedEvent(
                    Duration::from_secs(150),
                    delivery(started(), CommitRequirement::CommitBeforeDelivery),
                ),
                NextStep::Event(delivery(completed(), CommitRequirement::AlreadyCommitted)),
                NextStep::FinalizeSuccess,
            ],
        );
        let actions = if invalid_output {
            vec![ResponseFrameAction::Replace(Bytes::from_static(
                b"data: {invalid-json}\n\n",
            ))]
        } else {
            Vec::new()
        };
        let middleware = Arc::new(responses_middleware().with_response_actions(actions));
        let response = tokio::time::timeout(
            Duration::from_secs(20),
            response_with_middleware(&admin, "openai", session, true, Some(middleware)),
        )
        .await
        .expect("request middleware must not block transport keepalive");
        assert_eq!(response.status(), StatusCode::OK);
        assert!(response.headers().contains_key("x-gateway-request-id"));
        let bytes = to_bytes(response.into_body(), usize::MAX).await.unwrap();
        let text = std::str::from_utf8(&bytes).unwrap();
        assert!(text.starts_with(": keep-alive\n\n"));
        assert!(text.ends_with("data: [DONE]\n\n"));
        if invalid_output {
            assert!(text.contains("response.failed"));
            assert!(text.contains("middleware_failed"));
            assert!(!text.contains("{invalid-json}"));
            assert!(trace.is_cancelled());
        } else {
            assert!(text.contains("response.completed"));
            assert!(!text.contains("response.failed"));
            assert!(!trace.is_cancelled());
        }
        assert_eq!(trace.client_statuses(), vec![200]);
    }
}
