//! 网关核心使用的稳定错误分类

mod details;
mod source;
pub use details::ErrorDetails;

pub use source::ErrorSource;

use std::fmt;
use std::num::NonZeroU32;
use std::time::Duration;

use bytes::Bytes;
use thiserror::Error;

use crate::event::{ProviderEvent, ProviderResponseHeader};
pub use crate::upstream::OpaqueUpstreamValue;
use crate::upstream::UpstreamSendState;
pub use crate::validation::{
    IdentifierError, MeteringError, OperationError, PolicyError, RoutingError,
};

/// 跨 Provider 稳定的上游失败分类
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[non_exhaustive]
pub enum ProviderErrorKind {
    /// 请求语义错误
    InvalidRequest,
    /// previous-response 续接状态已不可用，需要客户端重建请求链
    ContinuationRecoveryRequired,
    /// Provider 不支持所需能力
    Unsupported,
    /// Credential 认证失败
    Unauthorized,
    /// Credential 没有权限
    PermissionDenied,
    /// 冻结的请求策略在 Provider 发送前明确拒绝本次请求
    RequestPolicyDenied,
    /// Provider 限流
    RateLimited,
    /// Credential 配额耗尽
    QuotaExhausted,
    /// 仍有符合条件的账号，但它们暂时没有可调度容量
    AccountCapacityUnavailable,
    ConcurrencyQueueFull,
    ConcurrencyQueueTimeout,
    /// Provider 已确认当前请求无法选出可用账号
    NoEligibleAccount,
    /// 会话已有的策略限制排除了可用账号，本地选号终止且不允许重放
    SessionPolicyRestricted,
    /// Provider 的账号存储、租约协调或本地凭据数据不可用
    ProviderInfrastructureUnavailable,
    /// 请求超时
    Timeout,
    /// 网络或 transport 失败
    Transport,
    /// 上游协议不合法
    Protocol,
    /// 上游以 message too big 拒收当前请求（如 WebSocket close 1009）
    /// 这是请求自身的问题：换账号或暂停 Provider 都无法让它成功
    MessageTooBig,
    /// Provider 暂不可用
    Unavailable,
    /// 上游明确拒绝当前请求的模型容量；不证明整个 Provider 的基础设施故障
    UpstreamCapacityUnavailable,
    /// 请求被取消
    Cancelled,
    /// 进程终止后由恢复流程收敛
    ProcessTerminated,
}

impl ProviderErrorKind {
    /// 返回可持久化的稳定名称
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::InvalidRequest => "invalid_request",
            Self::ContinuationRecoveryRequired => "continuation_recovery_required",
            Self::Unsupported => "unsupported",
            Self::Unauthorized => "unauthorized",
            Self::PermissionDenied => "permission_denied",
            Self::RequestPolicyDenied => "request_policy_denied",
            Self::RateLimited => "rate_limited",
            Self::QuotaExhausted => "quota_exhausted",
            Self::AccountCapacityUnavailable => "account_capacity_unavailable",
            Self::ConcurrencyQueueFull => "concurrency_queue_full",
            Self::ConcurrencyQueueTimeout => "concurrency_queue_timeout",
            Self::NoEligibleAccount => "no_eligible_account",
            Self::SessionPolicyRestricted => "session_policy_restricted",
            Self::ProviderInfrastructureUnavailable => "provider_infrastructure_unavailable",
            Self::Timeout => "timeout",
            Self::Transport => "transport",
            Self::Protocol => "protocol",
            Self::MessageTooBig => "message_too_big",
            Self::Unavailable => "unavailable",
            Self::UpstreamCapacityUnavailable => "upstream_capacity_unavailable",
            Self::Cancelled => "cancelled",
            Self::ProcessTerminated => "process_terminated",
        }
    }
}

/// Provider 对 previous-response 失败给出的稳定恢复语义
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ContinuationFailure {
    /// 原生 continuation 正被同账号的另一请求占用
    Busy,
    /// 原生 history 在当前连接或账号不可用，可由完整输入重放恢复
    HistoryUnavailable,
}

/// Provider 对 previous-response 失败给出的显式恢复边界
///
/// Core 不根据失败分类猜测 continuation 是否可迁移；只有 Provider 明确允许时，
/// 才能放宽 owner 范围
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ContinuationRecoveryDisposition {
    /// 只能再次取得同账号、同一精确连接，不能改变 continuation scope
    RetryExactConnection,
    /// 代理停止内部恢复，由客户端携带完整输入创建新链
    ClientReplayRequired,
    /// Provider 已证明可以进入 owner 或其他合法目标的恢复流程
    ProviderReplayAllowed,
}

/// 同账号瞬态错误的恢复策略，明确重试耗尽后的去向
///
/// Provider 按上游错误场景选择，Core 共用同一套退避与安全重放检查
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum TransientRetryPolicy {
    /// 同账号退避重试，耗尽后允许在安全边界与换号预算内选择其他账号
    RetryThenRotateAccount,
    /// 同账号退避重试，耗尽后返回最后一次上游错误，不因该错误换号
    RetryThenReturnError,
}

/// Provider 在下游尚未提交事件时请求的隐藏恢复方式
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum PreDeliveryRetry {
    /// 排除本次账号，按普通调度策略重新选号
    AccountRotation,
    /// 上游明确拒绝后的同账号退避；耗尽动作由 Provider 显式选择
    SameAccountTransientRetry {
        /// 每个账号在本请求中的重试上限，同时受总路由预算约束
        max_retries: NonZeroU32,
        /// 指数退避的起始间隔
        initial_delay: Duration,
        /// 本地指数退避的基准上限，不含附加抖动，也不缩短上游 Retry-After
        max_delay: Duration,
        /// Provider 为本次失败采样的附加等待，仅在没有 Retry-After 时使用
        jitter: Duration,
        /// 同账号恢复策略，不提供额外安全重放资格
        policy: TransientRetryPolicy,
    },
    /// 固定本次账号，并按 Provider 给出的序号重试当前传输
    /// 可用于发送结果不明确时的有界尽力恢复，不等于上游未执行的证明
    SameAccountTransportRetry {
        /// Provider-owned 传输重试序号，从 1 开始
        retry_index: NonZeroU32,
        /// 发起下一次传输尝试前的退避时长
        delay: Duration,
    },
    /// 可靠 NotSent 的建连恢复；次数与时间由 Core 的请求级预算裁决
    SameAccountConnectionRetry {
        /// Provider 明确指定实际失败的传输，避免 HTTP 恢复重新进入 WS
        transport: crate::upstream::AttemptTransport,
    },
    /// 固定本次账号，并要求 Provider 使用备用传输
    SameAccountTransportFallback,
}

/// 已由 Provider 从结构化上游错误中提取、仅供原客户端协议展示的错误详情
///
/// 它不是诊断日志或持久化错误信息：[`Debug`] 会隐藏全部值，调用方应只在
/// 原请求的协议响应中使用它
#[derive(Clone, PartialEq, Eq)]
pub struct ClientVisibleUpstreamError {
    message: String,
    code: Option<OpaqueUpstreamValue>,
    error_type: Option<OpaqueUpstreamValue>,
}

impl ClientVisibleUpstreamError {
    /// 原样保存结构化上游 `message`、`code` 和 `type`
    #[must_use]
    pub fn new(
        message: impl Into<String>,
        code: Option<String>,
        error_type: Option<String>,
    ) -> Self {
        Self {
            message: message.into(),
            code: code.map(OpaqueUpstreamValue::new),
            error_type: error_type.map(OpaqueUpstreamValue::new),
        }
    }

    /// 返回原上游的结构化 message
    #[must_use]
    pub fn message(&self) -> &str {
        &self.message
    }

    /// 返回原上游的结构化 code
    #[must_use]
    pub fn code(&self) -> Option<&str> {
        self.code.as_ref().map(OpaqueUpstreamValue::as_str)
    }

    /// 返回原上游的结构化 type
    #[must_use]
    pub fn error_type(&self) -> Option<&str> {
        self.error_type.as_ref().map(OpaqueUpstreamValue::as_str)
    }
}

impl fmt::Debug for ClientVisibleUpstreamError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("ClientVisibleUpstreamError(<redacted-from-Debug>)")
    }
}

/// 本次建连的代理诊断，仅用于管理端展示，不参与错误处置
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ProxyConnectionHint {
    InvalidConfiguration,
    Unreachable,
    TunnelFailed,
    CheckProxy,
}

impl ProxyConnectionHint {
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::InvalidConfiguration => "invalid_configuration",
            Self::Unreachable => "unreachable",
            Self::TunnelFailed => "tunnel_failed",
            Self::CheckProxy => "check_proxy",
        }
    }
}

/// Provider 已分类为可安全持久化和展示的诊断摘要
///
/// Adapter 只能放入不含凭据、cookie、原始请求正文和 opaque response ID 的有界摘要；
/// 原始上游错误返回由 [`RawUpstreamError`] 单独承载
#[derive(Clone, PartialEq, Eq)]
pub struct ProviderDiagnostic {
    proxy_hint: Option<ProxyConnectionHint>,
    message: String,
    stage: Option<&'static str>,
    code: Option<&'static str>,
}

impl ProviderDiagnostic {
    #[must_use]
    pub fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
            proxy_hint: None,
            stage: None,
            code: None,
        }
    }

    #[must_use]
    pub const fn with_proxy_hint(mut self, hint: ProxyConnectionHint) -> Self {
        self.proxy_hint = Some(hint);
        self
    }

    #[must_use]
    pub const fn proxy_hint(&self) -> Option<ProxyConnectionHint> {
        self.proxy_hint
    }

    /// 附着本地定义的阶段与原因码；独立于发送状态和重试策略
    #[must_use]
    pub const fn with_classification(mut self, stage: &'static str, code: &'static str) -> Self {
        self.stage = Some(stage);
        self.code = Some(code);
        self
    }

    /// 从错误链补充可证明的 I/O 原因；只保留本地原因码，不格式化原始错误
    #[must_use]
    pub fn with_io_cause(mut self, error: &(dyn std::error::Error + 'static)) -> Self {
        let mut source = Some(error);
        while let Some(error) = source {
            if let Some(error) = error.downcast_ref::<std::io::Error>() {
                let code = match error.kind() {
                    std::io::ErrorKind::NotFound => Some("io_not_found"),
                    std::io::ErrorKind::PermissionDenied => Some("io_permission_denied"),
                    std::io::ErrorKind::ConnectionRefused => Some("connection_refused"),
                    std::io::ErrorKind::ConnectionReset => Some("tcp_reset"),
                    std::io::ErrorKind::ConnectionAborted => Some("connection_aborted"),
                    std::io::ErrorKind::BrokenPipe => Some("broken_pipe"),
                    std::io::ErrorKind::UnexpectedEof => Some("unexpected_eof"),
                    std::io::ErrorKind::TimedOut => Some("io_timeout"),
                    std::io::ErrorKind::NetworkUnreachable => Some("network_unreachable"),
                    std::io::ErrorKind::HostUnreachable => Some("host_unreachable"),
                    _ => None,
                };
                if let Some(code) = code {
                    self.message.push_str("; I/O cause: ");
                    self.message.push_str(code);
                    if let Some(os_code) = error.raw_os_error() {
                        // 只重建操作系统错误，不能格式化可能包含 URL、路径或正文的自定义 I/O 错误
                        use std::fmt::Write as _;
                        let _ = write!(
                            self.message,
                            "; OS cause: {}",
                            std::io::Error::from_raw_os_error(os_code)
                        );
                    }
                    self.code = Some(code);
                    break;
                }
            }
            source = error.source();
        }
        self
    }

    #[must_use]
    pub const fn stage(&self) -> Option<&'static str> {
        self.stage
    }

    #[must_use]
    pub const fn code(&self) -> Option<&'static str> {
        self.code
    }

    #[must_use]
    pub fn as_str(&self) -> &str {
        &self.message
    }
}

impl fmt::Debug for ProviderDiagnostic {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("ProviderDiagnostic(<redacted-from-Debug>)")
    }
}

/// 运维错误详情中按原样展示的上游错误返回
///
/// 该值只接收响应方向的错误正文、WebSocket close/error frame 或上游适配插件 fault；不得放入请求
/// Authorization、Cookie 或客户端输入
/// 它会被持久化并由管理端显式返回，但普通
/// `Debug`/`Display` 不输出正文，避免在非运维日志中重复扩散
#[derive(Clone, PartialEq, Eq)]
pub struct RawUpstreamError(String);

impl RawUpstreamError {
    #[must_use]
    pub fn new(value: impl Into<String>) -> Self {
        Self(value.into())
    }

    #[must_use]
    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl fmt::Debug for RawUpstreamError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("RawUpstreamError(<present>)")
    }
}

/// Provider 上游物理连接结束时的低基数观测
///
/// 连接标识必须是随机或单向派生值，不得携带凭据、原始会话 ID
/// 或请求正文
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ProviderConnectionObservation {
    connection_id: String,
    exit_reason: String,
    age_ms: u64,
    idle_ms: u64,
}

impl ProviderConnectionObservation {
    #[must_use]
    pub fn new(
        connection_id: impl Into<String>,
        exit_reason: impl Into<String>,
        age_ms: u64,
        idle_ms: u64,
    ) -> Self {
        Self {
            connection_id: connection_id.into(),
            exit_reason: exit_reason.into(),
            age_ms,
            idle_ms,
        }
    }

    #[must_use]
    pub fn connection_id(&self) -> &str {
        &self.connection_id
    }

    #[must_use]
    pub fn exit_reason(&self) -> &str {
        &self.exit_reason
    }

    #[must_use]
    pub const fn age_ms(&self) -> u64 {
        self.age_ms
    }

    #[must_use]
    pub const fn idle_ms(&self) -> u64 {
        self.idle_ms
    }
}

/// 只供当前客户端请求使用的 HTTP 失败响应
///
/// 通常保留原始上游响应；Provider 也可为明确的恢复流程准备客户端投影
/// 投影不能覆盖 [`ProviderError`] 中用于诊断和记账的真实上游事实
///
/// 该值不属于稳定诊断事实，不能进入日志或持久化
/// 它刻意不实现 [`Clone`]；
/// [`ProviderError::stable_snapshot`] 会丢弃它，只有最终失败的原对象才能把响应交给
/// 原客户端协议，或由认证管理端的账号连接测试显式复制到请求局部结果
#[derive(PartialEq, Eq)]
pub struct ClientVisibleUpstreamResponse {
    status: u16,
    content_type: Option<Vec<u8>>,
    headers: Vec<ProviderResponseHeader>,
    body: Bytes,
}

impl ClientVisibleUpstreamResponse {
    /// 保存客户端响应的状态码、Content-Type 和正文
    #[must_use]
    pub fn new(status: u16, content_type: Option<Vec<u8>>, body: Bytes) -> Self {
        Self {
            status,
            content_type,
            headers: Vec::new(),
            body,
        }
    }

    /// 附加 Provider 已剔除账号绑定与 framing 信息的普通响应头
    #[must_use]
    pub fn with_headers(mut self, headers: Vec<ProviderResponseHeader>) -> Self {
        self.headers = headers;
        self
    }

    #[must_use]
    pub const fn status(&self) -> u16 {
        self.status
    }

    #[must_use]
    pub fn content_type(&self) -> Option<&[u8]> {
        self.content_type.as_deref()
    }

    #[must_use]
    pub fn headers(&self) -> &[ProviderResponseHeader] {
        &self.headers
    }

    #[must_use]
    pub const fn body(&self) -> &Bytes {
        &self.body
    }
}

impl fmt::Debug for ClientVisibleUpstreamResponse {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("ClientVisibleUpstreamResponse")
            .field("status", &self.status)
            .field(
                "content_type",
                &self.content_type.as_ref().map(|_| "<present>"),
            )
            .field("header_count", &self.headers.len())
            .field("body", &"<redacted>")
            .finish()
    }
}

/// 单次 Provider 调用的稳定错误
///
/// 稳定诊断字段不接收原始响应正文，也不会在 `Debug` 或 `Display` 中打印上游
/// code/request ID/response ID
/// 原始错误来源与上游响应正文仅由 [`ProviderError::error_details`] 提取到受控运维详情
/// 请求方向的凭据等敏感上下文必须先移除，并通过
/// [`ProviderError::redact_sensitive_context`] 留下脱敏标记
///
/// 唯一例外是 [`ProviderError::with_atomic_client_events`]：它只承载尚未交付客户端、
/// 必须与本错误一起完成重试判断的协议事件
/// Core 会在任何持久化或日志记录前取走
/// 这些事件，不能把它们当作诊断上下文使用
pub struct ProviderError {
    kind: ProviderErrorKind,
    send_state: UpstreamSendState,
    upstream_status: Option<u16>,
    upstream_values: Option<Box<ProviderErrorUpstreamValues>>,
    retry_after: Option<Duration>,
    continuation_failure: Option<ContinuationFailure>,
    continuation_recovery_disposition: Option<ContinuationRecoveryDisposition>,
    failure_observation: Option<Box<ProviderErrorFailureObservation>>,
    replay_safe: bool,
    retry_prohibited: bool,
    same_account_retry_blocked: bool,
    pre_delivery_retry: Option<Box<PreDeliveryRetry>>,
    credential_recovery_required: bool,
    retry_same_account: bool,
    sensitive_context_redacted: bool,
    diagnostic: Option<Box<ProviderDiagnostic>>,
    source: Option<ErrorSource>,
    raw_upstream_error: Option<Box<RawUpstreamError>>,
    client_visible_upstream_error: Option<Box<ClientVisibleUpstreamError>>,
    client_visible_upstream_response: Option<Box<ClientVisibleUpstreamResponse>>,
    atomic_client_events: Option<Box<AtomicClientEvents>>,
}

#[derive(Clone, Default)]
struct ProviderErrorUpstreamValues {
    failure_fields: Option<crate::upstream::UpstreamFailureFields>,
    code: Option<OpaqueUpstreamValue>,
    request_id: Option<OpaqueUpstreamValue>,
}

#[derive(Clone, Default)]
struct ProviderErrorFailureObservation {
    continuation_unavailable_reason: Option<&'static str>,
    connection: Option<ProviderConnectionObservation>,
}

#[derive(Clone)]
struct AtomicClientEvents(Vec<ProviderEvent>);

impl ProviderError {
    /// 创建 Provider 错误
    #[must_use]
    pub const fn new(kind: ProviderErrorKind, send_state: UpstreamSendState) -> Self {
        Self {
            kind,
            send_state,
            upstream_status: None,
            upstream_values: None,
            retry_after: None,
            continuation_failure: None,
            continuation_recovery_disposition: None,
            failure_observation: None,
            replay_safe: false,
            retry_prohibited: false,
            same_account_retry_blocked: false,
            pre_delivery_retry: None,
            credential_recovery_required: false,
            retry_same_account: false,
            sensitive_context_redacted: false,
            diagnostic: None,
            source: None,
            raw_upstream_error: None,
            client_visible_upstream_error: None,
            client_visible_upstream_response: None,
            atomic_client_events: None,
        }
    }

    /// 附加合法上游状态码
    #[must_use]
    pub fn with_status(mut self, status: u16) -> Self {
        if (100..=599).contains(&status) {
            self.upstream_status = Some(status);
        }
        self
    }

    /// 明确上游来源；本地错误不得使用这个入口构造匹配事实
    #[must_use]
    pub fn with_upstream_failure_fields(
        mut self,
        fields: crate::upstream::UpstreamFailureFields,
    ) -> Self {
        self.upstream_values_mut().failure_fields = Some(fields);
        self
    }

    #[must_use]
    pub fn upstream_failure_fields(&self) -> Option<&crate::upstream::UpstreamFailureFields> {
        self.upstream_values.as_ref()?.failure_fields.as_ref()
    }

    /// 保留原始上游错误 code，不参与普通格式化或替代稳定分类
    #[must_use]
    pub fn with_upstream_code(mut self, code: OpaqueUpstreamValue) -> Self {
        self.upstream_values_mut().code = Some(code);
        self
    }

    /// 附加 adapter 已分类为非 bearer 的上游 request ID
    #[must_use]
    pub fn with_upstream_request_id(mut self, request_id: OpaqueUpstreamValue) -> Self {
        self.upstream_values_mut().request_id = Some(request_id);
        self
    }

    fn upstream_values_mut(&mut self) -> &mut ProviderErrorUpstreamValues {
        self.upstream_values
            .get_or_insert_with(|| Box::new(ProviderErrorUpstreamValues::default()))
    }

    /// 附加 Provider 建议的冷却时间
    #[must_use]
    pub const fn with_retry_after(mut self, retry_after: Duration) -> Self {
        self.retry_after = Some(retry_after);
        self
    }

    /// 附加 previous-response 的恢复语义
    #[must_use]
    pub const fn with_continuation_failure(mut self, failure: ContinuationFailure) -> Self {
        self.continuation_failure = Some(failure);
        self
    }

    /// 附加 Provider 明确选择的 previous-response 恢复边界
    #[must_use]
    pub const fn with_continuation_recovery_disposition(
        mut self,
        disposition: ContinuationRecoveryDisposition,
    ) -> Self {
        self.continuation_recovery_disposition = Some(disposition);
        self
    }

    /// 附加 Provider 给出的低基数 continuation 不可用原因
    #[must_use]
    pub fn with_continuation_unavailable_reason(mut self, reason: &'static str) -> Self {
        self.failure_observation_mut()
            .continuation_unavailable_reason = Some(reason);
        self
    }

    /// 附加上游物理连接结束观测
    #[must_use]
    pub fn with_connection_observation(
        mut self,
        observation: ProviderConnectionObservation,
    ) -> Self {
        self.failure_observation_mut().connection = Some(observation);
        self
    }

    fn failure_observation_mut(&mut self) -> &mut ProviderErrorFailureObservation {
        self.failure_observation
            .get_or_insert_with(|| Box::new(ProviderErrorFailureObservation::default()))
    }

    /// 标记 Provider 已证明本次失败可在下游提交前安全重放
    ///
    /// 证明可以来自明确的“未执行”拒绝，也可以来自同 attempt 已交付、可恢复
    /// 同一业务请求的状态检查点；后者仍须由 Core 的同账号恢复门禁单独校验
    #[must_use]
    pub const fn with_replay_safe(mut self) -> Self {
        self.replay_safe = true;
        self
    }

    /// 标记必须交付客户端的终止拒绝，即使 payload 未发送也不自动重试
    #[must_use]
    pub const fn with_retry_prohibited(mut self) -> Self {
        self.retry_prohibited = true;
        self
    }

    /// 返回 Provider 是否明确禁止本请求的重试与传输回退
    #[must_use]
    pub const fn retry_is_prohibited(&self) -> bool {
        self.retry_prohibited
    }

    /// 保留已选择的耗尽策略，但禁止执行同账号退避和传输恢复
    ///
    /// Provider 在上游明确拒绝继续使用当前账号时设置
    /// Core 不根据错误码自行推断
    #[must_use]
    pub const fn with_same_account_retry_blocked(mut self) -> Self {
        self.same_account_retry_blocked = true;
        self
    }

    /// 返回上游是否拒绝继续重试当前账号
    #[must_use]
    pub const fn same_account_retry_blocked(&self) -> bool {
        self.same_account_retry_blocked
    }

    /// 允许 Core 仅在客户端尚未收到任何事件时执行一次受预算约束的换号恢复
    ///
    /// 该标记不证明上游未执行，也不等价于 [`Self::with_replay_safe`]；它只表达
    /// Provider 选择了“客户端无感恢复优先”的传输策略
    /// Core 在 continuation、
    /// 指定账号或下游已经进入提交状态时必须忽略它
    #[must_use]
    pub fn with_pre_delivery_retry(mut self) -> Self {
        self.pre_delivery_retry = Some(Box::new(PreDeliveryRetry::AccountRotation));
        self
    }

    /// 允许 Core 在首个客户端事件前固定原账号并改用 Provider 备用传输
    ///
    /// Provider 必须确认备用传输满足当前 continuation scope 并限制恢复次数
    /// Core 保持原账号，拒绝预算耗尽、外部副作用或下游已提交后的隐藏重放
    #[must_use]
    pub fn with_pre_delivery_transport_fallback(mut self) -> Self {
        self.set_pre_delivery_transport_fallback();
        self
    }

    /// 原地设置同账号备用传输恢复，保留当前错误携带的原客户端响应
    pub fn set_pre_delivery_transport_fallback(&mut self) {
        self.pre_delivery_retry = Some(Box::new(PreDeliveryRetry::SameAccountTransportFallback));
    }

    /// 允许 Core 在首个客户端事件前固定原账号并重试当前 Provider 传输
    ///
    /// 重试预算和退避策略由 Provider 所属协议定义；Core 只负责同账号钉选、
    /// deadline/取消边界以及下游 commit barrier
    /// 该意图允许发送结果不明确时尽力恢复，但不修改发送事实或安全重放证明
    #[must_use]
    pub fn with_pre_delivery_transport_retry(
        mut self,
        retry_index: NonZeroU32,
        delay: Duration,
    ) -> Self {
        self.set_pre_delivery_transport_retry(retry_index, delay);
        self
    }

    /// 原地设置同账号当前传输重试，保留当前错误携带的原客户端响应
    pub fn set_pre_delivery_transport_retry(&mut self, retry_index: NonZeroU32, delay: Duration) {
        self.pre_delivery_retry = Some(Box::new(PreDeliveryRetry::SameAccountTransportRetry {
            retry_index,
            delay,
        }));
    }

    #[must_use]
    pub fn with_connection_retry(mut self, transport: crate::upstream::AttemptTransport) -> Self {
        self.pre_delivery_retry = Some(Box::new(PreDeliveryRetry::SameAccountConnectionRetry {
            transport,
        }));
        self
    }

    /// 要求 Core 在账号凭据已恢复后仅对原账号重放一次
    #[must_use]
    pub const fn with_same_account_retry(mut self) -> Self {
        self.retry_same_account = true;
        self
    }

    /// 请求有界同账号退避并显式选择耗尽去向；该意图本身不提供安全重放证据
    #[must_use]
    pub fn with_transient_retry(
        mut self,
        max_retries: NonZeroU32,
        initial_delay: Duration,
        max_delay: Duration,
        jitter: Duration,
        policy: TransientRetryPolicy,
    ) -> Self {
        self.pre_delivery_retry = Some(Box::new(PreDeliveryRetry::SameAccountTransientRetry {
            max_retries,
            initial_delay,
            max_delay,
            jitter,
            policy,
        }));
        self
    }

    /// 标记上游明确拒绝应先触发 OAuth 恢复，而不是直接废弃账号
    #[must_use]
    pub const fn with_credential_recovery(mut self) -> Self {
        self.credential_recovery_required = true;
        self
    }

    /// 附加只用于原客户端协议响应的结构化上游错误
    #[must_use]
    pub fn with_client_visible_upstream_error(mut self, error: ClientVisibleUpstreamError) -> Self {
        self.client_visible_upstream_error = Some(Box::new(error));
        self
    }

    /// 附加仅可返回给当前请求方的原始上游 HTTP 失败响应
    #[must_use]
    pub fn with_client_visible_upstream_response(
        mut self,
        response: ClientVisibleUpstreamResponse,
    ) -> Self {
        self.client_visible_upstream_response = Some(Box::new(response));
        self
    }

    /// 附加必须先由 Core 判断重试、再决定丢弃或交付的客户端协议事件
    ///
    /// Provider 只能放入当前 attempt 尚未交付的事件；调用方应设置明确的有界缓冲，
    /// 并保证失败事件本身位于这批事件的末尾
    #[must_use]
    pub fn with_atomic_client_events(mut self, events: Vec<ProviderEvent>) -> Self {
        self.atomic_client_events =
            (!events.is_empty()).then(|| Box::new(AtomicClientEvents(events)));
        self
    }

    /// 丢弃敏感正文，只记录“发生过脱敏”这一事实
    #[must_use]
    pub fn redact_sensitive_context(mut self, _sensitive_context: impl AsRef<str>) -> Self {
        self.sensitive_context_redacted = true;
        self
    }

    /// 附加 Adapter 已确认可安全持久化和展示的诊断摘要
    #[must_use]
    pub fn with_diagnostic(mut self, diagnostic: ProviderDiagnostic) -> Self {
        self.diagnostic = Some(Box::new(diagnostic));
        self
    }

    /// 附加将由运维错误详情原样展示的上游错误返回
    #[must_use]
    pub fn with_raw_upstream_error(mut self, error: RawUpstreamError) -> Self {
        self.raw_upstream_error = Some(Box::new(error));
        self
    }

    /// 返回稳定错误分类
    #[must_use]
    pub const fn kind(&self) -> ProviderErrorKind {
        self.kind
    }

    /// 返回本次 payload 的保守发送状态
    #[must_use]
    pub const fn send_state(&self) -> UpstreamSendState {
        self.send_state
    }

    /// 返回合法上游状态码
    #[must_use]
    pub const fn upstream_status(&self) -> Option<u16> {
        self.upstream_status
    }

    /// 返回安全分类的上游错误 code
    #[must_use]
    pub fn upstream_code(&self) -> Option<&OpaqueUpstreamValue> {
        self.upstream_values
            .as_deref()
            .and_then(|values| values.code.as_ref())
    }

    /// 返回安全分类的上游 request ID
    #[must_use]
    pub fn upstream_request_id(&self) -> Option<&OpaqueUpstreamValue> {
        self.upstream_values
            .as_deref()
            .and_then(|values| values.request_id.as_ref())
    }

    /// 返回 Provider 建议的冷却时间
    #[must_use]
    pub const fn retry_after(&self) -> Option<Duration> {
        self.retry_after
    }

    /// 返回 previous-response 的恢复语义
    #[must_use]
    pub const fn continuation_failure(&self) -> Option<ContinuationFailure> {
        self.continuation_failure
    }

    /// 返回 Provider 明确选择的 previous-response 恢复边界
    #[must_use]
    pub const fn continuation_recovery_disposition(
        &self,
    ) -> Option<ContinuationRecoveryDisposition> {
        self.continuation_recovery_disposition
    }

    #[must_use]
    pub fn continuation_unavailable_reason(&self) -> Option<&'static str> {
        match self.failure_observation.as_deref() {
            Some(observation) => observation.continuation_unavailable_reason,
            None => None,
        }
    }

    #[must_use]
    pub fn connection_observation(&self) -> Option<&ProviderConnectionObservation> {
        self.failure_observation
            .as_deref()
            .and_then(|observation| observation.connection.as_ref())
    }

    /// 返回 Provider 是否已证明本次失败可安全重放
    #[must_use]
    pub const fn replay_is_safe(&self) -> bool {
        self.replay_safe
    }

    /// 返回 Provider 是否允许在首个客户端事件前隐藏恢复传输失败
    #[must_use]
    pub const fn allows_pre_delivery_retry(&self) -> bool {
        self.pre_delivery_retry.is_some()
    }

    /// 返回下游提交前由 Provider 选择的隐藏恢复方式
    #[must_use]
    pub const fn pre_delivery_retry(&self) -> Option<PreDeliveryRetry> {
        match self.pre_delivery_retry.as_ref() {
            Some(retry) => Some(**retry),
            None => None,
        }
    }

    /// 返回 Provider 是否已完成凭据恢复并要求原账号重放
    #[must_use]
    pub const fn retries_same_account(&self) -> bool {
        self.retry_same_account
    }

    #[must_use]
    pub const fn requires_credential_recovery(&self) -> bool {
        self.credential_recovery_required
    }

    /// 表示 adapter 是否丢弃过敏感错误正文
    #[must_use]
    pub const fn sensitive_context_was_redacted(&self) -> bool {
        self.sensitive_context_redacted
    }

    /// 返回可安全持久化和展示的 Provider 诊断摘要
    #[must_use]
    pub fn diagnostic(&self) -> Option<&ProviderDiagnostic> {
        self.diagnostic.as_deref()
    }

    /// 包装底层失败；来源只供显式诊断访问，不改变分类和发送事实
    #[must_use]
    pub fn with_source(mut self, source: impl Into<crate::error::ErrorSource>) -> Self {
        self.source = Some(source.into());
        self
    }

    /// 运维详情的唯一投影入口，来源链与上游正文分别保留，不进入公共响应或诊断包
    #[must_use]
    pub fn error_details(&self) -> Option<String> {
        ErrorDetails::capture(
            self.source.as_ref(),
            self.raw_upstream_error(),
            self.sensitive_context_was_redacted(),
        )
        .map(ErrorDetails::into_string)
    }

    /// 返回将由运维错误详情原样展示的上游错误返回
    #[must_use]
    pub fn raw_upstream_error(&self) -> Option<&RawUpstreamError> {
        self.raw_upstream_error.as_deref()
    }

    /// 返回仅供原客户端协议展示的结构化上游错误
    #[must_use]
    pub fn client_visible_upstream_error(&self) -> Option<&ClientVisibleUpstreamError> {
        self.client_visible_upstream_error.as_deref()
    }

    /// 返回只供当前协议响应使用的原始上游 HTTP 失败响应
    #[must_use]
    pub fn client_visible_upstream_response(&self) -> Option<&ClientVisibleUpstreamResponse> {
        self.client_visible_upstream_response.as_deref()
    }

    /// 取走只供本次重试/提交决策使用的原子客户端事件
    ///
    /// Core 必须在创建稳定快照、记录中间失败或构造终态前调用本方法，避免原始
    /// wire 进入诊断或持久化对象
    #[must_use]
    pub fn take_atomic_client_events(&mut self) -> Vec<ProviderEvent> {
        self.atomic_client_events
            .take()
            .map_or_else(Vec::new, |events| events.0)
    }

    /// 返回是否携带尚未提交的原子客户端事件；不暴露事件内容
    #[must_use]
    pub fn has_atomic_client_events(&self) -> bool {
        self.atomic_client_events.is_some()
    }

    /// 复制可安全进入诊断和持久化边界的稳定错误事实
    ///
    /// 保留原因链和上游错误详情；供协议透传的完整响应与尚未提交的客户端事件不进入快照
    #[must_use]
    pub fn stable_snapshot(&self) -> Self {
        Self {
            kind: self.kind,
            send_state: self.send_state,
            upstream_status: self.upstream_status,
            upstream_values: self.upstream_values.clone(),
            retry_after: self.retry_after,
            continuation_failure: self.continuation_failure,
            continuation_recovery_disposition: self.continuation_recovery_disposition,
            failure_observation: self.failure_observation.clone(),
            replay_safe: self.replay_safe,
            retry_prohibited: self.retry_prohibited,
            same_account_retry_blocked: self.same_account_retry_blocked,
            pre_delivery_retry: self.pre_delivery_retry.clone(),
            credential_recovery_required: self.credential_recovery_required,
            retry_same_account: self.retry_same_account,
            sensitive_context_redacted: self.sensitive_context_redacted,
            diagnostic: self.diagnostic.clone(),
            source: self.source.clone(),
            raw_upstream_error: self.raw_upstream_error.clone(),
            client_visible_upstream_error: self.client_visible_upstream_error.clone(),
            client_visible_upstream_response: None,
            atomic_client_events: None,
        }
    }
}

impl fmt::Debug for ProviderError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("ProviderError")
            .field("kind", &self.kind)
            .field("send_state", &self.send_state)
            .field("upstream_status", &self.upstream_status)
            .field("upstream_code", &self.upstream_code().map(|_| "<opaque>"))
            .field(
                "upstream_request_id",
                &self.upstream_request_id().map(|_| "<classified-safe>"),
            )
            .field("retry_after", &self.retry_after)
            .field("retry_prohibited", &self.retry_prohibited)
            .field(
                "same_account_retry_blocked",
                &self.same_account_retry_blocked,
            )
            .field("continuation_failure", &self.continuation_failure)
            .field(
                "continuation_recovery_disposition",
                &self.continuation_recovery_disposition,
            )
            .field(
                "continuation_unavailable_reason",
                &self.continuation_unavailable_reason(),
            )
            .field("connection_observation", &self.connection_observation())
            .field("replay_safe", &self.replay_safe)
            .field("pre_delivery_retry", &self.pre_delivery_retry)
            .field(
                "credential_recovery_required",
                &self.credential_recovery_required,
            )
            .field("retry_same_account", &self.retry_same_account)
            .field(
                "sensitive_context",
                &self.sensitive_context_redacted.then_some("<redacted>"),
            )
            .field(
                "diagnostic",
                &self.diagnostic.as_deref().map(|_| "<present>"),
            )
            .field(
                "raw_upstream_error",
                &self.raw_upstream_error.as_ref().map(|_| "<present>"),
            )
            .field(
                "client_visible_upstream_error",
                &self
                    .client_visible_upstream_error
                    .as_ref()
                    .map(|_| "<present>"),
            )
            .field(
                "client_visible_upstream_response",
                &self
                    .client_visible_upstream_response
                    .as_ref()
                    .map(|_| "<present>"),
            )
            .field(
                "atomic_client_events",
                &self
                    .atomic_client_events
                    .as_ref()
                    .map_or(0, |events| events.0.len()),
            )
            .finish()
    }
}

impl fmt::Display for ProviderError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "provider call failed: {}", self.kind.as_str())
    }
}

impl std::error::Error for ProviderError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        self.source.as_deref().map(|source| source as _)
    }
}

/// 对客户端协议稳定的网关错误分类
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[non_exhaustive]
pub enum GatewayErrorKind {
    /// 请求无效
    InvalidRequest,
    /// 请求再次进入已经过的部署
    PeerRoutingLoop,
    /// 请求能力不支持
    Unsupported,
    /// 下游认证失败
    Unauthorized,
    /// 调用方策略拒绝
    PolicyDenied,
    /// 对外模型或 route 不存在
    ModelNotFound,
    /// 当前没有可用 target
    NoAvailableProvider,
    /// 符合条件的上游账号暂时没有调度容量
    AccountCapacityUnavailable,
    /// 中间件在途资源或执行等待队列已满
    MiddlewareCapacityUnavailable,
    ConcurrencyQueueFull,
    ConcurrencyQueueTimeout,
    /// Provider 的本地账号基础设施不可用
    ProviderInfrastructureUnavailable,
    /// 上游限流
    RateLimited,
    /// 当前客户端 Key 的费用预算耗尽
    BudgetExhausted,
    /// 上游暂不可用
    UpstreamUnavailable,
    /// 上游拒收当前请求：消息过大（如 WebSocket close 1009）
    /// 客户端必须缩小或重建请求；重试或换账号都无法成功
    MessageTooBig,
    /// 请求超时
    Timeout,
    /// 请求取消
    Cancelled,
    /// 内部持久化或状态机失败
    Internal,
}

impl GatewayErrorKind {
    /// 返回适合客户端协议映射的稳定 code
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::InvalidRequest => "invalid_request",
            Self::PeerRoutingLoop => gateway_protocol::peer::ROUTING_LOOP_CODE,
            Self::Unsupported => "unsupported",
            Self::Unauthorized => "unauthorized",
            Self::PolicyDenied => "policy_denied",
            Self::ModelNotFound => "model_not_found",
            Self::NoAvailableProvider => "no_available_provider",
            Self::AccountCapacityUnavailable => "account_capacity_unavailable",
            Self::MiddlewareCapacityUnavailable => "middleware_capacity_unavailable",
            Self::ConcurrencyQueueFull => "concurrency_queue_full",
            Self::ConcurrencyQueueTimeout => "concurrency_queue_timeout",
            Self::ProviderInfrastructureUnavailable => "provider_infrastructure_unavailable",
            Self::RateLimited => "rate_limited",
            Self::BudgetExhausted => "budget_exhausted",
            Self::UpstreamUnavailable => "upstream_unavailable",
            Self::MessageTooBig => "message_too_big",
            Self::Timeout => "timeout",
            Self::Cancelled => "cancelled",
            Self::Internal => "internal_error",
        }
    }
}

/// 协议无关、可安全暴露的网关错误
#[derive(Clone, Error)]
#[error("{message}")]
pub struct GatewayError {
    kind: GatewayErrorKind,
    message: &'static str,
    diagnostic: Option<Box<ProviderDiagnostic>>,
    client_visible_upstream_error: Option<Box<ClientVisibleUpstreamError>>,
    client_details: Option<Box<GatewayClientErrorDetails>>,
    source: Option<ErrorSource>,
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
struct GatewayClientErrorDetails {
    code: Option<&'static str>,
    retry_after: Option<Duration>,
}

impl GatewayError {
    /// 使用静态安全消息创建错误
    #[must_use]
    pub const fn new(kind: GatewayErrorKind, message: &'static str) -> Self {
        Self {
            kind,
            message,
            diagnostic: None,
            client_visible_upstream_error: None,
            client_details: None,
            source: None,
        }
    }

    #[must_use]
    pub fn with_source(mut self, source: impl Into<ErrorSource>) -> Self {
        self.source = Some(source.into());
        self
    }

    #[must_use]
    pub fn error_details(&self) -> Option<ErrorDetails> {
        ErrorDetails::capture(self.source.as_ref(), None, false)
    }

    #[must_use]
    pub fn with_client_code(mut self, code: &'static str) -> Self {
        self.client_details
            .get_or_insert_with(Default::default)
            .code = Some(code);
        self
    }

    #[must_use]
    pub fn with_retry_after(mut self, delay: Duration) -> Self {
        self.client_details
            .get_or_insert_with(Default::default)
            .retry_after = Some(delay);
        self
    }

    #[must_use]
    pub fn retry_after(&self) -> Option<Duration> {
        self.client_details
            .as_ref()
            .and_then(|details| details.retry_after)
    }

    /// 将 Provider 错误归一为客户端无关错误
    #[must_use]
    pub fn from_provider(error: &ProviderError) -> Self {
        let gateway = match error.kind() {
            ProviderErrorKind::InvalidRequest
                if gateway_protocol::peer::is_routing_loop(
                    error.upstream_status(),
                    error.upstream_code().map(|code| code.as_str()),
                ) =>
            {
                Self::new(
                    GatewayErrorKind::PeerRoutingLoop,
                    "Peer routing loop detected.",
                )
            }
            ProviderErrorKind::InvalidRequest => Self::new(
                GatewayErrorKind::InvalidRequest,
                "Invalid upstream request.",
            ),
            ProviderErrorKind::SessionPolicyRestricted => Self::new(
                GatewayErrorKind::InvalidRequest,
                "No accounts are available under this conversation's restrictions.",
            ),
            ProviderErrorKind::ContinuationRecoveryRequired => Self::new(
                GatewayErrorKind::InvalidRequest,
                "Previous response unavailable. Resend the full conversation history.",
            ),
            ProviderErrorKind::Unsupported => Self::new(
                GatewayErrorKind::Unsupported,
                "Requested capability is unsupported.",
            ),
            ProviderErrorKind::Unauthorized | ProviderErrorKind::PermissionDenied => Self::new(
                GatewayErrorKind::UpstreamUnavailable,
                "The upstream account cannot access the service.",
            ),
            ProviderErrorKind::RequestPolicyDenied => {
                Self::new(GatewayErrorKind::PolicyDenied, "Request blocked by policy.")
            }
            ProviderErrorKind::RateLimited | ProviderErrorKind::QuotaExhausted => Self::new(
                GatewayErrorKind::RateLimited,
                "Upstream capacity is temporarily unavailable.",
            ),
            ProviderErrorKind::ConcurrencyQueueFull => Self::new(
                GatewayErrorKind::ConcurrencyQueueFull,
                "Request queue is full.",
            ),
            ProviderErrorKind::ConcurrencyQueueTimeout => Self::new(
                GatewayErrorKind::ConcurrencyQueueTimeout,
                "Request queue wait timed out.",
            ),
            ProviderErrorKind::AccountCapacityUnavailable => Self::new(
                GatewayErrorKind::AccountCapacityUnavailable,
                "All eligible upstream accounts are temporarily busy.",
            ),
            ProviderErrorKind::NoEligibleAccount => Self::new(
                GatewayErrorKind::NoAvailableProvider,
                "No upstream provider is available for this request.",
            ),
            ProviderErrorKind::ProviderInfrastructureUnavailable => Self::new(
                GatewayErrorKind::ProviderInfrastructureUnavailable,
                "Upstream accounts are temporarily inaccessible.",
            ),
            ProviderErrorKind::Timeout => {
                Self::new(GatewayErrorKind::Timeout, "Upstream request timed out.")
            }
            ProviderErrorKind::MessageTooBig => Self::new(
                GatewayErrorKind::MessageTooBig,
                "Request too large. Reduce the input size.",
            ),
            ProviderErrorKind::Cancelled => {
                Self::new(GatewayErrorKind::Cancelled, "Request was cancelled.")
            }
            ProviderErrorKind::Transport
            | ProviderErrorKind::Protocol
            | ProviderErrorKind::Unavailable
            | ProviderErrorKind::UpstreamCapacityUnavailable
            | ProviderErrorKind::ProcessTerminated => Self::new(
                GatewayErrorKind::UpstreamUnavailable,
                "Upstream service is unavailable.",
            ),
        };
        let gateway = match error.diagnostic() {
            Some(diagnostic) => gateway.with_diagnostic(diagnostic.clone()),
            None => gateway,
        };
        match error.client_visible_upstream_error() {
            Some(upstream) => gateway.with_client_visible_upstream_error(upstream.clone()),
            None => gateway,
        }
    }

    /// 附加只供运维观测使用的脱敏 Provider 摘要
    #[must_use]
    pub fn with_diagnostic(mut self, diagnostic: ProviderDiagnostic) -> Self {
        self.diagnostic = Some(Box::new(diagnostic));
        self
    }

    /// 附加只供请求方协议展示的结构化上游错误
    #[must_use]
    pub fn with_client_visible_upstream_error(mut self, error: ClientVisibleUpstreamError) -> Self {
        self.client_visible_upstream_error = Some(Box::new(error));
        self
    }

    /// 返回稳定错误分类
    #[must_use]
    pub const fn kind(&self) -> GatewayErrorKind {
        self.kind
    }

    /// 返回已经脱敏的静态消息
    #[must_use]
    pub const fn safe_message(&self) -> &'static str {
        self.message
    }

    /// 返回可安全持久化和展示的 Provider 诊断摘要
    #[must_use]
    pub fn diagnostic(&self) -> Option<&ProviderDiagnostic> {
        self.diagnostic.as_deref()
    }

    /// 返回优先用于原客户端协议响应的 message；持久化和日志必须继续使用
    /// [`Self::safe_message`]
    #[must_use]
    pub fn client_message(&self) -> &str {
        self.client_visible_upstream_error
            .as_deref()
            .map_or(self.message, ClientVisibleUpstreamError::message)
    }

    /// 返回原上游结构化 error type；没有时调用方应回退稳定网关 type
    #[must_use]
    pub fn client_error_type(&self) -> Option<&str> {
        self.client_visible_upstream_error
            .as_deref()
            .and_then(ClientVisibleUpstreamError::error_type)
    }

    /// 返回原上游结构化 error code；没有时调用方应回退稳定网关 code
    #[must_use]
    pub fn client_error_code(&self) -> Option<&str> {
        self.client_visible_upstream_error
            .as_deref()
            .and_then(ClientVisibleUpstreamError::code)
            .or_else(|| {
                self.client_details
                    .as_ref()
                    .and_then(|details| details.code)
            })
    }
}

impl fmt::Debug for GatewayError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("GatewayError")
            .field("kind", &self.kind)
            .field("message", &self.message)
            .field(
                "diagnostic",
                &self.diagnostic.as_deref().map(|_| "<present>"),
            )
            .field(
                "client_visible_upstream_error",
                &self
                    .client_visible_upstream_error
                    .as_ref()
                    .map(|_| "<present>"),
            )
            .finish()
    }
}

/// Store adapter 的稳定错误分类
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[non_exhaustive]
pub enum StoreErrorKind {
    /// CAS 或 expected revision 冲突
    Conflict,
    /// 存储暂不可用
    Unavailable,
    /// 生命周期状态转换非法
    InvalidState,
    /// 数据无法转换为核心事实
    InvalidData,
}

/// Core port 返回的存储错误，普通格式化不展开原始来源
#[derive(Debug, Clone, Error)]
#[error("execution store failed: {kind:?}")]
pub struct StoreError {
    kind: StoreErrorKind,
    source: Option<ErrorSource>,
}

impl StoreError {
    /// 创建只有分类的本地存储错误；包装实际异常使用 caused_by
    #[must_use]
    pub const fn new(kind: StoreErrorKind) -> Self {
        Self { kind, source: None }
    }

    /// 包装已有存储错误并保留来源
    #[must_use]
    pub fn caused_by(kind: StoreErrorKind, source: impl Into<crate::error::ErrorSource>) -> Self {
        Self {
            kind,
            source: Some(source.into()),
        }
    }

    /// 返回稳定错误分类
    #[must_use]
    pub const fn kind(&self) -> StoreErrorKind {
        self.kind
    }
}
