//! 唯一的账号重试、发送与下游 commit barrier owner

use crate::concurrency::ConcurrencyWaitBudget;
use crate::diagnostics::TraceContext;
use serde_json::json;

use std::collections::{BTreeMap, BTreeSet};
use std::num::NonZeroU32;
use std::sync::Arc;
use std::time::{Duration, Instant, SystemTime};

use super::client_retry::{ClientRetryGuard, ClientRetryKey};
use super::nested::ExecutionEffects;
use super::observation::{
    RequestObservationDispatch, ResponseObservation, WebSocketResponseAttempt,
};
use crate::engine::continuation::{
    ContinuationBinding, NativeContinuationPin, NativeContinuationScope, PreviousResponseId,
};

use crate::engine::probe::AccountProbeTarget;
use crate::engine::provider::{Provider, ProviderCallMetadata, ProviderRequest, ProviderStream};
use crate::engine::{
    AccountAttemptContext, AttemptContext, AttemptRecord, AttemptTransport, AttemptTrigger,
    CommitRequirement, ContinuationAttempt, CoordinatedEvent, EngineError, ExecutionOutcome,
    ExecutionStore, GatewayEngine, IntermediateFailure, ModelRequestFailureObservation,
    ModelRequestFinalization, ModelRequestId, NewModelRequest, ProviderAccountStateOwner,
    RequestAttemptContext, UpstreamSendState,
};
use crate::error::{
    ContinuationRecoveryDisposition, GatewayError, GatewayErrorKind, ProviderError,
    ProviderErrorKind, StoreError,
};
use crate::event::{
    GatewayEvent, ProviderEvent, ProviderResponseHeader, ProviderResponseObservation,
};
use crate::lifecycle::{CancellationToken, Deadline, LeaseGuard};
use crate::metering::Decimal;
use crate::operation::{Operation, ProviderSessionState};
use crate::routing::RoutingPlan;
use futures::future::{BoxFuture, Fuse};
use futures::{FutureExt, StreamExt, pin_mut, select_biased};
use futures_timer::Delay;

/// Request 级协调器；不会创建或写入 `request_attempts`
pub struct AttemptCoordinator<S: ?Sized> {
    engine: Arc<GatewayEngine<S>>,
}

#[derive(Debug, Clone)]
enum AccountSelection {
    Scheduled(Option<crate::account::ProviderAccountId>),
    Diagnostic(AccountProbeTarget),
}

pub(super) struct CoordinationExtensions {
    response_control: Option<super::response_control::ResponseControl>,
    continuation: Option<ContinuationBinding>,
    observation: Option<RequestObservationDispatch>,
    request_policy: Option<super::policy::RequestPolicyContext>,
    execution_effects: Option<Arc<ExecutionEffects>>,
    execution_effects_baseline: usize,
    middleware: Option<super::middleware::FrozenMiddlewarePlan>,
    upstream_adapters: Option<super::upstream_adapter::FrozenUpstreamAdapterPlan>,
    account_group_ids: Arc<[crate::account::scope::AccountGroupId]>,
    endpoint: String,
    client_transport: super::execution::ClientTransport,
    extension_scope: super::extensions::ExtensionCallScope,
}

impl CoordinationExtensions {
    pub(super) fn with_upstream_adapters(
        mut self,
        plan: Option<super::upstream_adapter::FrozenUpstreamAdapterPlan>,
    ) -> Self {
        self.upstream_adapters = plan;
        self
    }

    pub(super) fn with_response_control(
        mut self,
        control: Option<super::response_control::ResponseControl>,
    ) -> Self {
        self.response_control = control;
        self
    }

    pub(super) fn new(
        continuation: Option<ContinuationBinding>,
        observation: Option<RequestObservationDispatch>,
    ) -> Self {
        Self {
            continuation,
            response_control: None,
            observation,
            request_policy: None,
            execution_effects: None,
            execution_effects_baseline: 0,
            middleware: None,
            upstream_adapters: None,
            account_group_ids: Arc::from([]),
            endpoint: String::new(),
            client_transport: super::execution::ClientTransport::InternalProbe,
            extension_scope: super::extensions::ExtensionCallScope::default(),
        }
    }

    #[must_use]
    pub(super) fn with_extension_scope(
        mut self,
        extension_scope: super::extensions::ExtensionCallScope,
    ) -> Self {
        self.extension_scope = extension_scope;
        self
    }

    #[must_use]
    pub(super) fn with_request_policy(
        mut self,
        request_policy: Option<super::policy::RequestPolicyContext>,
    ) -> Self {
        self.request_policy = request_policy;
        self
    }

    #[must_use]
    pub(super) fn with_execution_effects(
        mut self,
        execution_effects: Option<Arc<ExecutionEffects>>,
        execution_effects_baseline: usize,
    ) -> Self {
        self.execution_effects = execution_effects;
        self.execution_effects_baseline = execution_effects_baseline;
        self
    }

    #[must_use]
    pub(super) fn with_middleware(
        mut self,
        middleware: Option<super::middleware::FrozenMiddlewarePlan>,
        account_group_ids: Arc<[crate::account::scope::AccountGroupId]>,
        endpoint: String,
        client_transport: super::execution::ClientTransport,
    ) -> Self {
        self.middleware = middleware;
        self.account_group_ids = account_group_ids;
        self.endpoint = endpoint;
        self.client_transport = client_transport;
        self
    }
}

impl AccountSelection {
    fn required_account(&self) -> Option<&crate::account::ProviderAccountId> {
        match self {
            Self::Scheduled(account) => account.as_ref(),
            Self::Diagnostic(target) => Some(target.account_id()),
        }
    }

    const fn is_diagnostic(&self) -> bool {
        matches!(self, Self::Diagnostic(_))
    }
}

impl<S: ?Sized> AttemptCoordinator<S>
where
    S: ExecutionStore + 'static,
{
    #[must_use]
    pub fn new(engine: GatewayEngine<S>) -> Self {
        Self {
            engine: Arc::new(engine),
        }
    }

    /// 接纳请求并返回由 Core 完整拥有 retry/commit 的流式会话
    ///
    /// # Errors
    ///
    /// 取消、已过 deadline 或 continuation 与路由不匹配时返回稳定错误
    pub async fn start(
        &self,
        request: NewModelRequest,
        operation: Operation,
        plan: RoutingPlan,
        required_account: Option<crate::account::ProviderAccountId>,
        continuation: Option<ContinuationBinding>,
        cancellation: CancellationToken,
    ) -> Result<ResponseExecutionSession<S>, EngineError> {
        self.start_with_account_selection(
            request,
            operation,
            plan,
            AccountSelection::Scheduled(required_account),
            CoordinationExtensions::new(continuation, None),
            cancellation,
        )
        .await
    }

    pub(super) async fn start_observed(
        &self,
        request: NewModelRequest,
        operation: Operation,
        plan: RoutingPlan,
        required_account: Option<crate::account::ProviderAccountId>,
        extensions: CoordinationExtensions,
        cancellation: CancellationToken,
    ) -> Result<ResponseExecutionSession<S>, EngineError> {
        self.start_with_account_selection(
            request,
            operation,
            plan,
            AccountSelection::Scheduled(required_account),
            extensions,
            cancellation,
        )
        .await
    }

    /// 对固定账号执行诊断请求
    ///
    /// 仅跳过该账号的本地可用性投影；账号租约和并发仍必须满足
    pub async fn start_diagnostic(
        &self,
        request: NewModelRequest,
        operation: Operation,
        plan: RoutingPlan,
        target: AccountProbeTarget,
        continuation: Option<ContinuationBinding>,
        cancellation: CancellationToken,
    ) -> Result<ResponseExecutionSession<S>, EngineError> {
        self.start_with_account_selection(
            request,
            operation,
            plan,
            AccountSelection::Diagnostic(target),
            CoordinationExtensions::new(continuation, None),
            cancellation,
        )
        .await
    }

    async fn start_with_account_selection(
        &self,
        request: NewModelRequest,
        operation: Operation,
        plan: RoutingPlan,
        account_selection: AccountSelection,
        extensions: CoordinationExtensions,
        cancellation: CancellationToken,
    ) -> Result<ResponseExecutionSession<S>, EngineError> {
        let CoordinationExtensions {
            response_control,
            continuation,
            observation: request_observation,
            request_policy,
            execution_effects,
            execution_effects_baseline,
            middleware,
            upstream_adapters,
            account_group_ids,
            endpoint,
            client_transport,
            extension_scope,
        } = extensions;
        let request_id = request.id.clone();
        let client_api_key_ref = request.client_api_key_ref.clone();
        let timing_started_at = Instant::now();
        let deadline = request.deadline_at;
        let account_state_owner = continuation
            .as_ref()
            .and_then(ContinuationBinding::pinned)
            .map(ProviderAccountStateOwner::from_continuation);
        let continuation_attempt =
            initial_continuation_attempt(&operation, &plan, continuation.as_ref());
        let candidate_index = continuation
            .as_ref()
            .and_then(ContinuationBinding::pinned)
            .map_or(Ok(0), |pin| {
                plan.candidates()
                    .iter()
                    .position(|candidate| candidate.provider() == pin.provider())
                    .ok_or(EngineError::ContinuationPinMismatch)
            })?;
        let trace = TraceContext::new(request_id.as_str());
        trace.record(
            "request.routed",
            json!({
                "endpoint": request.endpoint, "protocol": request.protocol,
                "clientTransport": request.client_transport,
                "model": request.requested_model.as_ref().map(|model| model.as_str()),
                "configRevision": format!("{:?}", request.config_revision),
                "admissionMs": request.admission_decision_ms,
                "continuation": format!("{continuation_attempt:?}"),
                "candidateCount": plan.candidates().len(),
                "accountPolicy": {
                    "strategy": plan.account_selection_policy().strategy().as_str(),
                    "affinity": plan.account_selection_policy().openai_account_affinity().as_str(),
                    "maxAccountRotations": plan.account_selection_policy().max_account_rotations(),
                    "maxRoutingAttempts": plan.max_attempts().get(),
                    "maxConcurrentPerAccount": plan.account_selection_policy().max_concurrent_per_account().get(),
                    "queueMaxWaiting": plan.account_selection_policy().queue_policy().max_waiting,
                    "queueTimeoutMs": plan.account_selection_policy().queue_policy().timeout.as_millis(),
                    "sessionAffinityTtlMs": plan.account_selection_policy().openai_session_affinity_ttl().as_millis(),
                    "smartWeights": plan.account_selection_policy().smart_scheduling().weights(),
                },
                "requiredAccount": account_selection.required_account().map(|account| account.as_str()),
                "hasMiddleware": middleware.is_some(),
                "hasRetryPolicy": request_policy.is_some(),
            }),
        );
        let image_generation_requested = operation.image_generation_requested();
        let mut session = ResponseExecutionSession {
            engine: Arc::clone(&self.engine),
            request_id,
            client_api_key_ref,
            concurrency_wait_budget: ConcurrencyWaitBudget::default(),
            connection_budget: super::connection::ConnectionBudget::default(),
            connection_retries: 0,
            connection_rotation: None,
            observation: ResponseObservation::new(timing_started_at),
            request_observation,
            budget_prior_attempts_usd: Decimal::ZERO,
            budget_attempt_already_counted: false,
            response_commit: super::execution::ResponseCommit::new(trace.clone()),
            trace,
            deadline,
            deadline_timer: deadline.wait().fuse(),
            lease: Some(self.engine.store.maintain_request(&request.id, deadline)),
            requested_model: request.requested_model.clone(),
            lease_metadata: Arc::new(crate::provider_ports::ProviderLeaseMetadata {
                request_id: request.id.as_str().to_owned(),
                client_key_id: request.client_api_key_ref.clone(),
                client_key_name: request.client_api_key_name_snapshot.clone(),
                model: request
                    .requested_model
                    .as_ref()
                    .map(|model| model.as_str().to_owned()),
                client_ip: request.client_ip,
                started_at: request.started_at,
            }),
            pending_request: Some(request),
            request_persisted: false,
            response_control,
            operation,
            plan,
            request_policy,
            execution_effects,
            execution_effects_baseline,
            middleware,
            upstream_adapters,
            account_group_ids,
            endpoint,
            client_transport,
            extension_scope,
            account_selection,
            continuation,
            continuation_attempt,
            account_state_owner,
            cancellation,
            attempts: 0,
            websocket_observation_sequence: 0,
            routing_attempts: 0,
            last_attempt_account: None,
            account_rotations: 0,
            candidate_index,
            excluded_accounts: BTreeSet::new(),
            credential_recovery_attempted_accounts: BTreeSet::new(),
            recovery_account: None,
            pending_retry: None,
            transient_retry_counts: BTreeMap::new(),
            request_profiles: BTreeMap::new(),
            current: None,
            send_state_watermark: UpstreamSendState::NotSent,
            delivery_committed: false,
            replay_barrier_reached: false,
            client_status_code: None,
            delivery_pending: false,
            upstream_complete: false,
            finalization: None,
            finalized_at: None,
            image_generation_requested,
            last_retryable_failure: None,
            last_retryable_failure_events: Vec::new(),
            last_observed_provider: None,
            pending_terminal_failure: None,
            pending_stream_failure: None,
            client_retry: None,
        };

        if session.cancellation.is_cancelled() {
            session.finish_interruption(&EngineError::Cancelled).await?;
            return Err(EngineError::Cancelled);
        }
        if deadline.is_elapsed() {
            session.finish_interruption(&EngineError::Deadline).await?;
            return Err(EngineError::Deadline);
        }
        if !session.account_selection.is_diagnostic()
            && let Some(store) = &self.engine.client_retry
            && let Operation::Generate(generate) = &session.operation
            && let Some(turn) = generate.client_turn()
        {
            let guard = ClientRetryGuard::load(
                Arc::clone(store),
                ClientRetryKey {
                    client_key_id: session.client_api_key_ref.clone(),
                    turn: turn.clone(),
                },
                session.request_id.clone(),
            )
            .await;
            session.trace.record(
                "client_retry.loaded",
                json!({"previousFailure": guard.has_failure()}),
            );
            session.client_retry = Some(guard);
        }
        Ok(session)
    }
}

struct CurrentAttempt {
    stream: ProviderStream,
    metadata: ProviderCallMetadata,
    trigger: AttemptTrigger,
    transport: AttemptTransport,
    connection_rotation_reserved: bool,
    index: NonZeroU32,
    started_at: SystemTime,
    send_observed: bool,
    response_observation: Option<ProviderResponseObservation>,
}

impl CurrentAttempt {
    fn upstream_request_id(&self) -> Option<&str> {
        self.response_observation
            .as_ref()
            .and_then(ProviderResponseObservation::request_id)
            .or_else(|| self.metadata.upstream_request_id())
            .map(|id| id.as_str())
    }
}

struct FailureFinalization {
    outcome: ExecutionOutcome,
    send_state: UpstreamSendState,
    error: GatewayError,
    upstream_status_code: Option<u16>,
    upstream_request_id: Option<String>,
    provider_error_code: Option<String>,
    error_details: Option<String>,
    retry_after_ms: Option<u64>,
    observation: ModelRequestFailureObservation,
}

#[derive(Debug, Clone)]
struct PendingAttemptRetry {
    account: crate::account::ProviderAccountId,
    transport: AttemptTransport,
    delay: Duration,
    transport_recovery: bool,
    reserve_connection_rotation: bool,
}

/// API 可逐事件消费的 Core 执行会话
///
/// API 只能提交下游 delivery 边界；账号重试、断流终结与
/// `model_requests` 写回均留在本类型内
pub struct ResponseExecutionSession<S: ?Sized> {
    engine: Arc<GatewayEngine<S>>,
    request_id: ModelRequestId,
    client_api_key_ref: crate::policy::ClientApiKeyId,
    concurrency_wait_budget: ConcurrencyWaitBudget,
    connection_budget: super::connection::ConnectionBudget,
    connection_retries: u32,
    /// 原账号恢复仍建连失败后尝试重选；选号不可用时消费该状态，恢复原账号剩余预算
    connection_rotation: Option<PendingAttemptRetry>,
    observation: ResponseObservation,
    request_observation: Option<RequestObservationDispatch>,
    budget_prior_attempts_usd: Decimal,
    budget_attempt_already_counted: bool,
    trace: TraceContext,
    deadline: Deadline,
    lease: Option<Box<dyn LeaseGuard>>,
    /// 会话级 deadline 计时器；deadline 固定，帧循环内复用而非逐事件新建
    deadline_timer: Fuse<BoxFuture<'static, ()>>,
    lease_metadata: Arc<crate::provider_ports::ProviderLeaseMetadata>,
    pending_request: Option<NewModelRequest>,
    requested_model: Option<crate::routing::PublicModelId>,
    request_persisted: bool,
    response_control: Option<super::response_control::ResponseControl>,
    operation: Operation,
    plan: RoutingPlan,
    request_policy: Option<super::policy::RequestPolicyContext>,
    execution_effects: Option<Arc<ExecutionEffects>>,
    execution_effects_baseline: usize,
    middleware: Option<super::middleware::FrozenMiddlewarePlan>,
    upstream_adapters: Option<super::upstream_adapter::FrozenUpstreamAdapterPlan>,
    account_group_ids: Arc<[crate::account::scope::AccountGroupId]>,
    endpoint: String,
    client_transport: super::execution::ClientTransport,
    extension_scope: super::extensions::ExtensionCallScope,
    account_selection: AccountSelection,
    continuation: Option<ContinuationBinding>,
    continuation_attempt: ContinuationAttempt,
    account_state_owner: Option<ProviderAccountStateOwner>,
    cancellation: CancellationToken,
    /// 所有实际上游 attempt 数；包含同账号传输重试，作为持久化序号
    attempts: u32,
    /// WebSocket 观察序列在同一逻辑请求内按实际上游 wire 单调递增
    websocket_observation_sequence: u64,
    /// 路由预算只统计正常选号/账号恢复，不被 Provider-owned 传输预算消耗
    routing_attempts: u32,
    /// 上一 attempt 实际选中的账号；与选号成功的 attempt 一一同步更新。
    /// 旧 CurrentAttempt 在丢弃时被 drop、excluded_accounts 无序、持久化记录异步
    /// best-effort，都不能还原「上一账号」，因此由本字段单独记账。
    last_attempt_account: Option<crate::account::ProviderAccountId>,
    /// 已发生的换号次数：选中账号与上一 attempt 不同的路由 attempt 计一次。
    /// 首个 attempt 不计；同账号钉选重试（瞬态退避、传输恢复、凭据恢复重放、
    /// continuation 精确重连）不消耗。预算耗尽后所有必然换号的重试门关闭，
    /// 换号深度由请求冻结的调度策略封顶
    account_rotations: u32,
    candidate_index: usize,
    excluded_accounts: BTreeSet<crate::account::ProviderAccountId>,
    credential_recovery_attempted_accounts: BTreeSet<crate::account::ProviderAccountId>,
    /// 凭据恢复后的一次性同账号钉选；只约束紧随其后的 replay attempt，
    /// attempt 建立时即被消费，后续可重试错误仍可换号消耗剩余重试预算
    /// 与 `required_account`（外部指定、贯穿整个请求）语义不同，不可合并
    recovery_account: Option<crate::account::ProviderAccountId>,
    /// 提交前同账号退避/传输恢复共用的等待与钉选状态；业务重试消耗路由预算
    pending_retry: Option<PendingAttemptRetry>,
    /// 请求内按账号累计的瞬时拒绝重试次数，不能跨请求污染账号健康状态
    transient_retry_counts: BTreeMap<crate::account::ProviderAccountId, u32>,
    /// 只在首次进入对应 Provider 时解析，避免后台发布更新改变同一请求的重试身份
    request_profiles: BTreeMap<crate::identity::ProviderKind, crate::account::OpaqueProviderData>,
    current: Option<CurrentAttempt>,
    /// 请求级发送状态水位；跨 attempt 单调不降，终态写回不得低于此档
    send_state_watermark: UpstreamSendState,
    response_commit: super::execution::ResponseCommit,
    // 传输心跳可先于首个业务批次提交，两者不能共用重放屏障
    delivery_committed: bool,
    /// 已交付的实际输出禁止重放，可替换前导事件不跨越此屏障
    replay_barrier_reached: bool,
    client_status_code: Option<u16>,
    delivery_pending: bool,
    upstream_complete: bool,
    finalization: Option<RequestFinalization>,
    finalized_at: Option<SystemTime>,
    image_generation_requested: bool,
    /// 最近一次为无感恢复而被丢弃的原始上游错误；只在后续空选路时成为终态
    last_retryable_failure: Option<ProviderError>,
    /// 与 `last_retryable_failure` 同属一个 attempt 的原始失败批次
    last_retryable_failure_events: Vec<ProviderEvent>,
    last_observed_provider: Option<crate::identity::ProviderKind>,
    /// 原子失败批次已交给协议层、但尚待下游提交后收敛的原 Provider 错误
    pending_terminal_failure: Option<PendingTerminalFailure>,
    /// 已消费的流错误及其异步决策由会话持有，取消读取只暂停处理
    pending_stream_failure: Option<PendingStreamFailure>,
    client_retry: Option<ClientRetryGuard>,
}

struct PendingTerminalFailure {
    error: Arc<ProviderError>,
    send_state: UpstreamSendState,
    events: Vec<ProviderEvent>,
}

struct PendingStreamFailure {
    completion: StreamFailureDecision,
    error: ProviderError,
    events: Vec<ProviderEvent>,
    send_state: UpstreamSendState,
    retry: StreamRetry,
    trace: serde_json::Value,
}

enum StreamFailureDecision {
    Pending(BoxFuture<'static, Result<bool, EngineError>>),
    Retry(bool),
    Interrupted(Arc<EngineError>),
}

enum StreamRetry {
    SameAccount,
    Pending(PendingAttemptRetry),
    ConnectionRotation(PendingAttemptRetry),
    ExcludeAccount,
    Continuation,
}

enum RequestFinalization {
    Pending(BoxFuture<'static, bool>),
    Complete,
}

impl<S: ?Sized> ResponseExecutionSession<S>
where
    S: ExecutionStore + 'static,
{
    /// 传输首字节事实可在 next_event 等待期间由协议层提交
    pub fn response_commit(&self) -> super::execution::ResponseCommit {
        self.response_commit.clone()
    }

    /// 当前请求共享的诊断上下文
    pub fn trace(&self) -> TraceContext {
        self.trace.clone()
    }

    pub(super) fn request_id(&self) -> &ModelRequestId {
        &self.request_id
    }

    /// 读取下一条 canonical event；首条未提交事件会携带 commit 要求
    ///
    /// # Errors
    ///
    /// 未提交上一条首事件、Provider 失败、取消或超时时返回错误；观测写入失败只记录告警
    pub async fn next_event(&mut self) -> Result<Option<CoordinatedEvent>, EngineError> {
        self.resume_finalization().await;
        if self.delivery_pending {
            return Err(EngineError::DownstreamCommitRequired);
        }
        if self.is_finalized() {
            self.pending_terminal_failure.take();
            self.pending_stream_failure.take();
            return Ok(None);
        }
        if self.pending_terminal_failure.is_some() {
            return self.next_terminal_failure().await;
        }
        loop {
            match self.pull().await? {
                PullOutcome::Events(events) => {
                    self.replay_barrier_reached |= self.middleware.is_some()
                        || events.iter().any(|event| !event.is_replayable_prelude());
                    let requirement = if self.delivery_committed {
                        CommitRequirement::AlreadyCommitted
                    } else {
                        self.delivery_pending = true;
                        CommitRequirement::CommitBeforeDelivery
                    };
                    return CoordinatedEvent::try_batch(events, requirement).map(Some);
                }
                PullOutcome::AttemptDiscarded => {}
                PullOutcome::TerminalFailure {
                    events,
                    error,
                    send_state,
                } => {
                    self.pending_terminal_failure = Some(PendingTerminalFailure {
                        error: Arc::new(error),
                        send_state,
                        events,
                    });
                    return self.next_terminal_failure().await;
                }
                PullOutcome::End => {
                    if self.delivery_committed {
                        self.finish_success().await?;
                    }
                    return Ok(None);
                }
            }
        }
    }

    /// 非流式协议可在任何下游提交前收集一个完整、可丢弃重试的结果
    ///
    /// # Errors
    ///
    /// 会话已提交、已有待提交结果或执行失败时返回错误
    pub async fn collect_uncommitted(&mut self) -> Result<Vec<ProviderEvent>, EngineError> {
        self.resume_finalization().await;
        if self.delivery_committed || self.delivery_pending {
            return Err(EngineError::InvalidDeliveryState);
        }
        if self.is_finalized() {
            return Ok(Vec::new());
        }

        let mut events = Vec::new();
        loop {
            match self.pull().await? {
                PullOutcome::Events(next) => events.extend(next),
                PullOutcome::AttemptDiscarded => events.clear(),
                PullOutcome::TerminalFailure {
                    error, send_state, ..
                } => {
                    self.pending_terminal_failure = Some(PendingTerminalFailure {
                        error: Arc::new(error),
                        send_state,
                        events: Vec::new(),
                    });
                    return Err(provider_engine_error(
                        self.finalize_pending_terminal_failure().await?,
                    ));
                }
                PullOutcome::End => {
                    if events.is_empty() {
                        return Err(EngineError::InvalidDeliveryState);
                    }
                    self.delivery_pending = true;
                    return Ok(events);
                }
            }
        }
    }

    /// 在协议 adapter 真正写出首字节前记录下游不可撤回边界
    ///
    /// # Errors
    ///
    /// 没有待提交结果或重复提交时返回错误；观测 Store 失败只记服务端告警
    pub async fn commit_downstream(
        &mut self,
        client_status_code: Option<u16>,
    ) -> Result<(), EngineError> {
        if !self.delivery_pending || self.delivery_committed || self.is_finalized() {
            return Err(EngineError::InvalidDeliveryState);
        }
        self.response_commit.record(client_status_code);
        let committed_at = self
            .response_commit
            .committed_at()
            .ok_or(EngineError::InvalidDeliveryState)?;
        let client_status_code = self.response_commit.status_code();
        if self.request_persisted {
            best_effort_store_write(
                "mark_downstream_committed",
                &self.request_id,
                self.engine.store().mark_downstream_committed(
                    &self.request_id,
                    committed_at,
                    client_status_code,
                ),
            )
            .await;
        }
        self.delivery_committed = true;
        self.client_status_code = client_status_code;
        self.delivery_pending = false;
        if self.upstream_complete {
            self.finish_success().await?;
        }
        Ok(())
    }

    /// 仅当 HTTP 流插件明确丢弃了整个尚未提交的非终态批次时释放交付屏障
    /// 原始 Provider facts 已经观察，不回滚计量，也不把丢弃误记为客户端 commit
    pub fn discard_pending_delivery(&mut self) -> Result<(), EngineError> {
        if !self.delivery_pending
            || self.delivery_committed
            || self.pending_terminal_failure.is_some()
            || self.is_finalized()
        {
            return Err(EngineError::InvalidDeliveryState);
        }
        self.delivery_pending = false;
        self.replay_barrier_reached = false;
        Ok(())
    }

    /// 在 HTTP adapter 已确定首字节前错误响应后补写最终状态
    ///
    /// # Errors
    ///
    /// 状态已经写入时返回错误；观测 Store 失败只记服务端告警
    pub async fn record_client_status(
        &mut self,
        client_status_code: u16,
    ) -> Result<(), EngineError> {
        if self.client_status_code.is_some() {
            return Err(EngineError::InvalidDeliveryState);
        }
        let committed_status = self.response_commit.status_code();
        let client_status_code = committed_status.unwrap_or(client_status_code);
        // 保活后的失败终结已写入实际 HTTP 状态，不能再触发仅补空值的 Store 更新
        if self.request_persisted && !(self.is_finalized() && committed_status.is_some()) {
            best_effort_store_write(
                "record_client_status",
                &self.request_id,
                self.engine
                    .store()
                    .record_client_status(&self.request_id, client_status_code),
            )
            .await;
        }
        self.client_status_code = Some(client_status_code);
        Ok(())
    }

    #[must_use]
    pub const fn is_finalized(&self) -> bool {
        matches!(self.finalization, Some(RequestFinalization::Complete))
    }

    #[must_use]
    pub fn budget_charge(&self) -> super::budget::ClientBudgetCharge {
        // 超出数据库可表示范围时保留最大金额，避免溢出后误记为零
        let amount_usd = self
            .budget_prior_attempts_usd
            .checked_add(self.budget_attempt_usd())
            .unwrap_or(Decimal::MAX);
        super::budget::ClientBudgetCharge {
            key_id: self.client_api_key_ref.clone(),
            request_id: self.request_id.clone(),
            amount_usd,
            completed_at: self.finalized_at.unwrap_or_else(SystemTime::now),
        }
    }

    fn budget_attempt_usd(&self) -> Decimal {
        if self.budget_attempt_already_counted {
            return Decimal::ZERO;
        }
        // Key 只累计已取得的 USD 费用；缺少费用的请求按零结算
        // 发送状态仍用于判断重放是否安全并保留在诊断中，不能据此推断存在欠费
        self.observation
            .cost
            .total()
            .filter(|money| money.currency().as_str() == "USD")
            .map(crate::metering::Money::amount)
            .unwrap_or(Decimal::ZERO)
    }

    /// 返回最终选中 attempt 已公开给协议层的安全响应头
    #[must_use]
    pub fn response_headers(&self) -> &[ProviderResponseHeader] {
        self.current
            .as_ref()
            .and_then(|current| current.response_observation.as_ref())
            .map(ProviderResponseObservation::client_headers)
            .unwrap_or_default()
    }

    /// 返回最终选中 attempt 观察到的上游 HTTP 状态码
    #[must_use]
    pub fn response_status_code(&self) -> Option<u16> {
        self.current
            .as_ref()
            .and_then(|current| current.response_observation.as_ref())
            .and_then(ProviderResponseObservation::status_code)
    }

    /// 将已完成响应的账号事实与 Provider 私有状态封装为可丢失的亲和记录
    ///
    /// Core 不读取 `state` 内容；Provider 将在后续同账号 continuation 时自行解释
    #[must_use]
    pub fn native_continuation_pin(
        &self,
        state: &ProviderSessionState,
    ) -> Option<NativeContinuationPin> {
        let current = self.current.as_ref()?;
        let provider = current.metadata.provider().clone();
        if state.provider() != provider.as_str() {
            return None;
        }
        let account = current.metadata.provider_account_id().clone();
        let response_id = self.observation.upstream_response_id.as_deref()?;
        let previous_response_id = PreviousResponseId::new(response_id.to_owned());
        let upstream_response_id = PreviousResponseId::new(response_id.to_owned());
        Some(
            NativeContinuationPin::new(
                previous_response_id,
                upstream_response_id,
                self.client_api_key_ref.clone(),
                provider,
                account,
            )
            .with_scope(
                if state
                    .extension_owner()
                    .is_some_and(|owner| owner.connection_local)
                {
                    NativeContinuationScope::ConnectionLocal
                } else {
                    NativeContinuationScope::Persisted
                },
            )
            .with_session_state(state.clone()),
        )
    }

    /// 请求取消；实际终态在下一次会话 poll 时由 Core 持久化
    pub fn cancel(&self) {
        self.cancellation.cancel();
    }

    /// 丢弃尚未提交的 delivery，并收敛为取消终态；已有终态写入继续保留原结果
    ///
    /// 观测写入失败只记录告警，不改变取消结果
    pub async fn cancel_and_finalize(&mut self) -> Result<(), EngineError> {
        self.cancellation.cancel();
        // 已观测事实归属 session，显式取消不再保留失败决策中的存储或插件调用
        self.pending_stream_failure.take();
        self.resume_finalization().await;
        if self.is_finalized() {
            return Ok(());
        }
        self.delivery_pending = false;
        if self.pending_terminal_failure.is_some() {
            self.finalize_pending_terminal_failure().await?;
            return Ok(());
        }
        self.finish_interruption(&EngineError::Cancelled).await
    }

    async fn pull(&mut self) -> Result<PullOutcome, EngineError> {
        loop {
            if self.pending_stream_failure.is_some() {
                return self.resume_stream_failure().await;
            }
            if self.current.is_none() {
                match self.prepare_attempt().await {
                    Ok(Some(outcome)) => return Ok(outcome),
                    Ok(None) => {}
                    Err(error) => {
                        if !self.is_finalized() {
                            self.finish_interruption(&error).await?;
                        }
                        return Err(error);
                    }
                }
            }

            let boundary = {
                let current = self.current.as_mut().ok_or(EngineError::NoActiveAttempt)?;
                poll_stream_item(
                    &mut current.stream,
                    self.cancellation.clone(),
                    self.deadline,
                    &mut self.deadline_timer,
                )
                .await
            };

            match boundary {
                PollBoundary::Cancelled => {
                    self.finish_interruption(&EngineError::Cancelled).await?;
                    return Err(EngineError::Cancelled);
                }
                PollBoundary::Deadline => {
                    // 会话 deadline 是网关自身的请求预算，不是上游超时；
                    // 真正的上游超时会作为流错误进入 `begin_stream_failure` 记账
                    // 这里不写 provider 失败，避免把本地预算到期归因为上游故障
                    self.finish_interruption(&EngineError::Deadline).await?;
                    return Err(EngineError::Deadline);
                }
                PollBoundary::Item(Some(Ok(mut event))) => {
                    if let Some(wire) = event.wire_event() {
                        self.trace
                            .attempt(self.attempts)
                            .wire_event(wire.protocol(), wire.event_type());
                    }
                    if let Some(state) = event.session_update() {
                        self.observe_session_update(state);
                    }
                    if let Some(observation) = event.take_observation() {
                        self.observe_response(observation);
                    }
                    for fact in event.canonical_facts() {
                        self.observation.observe_identity(fact);
                    }
                    for fact in event.canonical_facts() {
                        self.observe_event(fact).await;
                    }
                    if event.wire_event().is_some() && !event.has_canonical_facts() {
                        self.observe_wire_event().await;
                    }
                    if self.request_observation.is_some() && event.wire_event().is_some() {
                        let websocket_attempt = self
                            .current
                            .as_ref()
                            .and_then(websocket_observation_attempt);
                        self.observe_websocket_response(&event, websocket_attempt);
                    }
                    if !event.has_client_event() {
                        continue;
                    }
                    let terminal = event
                        .canonical_facts()
                        .iter()
                        .any(|fact| matches!(fact, GatewayEvent::Completed(_)));
                    let translated = self
                        .current
                        .as_mut()
                        .ok_or(EngineError::NoActiveAttempt)?
                        .stream
                        .translate_native_response(event, terminal);
                    match translated {
                        Ok(events) if events.is_empty() => continue,
                        Ok(events) => {
                            // 成功终态交付后客户端即可续发工具结果，不能等流 EOF 或异步观测再清理
                            if terminal && let Some(guard) = &mut self.client_retry {
                                guard.success().await;
                            }
                            return Ok(PullOutcome::Events(events));
                        }
                        Err(error) => {
                            self.finish_provider_error(&error).await?;
                            return Err(provider_engine_error(error));
                        }
                    }
                }
                PollBoundary::Item(Some(Err(error))) => {
                    self.begin_stream_failure(error)?;
                    return self.resume_stream_failure().await;
                }
                PollBoundary::Item(None) => {
                    self.record_current_provider_success();
                    self.upstream_complete = true;
                    return Ok(PullOutcome::End);
                }
            }
        }
    }

    async fn prepare_attempt(&mut self) -> Result<Option<PullOutcome>, EngineError> {
        let pending_retry = self.pending_retry.take();
        let is_transport_recovery = pending_retry
            .as_ref()
            .is_some_and(|retry| retry.transport_recovery);
        let connection_rotation_reserved = pending_retry
            .as_ref()
            .is_some_and(|retry| retry.reserve_connection_rotation);
        if !is_transport_recovery && self.routing_attempts >= self.plan.max_attempts().get() {
            return Err(EngineError::EmptyRoutingPlan);
        }
        if let Some(recovery) = pending_retry.as_ref()
            && !recovery.delay.is_zero()
        {
            let deadline = self
                .connection_budget
                .startup_remaining()
                .map_or(self.deadline, |remaining| {
                    self.deadline.min(SystemTime::now() + remaining)
                });
            match poll_retry_delay(recovery.delay, self.cancellation.clone(), deadline).await {
                RetryDelayBoundary::Elapsed => {}
                RetryDelayBoundary::Cancelled => {
                    self.finish_interruption(&EngineError::Cancelled).await?;
                    return Err(EngineError::Cancelled);
                }
                RetryDelayBoundary::Deadline => {
                    self.finish_interruption(&EngineError::Deadline).await?;
                    return Err(EngineError::Deadline);
                }
            }
        }
        let Some(candidate) = self.plan.candidates().get(self.candidate_index).cloned() else {
            let error = GatewayError::new(
                GatewayErrorKind::NoAvailableProvider,
                "No upstream service is available.",
            );
            self.finish_failure(FailureFinalization {
                outcome: ExecutionOutcome::Failed,
                send_state: self.current_send_state(),
                error,
                upstream_status_code: None,
                upstream_request_id: None,
                provider_error_code: None,
                error_details: None,
                retry_after_ms: None,
                observation: ModelRequestFailureObservation::default(),
            })
            .await?;
            return Err(EngineError::EmptyRoutingPlan);
        };
        let next_attempt = self
            .attempts
            .checked_add(1)
            .and_then(NonZeroU32::new)
            .ok_or(EngineError::EmptyRoutingPlan)?;
        // 请求局部恢复钉选在此被一次性消费，只绑定本次 replay attempt；
        // 外部 required_account 每次 attempt 都重新生效
        let (pinned_account, attempt_transport) = if let Some(recovery) = pending_retry {
            (Some(recovery.account), recovery.transport)
        } else {
            match &self.account_selection {
                AccountSelection::Diagnostic(target) => {
                    (Some(target.account_id().clone()), AttemptTransport::Default)
                }
                AccountSelection::Scheduled(_) => (
                    self.recovery_account
                        .take()
                        .or_else(|| self.account_selection.required_account().cloned()),
                    self.connection_rotation
                        .as_ref()
                        .map_or(AttemptTransport::Default, |recovery| recovery.transport),
                ),
            }
        };
        let account_context = match &self.account_selection {
            AccountSelection::Diagnostic(target) => AccountAttemptContext::diagnostic(
                self.excluded_accounts.clone(),
                target.clone(),
                self.account_state_owner.clone(),
            ),
            AccountSelection::Scheduled(_) => AccountAttemptContext::new(
                self.excluded_accounts.clone(),
                pinned_account.clone(),
                self.account_state_owner.clone(),
            )
            .with_account_scope(Arc::clone(candidate.account_scope())),
        }
        .with_credential_recovery_attempted(pinned_account.as_ref().is_some_and(|account| {
            self.credential_recovery_attempted_accounts
                .contains(account)
        }));
        let provider = self
            .engine
            .providers()
            .get(candidate.provider())
            .cloned()
            .ok_or_else(|| EngineError::ProviderNotRegistered {
                provider: candidate.provider().as_str().to_owned(),
            })?;
        if !self.request_profiles.contains_key(candidate.provider()) {
            let profile = match self
                .plan
                .account_scope()
                .request_profile(candidate.provider())
            {
                Some(configuration) => provider.resolve_request_profile(configuration).map(Some),
                None => provider.default_request_profile(),
            };
            match profile {
                Ok(Some(profile)) => {
                    self.request_profiles
                        .insert(candidate.provider().clone(), profile);
                }
                Ok(None) => {}
                Err(error) => {
                    self.trace
                        .attempt(self.attempts)
                        .record_provider_failure(&error);
                    self.finish_provider_error(&error).await?;
                    return Err(provider_engine_error(error));
                }
            }
        }
        let context = AttemptContext::new(
            RequestAttemptContext::new(self.request_id.clone(), self.client_api_key_ref.clone())
                .with_account_error_protection(
                    (!self.account_selection.is_diagnostic()
                        && self.plan.account_error_protection().policy().enabled)
                        .then(|| self.engine.account_error_protection.as_ref())
                        .flatten()
                        .map(|store| super::account_protection::ProtectionContext {
                            store: Arc::clone(store),
                            policy: self.plan.account_error_protection(),
                            revision: self.plan.account_error_protection_revision(),
                        }),
                )
                .with_lease_metadata(Arc::clone(&self.lease_metadata))
                .with_response_control(self.response_control.clone())
                .with_request_profile(self.request_profiles.get(candidate.provider()).cloned())
                .with_fast_mode(self.plan.fast_mode())
                .with_pricing(self.plan.pricing())
                .with_request_location(self.plan.request_location().cloned())
                .with_privacy(self.plan.privacy())
                .with_request_body_limit(self.plan.request_body_limit())
                .with_concurrency_wait_budget(self.concurrency_wait_budget.clone())
                .with_connection_budget(if connection_rotation_reserved {
                    self.connection_budget.clone().reserve_next_opening()
                } else {
                    self.connection_budget.clone()
                })
                .with_timing_started_at(self.observation.timing_started_at)
                .with_request_policy(self.request_policy.clone())
                .with_execution_effects(self.execution_effects.as_ref().map(Arc::clone))
                .with_upstream_adapters(self.upstream_adapters.clone())
                .with_requested_model(self.requested_model.clone())
                .with_middleware(
                    self.middleware.clone(),
                    Arc::clone(&self.account_group_ids),
                    self.endpoint.clone(),
                    self.client_transport,
                )
                .with_extension_scope(self.extension_scope.clone())
                .with_trace(self.trace.clone()),
            next_attempt,
            self.deadline,
            self.plan.account_selection_policy(),
            account_context,
            self.continuation.clone(),
            self.cancellation.clone(),
        )
        .with_continuation_attempt(self.continuation_attempt)
        .with_transport(attempt_transport);
        let trigger = if self.attempts == 0 {
            AttemptTrigger::Initial
        } else {
            AttemptTrigger::AccountRetry
        };
        let attempt_trace = self.trace.attempt(next_attempt.get());
        attempt_trace.record(
            "attempt.started",
            json!({
                "provider": candidate.provider().as_str(),
                "model": candidate.upstream_model().map(|model| model.as_str()),
                "transportPolicy": format!("{attempt_transport:?}"),
                "continuation": format!("{:?}", self.continuation_attempt),
                "pinnedAccount": pinned_account.as_ref().map(|id| id.as_str()),
                "transportRecovery": is_transport_recovery,
            }),
        );
        let provider_request = ProviderRequest::new(self.operation.clone(), candidate.clone());
        let provider_boundary = poll_provider(
            provider,
            provider_request,
            context,
            self.cancellation.clone(),
            self.deadline,
        )
        .await;
        let stream = match provider_boundary {
            ProviderBoundary::Cancelled => {
                self.finish_interruption(&EngineError::Cancelled).await?;
                return Err(EngineError::Cancelled);
            }
            ProviderBoundary::Deadline => {
                // 网关预算到期是本请求的终态，不推定候选 Provider 不可用
                self.finish_interruption(&EngineError::Deadline).await?;
                return Err(EngineError::Deadline);
            }
            ProviderBoundary::Result(result) => match *result {
                Ok(stream) => stream,
                Err(error) => {
                    attempt_trace.record_provider_failure(&error);
                    let connection_fallback = self.connection_rotation.is_some()
                        && !self.connection_budget.exhausted()
                        && !error.retry_is_prohibited()
                        && error.send_state() == UpstreamSendState::NotSent
                        && matches!(
                            error.kind(),
                            ProviderErrorKind::NoEligibleAccount
                                | ProviderErrorKind::AccountCapacityUnavailable
                                | ProviderErrorKind::QuotaExhausted
                                | ProviderErrorKind::ConcurrencyQueueFull
                                | ProviderErrorKind::ConcurrencyQueueTimeout
                        );
                    let continuation_retry = !error.retry_is_prohibited()
                        && self.prepare_unavailable_native_continuation_replay(&error);
                    let candidate_retry = !error.retry_is_prohibited() && !connection_fallback && !continuation_retry
                        && matches!(
                            error.kind(),
                            ProviderErrorKind::AccountCapacityUnavailable
                                | ProviderErrorKind::NoEligibleAccount
                                | ProviderErrorKind::QuotaExhausted
                                | ProviderErrorKind::ProviderInfrastructureUnavailable
                                | ProviderErrorKind::ConcurrencyQueueFull
                                | ProviderErrorKind::ConcurrencyQueueTimeout
                        )
                        && error.send_state() == UpstreamSendState::NotSent
                        && self.current_send_state() == UpstreamSendState::NotSent
                        && matches!(
                            self.continuation_attempt,
                            ContinuationAttempt::None | ContinuationAttempt::ReplayAny
                        )
                        // 跨 Provider 候选推进必然换号（账号行按 Provider 隔离），
                        // 预算耗尽后不再推进，交回容量类失败的原有终态语义。
                        && self.account_rotations < self.plan.account_selection_policy().max_account_rotations()
                        && self.advance_provider_candidate();
                    let retryable = self
                        .apply_retry_policy(super::policy::RetryFacts {
                            attempt_index: next_attempt,
                            provider: candidate.provider().clone(),
                            model: candidate
                                .upstream_model()
                                .map(|model| model.as_str().to_owned()),
                            error_kind: error.kind(),
                            upstream_status: error.upstream_status(),
                            send_state: error.send_state(),
                            remaining_routing_attempts: self
                                .plan
                                .max_attempts()
                                .get()
                                .saturating_sub(self.routing_attempts),
                            remaining_deadline: Duration::ZERO,
                            retry_allowed: connection_fallback
                                || continuation_retry
                                || candidate_retry,
                        })
                        .await?;
                    attempt_trace.record("retry.decided", json!({
                        "phase": "prepare", "retryable": retryable,
                        "continuationRetry": continuation_retry, "candidateRetry": candidate_retry,
                        "connectionFallback": connection_fallback,
                        "retryProhibited": error.retry_is_prohibited(),
                        "sendState": error.send_state().as_str(),
                        "requestSendState": self.current_send_state().as_str(),
                        "continuation": format!("{:?}", self.continuation_attempt),
                        "accountRotations": self.account_rotations,
                        "maxAccountRotations": self.plan.account_selection_policy().max_account_rotations(),
                        "remainingRoutingAttempts": self.plan.max_attempts().get().saturating_sub(self.routing_attempts),
                    }));
                    if retryable {
                        if connection_fallback {
                            let recovery = self
                                .connection_rotation
                                .take()
                                .expect("pending connection rotation");
                            self.excluded_accounts.remove(&recovery.account);
                            self.pending_retry = Some(recovery);
                        } else if candidate_retry {
                            // 原账号只属于原 Provider，跨候选后不能拿旧钉选作恢复兜底
                            self.connection_rotation = None;
                        }
                        return Ok(Some(PullOutcome::AttemptDiscarded));
                    }
                    if matches!(
                        error.kind(),
                        ProviderErrorKind::AccountCapacityUnavailable
                            | ProviderErrorKind::NoEligibleAccount
                            | ProviderErrorKind::SessionPolicyRestricted
                            | ProviderErrorKind::QuotaExhausted
                            | ProviderErrorKind::ConcurrencyQueueFull
                            | ProviderErrorKind::ConcurrencyQueueTimeout
                    ) && let Some(last_failure) = self.last_retryable_failure.take()
                    {
                        let send_state = self.current_send_state();
                        let mut events = std::mem::take(&mut self.last_retryable_failure_events);
                        if !events.is_empty() {
                            self.observe_atomic_terminal_events(&mut events);
                            self.budget_attempt_already_counted = true;
                            return Ok(Some(PullOutcome::TerminalFailure {
                                events,
                                error: last_failure,
                                send_state,
                            }));
                        }
                        self.finish_provider_error(&last_failure).await?;
                        return Err(provider_engine_error(last_failure));
                    }
                    if !(matches!(
                        error.kind(),
                        ProviderErrorKind::AccountCapacityUnavailable
                            | ProviderErrorKind::NoEligibleAccount
                            | ProviderErrorKind::SessionPolicyRestricted
                            | ProviderErrorKind::QuotaExhausted
                            | ProviderErrorKind::ProviderInfrastructureUnavailable
                            | ProviderErrorKind::ConcurrencyQueueFull
                            | ProviderErrorKind::ConcurrencyQueueTimeout
                    ) && error.send_state() == UpstreamSendState::NotSent)
                    {
                        self.record_provider_failure(candidate.provider().clone());
                    }
                    self.finish_provider_error(&error).await?;
                    return Err(provider_engine_error(error));
                }
            },
        };
        if !stream.metadata().confirms(&candidate) {
            drop(stream);
            self.record_provider_failure(candidate.provider().clone());
            let error = GatewayError::new(
                GatewayErrorKind::Internal,
                "Provider metadata did not match the frozen candidate.",
            );
            self.finish_failure(FailureFinalization {
                outcome: ExecutionOutcome::Failed,
                send_state: self.current_send_state(),
                error,
                upstream_status_code: None,
                upstream_request_id: None,
                provider_error_code: None,
                error_details: None,
                retry_after_ms: None,
                observation: ModelRequestFailureObservation::default(),
            })
            .await?;
            return Err(EngineError::ProviderMetadataMismatch);
        }

        let metadata = stream.metadata().clone();
        self.connection_rotation = None;
        attempt_trace.record("account.selected", json!({
            "provider": metadata.provider().as_str(), "accountId": metadata.provider_account_id().as_str(),
            "transport": metadata.transport().as_str(),
            "selectionMs": metadata.selection_observation().map(|o| o.account_selection_wait_ms()),
        }));
        let selection_observation = metadata.selection_observation();
        let capacity = selection_observation.and_then(|observation| observation.capacity());
        if !self.account_selection.is_diagnostic()
            && !candidate
                .account_scope()
                .allows(metadata.provider_account_id())
        {
            drop(stream);
            let error = GatewayError::new(
                GatewayErrorKind::Internal,
                "Provider selected an account outside the frozen client scope.",
            );
            self.finish_failure(FailureFinalization {
                outcome: ExecutionOutcome::Failed,
                send_state: self.current_send_state(),
                error,
                upstream_status_code: None,
                upstream_request_id: None,
                provider_error_code: None,
                error_details: None,
                retry_after_ms: None,
                observation: ModelRequestFailureObservation::default(),
            })
            .await?;
            return Err(EngineError::AccountOutsideClientScope);
        }
        if pinned_account
            .as_ref()
            .is_some_and(|required| metadata.provider_account_id() != required)
        {
            drop(stream);
            let error = GatewayError::new(
                GatewayErrorKind::Internal,
                "Provider did not use the required account.",
            );
            self.finish_failure(FailureFinalization {
                outcome: ExecutionOutcome::Failed,
                send_state: self.current_send_state(),
                error,
                upstream_status_code: None,
                upstream_request_id: None,
                provider_error_code: None,
                error_details: None,
                retry_after_ms: None,
                observation: ModelRequestFailureObservation::default(),
            })
            .await?;
            return Err(EngineError::RequiredAccountMismatch);
        }
        if let Some(pin) = self
            .continuation
            .as_ref()
            .and_then(ContinuationBinding::pinned)
            && self.continuation_attempt == ContinuationAttempt::Native
            && !pin.matches(metadata.provider(), metadata.provider_account_id())
        {
            drop(stream);
            let error = GatewayError::new(
                GatewayErrorKind::Internal,
                "Native continuation binding did not match selected account.",
            );
            self.finish_failure(FailureFinalization {
                outcome: ExecutionOutcome::Failed,
                send_state: self.current_send_state(),
                error,
                upstream_status_code: None,
                upstream_request_id: None,
                provider_error_code: None,
                error_details: None,
                retry_after_ms: None,
                observation: ModelRequestFailureObservation::default(),
            })
            .await?;
            return Err(EngineError::ContinuationPinMismatch);
        }
        // 换号预算按实际选中账号记账：与上一 attempt 选中账号不同即消耗一次。决策门
        // （重试分类、候选推进、continuation 排除臂）已拦截预算耗尽后的必然换号，
        // 这里是统一事实源，覆盖 Provider 自主换号（如 replay owner 重放）等路径；
        // 首 attempt 与同账号钉选重试不计数。
        if self.last_attempt_account.as_ref() != Some(metadata.provider_account_id())
            && self
                .last_attempt_account
                .replace(metadata.provider_account_id().clone())
                .is_some()
        {
            self.account_rotations = self.account_rotations.saturating_add(1);
        }
        if self.account_state_owner.is_none() {
            self.account_state_owner = Some(ProviderAccountStateOwner::new(
                metadata.provider().clone(),
                metadata.provider_account_id().clone(),
            ));
        }
        let attempt_record = AttemptRecord {
            account_snapshot: metadata.account_snapshot().cloned(),
            request_id: self.request_id.clone(),
            attempt_count: next_attempt,
            trigger,
            provider_kind: metadata.provider().clone(),
            provider_account_ref: Some(metadata.provider_account_id().clone()),
            upstream_model_id: metadata.upstream_model().cloned(),
            upstream_transport: metadata.transport().as_str().to_owned(),
            http_version: None,
            account_selection_wait_ms: selection_observation
                .map(|observation| observation.account_selection_wait_ms()),
            capacity_used_slots: capacity.map(|snapshot| snapshot.used_slots()),
            capacity_total_slots: capacity.map(|snapshot| snapshot.total_slots()),
        };
        // 合法冷流在可取消的观测写入前归会话所有，首写等待中断也不能退回零次或重新选号
        self.attempts = next_attempt.get();
        if !is_transport_recovery {
            self.routing_attempts = self.routing_attempts.saturating_add(1);
        }
        self.current = Some(CurrentAttempt {
            stream,
            metadata,
            trigger,
            transport: attempt_transport,
            connection_rotation_reserved,
            index: next_attempt,
            started_at: SystemTime::now(),
            send_observed: false,
            response_observation: None,
        });
        if self.request_persisted {
            best_effort_store_write(
                "record_attempt",
                &self.request_id,
                self.engine.store().record_attempt(attempt_record),
            )
            .await;
        } else {
            let request = self
                .pending_request
                .as_ref()
                .ok_or(EngineError::InvalidDeliveryState)?;
            if best_effort_store_write(
                "create_model_request_with_attempt",
                &self.request_id,
                self.engine
                    .store()
                    .create_model_request_with_attempt(request.clone(), attempt_record),
            )
            .await
            .is_some()
            {
                self.pending_request = None;
                self.request_persisted = true;
            }
        }
        Ok(None)
    }

    fn advance_provider_candidate(&mut self) -> bool {
        let Some(next) = self.candidate_index.checked_add(1) else {
            return false;
        };
        if next >= self.plan.candidates().len() {
            return false;
        }
        self.candidate_index = next;
        true
    }

    async fn observe_event(&mut self, event: &GatewayEvent) {
        self.observation.observe_event(event);
        self.mark_send_observed().await;
    }

    async fn observe_wire_event(&mut self) {
        self.mark_send_observed().await;
    }

    fn observe_session_update(&mut self, state: &ProviderSessionState) {
        let Some(current) = self.current.as_mut() else {
            return;
        };
        if state.provider() != current.metadata.provider().as_str() {
            return;
        }
        self.operation.set_provider_session_state(state.clone());
    }

    async fn mark_send_observed(&mut self) {
        let Some(current) = self.current.as_mut() else {
            return;
        };
        if !current.send_observed {
            if self.request_persisted {
                best_effort_store_write(
                    "mark_send_state",
                    &self.request_id,
                    self.engine
                        .store()
                        .mark_send_state(&self.request_id, UpstreamSendState::Sent),
                )
                .await;
            }
            current.send_observed = true;
            self.send_state_watermark = UpstreamSendState::Sent;
        }
    }

    fn observe_response(&mut self, observation: ProviderResponseObservation) {
        let Some(current) = self.current.as_mut() else {
            return;
        };
        if current
            .response_observation
            .as_ref()
            .is_some_and(|existing| existing.transport() != observation.transport())
        {
            return;
        }
        self.observation.observe_response(&observation);
        current.response_observation = Some(observation);
    }

    /// 失败可重试时要求丢弃本 attempt；预算耗尽时可返回最后一批原始失败事件
    fn begin_stream_failure(&mut self, mut error: ProviderError) -> Result<(), EngineError> {
        // 原始 wire 只活在 request-local 决策状态；clone、attempt 记录与持久化终态
        // 均只接触已剥离的稳定错误字段
        self.trace
            .attempt(self.attempts)
            .record_provider_failure(&error);
        let atomic_client_events = error.take_atomic_client_events();
        // 失败随附的事实也属于当前 attempt，取消观测写入时仍须保留 usage 与费用
        // 回退仍可能交付该批事件，因此这里只借用观测，确认终态交付后再移除
        for event in &atomic_client_events {
            if let Some(observation) = event.response_observation() {
                self.observe_response(observation.clone());
            }
            for fact in event.canonical_facts() {
                self.observation.observe_identity(fact);
                self.observation.observe_event(fact);
            }
        }
        let current = self.current.take().ok_or(EngineError::NoActiveAttempt)?;
        if self.request_observation.is_some() {
            let websocket_attempt = websocket_observation_attempt(&current);
            for event in atomic_client_events
                .iter()
                .filter(|event| event.wire_event().is_some())
            {
                self.observe_websocket_response(event, websocket_attempt.clone());
            }
        }
        self.record_provider_failure(current.metadata.provider().clone());
        // attempt_send_state 是本 attempt 自身的发送事实；共享 effect 单独作为
        // 一票否决的重试门
        // 持久化与终态用请求级水位，不能把早先 Provider attempt
        // 的 sent 传染给当前 attempt，但任何已观测外部副作用都必须阻止重放
        let attempt_send_state = if current.send_observed {
            UpstreamSendState::Sent
        } else {
            error.send_state()
        };
        if attempt_send_state != UpstreamSendState::NotSent {
            // 已发送的容量拒绝、凭据恢复沿用原策略，不再受首次建连窗口限制
            self.connection_budget.complete();
        }
        let execution_effect_observed = self.execution_effect_observed();
        let send_state = self.raise_send_watermark(attempt_send_state);
        let provider_proved_replay_safe = provider_proved_replay_safe(&error);
        let continuation_retry = !execution_effect_observed
            && self.prepare_continuation_retry(
                &current,
                &error,
                attempt_send_state,
                provider_proved_replay_safe,
            );
        let account_rotation_retry = !execution_effect_observed
            && self.account_selection.required_account().is_none()
            && self.continuation_attempt == ContinuationAttempt::None
            && !self.replay_barrier_reached
            && !self.delivery_pending
            && attempt_send_state != UpstreamSendState::Ambiguous
            && matches!(
                error.pre_delivery_retry(),
                Some(crate::error::PreDeliveryRetry::AccountRotation)
            )
            && self.routing_attempts < self.plan.max_attempts().get();
        // 只有尚未发送的逻辑请求进入新增策略；已有发送后安全恢复保持原有路由规则
        let connection_retry_requested = self.current_send_state() == UpstreamSendState::NotSent
            && matches!(
                error.pre_delivery_retry(),
                Some(crate::error::PreDeliveryRetry::SameAccountConnectionRetry { .. })
            );
        // 服务器建议不可截短
        // 超出上限，或上游拒绝继续重试当前账号时，跳过同账号等待
        // 较短的 Retry-After 也直接沿用安全换号或原错误出口
        let retry_after_exceeds_limit = error
            .retry_after()
            .is_some_and(|delay| delay > self.plan.max_retry_after());
        let same_account_retry_blocked = error.same_account_retry_blocked();
        // Provider 的有界同账号传输恢复是尽力重试策略，不要求把 Sent/Ambiguous
        // 改写成安全证明；外部副作用、取消、预算与下游提交仍由 Core 拦截
        let transport_recovery = match error.pre_delivery_retry() {
            Some(crate::error::PreDeliveryRetry::SameAccountConnectionRetry { transport })
                if !same_account_retry_blocked
                    && !execution_effect_observed
                    && !self.connection_budget.exhausted()
                    && !self.replay_barrier_reached
                    && !self.delivery_pending
                    && attempt_send_state == UpstreamSendState::NotSent
                    && self.current_send_state() == UpstreamSendState::NotSent
                    && self.continuation_attempt == ContinuationAttempt::None =>
            {
                self.connection_budget
                    .retry_delay(self.connection_retries, self.request_id.as_str())
                    .map(|delay| {
                        self.connection_retries += 1;
                        (transport, delay)
                    })
            }
            Some(crate::error::PreDeliveryRetry::SameAccountTransportRetry {
                retry_index,
                delay,
            }) if !same_account_retry_blocked
                && !retry_after_exceeds_limit
                && !execution_effect_observed
                && !self.connection_budget.exhausted()
                && !self.replay_barrier_reached
                && !self.delivery_pending =>
            {
                Some((AttemptTransport::Retry(retry_index), delay))
            }
            Some(crate::error::PreDeliveryRetry::SameAccountTransportFallback)
                if !same_account_retry_blocked
                    && !retry_after_exceeds_limit
                    && !execution_effect_observed
                    && !self.connection_budget.exhausted()
                    && !self.replay_barrier_reached
                    && !self.delivery_pending =>
            {
                Some((
                    AttemptTransport::Fallback,
                    error.retry_after().unwrap_or_default(),
                ))
            }
            _ => None,
        };
        let can_rotate_connection = connection_retry_requested
            && self.account_selection.required_account().is_none()
            && self.routing_attempts < self.plan.max_attempts().get()
            && self.account_rotations
                < self.plan.account_selection_policy().max_account_rotations();
        // A 先恢复一次，再利用预留预算重选；重选继续走已有降级传输，避免 WS 抢占最后一次 opening
        let connection_rotation = transport_recovery
            .filter(|_| can_rotate_connection && current.connection_rotation_reserved);
        let reserve_connection_rotation = can_rotate_connection
            && !current.connection_rotation_reserved
            && self.connection_budget.remaining_openings() >= 2;
        let transport_recovery = transport_recovery.filter(|_| connection_rotation.is_none());
        let ordinary_retry = !self.connection_budget.exhausted()
            && !connection_retry_requested
            && !execution_effect_observed
            && self.account_selection.required_account().is_none()
            && self.continuation_attempt == ContinuationAttempt::None
            && !self.replay_barrier_reached
            && !self.delivery_pending
            && attempt_send_state != UpstreamSendState::Ambiguous
            && provider_proved_replay_safe
            && self.routing_attempts < self.plan.max_attempts().get();
        let suppress_transient_retry = is_return_error_retry(&error)
            && self
                .client_retry
                .as_ref()
                .is_some_and(ClientRetryGuard::has_failure);
        let transient_retry = match error.pre_delivery_retry() {
            Some(crate::error::PreDeliveryRetry::SameAccountTransientRetry {
                max_retries,
                initial_delay,
                max_delay,
                jitter,
                ..
            }) if !same_account_retry_blocked
                && ordinary_retry
                && !suppress_transient_retry
                && !retry_after_exceeds_limit =>
            {
                let retries = self
                    .transient_retry_counts
                    .entry(current.metadata.provider_account_id().clone())
                    .or_default();
                if *retries < max_retries.get() {
                    let multiplier = 1_u32.checked_shl(*retries).unwrap_or(u32::MAX);
                    // 服务器建议优先于本地退避，不截断、不放大，也不叠加随机等待
                    let delay = error.retry_after().unwrap_or_else(|| {
                        initial_delay
                            .saturating_mul(multiplier)
                            .min(max_delay)
                            .saturating_add(jitter)
                    });
                    *retries = retries.saturating_add(1);
                    Some(delay)
                } else {
                    None
                }
            }
            _ => None,
        };
        let same_account_retry = !same_account_retry_blocked
            && !execution_effect_observed
            && error.retries_same_account()
            && provider_proved_replay_safe
            && !self.replay_barrier_reached
            && !self.delivery_pending
            && attempt_send_state != UpstreamSendState::Ambiguous
            && self.routing_attempts < self.plan.max_attempts().get()
            && !self
                .credential_recovery_attempted_accounts
                .contains(current.metadata.provider_account_id());
        // 排除当前账号的重选必然换号：ordinary 重选与显式 AccountRotation 标记都落入
        // 同一排除分支。换号预算只在这里消耗；同账号分支（瞬态退避、传输恢复、
        // 凭据恢复重放、continuation 精确重连）不消耗。不能直接把预算门写进
        // ordinary_retry：它是同账号瞬态退避的前置条件，会被连带误伤
        // RetryThenReturnError 耗尽后直接交付错误，不能落入 ordinary_retry 的换号兜底
        let rotation_retry = !continuation_retry
            && !same_account_retry
            && transient_retry.is_none()
            && !is_return_error_retry(&error)
            && transport_recovery.is_none()
            && (ordinary_retry || account_rotation_retry)
            && self.account_rotations
                < self.plan.account_selection_policy().max_account_rotations();
        let retryable = !error.retry_is_prohibited()
            && (continuation_retry
                || same_account_retry
                || transient_retry.is_some()
                || transport_recovery.is_some()
                || connection_rotation.is_some()
                || rotation_retry);

        let policy = self.apply_retry_policy(super::policy::RetryFacts {
            attempt_index: current.index,
            provider: current.metadata.provider().clone(),
            model: current
                .metadata
                .upstream_model()
                .map(|model| model.as_str().to_owned()),
            error_kind: error.kind(),
            upstream_status: error.upstream_status(),
            send_state: attempt_send_state,
            remaining_routing_attempts: self
                .plan
                .max_attempts()
                .get()
                .saturating_sub(self.routing_attempts),
            remaining_deadline: Duration::ZERO,
            retry_allowed: retryable,
        });
        let trace = json!({
            "phase": "execute",
            "retryable": retryable, "continuationRetry": continuation_retry,
            "sameAccountRetry": same_account_retry, "accountRotationRetry": account_rotation_retry,
            "ordinaryRetry": ordinary_retry, "transportRecovery": transport_recovery.is_some(),
            "connectionRotation": connection_rotation.is_some(),
            "reserveConnectionRotation": reserve_connection_rotation,
            "transientRetry": transient_retry.is_some(),
            "retryAfterExceeded": retry_after_exceeds_limit,
            "sameAccountRetryBlocked": same_account_retry_blocked,
            "maxRetryAfterSeconds": self.plan.max_retry_after().as_secs(),
            "clientRetrySuppressed": suppress_transient_retry,
            "rotationRetry": rotation_retry, "accountRotations": self.account_rotations,
            "connectionRetry": connection_retry_requested,
            "connectionRetries": self.connection_retries,
            "connectionBudgetRemainingMs": self.connection_budget.remaining().map(duration_ms),
            "executionEffectObserved": execution_effect_observed,
            "delayMs": transient_retry.or(transport_recovery.map(|(_, delay)| delay)).map(duration_ms),
            "downstreamCommitted": self.response_commit.committed_at().is_some(),
            "replayBarrierReached": self.replay_barrier_reached,
            "deliveryPending": self.delivery_pending,
            "providerProvedReplaySafe": provider_proved_replay_safe,
            "retryProhibited": error.retry_is_prohibited(),
            "requiredAccount": self.account_selection.required_account().map(|account| account.as_str()),
            "continuation": format!("{:?}", self.continuation_attempt),
            "connectionBudgetExhausted": self.connection_budget.exhausted(),
            "remainingRoutingAttempts": self.plan.max_attempts().get().saturating_sub(self.routing_attempts),
            "maxAccountRotations": self.plan.account_selection_policy().max_account_rotations(),
            "transientRetriesUsed": self.transient_retry_counts.get(current.metadata.provider_account_id()).copied().unwrap_or_default(),
            "credentialRecoveryAttempted": self.credential_recovery_attempted_accounts.contains(current.metadata.provider_account_id()),
            "hasRetryPolicy": self.request_policy.is_some(),
            "sendState": format!("{attempt_send_state:?}"),
        });
        let retry = if same_account_retry {
            StreamRetry::SameAccount
        } else if let Some(delay) = transient_retry {
            StreamRetry::Pending(PendingAttemptRetry {
                account: current.metadata.provider_account_id().clone(),
                transport: current.transport,
                delay,
                transport_recovery: false,
                reserve_connection_rotation: false,
            })
        } else if let Some((transport, delay)) = transport_recovery {
            StreamRetry::Pending(PendingAttemptRetry {
                account: current.metadata.provider_account_id().clone(),
                transport,
                delay,
                transport_recovery: true,
                reserve_connection_rotation,
            })
        } else if let Some((transport, delay)) = connection_rotation {
            StreamRetry::ConnectionRotation(PendingAttemptRetry {
                account: current.metadata.provider_account_id().clone(),
                transport,
                delay,
                transport_recovery: true,
                reserve_connection_rotation: false,
            })
        } else if continuation_retry {
            StreamRetry::Continuation
        } else {
            StreamRetry::ExcludeAccount
        };
        let intermediate = self.request_persisted.then(|| {
            let error = error.stable_snapshot();
            IntermediateFailure {
                account_snapshot: current.metadata.account_snapshot().cloned(),
                request_id: self.request_id.clone(),
                attempt_index: current.index,
                trigger: current.trigger,
                provider_kind: current.metadata.provider().clone(),
                account_id: Some(current.metadata.provider_account_id().clone()),
                upstream_model_id: current.metadata.upstream_model().cloned(),
                upstream_status_code: error.upstream_status().or_else(|| {
                    current
                        .response_observation
                        .as_ref()
                        .and_then(ProviderResponseObservation::status_code)
                }),
                upstream_request_id: error
                    .upstream_request_id()
                    .map(|id| id.as_str())
                    .or_else(|| current.upstream_request_id())
                    .map(str::to_owned),
                latency: current.started_at.elapsed().unwrap_or_default(),
                error,
            }
        });
        let store = Arc::clone(self.engine.store());
        let request_id = self.request_id.clone();
        let persisted = self.request_persisted;
        // 错误、账号 lease 与决策 future 都跨 next_event 的取消保留
        // 在持久化及策略回调完成前，不能再次拉流或建立新的 attempt
        self.current = Some(current);
        self.pending_stream_failure = Some(PendingStreamFailure {
            completion: StreamFailureDecision::Pending(Box::pin(async move {
                if persisted {
                    best_effort_store_write(
                        "mark_send_state",
                        &request_id,
                        store.mark_send_state(&request_id, send_state),
                    )
                    .await;
                }
                let retryable = policy.await?;
                if retryable && let Some(intermediate) = intermediate {
                    best_effort_store_write(
                        "record_intermediate_failure",
                        &request_id,
                        store.record_intermediate_failure(intermediate),
                    )
                    .await;
                }
                Ok(retryable)
            })),
            error,
            events: atomic_client_events,
            send_state,
            retry,
            trace,
        });
        Ok(())
    }

    async fn resume_stream_failure(&mut self) -> Result<PullOutcome, EngineError> {
        let pending = self
            .pending_stream_failure
            .as_mut()
            .ok_or(EngineError::NoActiveAttempt)?;
        if let StreamFailureDecision::Pending(completion) = &mut pending.completion {
            pending.completion = match completion.as_mut().await {
                Ok(retryable) => StreamFailureDecision::Retry(retryable),
                Err(error) => StreamFailureDecision::Interrupted(Arc::new(error)),
            };
        }
        if let StreamFailureDecision::Interrupted(error) = &pending.completion {
            let error = Arc::clone(error);
            self.finish_interruption(&error).await?;
            self.pending_stream_failure.take();
            return Err(Arc::try_unwrap(error).expect("interruption is owned by the session"));
        }
        let mut pending = self
            .pending_stream_failure
            .take()
            .ok_or(EngineError::NoActiveAttempt)?;
        let StreamFailureDecision::Retry(retryable) = pending.completion else {
            unreachable!("completed stream failure has a retry decision");
        };
        pending.trace["retryable"] = json!(retryable);
        self.trace
            .attempt(self.attempts)
            .record("retry.decided", pending.trace);
        if retryable {
            let current = self.current.take().ok_or(EngineError::NoActiveAttempt)?;
            match pending.retry {
                StreamRetry::SameAccount => {
                    let account = current.metadata.provider_account_id().clone();
                    self.credential_recovery_attempted_accounts
                        .insert(account.clone());
                    self.recovery_account = Some(account);
                }
                StreamRetry::Pending(retry) => self.pending_retry = Some(retry),
                StreamRetry::ConnectionRotation(retry) => {
                    self.excluded_accounts.insert(retry.account.clone());
                    self.connection_rotation = Some(retry);
                }
                StreamRetry::ExcludeAccount => {
                    self.excluded_accounts
                        .insert(current.metadata.provider_account_id().clone());
                }
                StreamRetry::Continuation => {}
            }
            self.last_retryable_failure_events = pending.events;
            self.last_retryable_failure = Some(pending.error);
            self.reset_uncommitted_observations();
            return Ok(PullOutcome::AttemptDiscarded);
        }
        if !pending.events.is_empty() {
            for event in &mut pending.events {
                let _ = event.take_observation();
            }
            return Ok(PullOutcome::TerminalFailure {
                events: pending.events,
                error: pending.error,
                send_state: pending.send_state,
            });
        }
        self.pending_terminal_failure = Some(PendingTerminalFailure {
            error: Arc::new(pending.error),
            send_state: pending.send_state,
            events: Vec::new(),
        });
        Err(provider_engine_error(
            self.finalize_pending_terminal_failure().await?,
        ))
    }

    async fn next_terminal_failure(&mut self) -> Result<Option<CoordinatedEvent>, EngineError> {
        let pending = self
            .pending_terminal_failure
            .as_ref()
            .ok_or(EngineError::NoActiveAttempt)?;
        if pending.events.is_empty() {
            return Err(provider_engine_error(
                self.finalize_pending_terminal_failure().await?,
            ));
        }
        let error = Arc::clone(&pending.error);
        self.record_client_retry_failure(&error).await;
        let pending = self
            .pending_terminal_failure
            .as_mut()
            .ok_or(EngineError::NoActiveAttempt)?;
        let events = std::mem::take(&mut pending.events);
        let requirement = if self.delivery_committed {
            CommitRequirement::AlreadyCommitted
        } else {
            self.delivery_pending = true;
            CommitRequirement::CommitBeforeDelivery
        };
        self.replay_barrier_reached = true;
        CoordinatedEvent::try_batch(events, requirement).map(Some)
    }

    async fn finalize_pending_terminal_failure(&mut self) -> Result<ProviderError, EngineError> {
        let pending = self
            .pending_terminal_failure
            .as_ref()
            .ok_or(EngineError::NoActiveAttempt)?;
        let error = Arc::clone(&pending.error);
        let send_state = pending.send_state;
        self.finish_provider_error_with_send_state(&error, send_state)
            .await?;
        drop(error);
        let pending = self
            .pending_terminal_failure
            .take()
            .ok_or(EngineError::NoActiveAttempt)?;
        Ok(Arc::try_unwrap(pending.error).expect("terminal failure is owned by the session"))
    }

    fn apply_retry_policy(
        &self,
        mut facts: super::policy::RetryFacts,
    ) -> BoxFuture<'static, Result<bool, EngineError>> {
        let policy = self.request_policy.clone();
        let deadline = self.deadline;
        let cancellation = self.cancellation.clone();
        let effects = self.execution_effects.clone();
        let baseline = self.execution_effects_baseline;
        let trace = self.trace.clone();
        Box::pin(async move {
            let Some(policy) = policy else {
                return Ok(facts.retry_allowed);
            };
            let effect_observed = || {
                effects
                    .as_ref()
                    .is_some_and(|effects| effects.epoch() != baseline)
            };
            facts.remaining_deadline = deadline.remaining().unwrap_or(Duration::MAX);
            facts.retry_allowed &= !facts.remaining_deadline.is_zero()
                && !cancellation.is_cancelled()
                && !effect_observed();
            let allowed = facts.retry_allowed;
            let attempt_index = facts.attempt_index;
            let decision = {
                let cancelled = cancellation.cancelled().fuse();
                let decision = policy.retry_decision(facts).fuse();
                let mut deadline_timer = deadline.wait().fuse();
                pin_mut!(cancelled, decision);
                select_biased! {
                    () = cancelled => Err(EngineError::Cancelled),
                    () = deadline_timer => Err(EngineError::Deadline),
                    decision = decision => Ok(decision),
                }
            }?;
            trace.attempt(attempt_index.get()).record(
                "retry.policy",
                json!({
                    "hostAllowed": allowed,
                    "policyStopped": decision == super::policy::RetryDecision::Stop,
                    "executionEffectObserved": effect_observed(),
                    "cancelled": cancellation.is_cancelled(),
                    "deadlineElapsed": deadline.is_elapsed(),
                }),
            );
            // 策略只收窄宿主已允许的恢复，返回后仍复核期限和外部副作用
            Ok(allowed
                && decision != super::policy::RetryDecision::Stop
                && !effect_observed()
                && !cancellation.is_cancelled()
                && !deadline.is_elapsed())
        })
    }

    fn observe_atomic_terminal_events(&mut self, events: &mut [ProviderEvent]) {
        for event in events {
            if let Some(observation) = event.take_observation() {
                self.observe_response(observation);
            }
            for fact in event.canonical_facts() {
                self.observation.observe_identity(fact);
                self.observation.observe_event(fact);
            }
        }
    }

    fn observe_websocket_response(
        &mut self,
        event: &ProviderEvent,
        attempt: Option<WebSocketResponseAttempt>,
    ) {
        let Some(observer) = self.request_observation.clone() else {
            return;
        };
        let Some(wire) = event.wire_event().cloned() else {
            return;
        };
        let Some(attempt) = attempt else {
            return;
        };
        self.websocket_observation_sequence = self.websocket_observation_sequence.saturating_add(1);
        observer.websocket_response(attempt, self.websocket_observation_sequence, wire);
    }

    fn prepare_continuation_retry(
        &mut self,
        current: &CurrentAttempt,
        error: &ProviderError,
        send_state: UpstreamSendState,
        provider_proved_replay_safe: bool,
    ) -> bool {
        if self.account_selection.required_account().is_some()
            || self.continuation_attempt == ContinuationAttempt::None
            || self.replay_barrier_reached
            || self.delivery_pending
            || send_state == UpstreamSendState::Ambiguous
            || !provider_proved_replay_safe
            || self.routing_attempts >= self.plan.max_attempts().get()
            || self
                .operation
                .provider_session_state(current.metadata.provider().as_str())
                .is_none()
        {
            return false;
        }

        match self.continuation_attempt {
            ContinuationAttempt::Native => match error.continuation_recovery_disposition() {
                Some(ContinuationRecoveryDisposition::RetryExactConnection) => {
                    self.recovery_account = Some(current.metadata.provider_account_id().clone());
                }
                Some(ContinuationRecoveryDisposition::ProviderReplayAllowed) => {
                    self.continuation_attempt = ContinuationAttempt::ReplayOwner;
                }
                Some(ContinuationRecoveryDisposition::ClientReplayRequired) | None => return false,
            },
            ContinuationAttempt::ReplayOwner | ContinuationAttempt::ReplayAny
                if matches!(
                    error.continuation_recovery_disposition(),
                    Some(
                        ContinuationRecoveryDisposition::RetryExactConnection
                            | ContinuationRecoveryDisposition::ClientReplayRequired
                    )
                ) =>
            {
                return false;
            }
            // 两个排除臂都必然换号；预算耗尽后不再排除当前账号做跨账号续写重放，
            // 落回不可重试路径以原始上游错误终态。
            ContinuationAttempt::ReplayOwner | ContinuationAttempt::ReplayAny
                if self.account_rotations
                    >= self.plan.account_selection_policy().max_account_rotations() =>
            {
                return false;
            }
            ContinuationAttempt::ReplayOwner => {
                self.continuation_attempt = ContinuationAttempt::ReplayAny;
                self.excluded_accounts
                    .insert(current.metadata.provider_account_id().clone());
            }
            ContinuationAttempt::ReplayAny => {
                self.excluded_accounts
                    .insert(current.metadata.provider_account_id().clone());
            }
            ContinuationAttempt::None => return false,
        }
        true
    }

    /// 原生续写的原账号在本地调度阶段已不可用时，交给 Provider 执行跨账号恢复
    ///
    /// 这不是强制 Smart：下一次 attempt 仍使用请求配置的调度策略
    /// 只有网关持有
    /// 对应 Provider 的会话状态时才进入恢复；是否保留 native handle、执行 probe
    /// 或使用完整 transcript，由 Provider 自己的协议边界决定
    fn prepare_unavailable_native_continuation_replay(&mut self, error: &ProviderError) -> bool {
        if self.account_selection.required_account().is_some()
            || self.continuation_attempt != ContinuationAttempt::Native
            || self.current_send_state() != UpstreamSendState::NotSent
            || !matches!(
                error.kind(),
                ProviderErrorKind::NoEligibleAccount
                    | ProviderErrorKind::AccountCapacityUnavailable
                    | ProviderErrorKind::QuotaExhausted
            )
        {
            return false;
        }
        let Some(pin) = self
            .continuation
            .as_ref()
            .and_then(ContinuationBinding::pinned)
        else {
            return false;
        };
        if self
            .operation
            .provider_session_state(pin.provider().as_str())
            .is_none()
        {
            return false;
        }
        // Native 期间仍可能配置为禁止换号，跨账号重放共用请求冻结的预算
        if self.account_rotations >= self.plan.account_selection_policy().max_account_rotations() {
            return false;
        }

        self.continuation_attempt = ContinuationAttempt::ReplayAny;
        self.excluded_accounts.insert(pin.account().clone());
        true
    }

    fn reset_uncommitted_observations(&mut self) {
        // 响应观测按尝试隔离；被丢弃尝试中已取得的费用仍计入 Key
        self.budget_prior_attempts_usd = self
            .budget_prior_attempts_usd
            .checked_add(self.budget_attempt_usd())
            .unwrap_or(Decimal::MAX);
        self.budget_attempt_already_counted = false;
        self.observation.reset_for_attempt();
        self.upstream_complete = false;
    }

    async fn finish_success(&mut self) -> Result<(), EngineError> {
        if self.is_finalized() {
            return Ok(());
        }
        if let Some(guard) = &mut self.client_retry {
            guard.success().await;
        }
        let completed_at = SystemTime::now();
        self.observation.finish();
        let upstream_request_id = self
            .current
            .as_ref()
            .and_then(CurrentAttempt::upstream_request_id)
            .map(str::to_owned);
        let upstream_status_code = self
            .current
            .as_ref()
            .and_then(|current| current.response_observation.as_ref())
            .and_then(ProviderResponseObservation::status_code);
        let (upstream_transport, http_version, websocket_pool) =
            self.current_transport_observation();
        let service_tier = self.current_service_tier();
        let provider_metadata_json = self.current_provider_metadata_json();
        self.record_final_usage();
        self.trace.record(
            "request.finished",
            json!({"outcome": "succeeded", "attempts": self.attempts}),
        );
        self.persist_finalization(ModelRequestFinalization {
            request_id: self.request_id.clone(),
            outcome: ExecutionOutcome::Succeeded,
            send_state: UpstreamSendState::Sent,
            attempt_count: self.attempts,
            downstream_committed_at: self.response_commit.committed_at(),
            client_status_code: self
                .response_commit
                .status_code()
                .or(self.client_status_code),
            upstream_status_code,
            client_response_id: self.observation.client_response_id.clone(),
            upstream_request_id,
            upstream_response_id: self.observation.upstream_response_id.clone(),
            upstream_transport,
            http_version,
            websocket_pool,
            service_tier,
            provider_metadata_json,
            diagnostic_trace_json: self.trace.snapshot().map(|value| value.to_string()),
            error: None,
            provider_error_code: None,
            error_details: None,
            failure_observation: ModelRequestFailureObservation::default(),
            retry_after_ms: None,
            usage: self.observation.usage.clone(),
            image_generation_succeeded: self.image_generation_succeeded(),
            cost: self.observation.cost.clone(),
            timings: self.observation.timings.clone(),
            completed_at,
        })
        .await;
        Ok(())
    }

    async fn finish_provider_error(&mut self, error: &ProviderError) -> Result<(), EngineError> {
        self.finish_provider_error_with_send_state(
            error,
            escalate_send_state(self.current_send_state(), error.send_state()),
        )
        .await
    }

    async fn finish_provider_error_with_send_state(
        &mut self,
        error: &ProviderError,
        send_state: UpstreamSendState,
    ) -> Result<(), EngineError> {
        self.record_client_retry_failure(error).await;
        let send_state = self.raise_send_watermark(send_state);
        let outcome = if error.kind() == ProviderErrorKind::Cancelled {
            ExecutionOutcome::Cancelled
        } else if self.response_commit.committed_at().is_some() {
            ExecutionOutcome::Incomplete
        } else {
            ExecutionOutcome::Failed
        };
        self.finish_failure(FailureFinalization {
            outcome,
            send_state,
            error: GatewayError::from_provider(error),
            upstream_status_code: error.upstream_status(),
            upstream_request_id: error.upstream_request_id().map(|id| id.as_str().to_owned()),
            provider_error_code: error.upstream_code().map(|code| code.as_str().to_owned()),
            error_details: error.error_details(),
            retry_after_ms: error.retry_after().map(duration_ms),
            observation: ModelRequestFailureObservation {
                continuation_unavailable_reason: error
                    .continuation_unavailable_reason()
                    .map(str::to_owned),
                upstream_connection: error.connection_observation().cloned(),
            },
        })
        .await
    }

    async fn record_client_retry_failure(&mut self, error: &ProviderError) {
        // 只记录本策略的终态失败，不让其他错误改变客户端轮次的退避预算
        if self.attempts > 0
            && is_return_error_retry(error)
            && let Some(guard) = &mut self.client_retry
        {
            guard.failure().await;
        }
    }

    async fn finish_interruption(&mut self, error: &EngineError) -> Result<(), EngineError> {
        // 结算 I/O 可能继续等待，先冻结交付事实以保持终态与实际 HTTP 状态一致
        self.response_commit.finish();
        let (outcome, gateway_error) = match error {
            EngineError::Cancelled => (
                ExecutionOutcome::Cancelled,
                GatewayError::new(
                    GatewayErrorKind::Cancelled,
                    self.cancellation
                        .reason()
                        .unwrap_or(crate::lifecycle::CancellationReason::Requested)
                        .message(),
                ),
            ),
            EngineError::Deadline => (
                if self.response_commit.committed_at().is_some() {
                    ExecutionOutcome::Incomplete
                } else {
                    ExecutionOutcome::Failed
                },
                GatewayError::new(GatewayErrorKind::Timeout, "Request deadline elapsed."),
            ),
            _ => (
                ExecutionOutcome::Failed,
                GatewayError::new(GatewayErrorKind::Internal, "Request execution failed."),
            ),
        };
        let send_state = if self.attempts == 0 {
            UpstreamSendState::NotSent
        } else if self.delivery_committed
            || self
                .current
                .as_ref()
                .is_some_and(|current| current.send_observed)
        {
            UpstreamSendState::Sent
        } else {
            UpstreamSendState::Ambiguous
        };
        let send_state = self.raise_send_watermark(send_state);
        if self.attempts > 0 && self.request_persisted {
            best_effort_store_write(
                "mark_send_state",
                &self.request_id,
                self.engine
                    .store()
                    .mark_send_state(&self.request_id, send_state),
            )
            .await;
        }
        self.finish_failure(FailureFinalization {
            outcome,
            send_state,
            error: gateway_error,
            upstream_status_code: None,
            upstream_request_id: None,
            provider_error_code: None,
            error_details: None,
            retry_after_ms: None,
            observation: ModelRequestFailureObservation::default(),
        })
        .await
    }

    async fn finish_failure(
        &mut self,
        finalization: FailureFinalization,
    ) -> Result<(), EngineError> {
        if self.is_finalized() {
            return Ok(());
        }
        self.record_final_usage();
        self.trace.record(
            "request.finished",
            json!({
                "outcome": format!("{:?}", finalization.outcome),
                "errorKind": finalization.error.kind().as_str(),
                "sendState": format!("{:?}", finalization.send_state), "attempts": self.attempts,
            }),
        );
        let completed_at = SystemTime::now();
        self.observation.finish();
        let upstream_request_id = self
            .current
            .as_ref()
            .and_then(CurrentAttempt::upstream_request_id)
            .map(str::to_owned);
        let observed_status_code = self
            .current
            .as_ref()
            .and_then(|current| current.response_observation.as_ref())
            .and_then(ProviderResponseObservation::status_code);
        let (upstream_transport, http_version, websocket_pool) =
            self.current_transport_observation();
        let service_tier = self.current_service_tier();
        let provider_metadata_json = self.current_provider_metadata_json();
        self.persist_finalization(ModelRequestFinalization {
            request_id: self.request_id.clone(),
            outcome: finalization.outcome,
            send_state: finalization.send_state,
            attempt_count: self.attempts,
            downstream_committed_at: self.response_commit.committed_at(),
            client_status_code: self
                .response_commit
                .status_code()
                .or(self.client_status_code),
            upstream_status_code: finalization.upstream_status_code.or(observed_status_code),
            client_response_id: self.observation.client_response_id.clone(),
            upstream_request_id: finalization.upstream_request_id.or(upstream_request_id),
            upstream_response_id: self.observation.upstream_response_id.clone(),
            upstream_transport,
            http_version,
            websocket_pool,
            service_tier,
            provider_metadata_json,
            diagnostic_trace_json: self.trace.snapshot().map(|value| value.to_string()),
            error: Some(finalization.error),
            provider_error_code: finalization.provider_error_code,
            error_details: finalization.error_details,
            failure_observation: finalization.observation,
            retry_after_ms: finalization.retry_after_ms,
            usage: self.observation.usage.clone(),
            image_generation_succeeded: self.image_generation_succeeded(),
            cost: self.observation.cost.clone(),
            timings: self.observation.timings.clone(),
            completed_at,
        })
        .await;
        Ok(())
    }

    async fn persist_finalization(&mut self, finalization: ModelRequestFinalization) {
        self.response_commit.finish();
        self.finalized_at = Some(finalization.completed_at);
        let observed_provider = self
            .current
            .as_ref()
            .map(|current| current.metadata.provider().clone())
            .or_else(|| self.last_observed_provider.clone());
        let observer = self.request_observation.clone();
        let observation = observer.as_ref().map(|observer| {
            observer.finalization(
                &finalization,
                observed_provider,
                self.current.as_ref().map(|current| &current.metadata),
            )
        });
        let mut persisted = self.request_persisted;
        // 首次合并写失败后不能以零 attempt 补行；建流前也只有确定未发送的请求可按零次收敛
        let request = if !persisted
            && finalization.attempt_count == 0
            && finalization.send_state == UpstreamSendState::NotSent
        {
            self.pending_request.take()
        } else {
            None
        };
        let store = Arc::clone(self.engine.store());
        let request_id = self.request_id.clone();
        // 终态写入由会话持有；取消事件等待只暂停同一个 future，不重建请求或覆盖原失败
        self.finalization = Some(RequestFinalization::Pending(Box::pin(async move {
            if let Some(request) = request {
                persisted = best_effort_store_write(
                    "create_model_request",
                    &request_id,
                    store.create_model_request(request),
                )
                .await
                .is_some();
            }
            if persisted {
                best_effort_store_write(
                    "finalize_model_request",
                    &request_id,
                    store.finalize_model_request(finalization),
                )
                .await;
            }
            if let (Some(observer), Some(observation)) = (observer, observation) {
                observer.dispatch(observation);
            }
            persisted
        })));
        self.resume_finalization().await;
    }

    async fn resume_finalization(&mut self) {
        if let Some(RequestFinalization::Pending(write)) = self.finalization.as_mut() {
            self.request_persisted = write.await;
            self.finalization = Some(RequestFinalization::Complete);
            self.lease.take();
        }
    }

    fn current_transport_observation(&self) -> (Option<String>, Option<String>, Option<String>) {
        let Some(current) = self.current.as_ref() else {
            return (None, None, None);
        };
        let Some(observation) = current.response_observation.as_ref() else {
            return (None, None, None);
        };
        (
            Some(observation.transport().as_str().to_owned()),
            observation
                .http_version()
                .map(|version| version.as_str().to_owned()),
            observation
                .websocket_pool()
                .map(|kind| kind.as_str().to_owned()),
        )
    }

    fn current_provider_metadata_json(&self) -> Option<String> {
        self.current
            .as_ref()
            .and_then(|current| current.response_observation.as_ref())
            .and_then(ProviderResponseObservation::provider_metadata)
            .map(|metadata| metadata.as_json().to_owned())
    }

    fn current_service_tier(&self) -> Option<String> {
        self.current
            .as_ref()
            .and_then(|current| current.response_observation.as_ref())
            .and_then(ProviderResponseObservation::service_tier)
            .map(str::to_owned)
    }

    fn image_generation_succeeded(&self) -> Option<bool> {
        self.image_generation_requested.then(|| {
            if matches!(self.operation, Operation::GenerateImage(_)) {
                self.upstream_complete
            } else {
                self.observation
                    .usage
                    .image_output_tokens
                    .unwrap_or_default()
                    > 0
            }
        })
    }

    fn current_send_state(&self) -> UpstreamSendState {
        let observed = if self
            .current
            .as_ref()
            .is_some_and(|current| current.send_observed)
        {
            UpstreamSendState::Sent
        } else {
            UpstreamSendState::NotSent
        };
        let observed = if self.execution_effect_observed() {
            escalate_send_state(observed, UpstreamSendState::Ambiguous)
        } else {
            observed
        };
        escalate_send_state(self.send_state_watermark, observed)
    }

    fn execution_effect_observed(&self) -> bool {
        self.execution_effects
            .as_ref()
            .is_some_and(|effects| effects.epoch() != self.execution_effects_baseline)
    }

    /// 抬升并返回请求级发送水位；attempt 间切换（`current` 被取走）后，
    /// 后续终态沿用已达到的最高档，不会把已落库的 `sent` 写回 `not_sent`
    fn raise_send_watermark(&mut self, observed: UpstreamSendState) -> UpstreamSendState {
        let observed = escalate_send_state(self.current_send_state(), observed);
        self.send_state_watermark = observed;
        self.send_state_watermark
    }

    fn record_final_usage(&self) {
        if !self.trace.is_enabled() {
            return;
        }
        let usage = &self.observation.usage;
        let mut facts = json!({
            "inputTokens": usage.input_tokens,
            "outputTokens": usage.output_tokens,
            "cachedInputTokens": usage.cached_input_tokens,
            "cacheWriteInputTokens": usage.cache_write_input_tokens,
            "reasoningOutputTokens": usage.reasoning_output_tokens,
            "imageInputTokens": usage.image_input_tokens,
            "imageOutputTokens": usage.image_output_tokens,
            "totalTokens": usage.total_tokens,
        });
        facts["boundary"] = json!("finalization_prepared");
        facts["costSource"] = json!(self.observation.cost.source().as_str());
        facts["downstreamCommitted"] = json!(self.delivery_committed);
        self.trace
            .attempt(self.attempts)
            .record_evidence("request.usage", facts);
    }

    fn record_current_provider_success(&mut self) {
        let provider_kind = self
            .current
            .as_ref()
            .map(|current| current.metadata.provider().clone());
        if let Some(provider_kind) = provider_kind {
            self.last_observed_provider = Some(provider_kind);
        }
    }

    fn record_provider_failure(&mut self, provider_kind: crate::identity::ProviderKind) {
        self.last_observed_provider = Some(provider_kind);
    }
}

fn is_return_error_retry(error: &ProviderError) -> bool {
    matches!(
        error.pre_delivery_retry(),
        Some(crate::error::PreDeliveryRetry::SameAccountTransientRetry {
            policy: crate::error::TransientRetryPolicy::RetryThenReturnError,
            ..
        })
    )
}

async fn best_effort_store_write<T>(
    operation: &'static str,
    request_id: &ModelRequestId,
    write: impl Future<Output = Result<T, StoreError>>,
) -> Option<T> {
    match write.await {
        Ok(value) => Some(value),
        Err(error) => {
            tracing::warn!(
                operation,
                request_id = request_id.as_str(),
                error_kind = ?error.kind(),
                "执行观测写入失败，数据面不受影响"
            );
            None
        }
    }
}

enum PullOutcome {
    Events(Vec<ProviderEvent>),
    AttemptDiscarded,
    TerminalFailure {
        events: Vec<ProviderEvent>,
        error: ProviderError,
        send_state: UpstreamSendState,
    },
    End,
}

enum PollBoundary {
    Item(Option<Result<ProviderEvent, ProviderError>>),
    Cancelled,
    Deadline,
}

async fn poll_stream_item(
    stream: &mut ProviderStream,
    cancellation: CancellationToken,
    deadline: Deadline,
    mut deadline_timer: &mut Fuse<BoxFuture<'static, ()>>,
) -> PollBoundary {
    if deadline.is_elapsed() {
        return PollBoundary::Deadline;
    }
    let next = stream.next().fuse();
    let cancelled = cancellation.cancelled().fuse();
    pin_mut!(next, cancelled);
    select_biased! {
        _ = cancelled => PollBoundary::Cancelled,
        _ = deadline_timer => PollBoundary::Deadline,
        item = next => PollBoundary::Item(item),
    }
}

enum ProviderBoundary {
    Result(Box<Result<ProviderStream, ProviderError>>),
    Cancelled,
    Deadline,
}

enum RetryDelayBoundary {
    Elapsed,
    Cancelled,
    Deadline,
}

async fn poll_retry_delay(
    delay: Duration,
    cancellation: CancellationToken,
    deadline: Deadline,
) -> RetryDelayBoundary {
    if deadline.is_elapsed() {
        return RetryDelayBoundary::Deadline;
    }
    let retry_delay = Delay::new(delay).fuse();
    let cancelled = cancellation.cancelled().fuse();
    let timeout = deadline.wait().fuse();
    pin_mut!(retry_delay, cancelled, timeout);
    select_biased! {
        _ = cancelled => RetryDelayBoundary::Cancelled,
        _ = timeout => RetryDelayBoundary::Deadline,
        _ = retry_delay => RetryDelayBoundary::Elapsed,
    }
}

async fn poll_provider(
    provider: Arc<dyn Provider>,
    request: ProviderRequest,
    context: AttemptContext,
    cancellation: CancellationToken,
    deadline: Deadline,
) -> ProviderBoundary {
    if deadline.is_elapsed() {
        return ProviderBoundary::Deadline;
    }
    let execution = provider.execute(request, context).fuse();
    let cancelled = cancellation.cancelled().fuse();
    let timeout = deadline.wait().fuse();
    pin_mut!(execution, cancelled, timeout);
    select_biased! {
        _ = cancelled => ProviderBoundary::Cancelled,
        _ = timeout => ProviderBoundary::Deadline,
        result = execution => ProviderBoundary::Result(Box::new(result)),
    }
}

fn websocket_observation_attempt(current: &CurrentAttempt) -> Option<WebSocketResponseAttempt> {
    (current.metadata.transport().as_str() == "websocket").then(|| {
        WebSocketResponseAttempt::new(
            current.metadata.provider().clone(),
            current.metadata.provider_account_id().clone(),
            current.index,
        )
    })
}

fn initial_continuation_attempt(
    operation: &Operation,
    plan: &RoutingPlan,
    continuation: Option<&ContinuationBinding>,
) -> ContinuationAttempt {
    match continuation {
        None => ContinuationAttempt::None,
        Some(ContinuationBinding::External(_))
            if plan.candidates().first().is_some_and(|candidate| {
                operation
                    .provider_session_state(candidate.provider().as_str())
                    .is_some()
            }) =>
        {
            ContinuationAttempt::ReplayAny
        }
        Some(_) => ContinuationAttempt::Native,
    }
}

fn provider_engine_error(error: ProviderError) -> EngineError {
    if error.kind() == ProviderErrorKind::Cancelled {
        EngineError::Cancelled
    } else {
        EngineError::Provider(error)
    }
}

fn provider_proved_replay_safe(error: &ProviderError) -> bool {
    error.send_state() == UpstreamSendState::NotSent
        || (error.send_state() != UpstreamSendState::Ambiguous && error.replay_is_safe())
}

/// 发送状态合并档位：`Sent` > `Ambiguous` > `NotSent`
/// 只要任一 attempt 达到过高档，请求整体就不允许回落到低档
const fn escalate_send_state(a: UpstreamSendState, b: UpstreamSendState) -> UpstreamSendState {
    match (a, b) {
        (UpstreamSendState::Sent, _) | (_, UpstreamSendState::Sent) => UpstreamSendState::Sent,
        (UpstreamSendState::Ambiguous, _) | (_, UpstreamSendState::Ambiguous) => {
            UpstreamSendState::Ambiguous
        }
        (UpstreamSendState::NotSent, UpstreamSendState::NotSent) => UpstreamSendState::NotSent,
    }
}

fn duration_ms(duration: Duration) -> u64 {
    u64::try_from(duration.as_millis()).unwrap_or(u64::MAX)
}
